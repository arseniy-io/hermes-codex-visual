/*! Hermes Codex Visual

MIT License

Copyright (c) 2026 arseniy-io

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Tabler Icons

MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// source/dom-changes.js
function movedElementMatches(record, selector) {
  for (const nodes of [record.addedNodes, record.removedNodes]) {
    for (const node3 of nodes) {
      if (node3 instanceof Element && (node3.matches(selector) || node3.querySelector(selector))) return true;
    }
  }
  return false;
}

// source/style-scope.js
var scopes = /* @__PURE__ */ new WeakMap();
var hiddenPane = "[data-pane-hidden], [hidden]";
var chatTab = '[data-zone-tabstrip="grp-main"] [role="tab"][data-tree-tab^="session-tile:"]';
var visibleChatTab = `${chatTab}:not(:is(${hiddenPane}) *)`;
var chatStyles = {
  surface: '[data-chat-surface], [data-slot="composer-surface"]',
  retainAcrossChatTabs: true
};
function registerStyleScope(ctx, theme2) {
  const root = document.documentElement;
  const entries = [];
  let watched = "";
  let queued = false;
  let disposed = false;
  function update() {
    queued = false;
    if (disposed) return;
    const enabled = root.dataset.hermesTheme === theme2;
    const [route, query] = location.hash.slice(2).split("?", 2);
    const screen = route.split("/")[0];
    const tab = screen === "settings" ? new URLSearchParams(query).get("tab") : null;
    const surfaces = /* @__PURE__ */ new Map();
    const pending = /* @__PURE__ */ new Set();
    let hasChatTabs;
    for (const { sheet, anchor, screens, tabs, surface: surface5, visibleSurface, retainAcrossChatTabs } of entries) {
      let visible = enabled && !screens && !surface5;
      if (enabled && screens?.includes(screen) && (!tabs || tabs.includes(tab))) visible = true;
      if (enabled && surface5 && !visible) {
        pending.add(surface5);
        if (retainAcrossChatTabs) {
          pending.add(chatTab);
          if (sheet.isConnected) visible = hasChatTabs ??= Boolean(document.querySelector(visibleChatTab));
        }
        if (!visible) {
          if (!surfaces.has(surface5)) surfaces.set(surface5, Boolean(document.querySelector(visibleSurface)));
          visible = surfaces.get(surface5);
        }
      }
      if (visible && !sheet.isConnected) anchor.after(sheet);
      if (!visible && sheet.isConnected) sheet.remove();
    }
    const next = [...pending].join(", ");
    if (watched !== next) {
      watched = next;
      bodyChanges.disconnect();
      if (watched) bodyChanges.observe(document.body, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["hidden", "data-pane-hidden", "aria-selected"]
      });
    }
  }
  function schedule() {
    if (queued || disposed) return;
    queued = true;
    queueMicrotask(update);
  }
  const bodyChanges = new MutationObserver((records) => {
    if (watched && records.some((record) => {
      if (record.type === "childList") return movedElementMatches(record, watched);
      if (record.attributeName === "aria-selected") return record.target.hasAttribute("data-tree-tab");
      return record.target.matches(watched) || record.target.querySelector(watched);
    })) schedule();
  });
  const themeChanges = new MutationObserver(schedule);
  themeChanges.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.addEventListener(window, "hashchange", schedule);
  ctx.addEventListener(window, "popstate", schedule);
  if (window.navigation) ctx.addEventListener(window.navigation, "currententrychange", schedule);
  scopes.set(ctx, (sheet, conditions) => {
    const anchor = document.createComment("Hermes Codex Visual style");
    document.head.append(anchor);
    const surface5 = conditions?.surface;
    const visibleSurface = surface5 && `:is(${surface5}):not(${hiddenPane}, :is(${hiddenPane}) *)`;
    entries.push({ sheet, anchor, ...conditions, visibleSurface });
    schedule();
  });
  ctx.onDispose(() => {
    disposed = true;
    scopes.delete(ctx);
    themeChanges.disconnect();
    bodyChanges.disconnect();
    for (const { sheet, anchor } of entries) {
      sheet.remove();
      anchor.remove();
    }
  });
}
function mountStyle(ctx, sheet, conditions) {
  scopes.get(ctx)(sheet, conditions);
}
function mountCSS(ctx, marker4, text, conditions) {
  const sheet = document.createElement("style");
  sheet.setAttribute(marker4, "");
  sheet.textContent = text;
  mountStyle(ctx, sheet, conditions);
}

// source/plugin.js
import { THEMES_AREA } from "@hermes/plugin-sdk";

// source/chrome.js
import { createElement as h3, Fragment, useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  host as host5,
  TITLEBAR_AREAS,
  useI18n,
  useTheme
} from "@hermes/plugin-sdk";

// source/codex-reference.js
var glyphs = {
  circle: '<circle cx="12" cy="12" r="9" />',
  circleCheck: '<circle cx="12" cy="12" r="9" /><path d="M9 12l2 2l4 -4" />',
  circleX: '<circle cx="12" cy="12" r="9" /><path d="M10 10l4 4m0 -4l-4 4" />',
  warning: '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"/><path d="M12 8v4"/><path d="M12 16h.01"/>',
  sidebarDisclosure: '<path d="M6 9l6 6l6 -6"/>',
  sidebarWorking: '<path d="M12 3a9 9 0 1 0 9 9"/>',
  messageCopy: '<path d="M7 9.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667l0 -8.666"/><path d="M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1"/>',
  messageEdit: '<path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4"/><path d="M13.5 6.5l4 4"/>',
  messageCopied: '<path d="M5 12l5 5l10 -10"/>',
  laptop: '<path d="M3 19l18 0"/><path d="M5 7a1 1 0 0 1 1 -1h12a1 1 0 0 1 1 1v8a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1l0 -8"/>',
  cloud: '<path d="M6.657 18c-2.572 0 -4.657 -2.007 -4.657 -4.483c0 -2.475 2.085 -4.482 4.657 -4.482c.393 -1.762 1.794 -3.2 3.675 -3.773c1.88 -.572 3.956 -.193 5.444 1c1.488 1.19 2.162 3.007 1.77 4.769h.99c1.913 0 3.464 1.56 3.464 3.486c0 1.927 -1.551 3.487 -3.465 3.487h-11.878"/>',
  branch: '<path d="M5 18a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M5 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M15 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M7 8l0 8"/><path d="M9 18h6a2 2 0 0 0 2 -2v-5"/><path d="M14 14l3 -3l3 3"/>',
  worktree: '<path d="M10 18a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M5 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M15 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M7 8v2a2 2 0 0 0 2 2h6a2 2 0 0 0 2 -2v-2"/><path d="M12 12l0 4"/>',
  queueGrip: '<path d="M8 5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M8 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M8 19a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M14 5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M14 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M14 19a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/>',
  queueEdit: '<path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4"/><path d="M13.5 6.5l4 4"/>',
  queueFollowUp: '<path d="M18 6v6a3 3 0 0 1 -3 3h-10l4 -4m0 8l-4 -4"/>',
  queueSteer: '<path d="M15 11l4 4l-4 4m4 -4h-11a4 4 0 0 1 0 -8h1"/>',
  queueTrash: '<path d="M4 7l16 0"/><path d="M10 11l0 6"/><path d="M14 11l0 6"/><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"/><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"/>',
  queueMore: '<path d="M4 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M18 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/>',
  paw: '<path d="M14.7 13.5c-1.1 -2 -1.441 -2.5 -2.7 -2.5c-1.259 0 -1.736 .755 -2.836 2.747c-.942 1.703 -2.846 1.845 -3.321 3.291c-.097 .265 -.145 .677 -.143 .962c0 1.176 .787 2 1.8 2c1.259 0 3 -1 4.5 -1s3.241 1 4.5 1c1.013 0 1.8 -.823 1.8 -2c0 -.285 -.049 -.697 -.146 -.962c-.475 -1.451 -2.512 -1.835 -3.454 -3.538"/><path d="M20.188 8.082a1.039 1.039 0 0 0 -.406 -.082h-.015c-.735 .012 -1.56 .75 -1.993 1.866c-.519 1.335 -.28 2.7 .538 3.052c.129 .055 .267 .082 .406 .082c.739 0 1.575 -.742 2.011 -1.866c.516 -1.335 .273 -2.7 -.54 -3.052l-.001 0"/><path d="M9.474 9c.055 0 .109 0 .163 -.011c.944 -.128 1.533 -1.346 1.32 -2.722c-.203 -1.297 -1.047 -2.267 -1.932 -2.267c-.055 0 -.109 0 -.163 .011c-.944 .128 -1.533 1.346 -1.32 2.722c.204 1.293 1.048 2.267 1.933 2.267"/><path d="M16.456 6.733c.214 -1.376 -.375 -2.594 -1.32 -2.722a1.164 1.164 0 0 0 -.162 -.011c-.885 0 -1.728 .97 -1.93 2.267c-.214 1.376 .375 2.594 1.32 2.722c.054 .007 .108 .011 .162 .011c.885 0 1.73 -.974 1.93 -2.267"/><path d="M5.69 12.918c.816 -.352 1.054 -1.719 .536 -3.052c-.436 -1.124 -1.271 -1.866 -2.009 -1.866c-.14 0 -.277 .027 -.407 .082c-.816 .352 -1.054 1.719 -.536 3.052c.436 1.124 1.271 1.866 2.009 1.866c.14 0 .277 -.027 .407 -.082"/>',
  bots: '<path d="M6 6a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v4a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2l0 -4"/><path d="M12 2v2"/><path d="M9 12v9"/><path d="M15 12v9"/><path d="M5 16l4 -2"/><path d="M15 14l4 2"/><path d="M9 18h6"/><path d="M10 8v.01"/><path d="M14 8v.01"/>',
  webhook: '<path d="M4.876 13.61a4 4 0 1 0 6.124 3.39h6"/><path d="M15.066 20.502a4 4 0 1 0 1.934 -7.502c-.706 0 -1.424 .179 -2 .5l-3 -5.5"/><path d="M16 8a4 4 0 1 0 -8 0c0 1.506 .77 2.818 2 3.5l-3 5.5"/>',
  graph: '<path d="M10 19a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M18 5a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M10 5a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M6 12a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M18 19a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M14 12a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M22 12a2 2 0 1 0 -4 0a2 2 0 0 0 4 0"/><path d="M6 12h4"/><path d="M14 12h4"/><path d="M15 7l-2 3"/><path d="M9 7l2 3"/><path d="M11 14l-2 3"/><path d="M13 14l2 3"/>',
  chatTab: '<path d="M3 20l1.3 -3.9c-2.324 -3.437 -1.426 -7.872 2.1 -10.374c3.526 -2.501 8.59 -2.296 11.845 .48c3.255 2.777 3.695 7.266 1.029 10.501c-2.666 3.235 -7.615 4.215 -11.574 2.293l-4.7 1"/>',
  openProject: '<path d="M5 19l2.757 -7.351a1 1 0 0 1 .936 -.649h12.307a1 1 0 0 1 .986 1.164l-.996 5.211a2 2 0 0 1 -1.964 1.625h-14.026a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2h4l3 3h7a2 2 0 0 1 2 2v2"/>',
  verified: '<path d="M5 7.2a2.2 2.2 0 0 1 2.2 -2.2h1a2.2 2.2 0 0 0 1.55 -.64l.7 -.7a2.2 2.2 0 0 1 3.12 0l.7 .7c.412 .41 .97 .64 1.55 .64h1a2.2 2.2 0 0 1 2.2 2.2v1c0 .58 .23 1.138 .64 1.55l.7 .7a2.2 2.2 0 0 1 0 3.12l-.7 .7a2.2 2.2 0 0 0 -.64 1.55v1a2.2 2.2 0 0 1 -2.2 2.2h-1a2.2 2.2 0 0 0 -1.55 .64l-.7 .7a2.2 2.2 0 0 1 -3.12 0l-.7 -.7a2.2 2.2 0 0 0 -1.55 -.64h-1a2.2 2.2 0 0 1 -2.2 -2.2v-1a2.2 2.2 0 0 0 -.64 -1.55l-.7 -.7a2.2 2.2 0 0 1 0 -3.12l.7 -.7a2.2 2.2 0 0 0 .64 -1.55v-1"/><path d="M9 12l2 2l4 -4"/>',
  attach: '<path d="M15 7l-6.5 6.5a1.5 1.5 0 0 0 3 3l6.5 -6.5a3 3 0 0 0 -6 -6l-6.5 6.5a4.5 4.5 0 0 0 9 9l6.5 -6.5"/>',
  image: '<path d="M15 8h.01"/><path d="M3 6a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v12a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-12"/><path d="M3 16l5 -5c.928 -.893 2.072 -.893 3 0l5 5"/><path d="M14 14l1 -1c.928 -.893 2.072 -.893 3 0l3 3"/>',
  summarySources: '<path d="M5.931 6.936l1.275 4.249m5.607 5.609l4.251 1.275"/><path d="M11.683 12.317l5.759 -5.759"/><path d="M4 5.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M17 5.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M17 18.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M4 15.5a4.5 4.5 0 1 0 9 0a4.5 4.5 0 1 0 -9 0"/>',
  summaryToggle: '<path d="M12 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 6l8 0"/><path d="M16 6l4 0"/><path d="M6 12a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 12l2 0"/><path d="M10 12l10 0"/><path d="M15 18a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 18l11 0"/><path d="M19 18l1 0"/>',
  home: '<path d="M5 12l-2 0l9 -9l9 9l-2 0"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-7"/><path d="M9 21v-6a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v6"/>',
  checkpoint: '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"/><path d="M9 12l2 2l4 -4"/>',
  folder: '<path d="M5 4h4l3 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2"/>',
  folderOpen: '<path d="M5 19l2.757 -7.351a1 1 0 0 1 .936 -.649h12.307a1 1 0 0 1 .986 1.164l-.996 5.211a2 2 0 0 1 -1.964 1.625h-14.026a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2h4l3 3h7a2 2 0 0 1 2 2v2"/>',
  folderPlus: '<path d="M12 19h-7a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2h4l3 3h7a2 2 0 0 1 2 2v3.5"/><path d="M16 19h6"/><path d="M19 16v6"/>',
  more: '<path d="M4 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M18 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/>',
  newChat: '<path d="M7 7h-1a2 2 0 0 0 -2 2v9a2 2 0 0 0 2 2h9a2 2 0 0 0 2 -2v-1"/><path d="M20.385 6.585a2.1 2.1 0 0 0 -2.97 -2.97l-8.415 8.385v3h3l8.385 -8.415"/><path d="M16 5l3 3"/>',
  projects: '<path d="M5 4h4l3 3h7a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-11a2 2 0 0 1 2 -2"/>',
  plus: '<path d="M12 5l0 14"/><path d="M5 12l14 0"/>',
  search: '<path d="M3 10a7 7 0 1 0 14 0a7 7 0 1 0 -14 0"/><path d="M21 21l-6 -6"/>',
  bell: '<path d="M10 5a2 2 0 1 1 4 0a7 7 0 0 1 4 6v3a4 4 0 0 0 2 3h-16a4 4 0 0 0 2 -3v-3a7 7 0 0 1 4 -6"/><path d="M9 17v1a3 3 0 0 0 6 0v-1"/>',
  right: '<path d="M9 6l6 6l-6 6"/>',
  down: '<path d="M6 9l6 6l6 -6"/>',
  scrollToBottom: '<path d="M12 5l0 14"/><path d="M18 13l-6 6"/><path d="M6 13l6 6"/>',
  back: '<path d="M5 12l14 0"/><path d="M5 12l6 6"/><path d="M5 12l6 -6"/>',
  forward: '<path d="M5 12l14 0"/><path d="M13 18l6 -6"/><path d="M13 6l6 6"/>',
  check: '<path d="M5 12l5 5l10 -10"/>',
  close: '<path d="M18 6l-12 12"/><path d="M6 6l12 12"/>',
  pin: '<path d="M9 4v6l-2 4v2h10v-2l-2 -4v-6"/><path d="M12 16l0 5"/><path d="M8 4l8 0"/>',
  unpin: '<path d="M3 3l18 18"/><path d="M15 4.5l-3.249 3.249m-2.57 1.433l-2.181 .818l-1.5 1.5l7 7l1.5 -1.5l.82 -2.186m1.43 -2.563l3.25 -3.251"/><path d="M9 15l-4.5 4.5"/><path d="M14.5 4l5.5 5.5"/>',
  archive: '<path d="M3 6a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2"/><path d="M5 8v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-10"/><path d="M10 12l4 0"/>',
  edit: '<path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4"/><path d="M13.5 6.5l4 4"/>',
  markRead: '<path d="M3 9l9 6l9 -6l-9 -6l-9 6"/><path d="M21 9v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10"/><path d="M3 19l6 -6"/><path d="M15 13l6 6"/>',
  section: '<path d="M4 6a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v2a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -2"/><path d="M4 16a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v2a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -2"/>',
  plugins: '<path d="M4 7h3a1 1 0 0 0 1 -1v-1a2 2 0 0 1 4 0v1a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h1a2 2 0 0 1 0 4h-1a1 1 0 0 0 -1 1v3a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-1a2 2 0 0 0 -4 0v1a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h1a2 2 0 0 0 0 -4h-1a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1"/>',
  skills: '<path d="M16 18a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2m0 -12a2 2 0 0 1 2 2a2 2 0 0 1 2 -2a2 2 0 0 1 -2 -2a2 2 0 0 1 -2 2m-7 12a6 6 0 0 1 6 -6a6 6 0 0 1 -6 -6a6 6 0 0 1 -6 6a6 6 0 0 1 6 6"/>',
  messages: '<path d="M3 20l1.3 -3.9c-2.324 -3.437 -1.426 -7.872 2.1 -10.374c3.526 -2.501 8.59 -2.296 11.845 .48c3.255 2.777 3.695 7.266 1.029 10.501c-2.666 3.235 -7.615 4.215 -11.574 2.293l-4.7 1"/>',
  artifacts: '<path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2"/><path d="M9 9l1 0"/><path d="M9 13l6 0"/><path d="M9 17l6 0"/>',
  schedule: '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"/><path d="M12 7v5l3 3"/>',
  settings: '<path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065"/><path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"/>',
  sidebar: '<path d="M4 6a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -12"/><path d="M9 4l0 16"/>',
  sidebarRight: '<path d="M4 6a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -12"/><path d="M15 4l0 16"/>',
  layout: '<path d="M4 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4"/><path d="M14 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4"/><path d="M4 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4"/><path d="M14 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4"/>',
  swap: '<path d="M7 10h14l-4 -4"/><path d="M17 14h-14l4 4"/>',
  hud: '<path d="M3 5a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1l0 -10"/><path d="M7 20h10"/><path d="M9 16v4"/><path d="M15 16v4"/><path d="M9 12v-4"/><path d="M12 12v-1"/><path d="M15 12v-2"/><path d="M12 12v-1"/>',
  changes: '<path d="M14 3v4a1 1 0 0 0 1 1h4"/><path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2"/><path d="M12 10l0 4"/><path d="M10 12l4 0"/><path d="M10 17l4 0"/>',
  turnDiffUndo: '<path d="M9 14l-4 -4l4 -4"/><path d="M5 10h11a4 4 0 1 1 0 8h-1"/>',
  source: '<path d="M5.931 6.936l1.275 4.249m5.607 5.609l4.251 1.275"/><path d="M11.683 12.317l5.759 -5.759"/><path d="M4 5.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M17 5.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M17 18.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0 -3 0"/><path d="M4 15.5a4.5 4.5 0 1 0 9 0a4.5 4.5 0 1 0 -9 0"/>',
  link: '<path d="M9 15l6 -6"/><path d="M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464"/><path d="M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463"/>',
  open: '<path d="M12 6h-6a2 2 0 0 0 -2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-6"/><path d="M11 13l9 -9"/><path d="M15 4h5v5"/>',
  mic: '<path d="M9 5a3 3 0 0 1 3 -3a3 3 0 0 1 3 3v5a3 3 0 0 1 -3 3a3 3 0 0 1 -3 -3l0 -5"/><path d="M5 10a7 7 0 0 0 14 0"/><path d="M8 21l8 0"/><path d="M12 17l0 4"/>',
  dictationStop: '<path d="M5 7a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2l0 -10"/>',
  send: '<path d="M12 5l0 14"/><path d="M18 11l-6 -6"/><path d="M6 11l6 -6"/>',
  sliders: '<path d="M12 6a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 6l8 0"/><path d="M16 6l4 0"/><path d="M6 12a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 12l2 0"/><path d="M10 12l10 0"/><path d="M15 18a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M4 18l11 0"/><path d="M19 18l1 0"/>',
  filter: '<path d="M4 4h16v2.172a2 2 0 0 1 -.586 1.414l-4.414 4.414v7l-6 2v-8.5l-4.48 -4.928a2 2 0 0 1 -.52 -1.345v-2.227"/>',
  model: '<path d="M5 6a1 1 0 0 1 1 -1h12a1 1 0 0 1 1 1v12a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1l0 -12"/><path d="M9 9h6v6h-6l0 -6"/><path d="M3 10h2"/><path d="M3 14h2"/><path d="M10 3v2"/><path d="M14 3v2"/><path d="M21 10h-2"/><path d="M21 14h-2"/><path d="M14 21v-2"/><path d="M10 21v-2"/>',
  palette: '<path d="M12 21a9 9 0 0 1 0 -18c4.97 0 9 3.582 9 8c0 1.06 -.474 2.078 -1.318 2.828c-.844 .75 -1.989 1.172 -3.182 1.172h-2.5a2 2 0 0 0 -1 3.75a1.3 1.3 0 0 1 -1 2.25"/><path d="M7.5 10.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M11.5 7.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M15.5 10.5a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/>',
  desktop: '<path d="M3 5a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1v-10"/><path d="M7 20h10"/><path d="M9 16v4"/><path d="M15 16v4"/>',
  lock: '<path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6"/><path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0"/><path d="M8 11v-4a4 4 0 1 1 8 0v4"/>',
  web: '<path d="M4 8h16"/><path d="M4 6a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -12"/><path d="M8 4v4"/>',
  shield: '<path d="M11.46 20.846a12 12 0 0 1 -7.96 -14.846a12 12 0 0 0 8.5 -3a12 12 0 0 0 8.5 3a12 12 0 0 1 -.09 7.06"/><path d="M15 19l2 2l4 -4"/>',
  shieldWarning: '<path d="M15.04 19.745c-.942 .551 -1.964 .976 -3.04 1.255a12 12 0 0 1 -8.5 -15a12 12 0 0 0 8.5 -3a12 12 0 0 0 8.5 3a12 12 0 0 1 .195 6.015"/><path d="M19 16v3"/><path d="M19 22v.01"/>',
  memory: '<path d="M15.5 13a3.5 3.5 0 0 0 -3.5 3.5v1a3.5 3.5 0 0 0 7 0v-1.8"/><path d="M8.5 13a3.5 3.5 0 0 1 3.5 3.5v1a3.5 3.5 0 0 1 -7 0v-1.8"/><path d="M17.5 16a3.5 3.5 0 0 0 0 -7h-.5"/><path d="M19 9.3v-2.8a3.5 3.5 0 0 0 -7 0"/><path d="M6.5 16a3.5 3.5 0 0 1 0 -7h.5"/><path d="M5 9.3v-2.8a3.5 3.5 0 0 1 7 0v10"/>',
  wrench: '<path d="M7 10h3v-3l-3.5 -3.5a6 6 0 0 1 8 8l6 6a2 2 0 0 1 -3 3l-6 -6a6 6 0 0 1 -8 -8l3.5 3.5"/>',
  usage: '<path d="M10 3.2a9 9 0 1 0 10.8 10.8a1 1 0 0 0 -1 -1h-3.8a4.1 4.1 0 1 1 -5 -5v-4a.9 .9 0 0 0 -1 -.8"/><path d="M15 3.5a9 9 0 0 1 5.5 5.5h-4.5a9 9 0 0 0 -1 -1v-4.5"/>',
  system: '<path d="M12.003 21c-.732 .001 -1.465 -.438 -1.678 -1.317a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c.886 .215 1.325 .957 1.318 1.694"/><path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0"/><path d="M17.001 19a2 2 0 1 0 4 0a2 2 0 1 0 -4 0"/><path d="M19.001 15.5v1.5"/><path d="M19.001 21v1.5"/><path d="M22.032 17.25l-1.299 .75"/><path d="M17.27 20l-1.3 .75"/><path d="M15.97 17.25l1.3 .75"/><path d="M20.733 20l1.3 .75"/>',
  bolt: '<path d="M13 3l0 7l6 0l-8 11l0 -7l-6 0l8 -11"/>',
  globe: '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"/><path d="M3.6 9h16.8"/><path d="M3.6 15h16.8"/><path d="M11.5 3a17 17 0 0 0 0 18"/><path d="M12.5 3a17 17 0 0 1 0 18"/>',
  keyboard: '<path d="M2 8a2 2 0 0 1 2 -2h16a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-16a2 2 0 0 1 -2 -2l0 -8"/><path d="M6 10l0 .01"/><path d="M10 10l0 .01"/><path d="M14 10l0 .01"/><path d="M18 10l0 .01"/><path d="M6 14l0 .01"/><path d="M18 14l0 .01"/><path d="M10 14l4 .01"/>',
  keys: '<path d="M16.555 3.843l3.602 3.602a2.877 2.877 0 0 1 0 4.069l-2.643 2.643a2.877 2.877 0 0 1 -4.069 0l-.301 -.301l-6.558 6.558a2 2 0 0 1 -1.239 .578l-.175 .008h-1.172a1 1 0 0 1 -.993 -.883l-.007 -.117v-1.172a2 2 0 0 1 .467 -1.284l.119 -.13l.414 -.414h2v-2h2v-2l2.144 -2.144l-.301 -.301a2.877 2.877 0 0 1 0 -4.069l2.643 -2.643a2.877 2.877 0 0 1 4.069 0"/><path d="M15 9h.01"/>',
  info: '<path d="M3 12a9 9 0 1 0 18 0a9 9 0 0 0 -18 0"/><path d="M12 9h.01"/><path d="M11 12h1v4h1"/>',
  download: '<path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2"/><path d="M7 11l5 5l5 -5"/><path d="M12 4l0 12"/>',
  upload: '<path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2"/><path d="M7 9l5 -5l5 5"/><path d="M12 4l0 12"/>',
  refresh: '<path d="M20 11a8.1 8.1 0 0 0 -15.5 -2m-.5 -4v4h4"/><path d="M4 13a8.1 8.1 0 0 0 15.5 2m.5 4v-4h-4"/>',
  copy: '<path d="M7 9.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667l0 -8.666"/><path d="M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1"/>',
  target: '<path d="M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0"/><path d="M7 12a5 5 0 1 0 10 0a5 5 0 1 0 -10 0"/><path d="M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0"/>',
  trash: '<path d="M4 7l16 0"/><path d="M10 11l0 6"/><path d="M14 11l0 6"/><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12"/><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3"/>',
  play: '<path d="M7 4v16l13 -8l-13 -8"/>',
  resourcePlay: '<path fill="white" stroke="none" d="M7 5v14l12 -7z"/>',
  resourcePause: '<rect fill="white" stroke="none" x="6" y="5" width="4" height="14" rx="1"/><rect fill="white" stroke="none" x="14" y="5" width="4" height="14" rx="1"/>',
  videoVolume: '<path d="M15 8a5 5 0 0 1 0 8"/><path d="M17.7 5a9 9 0 0 1 0 14"/><path d="M5 9h3l4 -4v14l-4 -4h-3a1 1 0 0 1 -1 -1v-4a1 1 0 0 1 1 -1"/>',
  videoMuted: '<path d="M5 9h3l4 -4v14l-4 -4h-3a1 1 0 0 1 -1 -1v-4a1 1 0 0 1 1 -1"/><path d="M16 10l4 4m0 -4l-4 4"/>',
  videoFullscreen: '<path d="M16 4h4v4m0 -4l-5 5M8 20h-4v-4m0 4l5 -5"/>',
  videoExitFullscreen: '<path d="M4 20l5 -5m-5 0h5v5M20 4l-5 5m0 -5v5h5"/>',
  person: '<path d="M8 7a4 4 0 1 0 8 0a4 4 0 0 0 -8 0"/><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"/>',
  team: '<path d="M5 7a4 4 0 1 0 8 0a4 4 0 1 0 -8 0"/><path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/><path d="M21 21v-2a4 4 0 0 0 -3 -3.85"/>',
  audio: '<path d="M21 12h-2c-.894 0 -1.662 -.857 -1.761 -2c-.296 -3.45 -.749 -6 -2.749 -6s-2.5 3.582 -2.5 8s-.5 8 -2.5 8s-2.452 -2.547 -2.749 -6c-.1 -1.147 -.867 -2 -1.763 -2h-2"/>',
  tools: '<path d="M3 21h4l13 -13a1.5 1.5 0 0 0 -4 -4l-13 13v4"/><path d="M14.5 5.5l4 4"/><path d="M12 8l-5 -5l-4 4l5 5"/><path d="M7 8l-1.5 1.5"/><path d="M16 12l5 5l-4 4l-5 -5"/><path d="M16 17l-1.5 1.5"/>',
  activityBrowser: '<path d="M4 8h16"/><path d="M4 6a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -12"/><path d="M8 4v4"/>',
  chatSkill: '<path d="M12 4l-8 4l8 4l8 -4l-8 -4"/><path d="M4 12l8 4l8 -4"/><path d="M4 16l8 4l8 -4"/>',
  terminal: '<path d="M8 9l3 3l-3 3"/><path d="M13 15l3 0"/><path d="M3 6a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2l0 -12"/>'
};
var glyphAliases = {
  inlineFileDocument: "artifacts",
  resourceDocument: "artifacts",
  resourceMore: "more",
  videoPlay: "play",
  videoPause: "resourcePause",
  videoMore: "more",
  activityEdit: "edit",
  activityImage: "image",
  activityIntegration: "tools",
  activityRead: "artifacts",
  activitySearch: "search",
  activityTerminal: "terminal",
  shellSuccess: "messageCopied",
  chatPreviewComputer: "laptop",
  tableClose: "close",
  tableCopy: "copy",
  tableExpand: "open",
  turnDiff: "changes",
  turnDiffOpen: "open",
  turnDiffDown: "down",
  turnDisclosure: "right"
};
var codexReference = Object.freeze({
  spacing: 4,
  font: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  enter: "cubic-bezier(.19, 1, .22, 1)",
  exit: "cubic-bezier(.8, 0, .4, 1)",
  hover: "cubic-bezier(.4, 0, .2, 1)",
  move: "cubic-bezier(.65, 0, .35, 1)",
  enterTime: "150ms",
  exitTime: "100ms",
  menuStartScale: ".95",
  // Desktop tooltip tokens: e77f816560c6.css. Scale and timing: the
  // Tooltip component in 299366.cf79ea855a.js.
  tooltip: Object.freeze({ radius: "16px", padding: "5px 12px", duration: "250ms", exitScale: ".97" }),
  // Compact tooltip and control geometry in 739301.37a39f26d6.js and 9ec44337a842.css.
  compactTooltip: Object.freeze({ radius: "8px", padding: "6px 8px", shadow: "0 8px 18px #0f172a33" }),
  quietControl: Object.freeze({ radius: "6px", height: "24px" }),
  // Desktop summary KWzM in 790272.8f3bb9e423.js: 300 ms with .01 bounce.
  summaryTime: "300ms",
  // Switch indicator and thumb from 0fff881d427a.css and its desktop tokens.
  switch: Object.freeze({ width: 32, height: 19, offset: 3, trackTime: "175ms", trackDelay: "50ms", thumbTime: "250ms" }),
  // Codex sidebar disclosure n4D0 in 499225.6d2e47bea2.js, easing V8uZ.Wu.
  disclosure: Object.freeze({ heightTime: 450, enterTime: 300, enterDelay: 75, exitTime: 150, ease: "cubic-bezier(.23, 1, .32, 1)" }),
  // Sidebar navigation tokens and the compact end of vQc5's rich preview width.
  // 499225.6d2e47bea2.js, 182735.bb2cb0d2af.js, e77f816560c6.css.
  sidebar: Object.freeze({ rowHeight: 30, rowRadius: 10, previewWidth: 336, previewRadius: 12, previewOffset: 2 })
});
var localAssets = false ? null : null;
var svgMask = (svg) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
var defaultMasks = /* @__PURE__ */ new Map();
function codexMask(name, ink = "white") {
  if (ink !== "white") return makeMask(name, ink);
  if (!defaultMasks.has(name)) defaultMasks.set(name, makeMask(name, ink));
  return defaultMasks.get(name);
}
function makeMask(name, ink) {
  const original = localAssets?.icons[name];
  if (original) return svgMask(ink === "white" ? original : original.replaceAll('"white"', `"${ink}"`));
  const paths = glyphs[glyphAliases[name] ?? name];
  if (!paths) throw new Error(`Unknown workspace icon: ${name}`);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="${ink}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
  return svgMask(svg);
}
function codexIconStyle(name) {
  return { mask: `${codexMask(name)} center / contain no-repeat`, backgroundColor: "currentColor" };
}
function codexIconRules(selector, name, flip = false) {
  return `
    ${selector} {
      background-color: currentColor;
      mask: ${codexMask(name)} center / contain no-repeat;
      ${flip ? "scale: -1 1;" : ""}
    }
    ${selector}::before, ${selector} > * { visibility: hidden; }
  `;
}

// source/sidebar-projects.js
import { host as host2 } from "@hermes/plugin-sdk";

// source/sidebar-recents.js
import { createElement as h, isValidElement, useSyncExternalStore, version } from "react";
var sectionActions = ["onResumeSession", "onArchiveSession", "onDeleteSession", "onTogglePin", "onToggleUnread"];
function committedFiber(element7) {
  if (!element7 || !version.startsWith("19.")) return null;
  const keys = Object.keys(element7);
  let fiber = element7[keys.find((key) => key.startsWith("__reactFiber$"))];
  const props = element7[keys.find((key) => key.startsWith("__reactProps$"))];
  if (!props) return null;
  if (fiber?.memoizedProps !== props) fiber = fiber?.alternate;
  return fiber?.memoizedProps === props ? fiber : null;
}
function nativeDraftWorkspaceAction(sidebar2) {
  for (let node3 = committedFiber(sidebar2); node3; node3 = node3.return) {
    const props = node3.memoizedProps;
    if (typeof props?.onNewSessionInWorkspace === "function" && typeof props.onNewSessionSplit === "function") {
      return props.onNewSessionInWorkspace;
    }
  }
  return null;
}
function nativeWorktreeTarget(button5) {
  for (let node3 = committedFiber(button5); node3; node3 = node3.return) {
    const props = node3.memoizedProps;
    if (typeof props?.repoPath === "string") return { path: props.repoPath };
    if (typeof props?.project?.path === "string") {
      const { path, connectionId, profile: profile2 } = props.project;
      return { path, connectionId, profile: profile2 };
    }
  }
  return null;
}
function groupingAction(element7) {
  if (Array.isArray(element7)) {
    for (const child of element7) {
      const action = groupingAction(child);
      if (action) return action;
    }
    return null;
  }
  if (!isValidElement(element7)) return null;
  const { children, onValueChange } = element7.props;
  if (typeof onValueChange === "function" && Array.isArray(children) && children.some((option) => option?.props?.option?.id === "project")) return onValueChange;
  return groupingAction(children);
}
function projectGroupingAction(trigger) {
  for (let node3 = committedFiber(trigger); node3; node3 = node3.return) {
    const props = node3.memoizedProps;
    if (props?.["data-slot"] === "dropdown-menu") return groupingAction(props.children);
  }
  return null;
}
function readNativeList(tree) {
  if (!version.startsWith("19.") || !tree?.matches('[data-sessions-mode="projects"], [data-sessions-mode="flat"]')) return null;
  for (const group2 of tree.querySelectorAll(':scope > [data-slot="sidebar-group"]')) {
    const fiber = committedFiber(group2);
    if (!fiber) continue;
    for (let node3 = fiber.return; node3; node3 = node3.return) {
      const props = node3.memoizedProps;
      if (typeof node3.type !== "function" || props?.pinned !== false || typeof props.onEnterProject !== "function" || !Array.isArray(props.sessions) || !sectionActions.every((name) => typeof props[name] === "function")) continue;
      let sidebar2 = node3.return;
      while (sidebar2 && typeof sidebar2.memoizedProps?.onRetrySessions !== "function") sidebar2 = sidebar2.return;
      return {
        group: group2,
        fiber: node3,
        section: node3.type,
        props,
        refresh: sidebar2?.memoizedProps.onRetrySessions,
        manageCronJob: sidebar2?.memoizedProps.onManageCronJob
      };
    }
  }
  return null;
}
var dotStates = /* @__PURE__ */ new Set(["background", "draft", "idle", "needs-input", "stalled", "unread", "working"]);
function nativeProjectActivity(tree) {
  const source = readNativeList(tree);
  const activity = /* @__PURE__ */ new Map();
  if (!source?.props.projectOverview?.length) return activity;
  let states;
  for (let hook = source.fiber.memoizedState; hook; hook = hook.next) {
    if (typeof hook.queue?.getSnapshot !== "function") continue;
    const value = hook.queue.getSnapshot();
    if (!value || Object.getPrototypeOf(value) !== Object.prototype) continue;
    const statuses = Object.values(value);
    if (!statuses.length || !statuses.every((status2) => dotStates.has(status2))) continue;
    if (states) return activity;
    states = value;
  }
  if (!states) return activity;
  const liveId = (id2) => states[id2] === "working" || states[id2] === "stalled";
  const unreadId = (id2) => states[id2] === "unread";
  if (!Object.keys(states).some((id2) => liveId(id2) || unreadId(id2))) return activity;
  const { projectOverview, projectOverviewPreviews } = source.props;
  const hasStatus = (project2, matches) => {
    const sessionMatches = (session) => matches(session.id);
    return project2.sessionIds?.some(matches) || projectOverviewPreviews?.[project2.id]?.some(sessionMatches) || !project2.sessionIds && (project2.previewSessions?.some(sessionMatches) || project2.repos.some((repo) => repo.groups.some((group2) => group2.sessions.some(sessionMatches))));
  };
  for (const project2 of projectOverview) {
    if (hasStatus(project2, liveId)) activity.set(project2.id, "working");
    else if (hasStatus(project2, unreadId)) activity.set(project2.id, "unread");
  }
  return activity;
}
function manageSidebarCronJob(tree, id2) {
  const action = readNativeList(tree)?.manageCronJob;
  if (typeof action !== "function") return false;
  action(id2);
  return true;
}
function createRecentRows() {
  let snapshot = null;
  const subscribers = /* @__PURE__ */ new Set();
  function set(value) {
    snapshot = value;
    for (const notify of subscribers) notify();
  }
  return {
    get: () => snapshot,
    subscribe(notify) {
      subscribers.add(notify);
      return () => subscribers.delete(notify);
    },
    update(tree, container, empty) {
      const source = readNativeList(tree);
      const flat2 = tree?.dataset.sessionsMode === "flat";
      if (!source || flat2 && (source.props.grouping !== "date" || source.props.groups?.length)) return null;
      if (snapshot?.container !== container || snapshot?.props !== source.props || snapshot?.group !== source.group || snapshot?.empty !== empty) {
        set({ ...source, container, empty, flat: flat2 });
      }
      return source.group;
    },
    clear(container) {
      if (snapshot?.container === container) set(null);
    }
  };
}
function NativeRecentRows({ rows }) {
  const snapshot = useSyncExternalStore(rows.subscribe, rows.get);
  if (!snapshot) return null;
  const { section: section2, props, container, empty, flat: flat2 } = snapshot;
  const sessions = props.sessions;
  const children = h(section2, flat2 ? {
    ...props,
    grouping: "none",
    showProfileTags: new Set(sessions.map((session) => session.profile)).size > 1
  } : {
    label: "",
    open: true,
    collapsible: false,
    pinned: false,
    preserveOrder: true,
    sessions,
    contentClassName: "hcv-recent-scroll",
    card: props.card,
    forceEmptyState: props.forceEmptyState,
    activeSessionId: props.activeSessionId,
    showProfileTags: new Set(sessions.map((session) => session.profile)).size > 1,
    onResumeSession: props.onResumeSession,
    onArchiveSession: props.onArchiveSession,
    onDeleteSession: props.onDeleteSession,
    onBranchSession: props.onBranchSession,
    onTogglePin: props.onTogglePin,
    onToggleUnread: props.onToggleUnread,
    emptyState: props.forceEmptyState ? props.emptyState : h("div", { "data-hcv-recent-empty": "" }, empty)
  });
  return { $$typeof: /* @__PURE__ */ Symbol.for("react.portal"), key: null, children, containerInfo: container, implementation: null };
}

// source/sidebar-chat-order.js
import { host } from "@hermes/plugin-sdk";
var rowButton = 'button[data-slot="row-button"]';
var ordered = "data-hcv-sidebar-ordered";
var orderProperty = "--hcv-sidebar-order";
var localDrag = "data-hcv-reordering-sidebar";
var lifted = "data-hcv-sidebar-lifted";
function sessionRows(list) {
  const chats = [];
  for (const row5 of list.children) {
    const button5 = row5.querySelector(rowButton);
    for (let fiber = committedFiber(button5); fiber; fiber = fiber.return) {
      const props = fiber.memoizedProps;
      const session = props?.session;
      if (typeof session?.id !== "string" || typeof props.onResume !== "function") continue;
      const parent = chats.at(-1);
      const profile2 = session.profile || "default";
      const lineage = session._lineage_root_id ?? session.id;
      const key = JSON.stringify([profile2, lineage]);
      if (props.branchStem && parent) parent.rows.push(row5);
      else chats.push({ key, id: session.id, profile: profile2, anchor: row5, button: button5, rows: [row5] });
      break;
    }
  }
  const counts = /* @__PURE__ */ new Map();
  for (const chat3 of chats) counts.set(chat3.key, (counts.get(chat3.key) ?? 0) + 1);
  for (const chat3 of chats) if (counts.get(chat3.key) > 1) chat3.key = JSON.stringify([chat3.profile, chat3.id]);
  return chats;
}
function nativeProjectOrder(item) {
  for (let fiber = committedFiber(item); fiber; fiber = fiber.return) {
    const props = fiber.memoizedProps;
    if (typeof props?.onReorderProjects === "function") return props.onReorderProjects;
  }
}
function scopeKey() {
  const connection = host.state.connectionId.get();
  const profile2 = host.state.profile.get();
  return connection && profile2 ? [connection, profile2] : null;
}
function savedOrder(storage, key) {
  const value = storage.get(key, []);
  return Array.isArray(value) ? [...new Set(value.filter((id2) => typeof id2 === "string"))] : [];
}
function applyRanks(items2, order) {
  const ranks = new Map(order.map((id2, index2) => [id2, index2]));
  const ranked = items2.filter((item) => ranks.has(item.key)).sort((a, b) => ranks.get(a.key) - ranks.get(b.key));
  let index = 0;
  return items2.map((item) => ranks.has(item.key) ? ranked[index++] : item);
}
function contains(rect, x, y) {
  return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
}
function attachSidebarOrder(content, storage) {
  const lists = /* @__PURE__ */ new Map();
  const styled = /* @__PURE__ */ new Set();
  const line = document.createElement("div");
  const ghost = document.createElement("div");
  const label3 = document.createElement("span");
  line.dataset.hcvChatDropLine = "";
  ghost.dataset.hcvSidebarDragGhost = "";
  ghost.append(label3);
  for (const node3 of [line, ghost]) node3.setAttribute("aria-hidden", "true");
  let bindings;
  let drag;
  let frame = 0;
  let clearClick;
  function restore(list) {
    list.removeAttribute(ordered);
    for (const row5 of list.children) row5.style.removeProperty(orderProperty);
    styled.delete(list);
  }
  function register(list, items2, key, kind, nativeOrder) {
    if (!list || items2.length === 0 || new Set(items2.map((item) => item.key)).size !== items2.length) return;
    const order = nativeOrder ? [] : savedOrder(storage, key);
    const ranked = applyRanks(items2, order);
    if (ranked.some((item, index) => item !== items2[index])) {
      const itemRows = new Set(items2.flatMap((item) => item.rows));
      const remaining = ranked.flatMap((item) => item.rows);
      let index = 0;
      list.setAttribute(ordered, kind);
      const children = [...list.children];
      const reordered = children.map((row5) => itemRows.has(row5) ? remaining[index++] : row5);
      reordered.forEach((row5, rank) => row5.style.setProperty(orderProperty, String(rank)));
      styled.add(list);
    } else if (styled.has(list)) restore(list);
    lists.set(list, { key, kind, items: ranked, nativeOrder });
  }
  function sync(nextBindings) {
    bindings = nextBindings;
    lists.clear();
    const scope4 = scopeKey();
    if (scope4) {
      for (const { project: project2, list } of bindings.chats) {
        if (list) register(list, sessionRows(list), "sidebar-chat-order:" + JSON.stringify([...scope4, project2]), "chat");
      }
      const projectGroups = /* @__PURE__ */ new Map();
      for (const { item, row: row5, name, id: id2 } of bindings.projects) {
        if (id2 === "__no_project__") continue;
        const list = item.parentElement;
        if (!projectGroups.has(list)) projectGroups.set(list, []);
        projectGroups.get(list).push({ key: id2, anchor: row5, button: name, rows: [item] });
      }
      for (const [list, items2] of projectGroups) {
        const positions = new Map([...list.children].map((row5, index) => [row5, index]));
        items2.sort((a, b) => positions.get(a.rows[0]) - positions.get(b.rows[0]));
        const reorder = nativeProjectOrder(items2[0].rows[0]);
        register(list, items2, "sidebar-project-order:" + JSON.stringify(scope4), "project", reorder);
      }
    }
    for (const list of styled) if (!lists.has(list)) restore(list);
    if (drag && lists.get(drag.list)?.key !== drag.key) end();
  }
  function targetAt(x, y) {
    const entry = lists.get(drag.list);
    if (!entry || entry.key !== drag.key || JSON.stringify(scopeKey()) !== drag.scope || !drag.list.isConnected || drag.list.closest("[hidden], [inert], [data-pane-hidden]") || !contains(content.getBoundingClientRect(), x, y) || !contains(drag.list.getBoundingClientRect(), x, y)) return null;
    const from = entry.items.findIndex((item) => item.key === drag.item);
    if (from < 0) return null;
    const geometry = entry.items.map((item) => ({
      rect: item.anchor.getBoundingClientRect(),
      bottom: item.rows.at(-1).getBoundingClientRect().bottom
    }));
    if (y < geometry[0].rect.top || y > geometry.at(-1).bottom) return null;
    const before = geometry.findIndex(({ rect: rect2, bottom: bottom2 }) => y <= (rect2.top + bottom2) / 2);
    const slot = before < 0 ? geometry.length : before;
    const index = slot > from ? slot - 1 : slot;
    if (index === from) return { entry };
    const { rect, bottom } = geometry[slot] ?? geometry.at(-1);
    return { entry, from, index, rect, y: slot === geometry.length ? bottom : rect.top };
  }
  function draw() {
    frame = 0;
    if (!drag?.point) return;
    const [x, y] = drag.point;
    const target = targetAt(x, y);
    const within = Boolean(target);
    document.documentElement.toggleAttribute(localDrag, within);
    if (drag.kind === "chat") drag.source.toggleAttribute(lifted, within);
    if (within || drag.kind === "project") {
      ghost.style.transform = `translate3d(${x - drag.offsetX}px, ${y - drag.offsetY}px, 0)`;
      if (!ghost.isConnected) document.body.append(ghost);
    } else ghost.remove();
    if (!target?.rect) {
      line.remove();
      return;
    }
    line.style.left = `${target.rect.left + 8}px`;
    line.style.width = `${Math.max(0, target.rect.width - 16)}px`;
    line.style.top = `${target.y - 1}px`;
    if (!line.isConnected) document.body.append(line);
  }
  function move(event) {
    if (event.pointerId !== drag.pointer) return;
    if (!drag.point) {
      if (Math.hypot(event.clientX - drag.x, event.clientY - drag.y) < 6) return;
      if (drag.kind === "project") {
        drag.source.setAttribute(lifted, "");
        try {
          drag.source.setPointerCapture(event.pointerId);
        } catch {
        }
      }
      label3.textContent = drag.label;
      ghost.dataset.hcvSidebarDragGhost = drag.kind;
    }
    drag.point = [event.clientX, event.clientY];
    if (!frame) frame = requestAnimationFrame(draw);
  }
  function end() {
    const previous = drag;
    drag = void 0;
    previous?.source.removeAttribute(lifted);
    if (previous?.kind === "project") {
      if (previous.source.hasPointerCapture(previous.pointer)) previous.source.releasePointerCapture(previous.pointer);
    }
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    line.remove();
    ghost.remove();
    document.documentElement.removeAttribute(localDrag);
    window.removeEventListener("pointermove", move, true);
    window.removeEventListener("pointerup", release, true);
    window.removeEventListener("pointercancel", cancel, true);
    window.removeEventListener("keydown", keydown, true);
    window.removeEventListener("blur", end);
    content.removeEventListener("scroll", redraw, true);
  }
  function redraw() {
    if (drag?.point && !frame) frame = requestAnimationFrame(draw);
  }
  function suppressClick(pointer, afterRelease) {
    clearClick?.();
    let timer;
    const reset = () => {
      clearTimeout(timer);
      window.removeEventListener("click", block2, true);
      window.removeEventListener("pointerup", disarm, true);
      window.removeEventListener("pointerdown", reset, true);
      clearClick = void 0;
    };
    const disarm = (event) => {
      if (event.pointerId === pointer) timer = setTimeout(reset, 0);
    };
    const block2 = (event) => {
      if (!event.detail) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      reset();
    };
    clearClick = reset;
    window.addEventListener("click", block2, true);
    window.addEventListener("pointerdown", reset, true);
    if (afterRelease) timer = setTimeout(reset, 0);
    else window.addEventListener("pointerup", disarm, true);
  }
  function commit({ entry, from, index }) {
    const keys = entry.items.map((item) => item.key);
    const visible = new Set(keys);
    keys.splice(index, 0, keys.splice(from, 1)[0]);
    const previous = [.../* @__PURE__ */ new Set([...savedOrder(storage, entry.key), ...visible])];
    let offset = 0;
    storage.set(entry.key, previous.map((id2) => visible.has(id2) ? keys[offset++] : id2));
    if (entry.nativeOrder) entry.nativeOrder(keys);
    else sync(bindings);
  }
  function release(event) {
    if (event.pointerId !== drag.pointer) return;
    const target = drag.point && targetAt(event.clientX, event.clientY);
    const sidebarDrop = drag.point && drag.kind === "chat" && contains(content.getBoundingClientRect(), event.clientX, event.clientY);
    if (drag.point && drag.kind === "project") suppressClick(drag.pointer, true);
    end();
    if (sidebarDrop) window.dispatchEvent(new PointerEvent("pointermove", {
      clientX: -1,
      clientY: -1,
      pointerId: event.pointerId
    }));
    if (target?.rect) commit(target);
  }
  function cancel(event) {
    if (event.pointerId === drag.pointer) end();
  }
  function keydown(event) {
    if (event.key !== "Escape") return;
    if (drag.point && drag.kind === "project") {
      event.preventDefault();
      event.stopPropagation();
      suppressClick(drag.pointer, false);
    }
    end();
  }
  function press(event) {
    if (drag || !event.isPrimary || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || !(event.target instanceof Element) || event.target.closest('[contenteditable="true"]')) return;
    const name = event.target.closest("[data-hcv-project-name]");
    const project2 = event.target.closest("[data-hcv-project-row]");
    const button5 = event.target.closest(rowButton);
    if (!name && event.target.closest('[data-row-actions], [data-reorder-handle], [data-slot="switch"]')) return;
    let list = (project2 ?? button5)?.parentElement;
    while (list && list !== content && !lists.has(list)) list = list.parentElement;
    const entry = lists.get(list);
    if (!entry || entry.items.length < 2) return;
    const item = entry.items.find((item2) => project2 ? item2.anchor === project2 : item2.button === button5);
    if (!item) return;
    if (project2) event.stopPropagation();
    const rect = item.anchor.getBoundingClientRect();
    const title = item.button.querySelector(".hover-marquee-inner")?.textContent || item.button.textContent;
    drag = {
      list,
      item: item.key,
      key: entry.key,
      kind: entry.kind,
      source: item.anchor,
      scope: JSON.stringify(scopeKey()),
      pointer: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      label: title.trim(),
      offsetX: Math.min(event.clientX - rect.left, 32),
      offsetY: event.clientY - rect.top
    };
    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", release, true);
    window.addEventListener("pointercancel", cancel, true);
    window.addEventListener("keydown", keydown, true);
    window.addEventListener("blur", end);
    content.addEventListener("scroll", redraw, true);
  }
  content.addEventListener("pointerdown", press, true);
  return {
    sync,
    dispose() {
      content.removeEventListener("pointerdown", press, true);
      end();
      clearClick?.();
      for (const list of styled) restore(list);
      lists.clear();
    }
  };
}
function sidebarOrderStyles(active2) {
  return `
    ${active2} [${ordered}] { reading-flow: grid-order; }
    ${active2} [${ordered}] > * { order: var(${orderProperty}, 0); }
    ${active2} [${ordered}="chat"] > [class~="group/workspace"]:has(> button[aria-expanded="true"]) {
      display: none;
    }
    ${active2} [data-hcv-chat-drop-line] {
      --hcv-drop-ring: light-dark(#0169cc, #0285ff);
      position: fixed;
      z-index: 100;
      height: 2px;
      border-radius: 999px;
      pointer-events: none;
      background: var(--hcv-drop-ring);
    }
    ${active2} [data-hcv-chat-drop-line]::before {
      content: '';
      position: absolute;
      inset: -3px auto auto -4px;
      inline-size: 8px;
      block-size: 8px;
      border: 2px solid var(--hcv-drop-ring);
      border-radius: 50%;
      background: light-dark(#ededed, #181818);
    }
    ${active2} [data-hcv-sidebar-drag-ghost] {
      position: fixed;
      inset: 0 auto auto 0;
      z-index: 10000;
      display: flex;
      align-items: center;
      gap: 8px;
      max-inline-size: 320px;
      block-size: 32px;
      padding-inline: 8px;
      border: 1px solid light-dark(#0d0d0d1a, #ffffff1f);
      border-radius: 10px;
      corner-shape: superellipse(1.5);
      background: light-dark(#ededed, #181818);
      color: light-dark(#282828, #dcdcdc);
      font: 400 14px/21px var(--hcv-ui-font);
      opacity: .7;
      box-shadow: 0 4px 8px -2px #0000001a;
      pointer-events: none;
    }
    ${active2} [data-hcv-sidebar-drag-ghost] > span {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    ${active2} [data-hcv-sidebar-drag-ghost]::before {
      content: '';
      flex: none;
      inline-size: 20px;
      block-size: 20px;
      background: currentColor;
      mask: ${codexMask("chatTab")} center / 16px 16px no-repeat;
    }
    ${active2} [data-hcv-sidebar-drag-ghost="project"]::before {
      mask-image: ${codexMask("folder")};
      mask-size: 14px 14px;
    }
    ${active2} [${lifted}] { opacity: .2 !important; }
    ${active2}[${localDrag}] body { cursor: grabbing !important; }
    ${active2}[${localDrag}] body > div[style*="z-index: 9999"][style*="max-width: 16rem"][style*="will-change: transform"],
    ${active2}[${localDrag}] [data-slot="chat-drop-overlay"],
    ${active2}[${localDrag}] [data-tree-group] > .pointer-events-none.absolute.inset-0.z-40:has(> .border-dashed) {
      visibility: hidden;
    }
  `;
}

// source/title-overflow.js
var overflowing = "data-hcv-title-overflow";
var marqueeDistance = "--hcv-title-distance";
var marqueeDuration = "--hcv-title-duration";
var marqueeTiming = "--hcv-title-timing";
function measureMarquee(label3) {
  const zoom2 = label3.currentCSSZoom || 1;
  const width = label3.getBoundingClientRect().width;
  const content = label3.firstElementChild;
  if (!width || !content) return null;
  const padding = Number.parseFloat(getComputedStyle(label3).paddingInlineStart) || 0;
  const distance = (content.getBoundingClientRect().width - width) / zoom2 + padding;
  if (distance < 1) return null;
  const fontSize = Number.parseFloat(getComputedStyle(content).fontSize);
  return { distance, fontSize: fontSize || 13 };
}
function setMarquee(label3, motion2) {
  if (!motion2) {
    label3.style.removeProperty(marqueeDistance);
    label3.style.removeProperty(marqueeDuration);
    label3.style.removeProperty(marqueeTiming);
    return;
  }
  const { distance, fontSize } = motion2;
  const travel = distance / (fontSize * 2);
  const hold = 0.35;
  const duration4 = hold + travel;
  const stops = ["0.0000 0.0000%"];
  for (let index = 0; index <= 32; index++) {
    const t = index / 32;
    const inverse = 1 - t;
    const first = 3 * inverse ** 2 * t;
    const second = 3 * inverse * t ** 2;
    const third = t ** 3;
    const x = first * 0.49 + second * 0.7 + third;
    const y = first * 0.6 + second + third;
    const percent = (hold + travel * x) / duration4 * 100;
    stops.push(`${y.toFixed(4)} ${percent.toFixed(4)}%`);
  }
  label3.style.setProperty(marqueeDistance, `${distance}px`);
  label3.style.setProperty(marqueeDuration, `${duration4.toFixed(3)}s`);
  label3.style.setProperty(marqueeTiming, `linear(${stops.join(", ")})`);
}
function trackTitleOverflow({ marquee = false } = {}) {
  const measured = /* @__PURE__ */ new Map();
  const update = (labels12) => {
    const sizes = labels12.map((label3) => {
      if (marquee) {
        const motion2 = measureMarquee(label3);
        return { label: label3, clipped: Boolean(motion2), motion: motion2 };
      }
      const width = label3.clientWidth;
      return { label: label3, clipped: width > 0 && label3.scrollWidth > width };
    });
    for (const { label: label3, clipped, motion: motion2 } of sizes) {
      const entry = measured.get(label3);
      if (!entry) continue;
      label3.toggleAttribute(overflowing, clipped);
      if (marquee && (entry.motion?.distance !== motion2?.distance || entry.motion?.fontSize !== motion2?.fontSize)) {
        setMarquee(label3, motion2);
        entry.motion = motion2;
      }
    }
  };
  const observer = new ResizeObserver((entries) => {
    const resized = /* @__PURE__ */ new Set();
    for (const { target } of entries) {
      const label3 = measured.has(target) ? target : target.parentElement;
      if (measured.has(label3)) resized.add(label3);
    }
    update([...resized]);
  });
  return (labels12 = []) => {
    const current = new Set(labels12);
    for (const [label3, entry] of measured) {
      if (current.has(label3)) continue;
      observer.unobserve(label3);
      if (entry.content) observer.unobserve(entry.content);
      label3.removeAttribute(overflowing);
      if (marquee) setMarquee(label3, null);
      measured.delete(label3);
    }
    const renamed = [];
    for (const label3 of current) {
      const title = label3.textContent;
      let entry = measured.get(label3);
      if (!entry) {
        entry = { title, content: null };
        measured.set(label3, entry);
        observer.observe(label3);
      }
      if (entry.title !== title) renamed.push(label3);
      entry.title = title;
      const content = marquee ? label3.firstElementChild : null;
      if (entry.content === content) continue;
      if (entry.content) observer.unobserve(entry.content);
      if (content) observer.observe(content);
      entry.content = content;
    }
    if (renamed.length) update(renamed);
  };
}
function sidebarMarqueeStyles(row5) {
  const viewport = `${row5} .hover-marquee`;
  const content = ".hover-marquee-inner";
  const hover = `${row5}:hover .hover-marquee[${overflowing}]`;
  return `
  ${viewport} {
    --hcv-title-fade-start: .571429em;
    --hcv-title-fade-end: 1.14286em;
    --hcv-title-direction: -1;
    --hcv-title-gradient: to right;
    display: block;
    box-sizing: border-box;
    inline-size: calc(100% + var(--hcv-title-fade-start));
    margin-inline-start: calc(-1 * var(--hcv-title-fade-start));
    padding-inline-start: var(--hcv-title-fade-start);
    overflow: hidden;
    white-space: nowrap;
    text-overflow: clip;
    text-align: start;
  }
  ${viewport}:dir(rtl) { --hcv-title-direction: 1; --hcv-title-gradient: to left; mask-position: 100% 0; }
  ${viewport} > ${content} {
    display: inline-block;
    min-inline-size: max-content;
  }
  ${viewport}[data-marquee="true"] > ${content} { animation: none; }
  ${viewport}[${overflowing}] {
    mask-image: linear-gradient(var(--hcv-title-gradient), transparent, #000 var(--hcv-title-fade-start), #000 calc(100% - var(--hcv-title-fade-end)), transparent);
    mask-size: 100% 100%;
    mask-repeat: no-repeat;
  }
  @media (hover: hover) and (prefers-reduced-motion: no-preference) {
    ${hover} { animation: hcv-chat-title-mask var(${marqueeDuration}) linear forwards; }
    ${hover} > ${content} {
      animation: hcv-chat-title-scroll var(${marqueeDuration}) var(${marqueeTiming}) forwards;
      will-change: transform;
    }
    @keyframes hcv-chat-title-scroll {
      to { transform: translateX(calc(var(--hcv-title-direction) * var(${marqueeDistance}))); }
    }
    @keyframes hcv-chat-title-mask {
      75% { mask-size: 100% 100%; }
      to { mask-size: calc(100% + var(--hcv-title-fade-end)) 100%; }
    }
  }
  `;
}
function fadingTitleStyles(selector, distance) {
  const edge = `#000 calc(100% - ${distance}), transparent`;
  return `
  ${selector} { text-overflow: clip; }
  ${selector}[${overflowing}] { mask-image: linear-gradient(to right, ${edge}); }
  ${selector}[${overflowing}]:dir(rtl) { mask-image: linear-gradient(to left, ${edge}); }
  `;
}

// source/sidebar-more.js
var firstPage = 4;
var nextPage = 10;
var hidden = "data-hcv-project-chat-hidden";
var nativeHidden = "data-hcv-project-more-native";
function attachProjectMore(t) {
  const states = /* @__PURE__ */ new Map();
  function restore(state) {
    for (const node3 of state.marked) node3.removeAttribute(hidden);
    state.marked.clear();
    state.native?.removeAttribute(nativeHidden);
    state.native = void 0;
    state.wrapper?.remove();
    state.wrapper = void 0;
  }
  function clear(entry) {
    const state = states.get(entry);
    if (!state) return;
    restore(state);
    states.delete(entry);
  }
  function nativeControl(list) {
    return [...list.children].find((node3) => node3.querySelector(':scope > button[class~="group/more"]'));
  }
  function apply(entry, state) {
    const list = entry.region();
    if (!list) {
      restore(state);
      state.list = void 0;
      state.limit = firstPage;
      state.requested = false;
      return;
    }
    if (entry.name.ariaExpanded === "false") return;
    if (state.list !== list) {
      restore(state);
      state.list = list;
      state.limit = firstPage;
      state.requested = false;
    }
    const chats = sessionRows(list);
    if (list.hasAttribute("data-hcv-sidebar-ordered")) {
      chats.sort((a, b) => Number(a.anchor.style.getPropertyValue("--hcv-sidebar-order")) - Number(b.anchor.style.getPropertyValue("--hcv-sidebar-order")));
    }
    const native2 = nativeControl(list);
    const allProfiles = localStorage.getItem("hermes.desktop.showAllProfiles") === "true";
    if (native2 && chats.length < firstPage && !state.requested && !allProfiles) {
      state.requested = true;
      const button5 = native2.querySelector('button[class~="group/more"]');
      queueMicrotask(() => {
        if (states.get(entry) === state && entry.region() === list && button5?.isConnected && !button5.disabled) button5.click();
      });
    }
    const ready = chats.length >= firstPage || !native2;
    const capped = ready && (chats.length > state.limit || Boolean(native2));
    const nextMarked = /* @__PURE__ */ new Set();
    if (ready) {
      for (const chat3 of chats.slice(state.limit)) for (const row5 of chat3.rows) nextMarked.add(row5);
    }
    for (const node3 of state.marked) if (!nextMarked.has(node3)) node3.removeAttribute(hidden);
    for (const node3 of nextMarked) if (!state.marked.has(node3)) node3.setAttribute(hidden, "");
    state.marked = nextMarked;
    if (state.native !== native2) state.native?.removeAttribute(nativeHidden);
    state.native = native2;
    if (native2) native2.toggleAttribute(nativeHidden, ready);
    if (capped) {
      if (!state.wrapper) {
        const wrapper = document.createElement("div");
        const button6 = document.createElement("button");
        wrapper.setAttribute("data-hcv-project-more", "");
        button6.type = "button";
        button6.addEventListener("click", (event) => {
          const previous = state.limit;
          state.limit += nextPage;
          const current = sessionRows(list);
          if (current.length < state.limit) {
            const next = nativeControl(list)?.querySelector('button[class~="group/more"]');
            if (next && !next.disabled) next.click();
          }
          apply(entry, state);
          if (event.detail === 0) {
            const revealed = sessionRows(list).filter((chat3) => !chat3.anchor.hasAttribute(hidden))[previous];
            revealed?.button.focus({ preventScroll: true });
          }
        });
        wrapper.append(button6);
        state.wrapper = wrapper;
      }
      const button5 = state.wrapper.firstElementChild;
      const label3 = t("showMore");
      if (button5.textContent !== label3) button5.textContent = label3;
      if (state.wrapper.parentElement !== list) list.append(state.wrapper);
    } else {
      state.wrapper?.remove();
      state.wrapper = void 0;
    }
  }
  return {
    sync(entries) {
      const live = new Set(entries);
      for (const entry of states.keys()) if (!live.has(entry)) clear(entry);
      for (const entry of entries) {
        let state = states.get(entry);
        if (!state) {
          state = { limit: firstPage, marked: /* @__PURE__ */ new Set(), requested: false };
          states.set(entry, state);
        }
        apply(entry, state);
      }
    },
    clear,
    dispose() {
      for (const entry of states.keys()) clear(entry);
    }
  };
}
function projectMoreStyles(active2) {
  return `
    ${active2} [${hidden}], ${active2} [${nativeHidden}] { display: none !important; }
    ${active2} [data-hcv-project-more] { padding: 4px 0 4px 28px; }
    ${active2} [data-hcv-project-more] > button {
      display: inline-flex; align-items: center; height: 24px;
      margin-inline-start: -8px; padding: 0 8px; border: 0; border-radius: 6px;
      background: transparent; color: light-dark(#8f8f8f, #8a8a8a); cursor: pointer;
      font: 400 14px/20px var(--hcv-ui-font); white-space: nowrap;
    }
    ${active2} [data-hcv-project-more] > button:hover { color: var(--hcv-text); }
    ${active2} [data-hcv-project-more] > button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -1px; }
    @media (prefers-reduced-motion: no-preference) {
      ${active2} [data-hcv-project-more] > button { transition: color 150ms ease; }
    }
  `;
}

// source/sidebar-projects.js
var media = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
var folderRows = "[data-sessions-project]:not([data-sessions-mode])";
var scope = '[data-sessions-mode="projects"]';
var sessionTitle = 'button[data-slot="row-button"] .hover-marquee';
var sidebarSessionRow = `[data-sessions-mode] .row-hover:has(${sessionTitle})`;
var scrollingRow = `:is(${sidebarSessionRow}, [data-hcv-recents-fallback] > button)`;
var projectSection = "[data-hcv-projects-section]";
var sectionHeader = "[data-hcv-projects-header]";
var projectRow = "[data-hcv-project-row]";
var sectionActions2 = "[data-hcv-projects-actions]";
var previewCard = "[data-hcv-project-preview]";
var sectionMotion = codexReference.disclosure;
function el(tag, attributes = {}, text) {
  const node3 = document.createElement(tag);
  for (const [key, value] of Object.entries(attributes)) node3.setAttribute(key, value);
  if (text !== void 0) node3.textContent = text;
  return node3;
}
function glyph(name) {
  const node3 = el("span", { "aria-hidden": "true", "data-hcv-icon": name });
  Object.assign(node3.style, codexIconStyle(name));
  return node3;
}
function projectStatus() {
  return el("span", { "data-hcv-project-status": "", role: "status", hidden: "" });
}
function showStatus(indicator, kind, t) {
  if (indicator.dataset.hcvProjectStatus !== kind) indicator.dataset.hcvProjectStatus = kind;
  if (kind) {
    const label3 = t(kind);
    if (indicator.getAttribute("aria-label") !== label3) indicator.setAttribute("aria-label", label3);
  }
  const hidden3 = !kind;
  if (indicator.hidden !== hidden3) indicator.hidden = hidden3;
}
function blockSize(node3) {
  const style = getComputedStyle(node3);
  return {
    height: `${node3.offsetHeight}px`,
    paddingBlockStart: style.paddingBlockStart,
    paddingBlockEnd: style.paddingBlockEnd
  };
}
function disclosure(button5, native2, region, regionId, timing = sectionMotion) {
  const direct = button5 === native2;
  const toggle2 = typeof native2 === "function" ? native2 : () => {
    if (native2.isConnected) native2.click();
  };
  const initialExpanded = button5.getAttribute("aria-expanded");
  const initialControls = button5.getAttribute("aria-controls");
  let pending = false;
  let forwarding = false;
  let motion2;
  let marked3;
  function toggleRegion() {
    forwarding = true;
    try {
      toggle2();
    } finally {
      forwarding = false;
    }
  }
  const restoreId = () => {
    if (marked3?.id === regionId) marked3.removeAttribute("id");
    marked3 = void 0;
  };
  function cancel() {
    const previous = motion2;
    motion2 = void 0;
    if (!previous) return;
    previous.height.cancel();
    previous.fade.cancel();
    previous.node.removeAttribute("data-hcv-disclosure-motion");
    if (previous.closing && !previous.wasInert) previous.node.inert = false;
  }
  function play(node3, opening, from, startOpacity) {
    cancel();
    if (!node3.isConnected || media()) {
      if (!opening && button5.isConnected) toggleRegion();
      return;
    }
    const natural = blockSize(node3);
    if (!node3.offsetHeight) {
      if (!opening && button5.isConnected) toggleRegion();
      return;
    }
    const wasInert = node3.inert;
    if (!opening) node3.inert = true;
    node3.setAttribute("data-hcv-disclosure-motion", "");
    const empty = { height: "0px", paddingBlockStart: "0px", paddingBlockEnd: "0px" };
    const height = node3.animate(
      [from || empty, opening ? natural : empty],
      { duration: timing.heightTime, easing: timing.ease, fill: "both" }
    );
    const fade = node3.animate(
      [{ opacity: startOpacity, scale: opening && !from ? ".98" : "1" }, { opacity: opening ? 1 : 0, scale: opening ? "1" : ".98" }],
      { duration: opening ? timing.enterTime : timing.exitTime, delay: opening && !from ? timing.enterDelay : 0, easing: timing.ease, fill: "both" }
    );
    const current = motion2 = { node: node3, height, fade, closing: !opening, wasInert };
    height.onfinish = () => {
      if (motion2 !== current) return;
      if (!opening && button5.isConnected && region() === node3) toggleRegion();
      cancel();
    };
  }
  function onClick(event) {
    if (forwarding) return;
    const node3 = region();
    const reduced = media();
    if (!node3 || reduced) {
      pending = !node3 && !reduced;
      if (!direct) toggleRegion();
      return;
    }
    if (direct) event.stopPropagation();
    const dimensions = blockSize(node3);
    const opacity = Number(getComputedStyle(node3).opacity);
    const opening = Boolean(motion2?.closing);
    button5.setAttribute("aria-expanded", String(opening));
    play(node3, opening, dimensions, opacity);
  }
  function onReducedMotion(event) {
    if (!event.matches || !motion2) return;
    const closing2 = motion2.closing && motion2.node === region();
    cancel();
    if (closing2 && button5.isConnected) toggleRegion();
  }
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  button5.addEventListener("click", onClick, direct);
  reducedMotion.addEventListener("change", onReducedMotion);
  return {
    sync() {
      const node3 = region();
      if (motion2 && motion2.node !== node3) cancel();
      if (node3 && pending) {
        pending = false;
        play(node3, true, null, 0);
      }
      if (marked3 !== node3) {
        restoreId();
        if (node3 && !node3.id) {
          node3.id = regionId;
          marked3 = node3;
        }
      }
      const expanded = Boolean(node3 && !motion2?.closing);
      if (button5.getAttribute("aria-expanded") !== String(expanded)) button5.setAttribute("aria-expanded", String(expanded));
      const controlId = node3?.id;
      if (controlId && button5.getAttribute("aria-controls") !== controlId) button5.setAttribute("aria-controls", controlId);
      else if (!controlId) button5.removeAttribute("aria-controls");
    },
    dispose() {
      cancel();
      restoreId();
      button5.removeEventListener("click", onClick, direct);
      reducedMotion.removeEventListener("change", onReducedMotion);
      if (direct) {
        if (initialExpanded === null) button5.removeAttribute("aria-expanded");
        else button5.setAttribute("aria-expanded", String(Boolean(region())));
        if (initialControls === null) button5.removeAttribute("aria-controls");
        else button5.setAttribute("aria-controls", initialControls);
      }
    }
  };
}
var projectMenu = '[data-row-actions] button[aria-haspopup="menu"]';
function nativeProject(trigger, id2) {
  for (let fiber = committedFiber(trigger); fiber; fiber = fiber.return) {
    const project2 = fiber.memoizedProps?.project;
    if (project2?.id === id2) return project2;
  }
}
function openNativeRename(entry, alive) {
  const trigger = entry?.row.querySelector(projectMenu);
  if (!trigger?.isConnected) return;
  trigger.focus({ preventScroll: true });
  trigger.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
  let remaining = 6;
  function select() {
    if (!alive() || !trigger.isConnected || trigger.getAttribute("aria-expanded") !== "true") return;
    const menu = document.getElementById(trigger.getAttribute("aria-controls"));
    if (menu) menu.querySelector('[role="menuitem"]:has(> .codicon-edit)')?.click();
    else if (--remaining) requestAnimationFrame(select);
  }
  requestAnimationFrame(select);
}
function positionSidebarPreview(card2, rect) {
  const gap = codexReference.sidebar.previewOffset;
  const width = card2.offsetWidth;
  const fitsRight = rect.right + width + gap + 8 <= innerWidth;
  const left = fitsRight ? rect.right + gap : rect.left - width - gap;
  card2.style.left = `${Math.max(8, Math.min(innerWidth - width - 8, left))}px`;
  card2.style.top = `${Math.max(8, Math.min(innerHeight - card2.offsetHeight - 8, rect.top))}px`;
}
function projectPreview(content, t) {
  const card2 = el("section", { "data-hcv-project-preview": "" });
  card2.hidden = true;
  const title = el("span");
  const heading = el("header");
  heading.append(glyph("folder"), title);
  const count = el("span");
  const sessions = el("div", { "data-hcv-project-preview-row": "" });
  sessions.append(glyph("messages"), count);
  const summary2 = el("div", { "data-hcv-project-preview-summary": "" });
  summary2.append(heading, sessions);
  const path = el("span");
  const folder = el("div", { "data-hcv-project-preview-row": "", "data-hcv-project-preview-path": "" });
  folder.append(glyph("folder"), path);
  const edit3 = el("button", { type: "button", "data-hcv-project-preview-row": "" });
  const editLabel = el("span");
  edit3.append(glyph("settings"), editLabel);
  const footer = el("div", { "data-hcv-project-preview-edit": "" });
  footer.append(edit3);
  card2.append(summary2, folder, footer);
  document.body.append(card2);
  let hovered;
  let showing;
  let timer;
  let delay;
  let cache;
  let alive = true;
  const supportsHover = window.matchMedia("(any-hover: hover) and (any-pointer: fine)");
  function close2() {
    clearTimeout(timer);
    clearTimeout(delay);
    hovered = void 0;
    showing?.row.removeAttribute("data-hcv-preview-open");
    showing = void 0;
    card2.hidden = true;
  }
  function position2() {
    if (!showing || !showing.row.isConnected || !content.isConnected) return close2();
    const rect = showing.row.getBoundingClientRect();
    if (rect.bottom <= 0 || rect.top >= innerHeight) return close2();
    positionSidebarPreview(card2, rect);
  }
  async function projectData(id2) {
    const connection = host2.state.connectionId.get();
    const profile2 = host2.state.profile.get();
    if (!profile2 || !connection || host2.state.gateway.get() !== "open") return;
    const key = JSON.stringify([connection, profile2]);
    const scopeMatches = () => connection === host2.state.connectionId.get() && profile2 === host2.state.profile.get();
    if (cache?.key !== key || Date.now() >= cache.until) {
      const result = (async () => {
        const routes = await host2.profileRoutes().catch(() => []);
        if (!alive || !scopeMatches()) return [];
        const route = routes.find((entry) => entry.connectionId === connection && entry.profile === profile2);
        const params = { preview_limit: 1 };
        const response3 = route ? await host2.requestProfile(route, "projects.tree", params, 5e3) : await host2.request("projects.tree", params, 5e3);
        return Array.isArray(response3?.projects) ? response3.projects : [];
      })().catch(() => []);
      cache = { key, until: Date.now() + 3e4, result };
    }
    const projects2 = await cache.result;
    return scopeMatches() ? projects2.find((item) => item.id === id2) : void 0;
  }
  async function show(entry) {
    if (!alive || !entry.row.isConnected || hovered !== entry) return;
    showing?.row.removeAttribute("data-hcv-preview-open");
    showing = entry;
    entry.row.setAttribute("data-hcv-preview-open", "");
    card2.setAttribute("aria-label", t("projectDetails"));
    editLabel.textContent = t("renameProject");
    title.textContent = entry.name.textContent;
    const trigger = entry.row.querySelector(projectMenu);
    const project2 = nativeProject(trigger, entry.id);
    sessions.hidden = true;
    folder.hidden = true;
    footer.hidden = !trigger || Boolean(project2?.isAuto || project2?.isNoProject);
    card2.hidden = false;
    if (!project2) position2();
    const data = project2 ?? await projectData(entry.id);
    if (!alive || showing !== entry || !data) return;
    if (Number.isFinite(data.sessionCount)) {
      count.textContent = t("projectChats", data.sessionCount);
      sessions.hidden = false;
    }
    if (typeof data.path === "string" && data.path) {
      path.textContent = data.path;
      folder.hidden = false;
    }
    position2();
  }
  function deferClose() {
    clearTimeout(timer);
    clearTimeout(delay);
    delay = setTimeout(close2, 110);
  }
  function onPointerDown(event) {
    if (!card2.contains(event.target)) close2();
  }
  function onEscape(event) {
    if (event.key === "Escape" && showing) close2();
  }
  edit3.addEventListener("click", () => {
    const entry = showing;
    close2();
    openNativeRename(entry, () => alive && entry?.row.isConnected);
  });
  card2.addEventListener("pointerenter", () => clearTimeout(delay));
  card2.addEventListener("pointerleave", deferClose);
  document.addEventListener("pointerdown", onPointerDown, true);
  document.addEventListener("keydown", onEscape, true);
  content.addEventListener("scroll", close2, true);
  window.addEventListener("resize", close2);
  const stopProfile = host2.state.profile.subscribe(() => {
    cache = void 0;
    close2();
  });
  const stopConnection = host2.state.connectionId.subscribe(() => {
    cache = void 0;
    close2();
  });
  return {
    attach(entry) {
      const enter = (event) => {
        if (!supportsHover.matches || event.pointerType !== "mouse" || event.buttons || !entry.row.querySelector(projectMenu)) return;
        clearTimeout(delay);
        clearTimeout(timer);
        hovered = entry;
        timer = setTimeout(() => {
          void show(entry);
        }, 350);
      };
      entry.name.addEventListener("pointerenter", enter);
      entry.row.addEventListener("pointerleave", deferClose);
      return () => {
        entry.name.removeEventListener("pointerenter", enter);
        entry.row.removeEventListener("pointerleave", deferClose);
        if (hovered === entry || showing === entry) close2();
      };
    },
    dispose() {
      alive = false;
      close2();
      stopProfile();
      stopConnection();
      content.removeEventListener("scroll", close2, true);
      window.removeEventListener("resize", close2);
      document.removeEventListener("pointerdown", onPointerDown, true);
      document.removeEventListener("keydown", onEscape, true);
      card2.remove();
    }
  };
}
function attachProjects(content, t, storage) {
  const rows = /* @__PURE__ */ new Map();
  const preview3 = projectPreview(content, t);
  const order = attachSidebarOrder(content, storage);
  const more = attachProjectMore(t);
  const measureTitles = trackTitleOverflow({ marquee: true });
  let section2;
  let reveal;
  let nativeProject2;
  function clearNativeProject() {
    nativeProject2 = void 0;
    content.removeAttribute("data-hcv-native-project-view");
  }
  function allowNativeProject(event) {
    if (localStorage.getItem("hermes.desktop.showAllProfiles") !== "true") return;
    const button5 = event.target instanceof Element ? event.target.closest('button[class~="group/more"]') : null;
    const project2 = button5?.closest("[data-sessions-project]:not([data-sessions-mode])");
    const id2 = project2?.dataset.sessionsProject;
    if (!id2 || button5.disabled || !content.contains(button5)) return;
    nativeProject2 = { id: id2, connection: host2.state.connectionId.get(), profile: host2.state.profile.get(), entered: false, until: Date.now() + 5e3 };
    content.setAttribute("data-hcv-native-project-view", "");
  }
  content.addEventListener("click", allowNativeProject, true);
  function clearSection() {
    if (!section2) return;
    section2.motion.dispose();
    section2.group.removeAttribute("data-hcv-projects-section");
    section2.header.removeAttribute("data-hcv-projects-header");
    section2.native.removeAttribute("data-hcv-native-project-action");
    section2.actions?.removeAttribute("data-hcv-projects-actions");
    section2.button.remove();
    section2.status.remove();
    section2 = void 0;
  }
  function clearRow(key, entry) {
    more.clear(entry);
    entry.detach();
    entry.motion?.dispose();
    entry.row.removeAttribute("data-hcv-project-row");
    entry.link.removeAttribute("data-hcv-native-project-action");
    entry.toggle?.removeAttribute("data-hcv-native-project-action");
    entry.name.remove();
    entry.status.remove();
    entry.empty?.remove();
    rows.delete(key);
  }
  function syncSection(tree) {
    const filter = tree?.querySelector(':scope > [data-slot="sidebar-group"] > div button:has(> .codicon-list-filter)');
    const group2 = filter?.closest('[data-slot="sidebar-group"]');
    const header2 = group2?.firstElementChild;
    const native2 = header2?.querySelector(":scope > button:not([data-hcv-section-toggle])");
    if (section2?.native !== native2) clearSection();
    if (!native2) return;
    if (!section2) {
      const button5 = el("button", { type: "button", "data-hcv-section-toggle": "" });
      const label3 = document.createTextNode("");
      const status2 = projectStatus();
      button5.append(label3, glyph("sidebarDisclosure"));
      native2.before(button5);
      native2.setAttribute("data-hcv-native-project-action", "");
      group2.setAttribute("data-hcv-projects-section", "");
      header2.setAttribute("data-hcv-projects-header", "");
      const actions = native2.nextElementSibling;
      actions?.setAttribute("data-hcv-projects-actions", "");
      header2.append(status2);
      const region = () => group2.querySelector(':scope > [data-slot="sidebar-group-content"]');
      section2 = { native: native2, button: button5, group: group2, header: header2, actions, label: label3, status: status2, motion: disclosure(button5, native2, region, "hcv-projects-list") };
    }
    const text = t("projects");
    if (section2.label.data !== text) section2.label.data = text;
    section2.motion.sync();
  }
  function syncActivity(tree = content.querySelector(scope)) {
    if (!tree) return;
    const activity = nativeProjectActivity(tree);
    if (section2) {
      const collapsedStatus = [...activity.values()].includes("working") ? "working" : activity.size ? "unread" : "";
      showStatus(section2.status, section2.button.ariaExpanded === "false" ? collapsedStatus : "", t);
    }
    for (const entry of rows.values()) {
      showStatus(entry.status, entry.name.ariaExpanded === "true" ? "" : activity.get(entry.id) || "", t);
    }
  }
  return {
    syncActivity,
    sync() {
      measureTitles(content.querySelectorAll(`${scrollingRow} .hover-marquee`));
      const view = content.querySelector("[data-sessions-mode]");
      const mode = view?.dataset.sessionsMode;
      if (reveal && (reveal.connection !== host2.state.connectionId.get() || reveal.profile !== host2.state.profile.get())) reveal = void 0;
      if (nativeProject2 && (localStorage.getItem("hermes.desktop.showAllProfiles") !== "true" || nativeProject2.connection !== host2.state.connectionId.get() || nativeProject2.profile !== host2.state.profile.get() || !nativeProject2.entered && Date.now() > nativeProject2.until || nativeProject2.entered && mode && mode !== "project")) clearNativeProject();
      if (mode === "project") {
        order.sync({ chats: [], projects: [] });
        if (nativeProject2?.id === view.dataset.sessionsProject) {
          nativeProject2.entered = true;
          for (const [key, entry] of rows) clearRow(key, entry);
          rows.clear();
          clearSection();
          return;
        }
        clearNativeProject();
        const back = view.querySelector('button[class~="group/back"]');
        const id2 = view.dataset.sessionsProject;
        if (back && (reveal?.back !== back || reveal.id !== id2)) {
          reveal = { back, id: id2, connection: host2.state.connectionId.get(), profile: host2.state.profile.get() };
          back.click();
        }
        return;
      }
      if (mode && mode !== "projects") reveal = void 0;
      const tree = content.querySelector(scope);
      syncSection(tree);
      const seen = /* @__PURE__ */ new Set();
      const projectLists = [];
      for (const item of tree?.querySelectorAll(folderRows) || []) {
        const row5 = item.querySelector(':scope > [class~="group/workspace"]');
        const link2 = row5?.querySelector(':scope > div > button:is([data-slot="row-button"], [data-slot="tooltip-trigger"]):not([data-row-actions])');
        const text = link2?.textContent.trim();
        if (!text) continue;
        const toggle2 = row5.querySelector(":scope > div > button[data-row-actions]:has(> .codicon-chevron-right)");
        const id2 = item.dataset.sessionsProject;
        const emptyKey = !toggle2 && id2 && id2 !== "home" ? JSON.stringify(["emptyProjectOpen", host2.state.connectionId.get(), host2.state.profile.get(), id2]) : null;
        seen.add(item);
        let entry = rows.get(item);
        let restoreFocus = false;
        let previousOpen;
        if (entry && (entry.link !== link2 || entry.toggle !== toggle2 || entry.emptyKey !== emptyKey)) {
          restoreFocus = document.activeElement === entry.name;
          if (entry.toggle && !toggle2) previousOpen = entry.name.ariaExpanded === "true";
          clearRow(item, entry);
          entry = void 0;
        }
        if (!entry) {
          const empty = emptyKey ? el("div", { "data-hcv-project-empty": "" }) : null;
          const expandable = Boolean(toggle2 || empty);
          const name = el(expandable ? "button" : "span", {
            ...expandable ? { type: "button", "data-row-actions": "" } : {},
            "data-hcv-project-name": ""
          }, text);
          const status2 = projectStatus();
          link2.before(name);
          row5.append(status2);
          row5.setAttribute("data-hcv-project-row", "");
          link2.setAttribute("data-hcv-native-project-action", "");
          toggle2?.setAttribute("data-hcv-native-project-action", "");
          const region = empty ? () => empty.hidden ? null : empty : () => item.querySelector(":scope > div.grid:not([data-hcv-project-row])");
          let action = toggle2;
          if (empty) {
            empty.hidden = !(previousOpen ?? storage.get(emptyKey, false) === true);
            empty.append(el("span"));
            item.append(empty);
            action = () => {
              empty.hidden = !empty.hidden;
              storage.set(emptyKey, !empty.hidden);
            };
          }
          const motion2 = action ? disclosure(name, action, region, `hcv-project-${encodeURIComponent(id2)}`) : null;
          entry = { item, row: row5, name, link: link2, toggle: toggle2, id: id2, region, motion: motion2, status: status2, empty, emptyKey };
          entry.detach = preview3.attach(entry);
          rows.set(item, entry);
          if (restoreFocus && expandable) name.focus({ preventScroll: true });
        } else if (entry.name.textContent !== text) entry.name.textContent = text;
        const emptyLabel = entry.empty?.firstElementChild;
        if (emptyLabel) {
          const label3 = t("recentEmpty");
          if (emptyLabel.textContent !== label3) emptyLabel.textContent = label3;
        }
        entry.motion?.sync();
        projectLists.push({ project: entry.id, list: entry.toggle ? entry.region() : null });
      }
      for (const [key, entry] of rows) if (!seen.has(key)) clearRow(key, entry);
      syncActivity(tree);
      order.sync({ chats: projectLists, projects: [...rows.values()] });
      more.sync([...rows.values()]);
      if (section2 && reveal) {
        if (section2.button.ariaExpanded === "false") {
          if (reveal.header !== section2.button) {
            reveal.header = section2.button;
            section2.button.click();
          }
        } else {
          const entry = [...rows.values()].find((row5) => row5.id === reveal.id);
          if (entry) {
            reveal = void 0;
            if (entry.name.ariaExpanded === "false") entry.name.click();
            entry.row.scrollIntoView({ block: "nearest" });
          }
        }
      }
    },
    dispose() {
      content.removeEventListener("click", allowNativeProject, true);
      clearNativeProject();
      measureTitles();
      order.dispose();
      more.dispose();
      for (const [key, entry] of rows) clearRow(key, entry);
      clearSection();
      preview3.dispose();
    }
  };
}
function projectSidebarStyles(active2) {
  const section2 = `${active2} ${projectSection}`;
  const header2 = `${active2} ${sectionHeader}`;
  const toggle2 = `${sectionHeader} > [data-hcv-section-toggle]`;
  const caret = '[data-hcv-icon="sidebarDisclosure"]';
  const row5 = `${active2} ${projectRow}`;
  const preview3 = `${active2} ${previewCard}`;
  const project2 = `${active2} ${folderRows}`;
  const nameFont = "430 14px/21px var(--hcv-ui-font)";
  const actions = `${header2} ${sectionActions2}`;
  const rowActions = `${row5} > [data-row-actions]`;
  const rowAction = `${rowActions} button`;
  const status2 = "[data-hcv-project-status]";
  const unread = '[data-hcv-project-status="unread"]:not([hidden])';
  const unreadHeader = `${header2}:has(> ${unread})`;
  const readAction = "button:has(> .codicon-check-all)";
  return `
  ${sidebarOrderStyles(active2)}
  ${projectMoreStyles(active2)}
  ${sidebarMarqueeStyles(`${active2} [data-tour="sessions-sidebar"] ${scrollingRow}`)}
  ${active2} [data-hcv-native-project-action] { display: none !important; }
  ${active2} [data-tour="sessions-sidebar"] [data-slot="sidebar-content"]:not([data-hcv-native-project-view]) [data-sessions-mode="project"]:has(button[class~="group/back"]) { visibility: hidden; }
  ${active2} [data-hcv-disclosure-motion] {
    flex: 0 0 auto;
    min-block-size: 0;
    box-sizing: border-box;
    overflow: clip;
    transform-origin: center bottom;
  }
  ${row5} > div:has(> [data-hcv-project-name]) { gap: 8px; padding-block: 0; }
  ${row5} [data-hcv-project-name] {
    min-inline-size: 0;
    flex: 1 1 auto;
    align-self: stretch;
    align-content: center;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    text-align: start;
    border-radius: 8px;
    color: var(--hcv-text);
    font: ${nameFont};
  }
  ${row5} button[data-hcv-project-name] { cursor: pointer; }
  ${row5} + div.grid { padding-block-start: 1px; }
  ${project2} .hover-marquee-inner { font: ${nameFont}; line-height: 20px; }
  ${project2} > [data-hcv-project-empty] {
    padding: 4px 32px;
    color: var(--hcv-muted);
    font: ${nameFont};
  }
  ${project2} > [data-hcv-project-empty] > span { opacity: .5; }
  ${row5} { position: relative; }
  ${row5}:is(:hover, [data-hcv-preview-open], [data-state="open"], :has(> [data-row-actions] button[data-state="open"])) {
    background-color: var(--hcv-sidebar-highlight);
  }
  ${rowActions} { padding-inline-end: 4px; }
  ${rowActions}, ${rowActions} > div[class~="group/group-actions"] > div { column-gap: 8px; }
  ${rowAction} {
    inline-size: 20px; block-size: 20px; padding: 0;
    border-color: transparent; background: transparent; box-shadow: none; color: var(--hcv-muted);
  }
  ${rowAction}::before { content: none; }
  ${rowAction}:is(:hover, :focus-visible, [data-state="open"]) {
    border-color: transparent; background: transparent; box-shadow: none; color: var(--hcv-text);
  }
  ${rowAction} > .codicon { font-size: 14px !important; }
  ${row5}:has(> ${status2}:not([hidden])) { padding-inline-end: 23px; }
  ${row5} > ${status2} {
    position: absolute; inset-inline-end: 5px; inset-block-start: 50%; translate: 0 -50%;
  }
  ${row5}:has(> [data-row-actions]):is(:hover, :has(:focus-visible, [data-state="open"]), [data-hcv-preview-open], [data-state="open"]) > ${status2} { opacity: 0; }
  ${header2} { min-block-size: 32px; padding: 0 4px 0 8px; column-gap: 0; }
  ${active2} ${toggle2} {
    display: flex; align-items: center; gap: 4px; min-block-size: 28px;
    flex: 1 1 0; min-inline-size: 0; align-self: stretch;
    border-radius: 7px; background-color: transparent; color: var(--hcv-sidebar-heading);
    font: 500 13px/18px var(--hcv-ui-font); cursor: pointer;
  }
  ${active2} ${toggle2} ${caret} { inline-size: 12px; block-size: 12px; flex: none; opacity: 0; }
  ${active2} ${toggle2}[aria-expanded="false"] ${caret} { rotate: -90deg; opacity: 1; }
  ${section2}:hover ${toggle2} ${caret}, ${active2} ${toggle2}:focus-visible ${caret} { opacity: 1; }
  ${actions} button { opacity: 0; inline-size: 26px; block-size: 26px; border-radius: 7px; }
  ${header2}:is(:hover, :focus-within) ${sectionActions2} button,
  ${actions}:has(button:is([aria-expanded="true"], [data-state="open"])) button { opacity: 1; }
  ${actions} > :has(.codicon-list-filter) { order: -1; }
  ${actions} > ${readAction} { display: none; }
  ${unreadHeader} ${sectionActions2} > ${readAction} {
    display: grid; order: 1; position: relative; opacity: 1; inline-size: 20px; block-size: 20px;
  }
  ${unreadHeader}:has(${sectionActions2} > button > .codicon-check-all) > ${unread} { display: none; }
  ${actions} > ${readAction} .codicon-check-all { opacity: 0; }
  ${actions} > ${readAction}::after {
    content: ''; position: absolute; inset: 0; margin: auto;
    inline-size: 7px; block-size: 7px; border-radius: 50%; background: var(--hcv-unread);
  }
  ${codexIconRules(`${actions} .codicon-list-filter`, "more")}
  ${codexIconRules(`${actions} .codicon-add`, "plus")}
  ${preview3} {
    position: fixed; z-index: 48; inline-size: min(${codexReference.sidebar.previewWidth}px, calc(100vw - 16px));
    display: flex; flex-direction: column; gap: 6px;
    max-block-size: calc(100vh - 16px); overflow: auto; padding: 8px; border-radius: ${codexReference.sidebar.previewRadius}px;
    background: var(--hcv-menu); box-shadow: 0 0 0 .5px var(--hcv-hairline), 0 8px 16px -4px #00000030;
    color: var(--hcv-text); font: 400 13px/20px var(--hcv-ui-font);
    opacity: 1; scale: 1; transform-origin: left top;
  }
  ${preview3}[hidden] { display: none; opacity: 0; scale: .97; pointer-events: none; }
  ${preview3} [hidden] { display: none; }
  ${preview3} [data-hcv-project-preview-summary] { display: flex; flex-direction: column; gap: 4px; }
  ${preview3} :is(header, [data-hcv-project-preview-row]):not([hidden]) {
    display: grid; grid-template-columns: 16px minmax(0, 1fr); align-items: center; gap: 6px;
  }
  ${preview3} header { font: 500 14px/20px var(--hcv-ui-font); }
  ${preview3} header > :last-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  ${preview3} [data-hcv-project-preview-row] { font-size: 13px; }
  ${preview3} :is([data-hcv-project-preview-path], [data-hcv-project-preview-edit]) {
    border-block-start: 1px solid var(--hcv-hairline); padding-block-start: 6px;
  }
  ${preview3} [data-hcv-project-preview-path] > :last-child { word-break: break-all; }
  ${preview3} [data-hcv-icon] { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; color: var(--hcv-muted); }
  ${preview3} button { inline-size: 100%; text-align: start; border-radius: 6px; cursor: pointer; }
  @supports (corner-shape: superellipse(1.5)) {
    ${preview3} { border-radius: ${codexReference.sidebar.previewRadius * 1.25}px; corner-shape: superellipse(1.5); }
  }
  ${active2} :is(${sectionHeader}, ${previewCard}) button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${preview3} button:focus-visible { background: var(--hcv-dropdown-hover); outline-offset: 0; }
  @media (hover: hover) and (pointer: fine) {
    ${preview3} button:hover { background: var(--hcv-dropdown-hover); }
  }
  @media (any-hover: none) {
    ${actions} button { opacity: 1; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${preview3} { transition: opacity 150ms var(--hcv-enter), scale 150ms var(--hcv-enter), display 150ms allow-discrete; }
    ${preview3}[hidden] { transition: opacity 100ms var(--hcv-exit), scale 100ms var(--hcv-exit), display 100ms allow-discrete; }
    @starting-style { ${preview3}:not([hidden]) { opacity: 0; scale: .95; } }
    ${preview3} button { transition: background-color 150ms var(--hcv-enter); }
    ${active2} ${toggle2} ${caret} { transition: opacity 150ms var(--hcv-enter), rotate 150ms var(--hcv-enter); }
  }
`;
}

// source/sidebar-chat-preview.js
import { createElement as h2 } from "react";
import { host as host3, SESSION_ROW_AREAS } from "@hermes/plugin-sdk";
var marker = "[data-hcv-preview-session]";
var preview = "[data-hcv-chat-preview]";
var row = ".row-hover:has(.hover-marquee-inner), [data-hcv-recents-fallback] > button";
var project = "[data-sessions-project]:not([data-sessions-mode])";
function registerChatPreviewMarker(ctx) {
  ctx.register({
    id: "chat-preview-session",
    area: SESSION_ROW_AREAS.trailing,
    data: { render: ({ sessionId }) => h2("span", { "data-hcv-preview-session": sessionId, hidden: true }) }
  });
}
function element(tag, attribute) {
  const node3 = document.createElement(tag);
  node3.setAttribute(attribute, "");
  return node3;
}
function ageLabel(dateTime) {
  const seconds = (Date.now() - Date.parse(dateTime)) / 1e3;
  if (!Number.isFinite(seconds)) return "";
  const ru = document.documentElement.matches(":lang(ru)");
  if (seconds < 60) return ru ? "\u0441\u0435\u0439\u0447\u0430\u0441" : "now";
  const units = ru ? ["\u0433", "\u043C\u0435\u0441", "\u043D", "\u0434", "\u0447", "\u043C"] : ["y", "mo", "w", "d", "h", "m"];
  const intervals = [31536e3, 2592e3, 604800, 86400, 3600, 60];
  const index = intervals.findIndex((interval) => seconds >= interval);
  return `${Math.floor(seconds / intervals[index])}${units[index]}`;
}
function scopeOf(node3) {
  const group2 = node3.closest("[data-gateway-group]");
  if (group2) {
    try {
      const [connection, profile2] = JSON.parse(group2.dataset.gatewayGroup);
      return { connectionId: connection ?? "local", profile: profile2 };
    } catch {
      return {};
    }
  }
  return { connectionId: host3.state.connectionId.get(), profile: host3.state.profile.get() };
}
function attachChatPreview(content) {
  const card2 = element("div", "data-hcv-chat-preview");
  card2.id = "hcv-sidebar-chat-preview";
  card2.setAttribute("role", "tooltip");
  card2.hidden = true;
  const header2 = element("div", "data-hcv-chat-preview-header");
  const subject = element("div", "data-hcv-chat-preview-subject");
  const title = element("span", "data-hcv-chat-preview-title");
  const computer = element("span", "data-hcv-chat-preview-computer");
  const age = element("time", "data-hcv-chat-preview-age");
  const folder = element("div", "data-hcv-chat-preview-project");
  const folderLabel = document.createElement("span");
  folder.append(folderLabel);
  subject.append(title, computer);
  header2.append(subject, age);
  card2.append(header2, folder);
  document.body.append(card2);
  const mouse = matchMedia("(any-hover: hover) and (any-pointer: fine)");
  let pending;
  let timer;
  let open;
  let button5;
  let description;
  function close2() {
    clearTimeout(timer);
    pending = null;
    open?.removeAttribute("data-hcv-chat-preview-open");
    open = null;
    if (button5?.getAttribute("aria-describedby") === [description, card2.id].filter(Boolean).join(" ")) {
      if (description) button5.setAttribute("aria-describedby", description);
      else button5.removeAttribute("aria-describedby");
    }
    button5 = null;
    card2.hidden = true;
  }
  function setAge(dateTime) {
    age.textContent = ageLabel(dateTime);
    age.hidden = !age.textContent;
    if (age.hidden) age.removeAttribute("datetime");
    else age.dateTime = dateTime;
  }
  function position2() {
    if (!open) return;
    const rect = open.getBoundingClientRect();
    if (!rect.width || rect.bottom <= 0 || rect.top >= innerHeight || open.closest("[inert], [hidden]")) {
      close2();
      return;
    }
    positionSidebarPreview(card2, rect);
  }
  async function show(target) {
    if (pending !== target || !target.isConnected || target.closest("[inert], [hidden]")) return;
    if (target.querySelector('[data-row-actions] [aria-expanded="true"]')) return;
    const titleNode = target.querySelector(".hover-marquee-inner") ?? target;
    title.textContent = titleNode.textContent.trim();
    if (!title.textContent) return;
    const { connectionId, profile: profile2 } = scopeOf(target);
    const ru = document.documentElement.matches(":lang(ru)");
    computer.hidden = connectionId !== "local";
    computer.setAttribute("role", "img");
    computer.setAttribute("aria-label", ru ? "\u042D\u0442\u043E\u0442 \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440" : "This device");
    folderLabel.textContent = target.closest(project)?.querySelector("[data-hcv-project-name]")?.textContent.trim() || "";
    folder.hidden = !folderLabel.textContent;
    setAge(target.querySelector("time[datetime]")?.dateTime ?? target.dataset.hcvPreviewTime ?? "");
    open = target;
    open.setAttribute("data-hcv-chat-preview-open", "");
    button5 = target.querySelector("button:has(.hover-marquee-inner)") ?? (target.matches("button") ? target : null);
    description = button5?.getAttribute("aria-describedby");
    button5?.setAttribute("aria-describedby", [description, card2.id].filter(Boolean).join(" "));
    card2.hidden = false;
    position2();
    const sessionId = target.querySelector(marker)?.dataset.hcvPreviewSession ?? target.dataset.hcvPreviewSession;
    if (!age.hidden || !sessionId || !connectionId || !profile2) return;
    try {
      const query = new URLSearchParams({ profile: profile2 });
      const result = await window.hermesDesktop.api({
        connectionId,
        profile: profile2,
        path: `/api/sessions/${encodeURIComponent(sessionId)}?${query}`,
        timeoutMs: 4e3
      });
      if (open !== target || scopeOf(target).connectionId !== connectionId || scopeOf(target).profile !== profile2) return;
      const seconds = Number(result?.last_active || result?.started_at);
      if (Number.isFinite(seconds) && seconds > 0) {
        const timestamp2 = new Date(seconds * 1e3);
        if (Number.isFinite(timestamp2.getTime())) setAge(timestamp2.toISOString());
      }
      position2();
    } catch {
    }
  }
  function enter(event) {
    const target = event.target.closest?.(row);
    if (!target || !content.contains(target)) return;
    if (event.target.closest("[data-row-actions], [data-reorder-handle]")) {
      close2();
      return;
    }
    const keyboard = event.type === "focusin";
    if (keyboard ? !event.target.matches(":focus-visible") : !mouse.matches || event.pointerType !== "mouse" || event.buttons) return;
    if (target === pending) return;
    close2();
    pending = target;
    timer = setTimeout(() => {
      void show(target);
    }, keyboard ? 0 : 350);
  }
  function leave(event) {
    if (pending?.contains(event.target) && !pending.contains(event.relatedTarget)) close2();
  }
  const onEscape = (event) => {
    if (event.key === "Escape") close2();
  };
  content.addEventListener("pointerover", enter);
  content.addEventListener("pointerout", leave);
  content.addEventListener("focusin", enter);
  content.addEventListener("focusout", leave);
  content.addEventListener("scroll", close2, true);
  document.addEventListener("pointerdown", close2, true);
  document.addEventListener("keydown", onEscape, true);
  window.addEventListener("resize", close2);
  const stopProfile = host3.state.profile.listen(close2);
  const stopConnection = host3.state.connectionId.listen(close2);
  return {
    sync() {
      if (pending && !pending.isConnected) close2();
    },
    dispose() {
      close2();
      stopProfile();
      stopConnection();
      content.removeEventListener("pointerover", enter);
      content.removeEventListener("pointerout", leave);
      content.removeEventListener("focusin", enter);
      content.removeEventListener("focusout", leave);
      content.removeEventListener("scroll", close2, true);
      document.removeEventListener("pointerdown", close2, true);
      document.removeEventListener("keydown", onEscape, true);
      window.removeEventListener("resize", close2);
      card2.remove();
    }
  };
}
function chatPreviewStyles(active2) {
  const card2 = `${active2} ${preview}`;
  return `
  ${card2} {
    position: fixed; z-index: 48; inline-size: min(320px, calc(100vw - 16px));
    box-sizing: border-box; padding: 6px 8px; display: flex; flex-direction: column; gap: 4px;
    border-radius: 12px; background: var(--hcv-menu); color: var(--hcv-text);
    box-shadow: 0 0 0 .5px var(--hcv-hairline), 0 8px 16px -4px #00000030;
    font: 430 13px/20px var(--hcv-ui-font); pointer-events: none;
  }
  ${card2}[hidden], ${card2} [hidden] { display: none; }
  ${active2}:has([data-hcv-chat-preview-open] .hover-marquee[data-state$="open"])
    [data-slot="tooltip-content"]:is([data-side="left"], [data-side="right"]) { visibility: hidden; }
  ${card2} [data-hcv-chat-preview-header] {
    display: flex; align-items: baseline; gap: 12px; padding-block-end: 2px; min-inline-size: 0;
  }
  ${card2} [data-hcv-chat-preview-subject] {
    display: flex; flex: 1; min-inline-size: 0; align-items: start; gap: 4px;
  }
  ${card2} [data-hcv-chat-preview-title] {
    display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3;
    min-inline-size: 0; overflow: hidden; overflow-wrap: anywhere; font: 500 14px/20px var(--hcv-ui-font);
  }
  ${card2} [data-hcv-chat-preview-computer] {
    flex: none; margin-block-start: 3px; inline-size: 14px; block-size: 14px;
    background: var(--hcv-sidebar-heading); mask: ${codexMask("chatPreviewComputer")} center / contain no-repeat;
  }
  ${card2} [data-hcv-chat-preview-age] {
    flex: none; color: var(--hcv-sidebar-heading); font-size: 12px; white-space: nowrap;
  }
  ${card2} [data-hcv-chat-preview-project] {
    display: flex; min-inline-size: 0; align-items: center; gap: 6px;
    overflow: hidden; white-space: nowrap;
  }
  ${card2} [data-hcv-chat-preview-project] > span { overflow: hidden; text-overflow: ellipsis; }
  ${card2} [data-hcv-chat-preview-project]::before {
    content: ''; flex: none; inline-size: 16px; block-size: 16px;
    background: var(--hcv-muted); mask: ${codexMask("folder")} center / contain no-repeat;
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${card2} { border-radius: 15px; corner-shape: superellipse(1.5); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${card2}:not([hidden]) { animation: hcv-chat-preview-in 150ms ${codexReference.enter}; }
    @keyframes hcv-chat-preview-in { from { opacity: 0; } }
  }
  `;
}

// source/sidebar-cron.js
import { host as host4, translateNow } from "@hermes/plugin-sdk";
var projects = '[data-sessions-mode="projects"]';
var nativeSection = "[data-hcv-cron-native]";
var nativeRows = '[class~="group/cron"]';
var nativeRowToggle = "> button[aria-expanded]";
var motion = { ...codexReference.disclosure, heightTime: 220, enterTime: 170, enterDelay: 0, exitTime: 120 };
function element2(tag, attrs = {}, value) {
  const node3 = document.createElement(tag);
  for (const [name, attr] of Object.entries(attrs)) node3.setAttribute(name, attr);
  if (value) node3.textContent = value;
  return node3;
}
function glyph2(name) {
  const node3 = element2("span", { "aria-hidden": "true", "data-hcv-cron-icon": name });
  Object.assign(node3.style, codexIconStyle(name));
  return node3;
}
function nextRun(job) {
  const time = Date.parse(job.next_run_at || "");
  return Number.isFinite(time) ? time : Infinity;
}
function attachNativeCron(content) {
  const headings = ':scope > [data-sessions-mode] > [data-slot="sidebar-group"] > [class~="group/section"] > button[class~="group/section-label"]';
  let heading;
  let group2;
  let section2;
  let nextId = 0;
  const rows = /* @__PURE__ */ new Map();
  function dispose() {
    for (const row5 of rows.values()) row5.dispose();
    rows.clear();
    section2?.dispose();
    section2 = void 0;
    group2?.removeAttribute("data-hcv-cron-native");
    group2 = void 0;
  }
  return {
    sync() {
      const label3 = translateNow("sidebar.cronJobs");
      const current = [...content.querySelectorAll(headings)].find((node3) => node3.textContent.trim() === label3);
      if (current !== heading) {
        dispose();
        heading = current;
        if (heading) {
          group2 = heading.closest('[data-slot="sidebar-group"]');
          group2.setAttribute("data-hcv-cron-native", "");
          section2 = disclosure(heading, heading, () => group2.querySelector(':scope > [data-slot="sidebar-group-content"]'), "hcv-native-cron-list", motion);
        }
      }
      if (!group2) return;
      section2.sync();
      const visible = new Set(group2.querySelectorAll(`${nativeRows} ${nativeRowToggle}`));
      for (const [button5, row5] of rows) {
        if (visible.has(button5)) continue;
        row5.dispose();
        rows.delete(button5);
      }
      for (const button5 of visible) {
        if (!rows.has(button5)) {
          const shell = button5.parentElement;
          rows.set(button5, disclosure(button5, button5, () => shell.nextElementSibling, `hcv-native-cron-runs-${++nextId}`, motion));
        }
        rows.get(button5).sync();
      }
    },
    dispose
  };
}
function attachSidebarCron(content, storage) {
  const native2 = attachNativeCron(content);
  const ru = () => document.documentElement.matches(":lang(ru)");
  const area = element2("section", { "data-hcv-cron-sidebar": "" });
  const header2 = element2("header");
  const toggle2 = element2("button", { type: "button", "aria-controls": "hcv-cron-sidebar-list" });
  const toggleLabel = document.createTextNode("");
  toggle2.append(toggleLabel);
  toggle2.append(glyph2("right"));
  const all = element2("button", { type: "button", "data-hcv-cron-manage": "" });
  all.append(glyph2("schedule"));
  all.addEventListener("click", () => host4.navigate("/cron"));
  header2.append(toggle2, all);
  const details = element2("div", { id: "hcv-cron-sidebar-list", "data-hcv-cron-body": "" });
  const list = element2("div", { "data-hcv-cron-list": "" });
  details.append(list);
  area.append(header2, details);
  let open = storage.get("cron-preview-open", false) === true;
  let generation = 0;
  let status2 = null;
  function updateDisclosure() {
    toggle2.setAttribute("aria-expanded", String(open));
    details.inert = !open;
    area.toggleAttribute("data-hcv-cron-open", open);
  }
  function note(kind) {
    status2 = kind;
    const words3 = ru() ? { profile: "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D", loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026", empty: "\u0412 \u044D\u0442\u043E\u043C \u043F\u0440\u043E\u0444\u0438\u043B\u0435 \u043D\u0435\u0442 \u0437\u0430\u0434\u0430\u0447", error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0437\u0430\u0434\u0430\u0447\u0438" } : { profile: "No profile selected", loading: "Loading\u2026", empty: "No tasks in this profile", error: "Could not load tasks" };
    const text = words3[kind];
    const current = list.childElementCount === 1 && list.firstElementChild?.matches('[role="status"]') ? list.firstElementChild : null;
    if (!current) list.replaceChildren(element2("p", { role: "status" }, text));
    else if (current.textContent !== text) current.textContent = text;
  }
  function localize() {
    const label3 = ru() ? "Cron-\u0437\u0430\u0434\u0430\u0447\u0438" : "Cron jobs";
    const allLabel = ru() ? "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0437\u0430\u0434\u0430\u0447\u0438" : "Open scheduled tasks";
    if (toggleLabel.data !== label3) toggleLabel.data = label3;
    if (all.getAttribute("aria-label") !== allLabel) all.setAttribute("aria-label", allLabel);
    if (all.title !== allLabel) all.title = allLabel;
    if (status2) note(status2);
  }
  async function load() {
    if (!open || !area.isConnected) return;
    const request = ++generation;
    const profile2 = host4.state.profile.get();
    const connectionId = host4.state.connectionId.get();
    const isCurrent = () => request === generation && area.isConnected && open && profile2 === host4.state.profile.get() && connectionId === host4.state.connectionId.get();
    if (!profile2) {
      note("profile");
      return;
    }
    note("loading");
    try {
      const path = `/api/cron/jobs?profile=${encodeURIComponent(profile2)}`;
      const jobs = await window.hermesDesktop.api({ ...connectionId ? { connectionId } : {}, profile: profile2, path, timeoutMs: 8e3 });
      if (!isCurrent()) return;
      const named = jobs.filter((job) => typeof job?.id === "string" && job.id).map((job) => ({ ...job, label: typeof job.name === "string" && job.name.trim() || job.id }));
      named.sort((a, b) => nextRun(a) - nextRun(b) || a.label.localeCompare(b.label));
      status2 = null;
      list.replaceChildren();
      for (const job of named.slice(0, 3)) {
        const row5 = element2("button", { type: "button", title: job.label, "data-hcv-cron-job": "" });
        row5.append(glyph2("schedule"), element2("span", { "data-hcv-cron-label": "" }, job.label), glyph2("right"));
        row5.addEventListener("click", () => {
          if (isCurrent() && !manageSidebarCronJob(content.querySelector(projects), job.id)) host4.navigate("/cron");
        });
        list.append(row5);
      }
      if (!named.length) note("empty");
    } catch {
      if (isCurrent()) note("error");
    }
  }
  toggle2.addEventListener("click", () => {
    open = !open;
    storage.set("cron-preview-open", open);
    updateDisclosure();
    if (open) void load();
    else ++generation;
  });
  localize();
  updateDisclosure();
  const stopProfile = host4.state.profile.subscribe(load);
  const stopConnection = host4.state.connectionId.subscribe(load);
  const stopCron = host4.onEvent?.("cron.changed", load);
  return {
    sync() {
      localize();
      native2.sync();
      const tree = content.querySelector(`:scope > ${projects}`);
      if (!tree || !content.querySelector('[data-tour="sidebar-nav-cron"]')) {
        if (area.isConnected) {
          ++generation;
          area.remove();
        }
        return;
      }
      if (area.previousElementSibling !== tree) {
        tree.after(area);
        void load();
      }
    },
    dispose() {
      ++generation;
      native2.dispose();
      stopProfile();
      stopConnection();
      stopCron?.();
      area.remove();
    }
  };
}
function sidebarCronStyles(active2) {
  const section2 = `${active2} [data-hcv-cron-sidebar]`;
  const stock = `${active2} ${nativeSection}`;
  const heading = `${stock} > div > button[class~="group/section-label"]`;
  const row5 = `${stock} ${nativeRows}`;
  const rowLabel = `${nativeRowToggle} > .truncate`;
  const trailing = `${row5} > [data-row-actions] > div`;
  const rowCaret = `${nativeRowToggle} > .codicon-chevron-right`;
  const caret = `${row5} ${rowCaret}`;
  const run = `${row5} + div > button`;
  return `
  ${section2} { flex: none; padding: 2px 5px 4px; }
  ${section2} > header { display: flex; align-items: center; justify-content: space-between; min-block-size: 28px; }
  ${section2} button {
    display: flex; align-items: center; gap: 6px; min-inline-size: 0; min-block-size: 26px;
    padding: 0 6px; border-radius: 7px; color: var(--hcv-muted); font: 500 12px/18px var(--hcv-ui-font);
  }
  ${section2} button:is(:hover, :focus-visible) { color: var(--hcv-text); background: var(--hcv-hover); }
  ${section2} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${section2} [data-hcv-cron-icon] { display: block; inline-size: 14px; block-size: 14px; flex: none; }
  ${section2} [aria-expanded="true"] > [data-hcv-cron-icon] { rotate: 90deg; }
  ${section2} [data-hcv-cron-manage] { inline-size: 26px; padding: 0; justify-content: center; }
  ${section2} [data-hcv-cron-body] { display: grid; grid-template-rows: 0fr; opacity: 0; }
  ${section2}[data-hcv-cron-open] [data-hcv-cron-body] { grid-template-rows: 1fr; opacity: 1; }
  ${section2} [data-hcv-cron-list] { min-block-size: 0; overflow: hidden; }
  ${section2} [data-hcv-cron-job] { inline-size: 100%; text-align: start; padding-inline: 8px; }
  ${section2} [data-hcv-cron-label] { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  ${section2} [data-hcv-cron-job] > [data-hcv-cron-icon="right"] { opacity: 0; }
  ${section2} [data-hcv-cron-job]:is(:hover, :focus-visible) > [data-hcv-cron-icon="right"] { opacity: 1; }
  ${section2} p { margin: 0; padding: 4px 6px; color: var(--hcv-muted); font-size: 12px; }

  ${heading} { min-block-size: 26px; padding-inline: 0 6px; gap: 6px; border-radius: 7px; }
  ${heading}:is(:hover, :focus-visible), ${row5}:is(:hover, :focus-within), ${run}:is(:hover, :focus-visible) {
    background-color: var(--hcv-hover);
    color: var(--hcv-text);
  }
  ${row5} { border-radius: 8px; }
  ${heading}:is(:hover, :focus-visible) > span, ${row5}:is(:hover, :focus-within) ${rowLabel} {
    color: var(--hcv-text);
  }
  ${row5} ${nativeRowToggle} { border-radius: inherit; }
  ${row5} ${nativeRowToggle}:focus-visible { background-color: transparent; box-shadow: none; }
  ${trailing} { display: grid; align-items: center; }
  ${trailing} > :is(span, div) { grid-area: 1 / 1; justify-self: end; }
  ${trailing} > span { display: inline; }
  ${trailing} > div { display: flex; gap: 2px; opacity: 0; pointer-events: none; }
  ${row5}:is(:hover, :focus-within) > [data-row-actions] > div > span { opacity: 0; }
  ${row5}:is(:hover, :focus-within) > [data-row-actions] > div > div { opacity: 1; pointer-events: auto; }
  ${trailing} button { inline-size: 24px; block-size: 24px; border-radius: 7px; }
  ${trailing} button:is(:hover, :focus-visible):enabled { color: var(--hcv-text); background-color: var(--hcv-hover); }
  ${stock} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${stock} :is(.codicon-chevron-right, .codicon-zap, .codicon-watch) { inline-size: 14px; block-size: 14px; }
  ${codexIconRules(`${heading} > .codicon-chevron-right, ${caret}`, "right")}
  ${codexIconRules(`${trailing} .codicon-zap`, "bolt")}
  ${codexIconRules(`${trailing} .codicon-watch`, "schedule")}
  ${heading} > .codicon-chevron-right { opacity: 1; }
  ${heading} > .codicon-chevron-right, ${caret} { rotate: 0deg; transform: none; transition: none; }
  ${heading}[aria-expanded="true"] > .codicon-chevron-right,
  ${row5} > button[aria-expanded="true"] > .codicon-chevron-right { opacity: 1; rotate: 90deg; }
  ${row5}:is(:hover, :focus-within) ${rowCaret} { opacity: 1; }
  @media (any-hover: none) {
    ${trailing} > span { opacity: 0; }
    ${trailing} > div { opacity: 1; pointer-events: auto; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${section2} [data-hcv-cron-body] { transition: grid-template-rows ${motion.heightTime}ms ${motion.ease}, opacity 150ms ${motion.ease}; }
    ${section2} [data-hcv-cron-icon="right"] { transition: rotate 150ms var(--hcv-enter); }
    ${section2} button, ${heading}, ${row5}, ${trailing} button, ${run} {
      transition: background-color 120ms var(--hcv-ease), color 120ms var(--hcv-ease);
    }
    ${heading} > span, ${row5} ${rowLabel} { transition: color 120ms var(--hcv-ease); }
    ${section2} [data-hcv-cron-job] > [data-hcv-cron-icon="right"], ${trailing} > :is(span, div) {
      transition: opacity 120ms var(--hcv-ease);
    }
    ${heading} > .codicon-chevron-right, ${caret} { transition: rotate 150ms var(--hcv-enter), opacity 120ms var(--hcv-ease); }
  }
  `;
}

// source/chrome.js
function icon(name) {
  return h3("span", { "aria-hidden": true, "data-hcv-icon": name, style: codexIconStyle(name) });
}
var sideSelector = '[data-tour="sessions-sidebar"]';
var filterButton = "button:has(> .codicon-list-filter)";
var filterSelector = `${sideSelector} ${filterButton}`;
var flatSelector = '[data-sessions-mode="flat"]:has(button > .codicon-list-filter)';
var newChatSelector = `${sideSelector} button:has(> [data-tour="sidebar-nav-new-session"])`;
var selectedTerminal = '[data-tree-tab="terminal"][aria-selected="true"]';
var toolbarOffsetEvent = "hcv:toolbar-offset";
var russianPlurals = new Intl.PluralRules("ru");
var sidebarCopy = {
  en: {
    projects: "Projects",
    showMore: "Show more",
    recent: "Recent",
    recentActions: "Recent chats actions",
    newChat: "New chat",
    refreshRecent: "Refresh recent chats",
    findSession: "Find a session",
    recentEmpty: "No chats",
    recentLoading: "Loading\u2026",
    recentProfile: "Open a Hermes profile",
    recentUnavailable: "Recent chats unavailable. Reopen this list.",
    recentRefreshError: "Could not refresh recent chats",
    recentOpenError: "Could not open the chat. Reopen this list.",
    untitledChat: "Untitled chat",
    projectDetails: "Project details",
    renameProject: "Rename project",
    working: "Working",
    unread: "Unread chats",
    projectChats: (count) => `${count} ${count === 1 ? "chat" : "chats"}`,
    noTerminals: "No open terminals",
    terminalShortcut: "Use the New terminal shortcut to start a shell.",
    terminalUnbound: "Set a shortcut for New terminal in Keyboard shortcuts."
  },
  ru: {
    projects: "\u041F\u0440\u043E\u0435\u043A\u0442\u044B",
    showMore: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0431\u043E\u043B\u044C\u0448\u0435",
    recent: "\u041D\u0435\u0434\u0430\u0432\u043D\u0438\u0435",
    recentActions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u043C\u0438",
    newChat: "\u041D\u043E\u0432\u044B\u0439 \u0447\u0430\u0442",
    refreshRecent: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0435",
    findSession: "\u041D\u0430\u0439\u0442\u0438 \u0441\u0435\u0430\u043D\u0441",
    recentEmpty: "\u041D\u0435\u0442 \u0447\u0430\u0442\u043E\u0432",
    recentLoading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
    recentProfile: "\u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043D\u0443\u0436\u043D\u044B\u0439 \u043F\u0440\u043E\u0444\u0438\u043B\u044C Hermes",
    recentUnavailable: "\u0421\u043F\u0438\u0441\u043E\u043A \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0435\u0433\u043E \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E.",
    recentRefreshError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u0447\u0430\u0442\u044B",
    recentOpenError: "\u0427\u0430\u0442 \u043D\u0435 \u043E\u0442\u043A\u0440\u044B\u043B\u0441\u044F. \u041E\u0431\u043D\u043E\u0432\u0438\u0442\u0435 \u0441\u043F\u0438\u0441\u043E\u043A.",
    untitledChat: "\u0427\u0430\u0442 \u0431\u0435\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F",
    projectDetails: "\u041E \u043F\u0440\u043E\u0435\u043A\u0442\u0435",
    renameProject: "\u041F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442",
    working: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435",
    unread: "\u0415\u0441\u0442\u044C \u043D\u0435\u043F\u0440\u043E\u0447\u0438\u0442\u0430\u043D\u043D\u044B\u0435 \u0447\u0430\u0442\u044B",
    projectChats: (count) => `${count} ${{ one: "\u0447\u0430\u0442", few: "\u0447\u0430\u0442\u0430" }[russianPlurals.select(count)] || "\u0447\u0430\u0442\u043E\u0432"}`,
    noTerminals: "\u041D\u0435\u0442 \u043E\u0442\u043A\u0440\u044B\u0442\u044B\u0445 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u043E\u0432",
    terminalShortcut: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0435 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0443 \u0441\u043E\u0447\u0435\u0442\u0430\u043D\u0438\u0435\u043C \xAB\u041D\u043E\u0432\u044B\u0439 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\xBB.",
    terminalUnbound: "\u0417\u0430\u0434\u0430\u0439\u0442\u0435 \u0441\u043E\u0447\u0435\u0442\u0430\u043D\u0438\u0435 \xAB\u041D\u043E\u0432\u044B\u0439 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\xBB \u0432 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430\u0445 \u043A\u043B\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u044B."
  }
};
function visibleControl(selector) {
  return [...document.querySelectorAll(selector)].find(
    (control4) => !control4.disabled && !control4.closest("[inert], [hidden]") && control4.getClientRects().length && getComputedStyle(control4).visibility === "visible"
  );
}
function newChat() {
  const native2 = visibleControl(newChatSelector);
  if (native2) native2.click();
  else host5.newChat();
}
function openGrouping() {
  const trigger = visibleControl(filterSelector);
  if (!trigger) return;
  trigger.focus({ preventScroll: true });
  trigger.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
}
function edit(command2) {
  const input = visibleControl('[data-chat-surface][data-composer-target="main"] [data-slot="composer-rich-input"]');
  if (!input) return;
  input.focus();
  if (command2 === "selectAll") document.execCommand(command2);
  else input.dispatchEvent(new KeyboardEvent("keydown", {
    key: "z",
    code: "KeyZ",
    ctrlKey: true,
    shiftKey: command2 === "redo",
    bubbles: true,
    cancelable: true
  }));
}
function WindowMenus({ menus: menus2, label: label3 }) {
  const [current, setCurrent] = useState(null);
  const openMenu = useRef(null);
  const triggers = useRef(/* @__PURE__ */ new Map());
  const menuOpen = current !== null;
  useLayoutEffect(() => {
    if (!menuOpen) return;
    const root = document.documentElement;
    root.setAttribute("data-hcv-window-menu-open", "");
    return () => root.removeAttribute("data-hcv-window-menu-open");
  }, [menuOpen]);
  function show(id2) {
    openMenu.current = id2;
    setCurrent(id2);
  }
  useEffect(() => {
    const wide = window.matchMedia("(forced-colors: none) and (min-width: 800px) and (min-height: 480px)");
    const dismiss = () => show(null);
    wide.addEventListener("change", dismiss);
    window.addEventListener("blur", dismiss);
    return () => {
      wide.removeEventListener("change", dismiss);
      window.removeEventListener("blur", dismiss);
    };
  }, []);
  function move(event, index) {
    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    event.preventDefault();
    const offset = event.key === "ArrowLeft" ? -1 : 1;
    const [id2] = menus2[(index + offset + menus2.length) % menus2.length];
    if (openMenu.current) show(id2);
    else triggers.current.get(id2)?.focus();
  }
  return h3("nav", { "aria-label": label3, "data-hcv-window-menu": "" }, menus2.map(([id2, label4, items2], index) => {
    const open = current === id2;
    const change = (next) => {
      if (next || openMenu.current === id2) show(next ? id2 : null);
    };
    return h3(
      DropdownMenu,
      { key: id2, modal: false, open, onOpenChange: change },
      h3(DropdownMenuTrigger, { asChild: true }, h3("button", {
        type: "button",
        ref: (node3) => {
          if (node3) triggers.current.set(id2, node3);
          else triggers.current.delete(id2);
        },
        "data-hcv-menu-button": "",
        onPointerEnter: (event) => {
          if (event.pointerType === "mouse" && !event.buttons && openMenu.current && openMenu.current !== id2) show(id2);
        },
        onKeyDown: (event) => move(event, index),
        onClick: (event) => {
          if (event.detail === 0) change(!open);
        }
      }, label4)),
      open && h3(DropdownMenuContent, {
        align: "start",
        sideOffset: 0,
        collisionPadding: 6,
        "data-hcv-window-menu-content": id2,
        onKeyDown: (event) => move(event, index),
        onCloseAutoFocus: (event) => {
          if (openMenu.current) event.preventDefault();
        },
        onInteractOutside: (event) => {
          if (event.target.closest?.("[data-hcv-menu-button]")) event.preventDefault();
        }
      }, items2.map(([title, run, disabled, shortcut], position2) => title === null ? h3(DropdownMenuSeparator, { key: position2 }) : h3(
        DropdownMenuItem,
        {
          key: title,
          textValue: title,
          disabled: typeof disabled === "function" ? disabled() : disabled,
          onSelect: () => setTimeout(run, 0)
        },
        h3("span", { "data-hcv-window-menu-label": "" }, title),
        shortcut && h3("span", { "data-hcv-window-menu-shortcut": "", "aria-hidden": true }, shortcut())
      )))
    );
  }));
}
function windowMenuShortcut(action, fallback) {
  return () => keybindLabel(action, fallback, "+");
}
function WindowChrome({ themeName: themeName2, recentRows }) {
  const selected = useTheme().themeName === themeName2;
  const { locale } = useI18n();
  const [historyState, setHistoryState] = useState({ back: false, forward: false });
  useLayoutEffect(() => {
    if (!selected) return;
    const root = document.documentElement;
    root.setAttribute("data-hcv-window-chrome", "");
    return () => root.removeAttribute("data-hcv-window-chrome");
  }, [selected]);
  useEffect(() => {
    if (!selected || !window.navigation) return;
    const update = () => {
      const { canGoBack: back, canGoForward: forward } = window.navigation;
      setHistoryState((previous) => previous.back === back && previous.forward === forward ? previous : { back, forward });
    };
    update();
    window.navigation.addEventListener("currententrychange", update);
    return () => window.navigation.removeEventListener("currententrychange", update);
  }, [selected]);
  if (!selected) return null;
  const ru = locale?.toLowerCase().startsWith("ru");
  const text = ru ? {
    menu: "\u041C\u0435\u043D\u044E \u043E\u043A\u043D\u0430",
    file: "\u0424\u0430\u0439\u043B",
    newChat: "\u041D\u043E\u0432\u044B\u0439 \u0447\u0430\u0442",
    projectFiles: "\u0424\u0430\u0439\u043B\u044B \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    settings: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
    edit: "\u041F\u0440\u0430\u0432\u043A\u0430",
    undo: "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0432\u0432\u043E\u0434",
    redo: "\u041F\u043E\u0432\u0442\u043E\u0440\u0438\u0442\u044C \u0432\u0432\u043E\u0434",
    selectAll: "\u0412\u044B\u0434\u0435\u043B\u0438\u0442\u044C \u0442\u0435\u043A\u0441\u0442 \u0432\u0432\u043E\u0434\u0430",
    view: "\u0412\u0438\u0434",
    sessions: "\u0421\u0435\u0430\u043D\u0441\u044B",
    bots: "\u0411\u043E\u0442\u044B",
    grouping: "\u0413\u0440\u0443\u043F\u043F\u0438\u0440\u043E\u0432\u043A\u0430 \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432 \u0438 \u0447\u0430\u0442\u043E\u0432",
    right: "\u041F\u0440\u0430\u0432\u0430\u044F \u043F\u0430\u043D\u0435\u043B\u044C",
    help: "\u0421\u043F\u0440\u0430\u0432\u043A\u0430",
    about: "\u041E \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0435",
    back: "\u041D\u0430\u0437\u0430\u0434",
    forward: "\u0412\u043F\u0435\u0440\u0451\u0434"
  } : {
    menu: "Window menu",
    file: "File",
    newChat: "New chat",
    projectFiles: "Project files",
    settings: "Settings",
    edit: "Edit",
    undo: "Undo typing",
    redo: "Redo typing",
    selectAll: "Select input text",
    view: "View",
    sessions: "Sessions",
    bots: "Bots",
    grouping: "Group projects and chats",
    right: "Right sidebar",
    help: "Help",
    about: "About",
    back: "Back",
    forward: "Forward"
  };
  const menus2 = [
    ["file", text.file, [
      [text.newChat, newChat, false, windowMenuShortcut("session.new", "mod+n")],
      [text.projectFiles, () => host5.revealPane("files")],
      [null],
      [text.settings, () => host5.navigate("/settings"), false, windowMenuShortcut("nav.settings", "mod+,")]
    ]],
    ["edit", text.edit, [
      [text.undo, () => edit("undo")],
      [text.redo, () => edit("redo")],
      [null],
      [text.selectAll, () => edit("selectAll")]
    ]],
    ["view", text.view, [
      [text.sessions, () => host5.revealPane("sessions")],
      [text.bots, () => host5.revealPane("hermes-bots:pane")],
      [null],
      [text.grouping, openGrouping, () => !visibleControl(filterSelector)],
      [text.right, () => visibleControl('[data-tour="right-pane-toggle"]')?.click(), false, windowMenuShortcut("view.toggleRightSidebar", "mod+j")]
    ]],
    ["help", text.help, [[text.about, () => host5.navigate("/settings?tab=about")]]]
  ];
  return h3(
    Fragment,
    null,
    h3(
      "div",
      { "data-hcv-history": "" },
      h3("button", { type: "button", "aria-label": text.back, title: text.back, disabled: !historyState.back, onClick: () => history.back() }, icon("back")),
      h3("button", { type: "button", "aria-label": text.forward, title: text.forward, disabled: !historyState.forward, onClick: () => history.forward() }, icon("forward"))
    ),
    h3(WindowMenus, { menus: menus2, label: text.menu }),
    h3(NativeRecentRows, { rows: recentRows })
  );
}
function element3(tag, attrs = {}, text) {
  const node3 = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) node3.setAttribute(key, value);
  if (text) node3.textContent = text;
  return node3;
}
function appendIcon(node3, name) {
  const glyph3 = element3("span", { "aria-hidden": "true", "data-hcv-icon": name });
  Object.assign(glyph3.style, codexIconStyle(name));
  node3.append(glyph3);
}
function sidebarButton(label3, symbol, onClick) {
  const button5 = element3("button", { type: "button", "aria-label": label3, title: label3 });
  appendIcon(button5, symbol);
  if (onClick) button5.addEventListener("click", onClick);
  return button5;
}
function recentsControl(groupId, rows, t) {
  const area = element3("div", { "data-hcv-recents": "" });
  const id2 = `hcv-recents-${groupId}`;
  const body2 = element3("div", { id: id2, "data-hcv-recents-body": "" });
  const list = element3("div", { "data-hcv-recents-list": "" });
  const fallback = element3("div", { "data-hcv-recents-fallback": "", hidden: "" });
  body2.append(list, fallback);
  body2.inert = true;
  const button5 = element3("button", { type: "button", "aria-expanded": "false", "aria-controls": id2 });
  const label3 = document.createTextNode("");
  button5.dataset.hcvRecentsToggle = "";
  button5.append(label3);
  appendIcon(button5, "sidebarDisclosure");
  const header2 = element3("div", { "data-hcv-recents-header": "" });
  const actions = element3("div", { "data-hcv-recents-actions": "" });
  const popup = element3("div", { popover: "auto", "data-hcv-recents-menu": "" });
  const more = sidebarButton(t("recentActions"), "more", () => {
    const rect = more.getBoundingClientRect();
    popup.style.left = `${Math.max(8, Math.min(window.innerWidth - 218, rect.left))}px`;
    popup.style.top = `${Math.max(8, rect.bottom + 84 < window.innerHeight ? rect.bottom + 4 : rect.top - 84)}px`;
  });
  more.popoverTargetElement = popup;
  more.setAttribute("aria-expanded", "false");
  popup.addEventListener("toggle", (event) => more.setAttribute("aria-expanded", String(event.newState === "open")));
  const add = sidebarButton(t("newChat"), "newChat", newChat);
  const refresh = element3("button", { type: "button", autofocus: "" });
  const all = element3("button", { type: "button" });
  function localize() {
    label3.data = t("recent");
    more.title = t("recentActions");
    more.setAttribute("aria-label", more.title);
    add.title = t("newChat");
    add.setAttribute("aria-label", add.title);
    refresh.textContent = t("refreshRecent");
    all.textContent = t("findSession");
  }
  const dismiss = () => {
    if (popup.matches(":popover-open")) popup.hidePopover();
  };
  refresh.addEventListener("click", () => {
    dismiss();
    const source = rows.get();
    if (source?.container === list && source.refresh) {
      void Promise.resolve().then(source.refresh).catch((error) => host5.notifyError(error, t("recentRefreshError")));
    } else void show();
  });
  all.addEventListener("click", () => {
    dismiss();
    host5.navigate("/command-center?section=sessions");
  });
  popup.append(refresh, all);
  actions.append(more, add);
  header2.append(button5, actions);
  let generation = 0;
  let nativeUpdates;
  const close2 = () => {
    ++generation;
    clearInterval(nativeUpdates);
    area.removeAttribute("data-hcv-recents-open");
    body2.inert = true;
    fallback.removeAttribute("aria-busy");
    button5.setAttribute("aria-expanded", "false");
    dismiss();
  };
  const reset = () => {
    close2();
    rows.clear(list);
  };
  async function show() {
    if (!area.isConnected) return;
    const request = ++generation;
    clearInterval(nativeUpdates);
    area.setAttribute("data-hcv-recents-open", "");
    body2.inert = false;
    button5.setAttribute("aria-expanded", "true");
    const update = () => rows.update(area.parentElement, list, t("recentEmpty"));
    if (update()) {
      list.hidden = false;
      fallback.hidden = true;
      nativeUpdates = setInterval(() => {
        if (!update()) void show();
      }, 400);
      return;
    }
    rows.clear(list);
    list.hidden = true;
    fallback.hidden = false;
    fallback.textContent = t("recentLoading");
    fallback.setAttribute("aria-busy", "true");
    const profile2 = host5.state.profile.get();
    const connection = host5.state.connectionId.get();
    const current = () => request === generation && fallback.isConnected && host5.state.profile.get() === profile2 && host5.state.connectionId.get() === connection;
    try {
      if (!profile2 || !connection) {
        fallback.textContent = t("recentProfile");
        return;
      }
      const query = new URLSearchParams({ recents_profile: profile2, recents_limit: "12", recents_exclude: "cron,tool", cron_limit: "1", messaging_limit: "1" });
      const result = await window.hermesDesktop.api({ connectionId: connection, path: `/api/profiles/sessions/sidebar?${query}`, timeoutMs: 8e3 });
      if (!current()) return;
      fallback.textContent = "";
      for (const session of (result.recents?.sessions ?? []).filter((session2) => session2.id && !session2.pinned).slice(0, 12)) {
        const title = session.title?.trim() || t("untitledChat");
        const row5 = element3("button", { type: "button", title });
        const label4 = element3("span", { class: "hover-marquee" });
        label4.append(element3("span", { class: "hover-marquee-inner" }, title));
        row5.append(label4);
        const seconds = Number(session.last_active || session.started_at);
        const date = new Date(seconds * 1e3);
        row5.dataset.hcvPreviewSession = session.id;
        if (seconds > 0 && Number.isFinite(date.getTime())) row5.dataset.hcvPreviewTime = date.toISOString();
        row5.addEventListener("click", async () => {
          if (!current()) return;
          try {
            await host5.openSession(session.id);
          } catch {
            if (current()) fallback.textContent = t("recentOpenError");
          }
        });
        fallback.append(row5);
      }
      if (!fallback.childElementCount) fallback.textContent = t("recentEmpty");
    } catch {
      if (current()) fallback.textContent = t("recentUnavailable");
    } finally {
      if (current()) fallback.removeAttribute("aria-busy");
    }
  }
  button5.addEventListener("click", () => {
    if (area.hasAttribute("data-hcv-recents-open")) close2();
    else void show();
  });
  area.append(header2, body2, popup);
  return {
    area,
    localize,
    reset,
    show,
    remove() {
      reset();
      area.remove();
    }
  };
}
function sidebarMenuBehavior(content) {
  const triggerSelector = '[data-sessions-mode] :is([class~="group/workspace"], .row-hover) [data-row-actions] button[aria-haspopup="menu"][aria-expanded="true"][aria-controls]';
  let open;
  let returnFocus;
  const placement = new MutationObserver(alignMenu);
  function alignMenu() {
    if (!open?.menu.isConnected) return;
    const { menu, trigger, wrapper } = open;
    const rect = trigger.getBoundingClientRect();
    const base = wrapper.getBoundingClientRect();
    const width = menu.offsetWidth;
    const center = rect.left + rect.width / 2;
    const left = Math.max(8, Math.min(
      window.innerWidth - width - 8,
      center < window.innerWidth / 2 ? rect.left : rect.right - width
    ));
    const origin = Math.max(0, Math.min(width, center - left));
    menu.style.setProperty("--hcv-sidebar-menu-shift", `${left - base.left}px`);
    menu.style.setProperty("--hcv-sidebar-menu-origin", `${origin}px ${menu.dataset.side === "top" ? "bottom" : "top"}`);
  }
  function clear() {
    placement.disconnect();
    open?.menu.removeAttribute("data-hcv-sidebar-menu");
    open?.menu.style.removeProperty("--hcv-sidebar-menu-shift");
    open?.menu.style.removeProperty("--hcv-sidebar-menu-origin");
    open = void 0;
  }
  function handleEscape(event) {
    if (event.key === "Escape" && open?.menu.contains(event.target)) returnFocus = open;
  }
  document.addEventListener("keydown", handleEscape, true);
  return {
    sync() {
      if (returnFocus && !returnFocus.menu.isConnected) {
        const { trigger: trigger2 } = returnFocus;
        returnFocus = void 0;
        if (trigger2.isConnected && document.activeElement === document.body) trigger2.focus({ preventScroll: true });
      }
      const trigger = content.querySelector(triggerSelector);
      const menu = trigger && document.getElementById(trigger.getAttribute("aria-controls"));
      const wrapper = menu?.closest("[data-radix-popper-content-wrapper]");
      if (!wrapper || !menu.matches('[data-slot="dropdown-menu-content"][data-state="open"]')) {
        if (open && !open.menu.isConnected) clear();
        return;
      }
      if (open?.menu !== menu || open.wrapper !== wrapper) {
        clear();
        open = { menu, trigger, wrapper };
        placement.observe(wrapper, { attributes: true, attributeFilter: ["style"] });
        menu.setAttribute("data-hcv-sidebar-menu", "");
      }
      alignMenu();
    },
    dispose() {
      document.removeEventListener("keydown", handleEscape, true);
      returnFocus = void 0;
      clear();
    }
  };
}
function keybindLabel(action, fallback, separator) {
  let binding;
  try {
    binding = JSON.parse(localStorage.getItem("hermes.desktop.keybinds"))?.[action];
  } catch {
  }
  const combo = Array.isArray(binding) ? binding.find((value) => typeof value === "string") : fallback;
  const mac = /Mac/.test(navigator.platform);
  const labels12 = { ctrl: "Ctrl", mod: mac ? "\u2318" : "Ctrl", meta: mac ? "\u2318" : "Win", alt: "Alt", shift: "Shift" };
  return combo?.split("+").map((key) => labels12[key] || key.toUpperCase()).join(separator);
}
function newTerminalShortcut() {
  return keybindLabel("view.newTerminal", "ctrl+shift+`", " + ");
}
function attachSidebarHeader(group2, t) {
  const bar = element3("header", { "data-hcv-sidebar-bar": "" });
  const search = sidebarButton("\u041F\u043E\u0438\u0441\u043A \u0447\u0430\u0442\u043E\u0432", "search");
  const bell = sidebarButton("\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F", "bell", () => host5.navigate("/settings?tab=notifications"));
  search.dataset.hcvSearchToggle = "";
  bell.dataset.hcvNotifications = "";
  search.setAttribute("aria-expanded", "false");
  bar.append(element3("span", { "data-hcv-brand": "" }, "Hermes"), bell, search);
  group2.setAttribute("data-hcv-sidebar-shell", "");
  let terminalEmpty;
  function syncTerminal() {
    const surface5 = group2.querySelector(`:scope > [data-panel-header] ${selectedTerminal}`) && document.querySelector("[data-persistent-terminal]:not(:has(> [data-terminal]))");
    if (!surface5) {
      terminalEmpty?.remove();
      return;
    }
    if (!terminalEmpty) {
      terminalEmpty = element3("div", { "data-hcv-terminal-empty": "" });
      terminalEmpty.append(element3("p"), element3("p"), element3("kbd"));
    }
    const shortcut = newTerminalShortcut();
    const [title, description, keys] = terminalEmpty.children;
    const copy7 = [t("noTerminals"), t(shortcut ? "terminalShortcut" : "terminalUnbound"), shortcut || ""];
    for (const [index, node3] of [title, description, keys].entries()) {
      if (node3.textContent !== copy7[index]) node3.textContent = copy7[index];
    }
    if (terminalEmpty.parentElement !== surface5) surface5.append(terminalEmpty);
  }
  return {
    group: group2,
    search,
    sync(content) {
      const parent = group2.querySelector(":scope > [data-panel-header]") || content;
      if (parent && bar.parentElement !== parent) parent.prepend(bar);
      if (search.hidden !== !content) search.hidden = !content;
      syncTerminal();
    },
    remove() {
      bar.remove();
      terminalEmpty?.remove();
      group2.removeAttribute("data-hcv-sidebar-shell");
    }
  };
}
function flatRecents(recentRows, t) {
  let flatHeader;
  let previousFlatLabel;
  const flatList = element3("div", { "data-hcv-flat-list": "" });
  function localizeFlatHeader() {
    if (!flatHeader) return;
    const label3 = t("recent");
    flatHeader.setAttribute("data-hcv-flat-recent", label3);
    flatHeader.setAttribute("aria-label", label3);
  }
  function updateFlatHeader(next) {
    if (flatHeader === next) return;
    if (flatHeader) {
      flatHeader.removeAttribute("data-hcv-flat-recent");
      if (previousFlatLabel === null) flatHeader.removeAttribute("aria-label");
      else flatHeader.setAttribute("aria-label", previousFlatLabel);
    }
    flatHeader = next;
    if (flatHeader) {
      previousFlatLabel = flatHeader.getAttribute("aria-label");
      localizeFlatHeader();
    }
  }
  function syncFlatList(flat2) {
    const nativeFlat = flat2 && recentRows.update(flat2, flatList);
    if (nativeFlat) {
      if (flatList.nextElementSibling !== nativeFlat) nativeFlat.before(flatList);
    } else {
      recentRows.clear(flatList);
      flatList.remove();
    }
    const root = nativeFlat && flatList.firstElementChild ? flatList : flat2;
    updateFlatHeader(root?.querySelector(':scope > [data-slot="sidebar-group"] > :first-child:has(button > .codicon-list-filter) > button'));
  }
  return { sync: syncFlatList, localize: localizeFlatHeader };
}
function attachSidebar(content, group2, recentRows, t, { search }) {
  let searchField;
  let searchOpen = false;
  let chooseGrouping;
  let projectRequest;
  const searchFieldId = `hcv-search-${group2.dataset.treeGroup}`;
  const toggleSearch = () => {
    if (searchOpen) closeSearch(true);
    else openSearch();
  };
  search.addEventListener("click", toggleSearch);
  const recent = recentsControl(group2.dataset.treeGroup, recentRows, t);
  const sidebarMenu2 = sidebarMenuBehavior(content);
  const projectsLabel = document.createTextNode("");
  const projectsButton = element3("button", {
    type: "button",
    "data-hcv-show-projects": "",
    "aria-expanded": "false"
  });
  projectsButton.append(projectsLabel);
  appendIcon(projectsButton, "sidebarDisclosure");
  function localize() {
    recent.localize();
    projectsLabel.data = t("projects");
  }
  localize();
  projectsButton.addEventListener("click", () => {
    if (!chooseGrouping || projectRequest) return;
    const recentGroup = projectsButton.parentElement?.querySelector("[data-hcv-flat-recent]")?.closest('[data-slot="sidebar-group"]');
    projectRequest = {
      keepRecentOpen: Boolean(recentGroup?.querySelector(':scope > [data-slot="sidebar-group-content"]')),
      restoreFocus: document.activeElement === projectsButton
    };
    chooseGrouping("project");
  });
  const reset = () => {
    projectRequest = void 0;
    recent.reset();
  };
  const stopProfile = host5.state.profile.subscribe(reset);
  const stopConnection = host5.state.connectionId.subscribe(reset);
  function showSearch(open) {
    searchOpen = open && Boolean(searchField);
    searchField?.toggleAttribute("data-hcv-search-open", searchOpen);
    search.setAttribute("aria-expanded", String(searchOpen));
  }
  function openSearch() {
    showSearch(true);
    searchField?.querySelector("input")?.focus({ preventScroll: true });
  }
  function closeSearch(restoreFocus) {
    const clear = searchField?.querySelector("button:has(.codicon-close)");
    const input = searchField?.querySelector("input");
    if (clear) clear.click();
    else if (input?.value) {
      const { set } = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
      set.call(input, "");
      input.dispatchEvent(new Event("input", { bubbles: true }));
    }
    showSearch(false);
    if (restoreFocus) search.focus({ preventScroll: true });
  }
  function clearSearchField() {
    searchField?.removeAttribute("data-hcv-search-field");
    searchField?.removeAttribute("data-hcv-search-open");
    if (searchField?.id === searchFieldId) searchField.removeAttribute("id");
    search.removeAttribute("aria-controls");
  }
  function onSearchKey(event) {
    if (!searchOpen || event.key !== "Escape" || event.isComposing || event.defaultPrevented) return;
    event.preventDefault();
    event.stopPropagation();
    closeSearch(true);
  }
  function onSearchResult(event) {
    if (!searchOpen || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    if (!event.target.closest?.('[data-sessions-mode="search"] button[data-slot="row-button"]')) return;
    queueMicrotask(() => {
      if (!event.defaultPrevented) closeSearch(false);
    });
  }
  function onOutsidePress(event) {
    if (searchOpen && !group2.contains(event.target)) closeSearch(false);
  }
  content.addEventListener("click", onSearchResult);
  group2.addEventListener("keydown", onSearchKey, true);
  document.addEventListener("pointerdown", onOutsidePress, true);
  window.addEventListener("hermes:focus-session-search", openSearch, true);
  return {
    content,
    group: group2,
    localize,
    sync(flat2) {
      const input = content.querySelector(':scope > div > div > input[type="text"][placeholder]');
      const field = input?.parentElement?.parentElement;
      if (field !== searchField) {
        clearSearchField();
        searchField = field;
        if (field) {
          field.setAttribute("data-hcv-search-field", "");
          if (!field.id) field.id = searchFieldId;
          search.setAttribute("aria-controls", field.id);
        }
        showSearch(searchOpen || input === document.activeElement || Boolean(input?.value));
      }
      search.disabled = !searchField;
      const tree = content.querySelector('[data-sessions-mode="projects"]');
      if (tree && recent.area.parentElement !== tree) {
        recent.reset();
        tree.append(recent.area);
      } else if (!tree && recent.area.isConnected) recent.remove();
      chooseGrouping = flat2 && projectGroupingAction(flat2.querySelector(filterButton));
      if (chooseGrouping && projectsButton.parentElement !== flat2) flat2.prepend(projectsButton);
      else if (!chooseGrouping) projectsButton.remove();
      const projectsToggle = tree?.querySelector("[data-hcv-projects-header] [data-hcv-section-toggle]");
      if (projectRequest && projectsToggle) {
        const { keepRecentOpen, restoreFocus } = projectRequest;
        projectRequest = void 0;
        if (projectsToggle.getAttribute("aria-expanded") === "false") projectsToggle.click();
        if (keepRecentOpen) void recent.show();
        if (restoreFocus) projectsToggle.focus({ preventScroll: true });
      } else if (!tree && !flat2) {
        projectRequest = void 0;
      }
      sidebarMenu2.sync();
    },
    remove() {
      search.removeEventListener("click", toggleSearch);
      search.setAttribute("aria-expanded", "false");
      clearSearchField();
      content.removeEventListener("click", onSearchResult);
      group2.removeEventListener("keydown", onSearchKey, true);
      document.removeEventListener("pointerdown", onOutsidePress, true);
      window.removeEventListener("hermes:focus-session-search", openSearch, true);
      stopProfile();
      stopConnection();
      recent.remove();
      projectsButton.remove();
      sidebarMenu2.dispose();
    }
  };
}
function sidebarFills() {
  const fills = /* @__PURE__ */ new Map();
  function skipHiddenTooltip(event) {
    if (event.pointerType === "mouse" && !event.buttons && event.cancelable && !event.currentTarget.closest('[data-slot="sidebar"][data-state="collapsed"], [data-collapsible="icon"]')) {
      event.preventDefault();
    }
  }
  return (content) => {
    const labels12 = content?.querySelectorAll('[data-sidebar="menu-button"] > [data-tour^="sidebar-nav-"]') ?? [];
    const buttons = new Set(Array.from(labels12, (label3) => label3.parentElement));
    for (const [button5, fill] of fills) {
      if (buttons.has(button5) && fill.parentElement === button5) continue;
      fill.remove();
      button5.removeEventListener("pointermove", skipHiddenTooltip);
      button5.removeAttribute("data-hcv-sidebar-nav");
      fills.delete(button5);
    }
    for (const button5 of buttons) {
      if (fills.has(button5)) continue;
      const fill = element3("span", { "data-hcv-sidebar-fill": "", "aria-hidden": "true" });
      button5.prepend(fill);
      button5.addEventListener("pointermove", skipHiddenTooltip, { passive: false });
      button5.setAttribute("data-hcv-sidebar-nav", "");
      fills.set(button5, fill);
    }
  };
}
function registerSidebar(ctx, active2, recentRows) {
  const wide = window.matchMedia("(forced-colors: none) and (min-width: 800px) and (min-height: 480px)");
  const contrast = window.matchMedia("(forced-colors: none)");
  const flatList = flatRecents(recentRows, ctx.i18n.t);
  const syncFills = sidebarFills();
  let projects2;
  let chatPreview;
  let cron;
  let projectContent;
  let mounted;
  let header2;
  let anchors = [];
  let measuredWidth = 0;
  let measure = true;
  let queued;
  let activityFrame = 0;
  const setToolbarOffset = (value) => {
    const property = "--hcv-sidebar-right-offset";
    const style = document.documentElement.style;
    const offset = value > 0 ? `${value}px` : "";
    if (style.getPropertyValue(property) === offset) return;
    if (offset) style.setProperty(property, offset);
    else style.removeProperty(property);
    window.dispatchEvent(new Event(toolbarOffsetEvent));
  };
  const sync = () => {
    queued = void 0;
    if (activityFrame) {
      cancelAnimationFrame(activityFrame);
      activityFrame = 0;
    }
    const enabled = contrast.matches && document.documentElement.matches(active2);
    const sidebar2 = enabled ? [...document.querySelectorAll(`${sideSelector} > [data-slot="sidebar-content"]`)].find(
      (node3) => !node3.closest("[data-pane-hidden], [hidden]") && node3.getClientRects().length
    ) : null;
    if (projectContent !== sidebar2) {
      projectLabels.disconnect();
      projects2?.dispose();
      chatPreview?.dispose();
      cron?.dispose();
      projectContent = sidebar2;
      if (sidebar2) projectLabels.observe(sidebar2, { characterData: true, subtree: true });
      projects2 = sidebar2 ? attachProjects(sidebar2, ctx.i18n.t, ctx.storage) : void 0;
      chatPreview = sidebar2 ? attachChatPreview(sidebar2) : void 0;
      cron = sidebar2 ? attachSidebarCron(sidebar2, ctx.storage) : void 0;
    }
    syncFills(sidebar2);
    projects2?.sync();
    chatPreview?.sync();
    cron?.sync();
    const content = wide.matches ? sidebar2 : null;
    const group2 = enabled && wide.matches ? content?.closest("[data-tree-group]") ?? document.querySelector('[data-tree-tab="sessions"]')?.closest("[data-tree-group]") ?? document.querySelector('[data-tree-group="grp-sessions"][data-window-top]:not([data-pane-host])') : null;
    const workspace = group2 && document.querySelector('[data-tree-group="grp-main"][data-window-top]');
    const targets = [...new Set([content, group2, workspace].filter(Boolean))];
    if (targets.length !== anchors.length || targets.some((node3, index) => node3 !== anchors[index])) {
      resize.disconnect();
      for (const node3 of targets) resize.observe(node3);
      anchors = targets;
      measure = true;
    }
    if (measure) {
      measure = false;
      const railBox = group2?.getBoundingClientRect();
      const workspaceBox = workspace?.getBoundingClientRect();
      measuredWidth = group2?.clientWidth ?? 0;
      const rightRail = railBox?.width > 0 && workspaceBox?.width > 0 && railBox.left >= workspaceBox.right - 2;
      setToolbarOffset(rightRail ? Math.max(0, window.innerWidth - workspaceBox.right) : 0);
    }
    const compatible = group2 && measuredWidth >= 190 && (content || group2.querySelector(":scope > [data-panel-header]"));
    if (mounted && (mounted.content !== content || mounted.group !== group2 || !compatible)) {
      mounted.remove();
      mounted = void 0;
    }
    if (header2 && (header2.group !== group2 || !compatible)) {
      header2.remove();
      header2 = void 0;
    }
    if (compatible && !header2) header2 = attachSidebarHeader(group2, ctx.i18n.t);
    header2?.sync(content);
    if (header2 && content && !mounted) mounted = attachSidebar(content, group2, recentRows, ctx.i18n.t, header2);
    const flat2 = sidebar2?.querySelector(flatSelector);
    mounted?.sync(flat2);
    flatList.sync(flat2);
  };
  const schedule = () => {
    if (queued === void 0) queued = requestAnimationFrame(sync);
  };
  const stopBusy = host5.state.busyBySession.listen(() => {
    if (queued !== void 0 || activityFrame || !projectContent?.isConnected) return;
    activityFrame = requestAnimationFrame(() => {
      activityFrame = 0;
      if (queued !== void 0 || !contrast.matches || !document.documentElement.matches(active2)) return;
      projects2?.syncActivity();
      const flat2 = projectContent?.querySelector(flatSelector);
      if (flat2) flatList.sync(flat2);
    });
  });
  ctx.i18n.onLocaleChange(() => {
    mounted?.localize();
    flatList.localize();
    schedule();
  });
  const measureAndSync = () => {
    measure = true;
    schedule();
  };
  const resize = new ResizeObserver(measureAndSync);
  const projectLabels = new MutationObserver((records) => {
    if (records.some(({ target }) => target.parentElement?.closest("[data-hcv-native-project-action], .hover-marquee-inner"))) schedule();
  });
  const root = document.documentElement;
  const mounts = `${sideSelector}, [data-tree-group], [data-tree-tab="sessions"], [data-persistent-terminal]`;
  const visibility = /* @__PURE__ */ new Set(["data-window-top", "inert", "hidden", "data-pane-hidden"]);
  const observer = new MutationObserver((records) => {
    const enabled = root.matches(active2);
    let needsSync = false;
    for (const record of records) {
      const { target, type, attributeName } = record;
      if (target === root) return measureAndSync();
      if (!enabled || !(target instanceof Element)) continue;
      if (type === "attributes") {
        if (visibility.has(attributeName) && anchors.some((node3) => target.contains(node3))) return measureAndSync();
      } else if (target.matches("[data-tree-split]") || !target.closest("[data-chat-surface], [data-catalog-results]") && movedElementMatches(record, mounts)) {
        return measureAndSync();
      }
      if (needsSync) continue;
      needsSync = Boolean(target.closest(sideSelector) || header2?.group.contains(target) || type === "childList" && !target.closest("[data-tree-group]") && movedElementMatches(record, '[data-slot="dropdown-menu-content"]') && projectContent?.querySelector('button[aria-haspopup="menu"][aria-expanded="true"]'));
    }
    if (needsSync) schedule();
  });
  observer.observe(root, {
    attributes: true,
    attributeFilter: ["data-hermes-theme", "data-hermes-codex-visual", "aria-expanded", "aria-selected", "data-sessions-mode", "data-sessions-project", "data-working", "data-window-top", "inert", "hidden", "data-pane-hidden"],
    childList: true,
    subtree: true
  });
  wide.addEventListener("change", measureAndSync);
  contrast.addEventListener("change", measureAndSync);
  window.addEventListener("resize", measureAndSync);
  ctx.onDispose(() => {
    stopBusy();
    observer.disconnect();
    projectLabels.disconnect();
    resize.disconnect();
    wide.removeEventListener("change", measureAndSync);
    contrast.removeEventListener("change", measureAndSync);
    window.removeEventListener("resize", measureAndSync);
    setToolbarOffset(0);
    if (queued !== void 0) cancelAnimationFrame(queued);
    if (activityFrame) cancelAnimationFrame(activityFrame);
    mounted?.remove();
    flatList.sync(void 0);
    syncFills(null);
    header2?.remove();
    projects2?.dispose();
    chatPreview?.dispose();
    cron?.dispose();
  });
  schedule();
}
function registerWorkspaceChrome(ctx, themeName2) {
  ctx.i18n.register(sidebarCopy);
  registerChatPreviewMarker(ctx);
  const active2 = `html[data-hermes-codex-visual][data-hermes-theme="${themeName2}"]`;
  const shell = `${active2}[data-hcv-window-chrome]`;
  const side = `${shell} [data-hcv-sidebar-shell]`;
  const sidebarTrack = `${active2} [data-tree-split].flex-row > div[style*="min-width: 237px"]:has(> [data-tree-group="grp-sessions"]:not([data-pane-host]))`;
  const sidebarStrip = `${active2} :is([data-hcv-sidebar-shell] > [data-panel-header] [data-zone-tabstrip], [data-zone-tabstrip="grp-sessions"])`;
  const sidebarTab = `${sidebarStrip} > [role="tablist"] > [role="tab"]:has(> .pane-tab-content)`;
  const sidebarTerminal = `${active2}:has([data-hcv-sidebar-shell] > [data-panel-header] ${selectedTerminal}) [data-persistent-terminal]`;
  const sidebarRow = `${active2} ${sideSelector} [data-sessions-mode] .row-hover:not([class~="group/workspace"])`;
  const flat2 = `${active2} ${sideSelector} [data-sessions-mode="flat"]`;
  const rowMore = '[data-row-actions] > button[aria-haspopup="menu"]:has(> .codicon-kebab-vertical)';
  const recentsButton = "[data-hcv-recents-actions] button, [data-hcv-recents-menu] button, [data-hcv-recents-fallback] button";
  const recentToggle = "[data-hcv-recents-toggle]";
  const caret = '[data-hcv-icon="sidebarDisclosure"]';
  const flatRecent = "[data-hcv-flat-recent]";
  const flatCaret = `${flatRecent} > .codicon-chevron-right`;
  const flatGroup = `${flat2} [data-slot="sidebar-group"]`;
  const flatOpenGroup = `${flatGroup}:has(> [data-slot="sidebar-group-content"])`;
  const neutralHeadings = `${side} :is([data-hcv-recents-toggle], [data-hcv-show-projects], [data-hcv-flat-recent])`;
  const chromeButton = `${shell} :is([data-hcv-history] button, [data-hcv-sidebar-bar] button, ${recentsButton})`;
  const windowBar = `${shell} [data-hcv-window-menu]`;
  const windowButton = `${windowBar} [data-hcv-menu-button]`;
  const windowPopup = `${shell} [data-slot="dropdown-menu-content"][data-hcv-window-menu-content]`;
  const windowItem = `${windowPopup} > [role="menuitem"]`;
  const recentRows = createRecentRows();
  const stylesheet = element3("style", { "data-hcv-chrome-styles": "" });
  stylesheet.textContent = `
@media (forced-colors: none) {
  ${active2} {
    --hcv-sidebar-heading: light-dark(color-mix(in oklab, var(--hcv-text) 50%, transparent), rgb(255 255 255 / 50%));
  }
  /* Match the reference at the owner's current zoom. The native sash
     reads this minimum and still writes the user's width. */
  ${sidebarTrack} { min-width: 222px !important; }
  ${projectSidebarStyles(active2)}
  ${chatPreviewStyles(active2)}
  ${sidebarCronStyles(active2)}
  ${flat2} [data-hcv-flat-list] { display: contents; }
  ${flat2} [data-hcv-flat-list]:has(> [data-slot="sidebar-group"]) + [data-slot="sidebar-group"] { display: none; }
  ${flat2} ${flatRecent} { flex: 1 1 0; align-self: stretch; }
  ${codexIconRules(`${flat2} ${flatCaret}`, "sidebarDisclosure")}
  ${flat2} ${flatCaret} { rotate: -90deg; opacity: 1; }
  ${flatOpenGroup} ${flatCaret} { rotate: none; opacity: 0; }
  ${flatOpenGroup}:hover ${flatCaret}, ${flatOpenGroup} ${flatRecent}:focus-visible > .codicon-chevron-right { opacity: 1; }
  ${flat2} [data-hcv-flat-recent] > span:has(> .dither) { display: none; }
  ${flat2} [data-hcv-flat-recent]::before {
    content: attr(data-hcv-flat-recent);
    padding-inline-start: 8px;
    font: 500 13px/18px var(--hcv-ui-font);
  }
  ${sidebarStrip} > [role="tablist"] { gap: 2px; align-items: center; }
  ${sidebarStrip} > button { margin-inline: 1px; }
  ${sidebarTab} {
    block-size: 28px;
    min-block-size: 28px;
    max-block-size: 28px;
    margin-inline: 0;
    padding-inline: 7px;
  }
  ${sidebarTab} > .pane-tab-content,
  ${sidebarTab} > .pane-tab-content > :has(> .truncate) { margin-inline: 0; padding-inline: 0; }
  ${sidebarTab} .pane-tab-content .truncate { font-size: 12px; line-height: 16px; }
  ${sidebarTab}[data-closeable] { --pane-tab-close-width: 16px; padding-inline-end: 17px; }
  ${sidebarTab}[data-closeable]:hover > .pane-tab-content { mask-image: none; }
  ${sidebarTerminal} > [data-terminal] { padding-block-start: 8px; padding-inline-start: 10px; }
  ${sidebarTerminal} > [data-hcv-terminal-empty] {
    display: grid;
    justify-items: start;
    gap: 6px;
    padding: 12px 14px;
    color: var(--hcv-muted);
    font: 400 12px/18px var(--hcv-ui-font);
  }
  ${sidebarTerminal} > [data-hcv-terminal-empty] > p:first-child { color: var(--hcv-text); font-weight: 600; }
  ${sidebarTerminal} > [data-hcv-terminal-empty] kbd {
    padding-inline: 5px;
    border-radius: 5px;
    background: var(--hcv-hover);
    color: var(--hcv-text);
  }
  ${sidebarTerminal} > [data-hcv-terminal-empty] kbd:empty,
  ${sidebarTerminal}:has(> [data-terminal]) > [data-hcv-terminal-empty] { display: none; }
  ${sidebarRow} ${rowMore} {
    inline-size: 24px;
    block-size: 24px;
    border-radius: 7px;
    color: var(--hcv-muted);
    opacity: 0;
    pointer-events: none;
  }
  ${sidebarRow}:is(:hover, :focus-within) ${rowMore},
  ${sidebarRow} ${rowMore}:is(:focus-visible, [aria-expanded="true"]) { opacity: 1; pointer-events: auto; }
  ${sidebarRow} ${rowMore}:is(:hover, :focus-visible, [aria-expanded="true"]) {
    color: var(--hcv-text);
    background: var(--hcv-hover);
  }
  ${sidebarRow} ${rowMore}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  @media (any-hover: none) {
    ${sidebarRow} ${rowMore} { opacity: 1; pointer-events: auto; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${sidebarRow} ${rowMore} { transition: opacity 120ms var(--hcv-ease), color 120ms var(--hcv-ease), background-color 120ms var(--hcv-ease); }
  }
}
@media (forced-colors: none) and (min-width: 800px) and (min-height: 480px) {
  ${shell} [data-tree-split="spl-root"] { padding-block-start: 39px; }
  ${shell} [data-titlebar-cluster="left"] {
    inset-inline-start: 6px;
    inset-block-start: 4px;
    gap: 6px;
  }
  ${shell} [data-titlebar-cluster="right"] {
    inset-block-start: 51px;
    right: calc(13px + var(--hcv-sidebar-right-offset, 0px));
  }
  ${shell} [data-hcv-history] { order: -1; display: flex; align-items: center; gap: 6px; }
  ${chromeButton} {
    display: flex;
    align-items: center;
    color: var(--hcv-muted);
    border-radius: 8px;
    background: transparent;
    cursor: pointer;
    -webkit-app-region: no-drag;
  }
  ${shell} :is([data-hcv-history] button, [data-hcv-sidebar-bar] button) {
    inline-size: 28px;
    block-size: 28px;
    justify-content: center;
  }
  ${shell} [data-titlebar-cluster="left"] > [data-size="icon-titlebar"] {
    inline-size: 28px;
    block-size: 28px;
  }
  ${shell} [data-hcv-icon] { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; }
  ${chromeButton}:not(:disabled, [data-hcv-recents-menu] button):is(:hover, :focus-visible, [data-state="open"]) {
    color: var(--hcv-text);
    background: var(--hcv-hover);
  }
  ${shell} [data-hcv-history] button:disabled { opacity: .32; cursor: default; }

  /* Windows application menu from Codex e6/eY/eJ, separate from contextual menus. */
  ${shell} {
    --hcv-window-text: light-dark(#1a1c1f, #dfdfdf);
    --hcv-window-muted: light-dark(rgb(26 28 31 / .495), rgb(255 255 255 / .498));
    --hcv-window-ink: light-dark(#1a1c1f, #ffffff);
    --hcv-window-row-hover: light-dark(rgb(26 28 31 / .0535), rgb(255 255 255 / .078));
    --hcv-window-divider: light-dark(rgb(26 28 31 / .117), rgb(255 255 255 / .156));
  }
  ${windowBar} {
    display: flex;
    align-items: center;
    gap: 2px;
    padding-inline: 4px 8px;
    user-select: none;
  }
  ${windowButton} {
    padding: 4px 10px;
    border: 1px solid transparent;
    border-radius: 8px;
    background: transparent;
    color: var(--hcv-window-muted);
    font: 400 14px/1 ${codexReference.font};
    -webkit-app-region: no-drag;
  }
  ${windowButton}:is(:hover, :focus-visible) {
    background: color-mix(in srgb, var(--hcv-window-text) 5%, transparent);
  }
  ${windowButton}[aria-expanded="true"] {
    background: color-mix(in srgb, var(--hcv-window-ink) 3.2%, transparent);
    color: var(--hcv-window-text);
  }
  /* Deliver outside presses to the menu while the window's drag zones are covered. */
  ${shell}[data-hcv-window-menu-open] :is([class~="[-webkit-app-region:drag]"], [data-window-drag-handle]) {
    -webkit-app-region: no-drag;
  }
  ${windowPopup}[data-state] {
    --hcv-window-max: min(calc(100vw - 16px), var(--radix-dropdown-menu-content-available-width, 100vw));
    display: flex;
    flex-direction: column;
    min-inline-size: min(220px, var(--hcv-window-max));
    max-inline-size: var(--hcv-window-max);
    max-block-size: calc(100vh - 12px);
    padding: 4px 0;
    border: 0;
    border-radius: 6px;
    background: light-dark(#f8f8f9, #1f1f1f);
    color: var(--hcv-window-text);
    box-shadow: 0 4px 12px #0000006b;
    font: 400 12px/18px ${codexReference.font};
    animation: none;
    user-select: none;
  }
  ${windowPopup}[data-hcv-window-menu-content="view"] { min-inline-size: min(300px, var(--hcv-window-max)); }
  ${windowItem} {
    flex: none;
    min-block-size: 28px;
    margin-inline: 4px;
    padding: 5px 16px;
    gap: 8px;
    border-radius: 6px;
    color: inherit;
    font: inherit;
    outline: none;
    box-shadow: none;
  }
  ${windowItem}::before { content: none; }
  ${windowItem}:is(:hover, :focus, [data-highlighted]):not([data-disabled]) {
    background: var(--hcv-window-row-hover);
    color: inherit;
  }
  ${windowItem}[data-disabled] { opacity: .6; }
  ${windowItem} [data-hcv-window-menu-label] { flex: 1; min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  ${windowItem} [data-hcv-window-menu-shortcut] { flex: none; color: color-mix(in srgb, var(--hcv-window-text) 75%, transparent); }
  ${windowItem} [data-hcv-window-menu-shortcut]:empty { display: none; }
  ${windowPopup} > [role="separator"] {
    flex: none;
    block-size: .5px;
    margin: 8px 0;
    background: var(--hcv-window-divider);
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${windowButton} { border-radius: 10px; corner-shape: superellipse(1.5); }
    ${windowPopup}[data-state], ${windowItem} { border-radius: 7.5px; }
  }

  ${shell} [data-tree-group="grp-main"][data-window-top] > [data-panel-header]:has([data-zone-tabstrip]) {
    block-size: 48px !important;
    align-items: center;
    background: var(--hcv-chat);
    padding-inline: 20px 168px;
  }
  ${shell} [data-tree-group="grp-main"] > [data-panel-header]:has([data-zone-tabstrip]) > [style*="--panel-titlebar-left"] {
    inline-size: 0 !important;
  }
  ${shell} [data-tree-group="grp-main"] [data-zone-tabstrip] {
    position: static;
    background: transparent;
    box-shadow: none;
    border: 0;
  }
  ${shell} [data-tree-tab="workspace"] { font-size: 13px; text-transform: none; box-shadow: none; background: transparent; }
  ${shell} [data-tree-tab="workspace"] :is(span, .truncate) { font-size: 13px; font-weight: 600; letter-spacing: normal; text-transform: none; }
  ${shell} [data-tree-tab="workspace"]::before {
    content: '';
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: ${codexMask("folder")} center / contain no-repeat;
  }

  ${side} { border-start-start-radius: 12px; background: var(--hcv-sidebar); }
  ${side} > [data-panel-header]:has(> [data-hcv-sidebar-bar]) {
    block-size: 46px !important;
  }
  ${side} > [data-panel-header]:has(> [data-hcv-sidebar-bar]):has([data-zone-tabstrip]) {
    block-size: 78px !important;
  }
  ${side} > [data-panel-header]:has(> [data-hcv-sidebar-bar]) [data-zone-tabstrip] {
    position: absolute;
    inset: auto 6px 4px;
    block-size: 28px;
    background: transparent;
  }
  ${side} [data-hcv-sidebar-bar] {
    display: flex;
    align-items: center;
    block-size: 46px;
    flex: none;
    order: -2;
    gap: 3px;
    padding-inline: 6px 0;
  }
  ${side} > [data-panel-header] > [data-hcv-sidebar-bar] {
    position: absolute;
    inset: 0 0 auto;
    padding-inline: 15px 8px;
  }
  ${side} [data-hcv-sidebar-bar] [data-hcv-brand] {
    flex: 1;
    font: 600 16px/20px var(--hcv-ui-font, system-ui, sans-serif);
    letter-spacing: -.015em;
    color: var(--hcv-text);
  }
  ${side} [data-hcv-sidebar-bar] button {
    position: relative;
    color: var(--hcv-muted);
    transition: color 150ms var(--hcv-ease), background-color 150ms var(--hcv-ease);
  }
  ${side} [data-hcv-sidebar-bar] button:focus-visible {
    outline: 1px solid var(--hcv-focus);
    outline-offset: -1px;
  }
  ${side} [data-hcv-sidebar-bar] button:disabled { opacity: .4; cursor: default; }
  ${side} [data-hcv-sidebar-bar] button[hidden] { display: none; }
  ${side} [data-hcv-search-toggle][aria-expanded="true"] { background: var(--hcv-hover); }
  ${side} [data-hcv-search-field]:not([data-hcv-search-open]) { display: none; }
  ${side} [data-hcv-search-field] {
    order: -1;
    padding: 0 0 8px;
  }
  ${side} [data-hcv-search-field] > div {
    display: flex;
    inline-size: 100%;
    padding-inline: 8px;
    border: 1px solid var(--hcv-stroke);
    border-radius: 8px;
    background: var(--hcv-menu);
    opacity: 1;
  }
  ${side} [data-hcv-search-field] > div:focus-within { border-color: var(--hcv-focus); }
  ${side} [data-hcv-search-field] input { font-size: 13px; }
  ${side} [data-slot="sidebar-content"] > [data-slot="sidebar-group"]:has([data-slot="sidebar-menu"]) {
    padding-block: 2px 10px;
  }
  ${side} [data-slot="sidebar-menu"] > li > button {
    min-block-size: ${codexReference.sidebar.rowHeight}px;
    block-size: ${codexReference.sidebar.rowHeight}px;
    padding-inline: 8px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 430;
  }
  ${side} [data-slot="sidebar-menu"] { gap: 1px; }
  ${side} [data-sessions-mode="projects"] > [data-slot="sidebar-group"] {
    flex: none;
    min-block-size: 0;
    overflow: visible;
  }
  ${side} [data-sessions-mode="projects"] > [data-slot="sidebar-group"] > [data-slot="sidebar-group-content"] { overflow: visible; }
  ${side} [data-sessions-mode]:not([data-sessions-mode="search"]) > [data-slot="sidebar-group"]:first-of-type:has([data-slot="sidebar-group-content"] > div > span > .codicon-pin):not(:has([data-row-actions])) { display: none; }
  ${side} [data-sessions-mode] > [data-slot="sidebar-group"] > :first-child span:has(> .dither) {
    font-size: 13px;
    line-height: 18px;
    font-weight: 600;
    letter-spacing: normal;
    text-transform: none;
    color: var(--hcv-muted);
  }
  ${side} [data-sessions-mode] > [data-slot="sidebar-group"] > :first-child span > .dither { display: none; }
  ${side} [data-sessions-mode] > [data-slot="sidebar-group"] > :first-child button:not(${flatRecent}) > .codicon-chevron-right { opacity: 1; }
  ${codexIconRules(`${side} [data-sessions-mode] > [data-slot="sidebar-group"] > :first-child button:not(${flatRecent}) > .codicon-chevron-right`, "right")}
  ${side} [data-sessions-mode="projects"] .row-hover { min-block-size: ${codexReference.sidebar.rowHeight}px; border-radius: 9px; }
  ${side} [data-sessions-project]:not([data-sessions-mode]) :is(.codicon-folder-library, .codicon-repo)::before {
    content: '';
    display: block;
    inline-size: 15px;
    block-size: 15px;
    background: currentColor;
    mask: ${codexMask("folder")} center / contain no-repeat;
  }
  ${side} [data-hcv-project-row]:has([data-hcv-project-name][aria-expanded="true"]) :is(.codicon-folder-library, .codicon-repo)::before { mask-image: ${codexMask("folderOpen")}; }
  ${codexIconRules(`${side} [data-sessions-project]:not([data-sessions-mode]) .codicon-home`, "home")}
  ${side} [data-hcv-recents] { margin-block: 12px 5px; }
  ${side} [data-hcv-recents-header] { display: flex; align-items: center; justify-content: space-between; padding-inline: 0 4px; min-block-size: 32px; }
  ${side} :is(${recentsButton}) { min-block-size: 30px; gap: 5px; padding-inline: 8px; font-size: 13px; }
  ${side} :is([data-hcv-recents-toggle], [data-hcv-show-projects]) {
    display: flex;
    align-items: center;
    align-self: stretch;
    min-inline-size: 0;
    gap: 4px;
    min-block-size: 28px;
    padding-inline: 8px;
    border-radius: 8px;
    font: 500 13px/18px var(--hcv-ui-font);
  }
  ${side} ${recentToggle} { flex: 1 1 0; }
  ${side} [data-hcv-show-projects] { flex: none; }
  ${neutralHeadings}, ${neutralHeadings}:hover { background-color: transparent; color: var(--hcv-sidebar-heading); }
  ${neutralHeadings}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${side} :is(${recentToggle}, [data-hcv-show-projects]) ${caret} { inline-size: 12px; block-size: 12px; flex: none; opacity: 0; }
  ${side} :is(${recentToggle}, [data-hcv-show-projects])[aria-expanded="false"] ${caret} { rotate: -90deg; opacity: 1; }
  ${side} [data-hcv-recents]:hover ${recentToggle} ${caret}, ${side} ${recentToggle}:focus-visible ${caret} { opacity: 1; }
  ${side} [data-hcv-recents-actions] { display: flex; align-items: center; gap: 1px; opacity: 0; pointer-events: none; }
  ${side} [data-hcv-recents-header]:is(:hover, :focus-within) [data-hcv-recents-actions],
  ${side} [data-hcv-recents-actions]:has([aria-expanded="true"]) { opacity: 1; pointer-events: auto; }
  ${side} [data-hcv-recents-actions] button { inline-size: 26px; min-block-size: 26px; justify-content: center; padding: 0; }
  ${side} [data-hcv-recents-actions] [data-hcv-icon] { inline-size: 14px; block-size: 14px; }
  ${side} [data-hcv-recents-body] { display: grid; grid-template-rows: 0fr; opacity: 0; }
  ${side} [data-hcv-recents-open] [data-hcv-recents-body] { grid-template-rows: 1fr; opacity: 1; }
  ${side} [data-hcv-recents-menu] {
    position: fixed; inset: auto; margin: 0; padding: 4px; inline-size: 210px;
    border: 0; border-radius: var(--hcv-dropdown-radius); corner-shape: superellipse(1.5);
    background: var(--hcv-dropdown-background); color: var(--hcv-dropdown-text);
    box-shadow: var(--hcv-dropdown-shadow);
    opacity: 0; scale: .95; pointer-events: none; transform-origin: top left;
  }
  ${side} [data-hcv-recents-menu]:popover-open { opacity: 1; scale: 1; pointer-events: auto; }
  ${side} [data-hcv-recents-menu] button {
    inline-size: 100%; color: inherit; text-align: start;
    border-radius: var(--hcv-dropdown-row-radius); corner-shape: superellipse(1.5);
  }
  @media (any-hover: none) {
    ${side} [data-hcv-recents-actions] { opacity: 1; pointer-events: auto; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${side} ${recentToggle} ${caret}, ${flat2} ${flatCaret} { transition: opacity 150ms var(--hcv-enter), rotate 150ms var(--hcv-enter); }
    ${side} [data-hcv-recents-actions] { transition: opacity 150ms var(--hcv-ease); }
    ${side} [data-hcv-recents-body] {
      transition: grid-template-rows ${codexReference.disclosure.heightTime}ms ${codexReference.disclosure.ease}, opacity ${codexReference.disclosure.exitTime}ms ${codexReference.disclosure.ease};
    }
    ${side} [data-hcv-recents-open] [data-hcv-recents-body] {
      transition-delay: 0ms, ${codexReference.disclosure.enterDelay}ms;
      transition-duration: ${codexReference.disclosure.heightTime}ms, ${codexReference.disclosure.enterTime}ms;
    }
    ${side} [data-hcv-recents-menu] {
      transition: opacity 100ms var(--hcv-exit), scale 100ms var(--hcv-exit), display 100ms allow-discrete, overlay 100ms allow-discrete;
    }
    ${side} [data-hcv-recents-menu]:popover-open {
      transition: opacity 150ms var(--hcv-enter), scale 150ms var(--hcv-enter), display 150ms allow-discrete, overlay 150ms allow-discrete;
    }
    @starting-style { ${side} [data-hcv-recents-menu]:popover-open { opacity: 0; scale: .95; } }
  }
  ${side} :is([data-hcv-recents-list], [data-hcv-recents-fallback]) { min-block-size: 0; overflow: hidden; padding-inline: 5px; font-size: 12px; }
  ${side} [data-hcv-recents-list] > [data-slot="sidebar-group"] { padding: 0; }
  ${side} [data-hcv-recents-list] > [data-slot="sidebar-group"] > :first-child { display: none; }
  /* The native virtual list owns scrolling once it has enough rows. */
  ${side} [data-hcv-recents-list] .hcv-recent-scroll .hcv-recent-scroll {
    block-size: min(40vh, 320px);
  }
  ${side} [data-hcv-recents-fallback]:not([hidden]) { display: grid; gap: 2px; }
  ${side} [data-hcv-recents-fallback] button { display: block; text-align: start; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  ${side} [data-hcv-recent-empty] { padding: 6px 8px; color: var(--hcv-muted); }
}
@media (prefers-reduced-motion: reduce) {
  ${active2} [data-hcv-sidebar-bar] button { transition: none; }
}
@media (forced-colors: active), (max-width: 799px), (max-height: 479px) {
  ${active2} :is([data-hcv-history], [data-hcv-window-menu]) { display: none; }
}
`;
  mountStyle(ctx, stylesheet);
  ctx.register({ id: "window-menu", area: TITLEBAR_AREAS.left, render: () => h3(WindowChrome, { themeName: themeName2, recentRows }) });
  registerSidebar(ctx, active2, recentRows);
}

// source/workspace-card.js
import {
  atom as atom4,
  DropdownMenu as DropdownMenu4,
  DropdownMenuContent as DropdownMenuContent4,
  DropdownMenuItem as DropdownMenuItem4,
  DropdownMenuSeparator as DropdownMenuSeparator3,
  DropdownMenuTrigger as DropdownMenuTrigger4,
  host as host10,
  TITLEBAR_AREAS as TITLEBAR_AREAS3,
  Tip,
  useI18n as useI18n5,
  useTheme as useTheme2,
  useValue as useValue4
} from "@hermes/plugin-sdk";
import { createElement as h11, Fragment as Fragment2, useEffect as useEffect7, useId as useId3, useRef as useRef5, useState as useState7 } from "react";

// source/summary-sources.js
import { useEffect as useEffect2, useState as useState3 } from "react";

// source/chat-audio.js
var mark = "data-hcv-audio";
var controls = "data-hcv-audio-controls";
var mediaEvents = [
  "emptied",
  "loadedmetadata",
  "durationchange",
  "timeupdate",
  "seeking",
  "play",
  "pause",
  "ended",
  "error"
];
function node(tag, className) {
  const element7 = document.createElement(tag);
  if (className) element7.className = className;
  return element7;
}
function clock(seconds) {
  const time = Number.isFinite(seconds) ? Math.max(0, Math.floor(seconds)) : 0;
  return `${Math.floor(time / 60)}:${String(time % 60).padStart(2, "0")}`;
}
function attachPlayer(card2, audio) {
  const nativeTitle = card2.firstElementChild;
  const player = node("span");
  const header2 = node("span", "hcv-audio-header");
  const glyph3 = node("span", "hcv-audio-glyph");
  const info = node("span", "hcv-audio-info");
  const title = node("span", "hcv-audio-title");
  const subtitle = node("span", "hcv-audio-subtitle");
  const play = node("button", "hcv-audio-play");
  const options = node("button", "hcv-audio-options");
  const timeline = node("span", "hcv-audio-timeline");
  const seek = node("input");
  const time = node("span");
  const listeners = new AbortController();
  const { signal } = listeners;
  let currentName;
  let currentLocale;
  let currentPlaying;
  let currentError;
  let currentDuration;
  play.type = options.type = "button";
  options.setAttribute("aria-expanded", "false");
  seek.type = "range";
  seek.min = "0";
  seek.step = "0.1";
  glyph3.setAttribute("aria-hidden", "true");
  player.setAttribute(controls, "");
  info.append(title, subtitle);
  header2.append(glyph3, info, play, options);
  timeline.append(seek, time);
  player.append(header2, timeline);
  card2.insertBefore(player, audio);
  card2.setAttribute(mark, "");
  function sync() {
    const ru = /^ru\b/i.test(document.documentElement.lang);
    const name = nativeTitle.textContent.trim();
    const unavailable = !!audio.error;
    const playing = !audio.paused && !audio.ended;
    const duration4 = Number.isFinite(audio.duration) && audio.duration > 0 ? audio.duration : 0;
    const position2 = Math.min(audio.currentTime, duration4);
    const labelChanged = name !== currentName || ru !== currentLocale;
    if (labelChanged) {
      title.title = title.textContent = name;
      options.title = ru ? "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u044F" : "Playback options";
      options.setAttribute("aria-label", `${options.title} \xB7 ${name}`);
      seek.setAttribute("aria-label", `${ru ? "\u041F\u043E\u0437\u0438\u0446\u0438\u044F \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u044F" : "Playback position"} \xB7 ${name}`);
      currentName = name;
      currentLocale = ru;
    }
    if (labelChanged || unavailable !== currentError) {
      const format = name.match(/\.([a-z\d]+)$/i)?.[1]?.toUpperCase();
      const audioType = format ? ru ? `\u0410\u0443\u0434\u0438\u043E ${format}` : `${format} audio` : ru ? "\u0410\u0443\u0434\u0438\u043E" : "Audio";
      subtitle.textContent = unavailable ? ru ? "\u0410\u0443\u0434\u0438\u043E \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E" : "Audio unavailable" : audioType;
      play.disabled = unavailable;
    }
    if (labelChanged || playing !== currentPlaying) {
      const action = playing ? ru ? "\u041F\u0430\u0443\u0437\u0430" : "Pause" : ru ? "\u0412\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0441\u0442\u0438" : "Play";
      play.dataset.playing = String(playing);
      play.setAttribute("aria-label", `${action} ${name}`);
      currentPlaying = playing;
    }
    if (duration4 !== currentDuration || unavailable !== currentError) {
      seek.disabled = unavailable || duration4 <= 0;
      seek.max = String(duration4 || 1);
      currentDuration = duration4;
      currentError = unavailable;
    }
    seek.value = String(position2);
    const progress = `${clock(position2)} / ${clock(duration4)}`;
    if (time.textContent !== progress) time.textContent = progress;
  }
  play.addEventListener("click", () => {
    if (audio.paused) void audio.play().catch(sync);
    else audio.pause();
  }, { signal });
  seek.addEventListener("input", () => {
    if (seek.disabled) return;
    audio.currentTime = seek.valueAsNumber;
    sync();
  }, { signal });
  options.addEventListener("click", () => {
    const expanded = card2.toggleAttribute("data-hcv-audio-expanded");
    options.setAttribute("aria-expanded", String(expanded));
  }, { signal });
  for (const event of mediaEvents) audio.addEventListener(event, sync, { signal });
  sync();
  return {
    sync,
    remove() {
      listeners.abort();
      player.remove();
      card2.removeAttribute(mark);
      card2.removeAttribute("data-hcv-audio-expanded");
    }
  };
}
function registerChatAudio(ctx, active2, selector) {
  const root = document.documentElement;
  const forcedColors = window.matchMedia("(forced-colors: active)");
  const players = /* @__PURE__ */ new Map();
  const card2 = `${active2} [${mark}]`;
  const waveform = localAssets?.icons.resourceAudioLight && localAssets?.icons.resourceAudioDark ? `background: light-dark(${svgMask(localAssets.icons.resourceAudioLight)}, ${svgMask(localAssets.icons.resourceAudioDark)}) center / contain no-repeat;` : `background: var(--hcv-focus); mask: ${codexMask("audio")} center / contain no-repeat;`;
  mountCSS(ctx, "data-hcv-chat-audio", `
@media (forced-colors: none) {
  ${card2} {
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    inline-size: 100%;
    max-inline-size: 32rem;
    container: hcv-audio-card / inline-size;
    padding: 0;
    border: 0;
    border-radius: 10px;
    corner-shape: superellipse(1.5);
    background: color-mix(in oklab, var(--hcv-panel) 50%, transparent);
    box-shadow: inset 0 0 0 .5px var(--hcv-hairline);
    color: var(--hcv-text);
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${card2}, ${card2} .hcv-audio-glyph { border-radius: 12.5px; }
  }
  ${card2} > span:first-child, ${card2}:not([data-hcv-audio-expanded]) > audio { display: none; }
  ${card2} > [${controls}] { display: block; }
  ${card2} > audio { box-sizing: border-box; padding: 0 12px 8px; }
  ${card2} .hcv-audio-header {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 6px;
  }
  ${card2} .hcv-audio-glyph {
    display: grid;
    place-items: center;
    flex: none;
    inline-size: 40px;
    block-size: 40px;
    border-radius: 10px;
    background: var(--hcv-hover);
  }
  ${card2} .hcv-audio-glyph::before {
    content: '';
    inline-size: 24px;
    block-size: 24px;
    ${waveform}
  }
  ${card2} .hcv-audio-info {
    display: grid;
    flex: 1;
    min-inline-size: 0;
    margin-inline: 6px;
  }
  ${card2} :is(.hcv-audio-title, .hcv-audio-subtitle) {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  ${card2} .hcv-audio-title { font: 500 var(--conversation-text-font-size, 13px)/20px var(--hcv-ui-font); }
  ${card2} :is(.hcv-audio-subtitle, .hcv-audio-timeline) {
    color: var(--hcv-muted);
    font: 400 calc(var(--conversation-text-font-size, 13px) - 1px)/18px var(--hcv-ui-font);
  }
  ${card2} :is(.hcv-audio-play, .hcv-audio-options) {
    display: grid;
    place-items: center;
    flex: none;
    inline-size: 28px;
    block-size: 28px;
    padding: 0;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: var(--hcv-muted);
    cursor: pointer;
  }
  ${card2} .hcv-audio-play {
    inline-size: 32px;
    block-size: 32px;
    border-radius: 50%;
    background: color-mix(in srgb, var(--hcv-text) 5%, transparent);
    color: var(--hcv-text);
  }
  ${card2} .hcv-audio-play:not(:disabled):hover { background: color-mix(in srgb, var(--hcv-text) 10%, transparent); }
  ${card2} .hcv-audio-options:hover { color: var(--hcv-text); }
  ${card2} .hcv-audio-play:disabled { opacity: .4; cursor: default; }
  ${card2} :is(.hcv-audio-play, .hcv-audio-options)::before {
    content: '';
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: ${codexMask("resourcePlay")} center / contain no-repeat;
  }
  ${card2} .hcv-audio-play[data-playing="true"]::before { mask-image: ${codexMask("resourcePause")}; }
  ${card2} .hcv-audio-options::before { mask-image: ${codexMask("resourceMore")}; }
  ${card2} .hcv-audio-timeline {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 12px;
    border-block-start: 1px solid var(--hcv-hairline);
    font-variant-numeric: tabular-nums;
  }
  ${card2} .hcv-audio-timeline input {
    flex: 1;
    min-inline-size: 0;
    block-size: 20px;
    margin: 0;
    accent-color: var(--hcv-focus);
    cursor: pointer;
  }
  ${card2} .hcv-audio-timeline input:disabled { opacity: .4; cursor: default; }
  ${card2} :is(.hcv-audio-play, .hcv-audio-options, input):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: 1px;
  }
  @container hcv-audio-card (max-width: 175px) {
    ${card2} .hcv-audio-header { flex-wrap: wrap; }
    ${card2} .hcv-audio-info { flex: 1 1 calc(100% - 64px); }
    ${card2} .hcv-audio-play { margin-inline-start: auto; }
  }
  @container hcv-audio-card (max-width: 110px) {
    ${card2} .hcv-audio-timeline { flex-wrap: wrap; }
    ${card2} .hcv-audio-timeline input { flex: 1 1 30px; }
  }
}
`, { surface: `[${mark}]` });
  function clear() {
    for (const player of players.values()) player.remove();
    players.clear();
  }
  function collect() {
    for (const [audio, player] of players) {
      if (audio.isConnected && audio.matches(selector)) continue;
      player.remove();
      players.delete(audio);
    }
    for (const audio of document.querySelectorAll(selector)) {
      if (players.has(audio)) continue;
      players.set(audio, attachPlayer(audio.parentElement, audio));
    }
  }
  const changes2 = new MutationObserver((records) => {
    if (records.some((record) => movedElementMatches(record, "audio"))) collect();
  });
  function reconcile() {
    changes2.disconnect();
    if (!root.matches(active2) || forcedColors.matches) {
      clear();
      return;
    }
    collect();
    changes2.observe(document.body, { childList: true, subtree: true });
  }
  const theme2 = new MutationObserver((records) => {
    if (records.some((record) => record.attributeName === "data-hermes-theme")) reconcile();
    if (records.some((record) => record.attributeName === "lang")) {
      for (const player of players.values()) player.sync();
    }
  });
  theme2.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  forcedColors.addEventListener("change", reconcile);
  reconcile();
  ctx.onDispose(() => {
    theme2.disconnect();
    changes2.disconnect();
    forcedColors.removeEventListener("change", reconcile);
    clear();
  });
}

// source/chat-video.js
var cardSelector = "[data-hcv-video]";
var rates = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
var labels = {
  ru: {
    play: "\u0412\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0441\u0442\u0438 \u0432\u0438\u0434\u0435\u043E",
    pause: "\u041F\u0440\u0438\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u0435 \u0432\u0438\u0434\u0435\u043E",
    seek: "\u041F\u0435\u0440\u0435\u043C\u043E\u0442\u043A\u0430 \u0432\u0438\u0434\u0435\u043E",
    volume: "\u0413\u0440\u043E\u043C\u043A\u043E\u0441\u0442\u044C \u0432\u0438\u0434\u0435\u043E",
    mute: "\u041E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0437\u0432\u0443\u043A \u0432\u0438\u0434\u0435\u043E",
    options: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0432\u0438\u0434\u0435\u043E",
    speed: "\u0421\u043A\u043E\u0440\u043E\u0441\u0442\u044C \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0434\u0435\u043D\u0438\u044F",
    save: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0432\u0438\u0434\u0435\u043E \u043A\u0430\u043A\u2026",
    pictureInPicture: "\u041A\u0430\u0440\u0442\u0438\u043D\u043A\u0430 \u0432 \u043A\u0430\u0440\u0442\u0438\u043D\u043A\u0435",
    fullscreen: "\u0412\u043E \u0432\u0435\u0441\u044C \u044D\u043A\u0440\u0430\u043D",
    exitFullscreen: "\u0412\u044B\u0439\u0442\u0438 \u0438\u0437 \u043F\u043E\u043B\u043D\u043E\u044D\u043A\u0440\u0430\u043D\u043D\u043E\u0433\u043E \u0440\u0435\u0436\u0438\u043C\u0430",
    video: "\u0412\u0438\u0434\u0435\u043E",
    error: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u0442\u044C \u044D\u0442\u043E \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u0441 \u0432\u0438\u0434\u0435\u043E. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0441\u043D\u043E\u0432\u0430."
  },
  en: {
    play: "Play video",
    pause: "Pause video",
    seek: "Seek in video",
    volume: "Video volume",
    mute: "Mute video",
    options: "Video options",
    speed: "Playback speed",
    save: "Save video as\u2026",
    pictureInPicture: "Picture in picture",
    fullscreen: "Fullscreen",
    exitFullscreen: "Exit fullscreen",
    video: "Video",
    error: "Could not complete this video action. Try again"
  }
};
function element4(tag, className) {
  const el2 = document.createElement(tag);
  el2.className = className;
  return el2;
}
function control(label3, icon8) {
  const el2 = element4("button", "hcv-video-button");
  el2.type = "button";
  el2.dataset.icon = icon8;
  el2.setAttribute("aria-label", label3);
  return el2;
}
function range(label3, max, step2) {
  const el2 = element4("input", "hcv-video-range");
  el2.type = "range";
  el2.min = "0";
  el2.max = max;
  el2.step = step2;
  el2.setAttribute("aria-label", label3);
  return el2;
}
function setRange(el2, value, max, description) {
  el2.value = value;
  el2.style.setProperty("--hcv-video-position", el2.valueAsNumber / max);
  el2.setAttribute("aria-valuetext", description);
}
function clock2(seconds) {
  const whole = Math.max(0, Math.floor(seconds));
  return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, "0")}`;
}
function popover(trigger, className, label3, role) {
  const panel2 = element4("span", `hcv-video-popover ${className}`);
  panel2.setAttribute("popover", "auto");
  panel2.setAttribute("aria-label", label3);
  trigger.setAttribute("aria-haspopup", role);
  trigger.setAttribute("aria-expanded", "false");
  trigger.popoverTargetElement = panel2;
  return panel2;
}
function menuItem(label3, role = "menuitem") {
  const item = element4("button", "hcv-video-menu-item");
  item.type = "button";
  item.tabIndex = -1;
  item.setAttribute("role", role);
  item.textContent = label3;
  return item;
}
function saveVideo(video, filename) {
  const url = video.currentSrc || video.src;
  if (!url) throw new Error("Missing video source");
  const src = new URL(url, document.baseURI);
  if (src.protocol === "hermes-media:" && window.hermesDesktop?.saveGatewayFile) {
    const params = src.searchParams;
    return window.hermesDesktop.saveGatewayFile({
      path: decodeURIComponent(src.pathname.slice(1)),
      connectionId: params.get("connectionId") || (src.hostname === "stream" ? "local" : void 0),
      profile: params.get("profile") || void 0,
      sessionId: params.get("sessionId") || void 0,
      suggestedName: filename
    });
  }
  const sameOrigin = /^(https?):$/.test(src.protocol) && src.origin === location.origin;
  if (!sameOrigin && src.protocol !== "blob:" && !/^data:video\//i.test(url)) {
    throw new Error("Video download source is unavailable");
  }
  const link2 = document.createElement("a");
  link2.href = src.href;
  link2.download = filename;
  link2.click();
}
function attachPlayer2(card2, video) {
  const controller = new AbortController();
  const { signal } = controller;
  let locale = /^ru\b/i.test(document.documentElement.lang) ? "ru" : "en";
  let copy7 = labels[locale];
  let formatPercent = new Intl.NumberFormat(locale, { style: "percent" });
  let formatRate = new Intl.NumberFormat(locale);
  const nativeTitle = card2.firstElementChild;
  const filename = () => nativeTitle?.textContent.trim() || copy7.video;
  const nativeAttrs = ["controls", "tabindex", "preload", "aria-label"].map((name) => [name, video.getAttribute(name)]);
  const controls2 = element4("span", "hcv-video-controls");
  const row5 = element4("span", "hcv-video-row");
  const actions = element4("span", "hcv-video-actions");
  const time = element4("span", "hcv-video-time");
  const status2 = element4("span", "hcv-video-status");
  status2.setAttribute("role", "status");
  status2.hidden = true;
  status2.textContent = copy7.error;
  const play = control(copy7.play, "play");
  const seek = range(copy7.seek, 1, 0.1);
  const volume = control(copy7.volume, "volume");
  const mute = control(copy7.mute, "volume");
  const volumeRange = range(copy7.volume, 1, 0.01);
  const sound = popover(volume, "hcv-video-sound", copy7.volume, "dialog");
  sound.append(mute, volumeRange);
  const options = control(copy7.options, "more");
  const menu = popover(options, "hcv-video-menu", copy7.options, "menu");
  const save = menuItem(copy7.save);
  const separator = document.createElement("hr");
  separator.setAttribute("role", "separator");
  const heading = element4("span", "hcv-video-menu-label");
  heading.textContent = copy7.speed;
  const speedItems = rates.map((rate) => menuItem(`${formatRate.format(rate)}\xD7`, "menuitemradio"));
  const items2 = [save, ...speedItems];
  menu.append(save, separator, heading, ...speedItems);
  const pip = document.pictureInPictureEnabled && !video.disablePictureInPicture ? menuItem(copy7.pictureInPicture) : null;
  if (pip) {
    menu.append(pip);
    items2.push(pip);
  }
  const fullscreen = control(copy7.fullscreen, "fullscreen");
  actions.append(volume, sound, options, menu);
  if (document.fullscreenEnabled) actions.append(fullscreen);
  row5.append(play, seek, time, actions);
  controls2.append(row5, status2);
  video.after(controls2);
  card2.setAttribute("data-hcv-video", "");
  video.controls = false;
  video.tabIndex = 0;
  video.preload = "metadata";
  video.setAttribute("aria-label", filename());
  const listen = (el2, type, fn, extra) => el2.addEventListener(type, fn, { signal, ...extra });
  const duration4 = () => Number.isFinite(video.duration) && video.duration > 0 ? video.duration : 0;
  let drag = null;
  let wasFullscreen = false;
  async function run(action) {
    status2.hidden = true;
    try {
      await action();
    } catch {
      status2.hidden = false;
    }
  }
  function updateTime() {
    const total = duration4();
    const current = Math.min(video.currentTime, total);
    const progress = `${clock2(current)} / ${clock2(total)}`;
    if (time.textContent !== progress) time.textContent = progress;
    seek.max = total || 1;
    seek.disabled = !total;
    setRange(seek, current, total || 1, progress);
  }
  function updatePlayback() {
    const playing = !video.paused && !video.ended;
    play.dataset.icon = playing ? "pause" : "play";
    play.setAttribute("aria-label", playing ? copy7.pause : copy7.play);
  }
  function updateVolume() {
    const level = video.muted ? 0 : video.volume;
    volume.dataset.icon = mute.dataset.icon = level === 0 ? "muted" : "volume";
    mute.setAttribute("aria-pressed", video.muted);
    setRange(volumeRange, level, 1, formatPercent.format(level));
  }
  function updateSpeed() {
    for (const [i, item] of speedItems.entries()) item.setAttribute("aria-checked", video.playbackRate === rates[i]);
  }
  function localize() {
    locale = /^ru\b/i.test(document.documentElement.lang) ? "ru" : "en";
    copy7 = labels[locale];
    formatPercent = new Intl.NumberFormat(locale, { style: "percent" });
    formatRate = new Intl.NumberFormat(locale);
    status2.textContent = copy7.error;
    seek.setAttribute("aria-label", copy7.seek);
    volume.setAttribute("aria-label", copy7.volume);
    mute.setAttribute("aria-label", copy7.mute);
    volumeRange.setAttribute("aria-label", copy7.volume);
    sound.setAttribute("aria-label", copy7.volume);
    options.setAttribute("aria-label", copy7.options);
    menu.setAttribute("aria-label", copy7.options);
    save.textContent = copy7.save;
    heading.textContent = copy7.speed;
    for (const [i, item] of speedItems.entries()) item.textContent = `${formatRate.format(rates[i])}\xD7`;
    if (pip) pip.textContent = copy7.pictureInPicture;
    const full = document.fullscreenElement === card2;
    fullscreen.setAttribute("aria-label", full ? copy7.exitFullscreen : copy7.fullscreen);
    video.setAttribute("aria-label", filename());
    if (full) card2.setAttribute("aria-label", filename());
    updatePlayback();
    updateVolume();
  }
  const togglePlayback = () => void run(() => video.paused ? video.play() : video.pause());
  listen(video, "click", (event) => {
    event.preventDefault();
    togglePlayback();
  });
  listen(video, "keydown", (event) => {
    if (event.key !== " " && event.code !== "Space" && event.key !== "Enter") return;
    event.preventDefault();
    event.stopPropagation();
    if (!event.repeat) togglePlayback();
  });
  listen(play, "click", togglePlayback);
  listen(seek, "input", () => {
    video.currentTime = seek.valueAsNumber;
    updateTime();
  });
  listen(seek, "pointerdown", (event) => {
    if (seek.disabled || event.button !== 0 || drag) return;
    drag = { pointerId: event.pointerId, resume: !video.paused };
    seek.setPointerCapture(event.pointerId);
    video.pause();
  });
  function finishSeek(event) {
    if (drag?.pointerId !== event.pointerId) return;
    const { resume } = drag;
    drag = null;
    if (resume) void run(() => video.play());
  }
  for (const event of ["pointerup", "pointercancel", "lostpointercapture"]) listen(seek, event, finishSeek);
  listen(mute, "click", () => {
    video.muted = !video.muted;
  });
  listen(volumeRange, "input", () => {
    video.volume = volumeRange.valueAsNumber;
    video.muted = false;
    updateVolume();
  });
  for (const [panel2, button5, role] of [[sound, volume, "dialog"], [menu, options, "menu"]]) {
    listen(panel2, "beforetoggle", (event) => {
      if (event.newState === "open") panel2.setAttribute("role", role);
    });
    listen(panel2, "toggle", () => {
      const open = panel2.matches(":popover-open");
      button5.setAttribute("aria-expanded", open);
      if (!open) panel2.removeAttribute("role");
      else if (panel2 === menu) items2[0].focus({ preventScroll: true });
    });
  }
  listen(menu, "keydown", (event) => {
    const index = items2.indexOf(document.activeElement);
    let next;
    switch (event.key) {
      case "ArrowDown":
        next = (index + 1) % items2.length;
        break;
      case "ArrowUp":
        next = index > 0 ? index - 1 : items2.length - 1;
        break;
      case "Home":
        next = 0;
        break;
      case "End":
        next = items2.length - 1;
        break;
      default:
        return;
    }
    event.preventDefault();
    items2[next].focus({ preventScroll: true });
  });
  function choose(item, action) {
    listen(item, "click", () => {
      menu.hidePopover();
      options.focus({ preventScroll: true });
      void run(action);
    });
  }
  choose(save, () => saveVideo(video, filename()));
  for (const [i, item] of speedItems.entries()) choose(item, () => {
    video.playbackRate = rates[i];
  });
  if (pip) choose(pip, () => document.pictureInPictureElement === video ? document.exitPictureInPicture() : video.requestPictureInPicture());
  const toggleFullscreen = () => run(() => document.fullscreenElement === card2 ? document.exitFullscreen() : card2.requestFullscreen());
  listen(fullscreen, "click", toggleFullscreen);
  listen(card2, "fullscreenchange", () => {
    const enabled = document.fullscreenElement === card2;
    fullscreen.dataset.icon = enabled ? "exitFullscreen" : "fullscreen";
    fullscreen.setAttribute("aria-label", enabled ? copy7.exitFullscreen : copy7.fullscreen);
    if (enabled) {
      card2.setAttribute("role", "dialog");
      card2.setAttribute("aria-label", filename());
      video.focus({ preventScroll: true });
    } else if (wasFullscreen) {
      fullscreen.focus({ preventScroll: true });
      card2.removeAttribute("role");
      card2.removeAttribute("aria-label");
    }
    wasFullscreen = enabled;
  });
  listen(card2, "keydown", (event) => {
    if (event.key !== "Escape") return;
    const panel2 = [sound, menu].find((el2) => el2.matches(":popover-open"));
    if (!panel2 && document.fullscreenElement !== card2) return;
    event.preventDefault();
    event.stopPropagation();
    if (panel2) {
      const trigger = panel2 === sound ? volume : options;
      panel2.hidePopover();
      trigger.focus({ preventScroll: true });
    } else void toggleFullscreen();
  });
  for (const event of ["durationchange", "timeupdate", "loadedmetadata", "emptied"]) listen(video, event, updateTime);
  for (const event of ["play", "pause", "ended", "emptied"]) listen(video, event, updatePlayback);
  listen(video, "volumechange", updateVolume);
  listen(video, "ratechange", updateSpeed);
  updateTime();
  updatePlayback();
  updateVolume();
  updateSpeed();
  return {
    localize,
    remove() {
      controller.abort();
      if (document.fullscreenElement === card2) void document.exitFullscreen().catch(() => {
      });
      if (wasFullscreen) {
        card2.removeAttribute("role");
        card2.removeAttribute("aria-label");
      }
      if (drag?.resume && video.isConnected) void video.play().catch(() => {
      });
      controls2.remove();
      card2.removeAttribute("data-hcv-video");
      for (const [name, value] of nativeAttrs) {
        if (value === null) video.removeAttribute(name);
        else video.setAttribute(name, value);
      }
    }
  };
}
function registerChatVideo(ctx, active2, selector) {
  if (!HTMLElement.prototype.showPopover || !CSS.supports("bottom", "anchor(top)")) return;
  const card2 = `${active2} ${cardSelector}`;
  const iconRules2 = Object.entries({
    play: "videoPlay",
    pause: "videoPause",
    volume: "videoVolume",
    muted: "videoMuted",
    more: "videoMore",
    fullscreen: "videoFullscreen",
    exitFullscreen: "videoExitFullscreen"
  }).map(([icon8, mask2]) => `${card2} .hcv-video-button[data-icon="${icon8}"]::before { mask-image: ${codexMask(mask2)}; }`).join("\n");
  mountCSS(ctx, "data-hcv-chat-video", `
  ${card2} {
    --hcv-video-surface: light-dark(#fff, #181818);
    --hcv-video-ink: light-dark(#181818, #dfdfdf);
    --hcv-video-secondary: light-dark(#666, #a1a1a1);
    --hcv-video-track: light-dark(#dedede, #2b2b2b);
    --hcv-video-divider: light-dark(#efefef, #222);
    --hcv-video-thumb: light-dark(#f3f3f3, #282828);
    --hcv-video-thumb-shadow: 0 2px 4px -1px #00000014;
    --hcv-video-ring: light-dark(#0169cc, #0285ff);
    --hcv-video-hover: light-dark(#eeeeee, #292929);
    --hcv-video-menu-surface: light-dark(#fff, #2d2d2d);
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    inline-size: fit-content;
    min-inline-size: min(100%, 14rem);
    max-inline-size: min(100%, 44rem);
    max-block-size: min(48vh, 32rem);
    margin-block: 12px;
    padding: 0;
    border: 0;
    border-radius: 8px;
    background: var(--hcv-video-surface);
    box-shadow: 0 2px 4px -1px #00000014;
    anchor-scope: --hcv-video-volume-anchor, --hcv-video-options-anchor;
  }
  ${card2} > span:first-child { display: none; }
  ${card2} > video {
    display: block;
    flex: 1 1 auto;
    box-sizing: border-box;
    inline-size: 100%;
    block-size: auto;
    min-block-size: 0;
    max-block-size: none;
    margin: 0;
    border-radius: 8px 8px 0 0;
    background: transparent;
    object-fit: contain;
    cursor: pointer;
  }
  ${card2}:fullscreen {
    inline-size: 100%;
    block-size: 100%;
    max-inline-size: none;
    max-block-size: none;
    margin: 0;
    border-radius: 0;
    box-shadow: none;
  }
  ${card2}:fullscreen > video { border-radius: 0; }
  ${card2} .hcv-video-controls {
    container: hcv-video-controls / inline-size;
    flex: none;
    border-block-start: 1px solid var(--hcv-video-divider);
    color: var(--hcv-video-secondary);
    font: 400 12px/16px var(--hcv-ui-font);
    user-select: none;
  }
  ${card2} .hcv-video-row {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    column-gap: 8px;
    block-size: 40px;
    padding-inline: 8px;
  }
  ${card2} .hcv-video-actions {
    display: flex;
    flex: none;
    align-items: center;
    gap: 6px;
    margin-inline-start: auto;
  }
  ${card2} .hcv-video-time { flex: none; white-space: nowrap; font-variant-numeric: tabular-nums; }
  ${card2} .hcv-video-button {
    position: relative;
    display: grid;
    flex: none;
    place-items: center;
    box-sizing: border-box;
    inline-size: 28px;
    block-size: 28px;
    margin: 0;
    padding: 0;
    border: 0;
    border-radius: 10px;
    background: transparent;
    color: var(--hcv-video-secondary);
    cursor: pointer;
  }
  ${card2} .hcv-video-button:is(:hover, [aria-expanded="true"]) { background: var(--hcv-video-hover); }
  ${card2} .hcv-video-button::before {
    content: "";
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: none center / contain no-repeat;
  }
  ${iconRules2}
  ${card2} .hcv-video-button::after {
    position: absolute;
    z-index: 1;
    inset-inline-end: 0;
    inset-block-end: calc(100% + 5px);
    content: attr(aria-label);
    inline-size: max-content;
    max-inline-size: 320px;
    padding: ${codexReference.tooltip.padding};
    border-radius: ${codexReference.tooltip.radius};
    background: var(--hcv-dropdown-background);
    color: var(--hcv-dropdown-text);
    box-shadow: var(--hcv-popover-shadow);
    font: 400 13px/18px var(--hcv-ui-font);
    letter-spacing: -.15px;
    pointer-events: none;
    visibility: hidden;
    transition: visibility 0s;
  }
  ${card2} .hcv-video-row > .hcv-video-button::after { inset-inline: 0 auto; }
  ${card2} .hcv-video-button:not([aria-expanded="true"]):is(:hover, :focus-visible)::after {
    visibility: visible;
    transition-delay: 150ms;
  }
  ${card2} .hcv-video-range {
    appearance: none;
    flex: 1 1 0;
    min-inline-size: 0;
    block-size: 24px;
    margin: 0;
    padding: 0;
    border: 0;
    border-radius: 0;
    background: transparent;
    cursor: pointer;
    touch-action: none;
  }
  ${card2} .hcv-video-range:disabled { opacity: .4; cursor: default; }
  ${card2} .hcv-video-range::-webkit-slider-runnable-track {
    --fill: calc(8px + (100% - 16px) * var(--hcv-video-position, 0));
    block-size: 2px;
    border-radius: 999px;
    background: linear-gradient(to right, var(--hcv-video-ink) var(--fill), var(--hcv-video-track) var(--fill));
  }
  ${card2} .hcv-video-range::-webkit-slider-thumb {
    appearance: none;
    box-sizing: border-box;
    inline-size: 16px;
    block-size: 16px;
    margin-block-start: -7px;
    border: 1px solid color-mix(in srgb, var(--hcv-video-ink) 8%, transparent);
    border-radius: 50%;
    background: var(--hcv-video-thumb);
    box-shadow: var(--hcv-video-thumb-shadow);
    outline: none;
  }
  ${card2} :is(video, .hcv-video-button, .hcv-video-menu-item):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${card2} .hcv-video-range:focus { outline: none; }
  ${card2} .hcv-video-range:focus-visible:not(:active)::-webkit-slider-thumb {
    box-shadow: 0 0 0 2px var(--hcv-video-ring), var(--hcv-video-thumb-shadow);
  }
  ${card2} .hcv-video-actions > [data-icon="more"] { anchor-name: --hcv-video-options-anchor; }
  ${card2} .hcv-video-actions > :is([data-icon="volume"], [data-icon="muted"]) { anchor-name: --hcv-video-volume-anchor; }
  ${card2} .hcv-video-popover {
    position: fixed;
    inset: auto;
    right: anchor(right);
    bottom: calc(anchor(top) + 5px);
    position-try-fallbacks: flip-block, flip-inline, flip-block flip-inline;
    box-sizing: border-box;
    max-inline-size: calc(100vw - 16px);
    max-block-size: calc(100vh - 16px);
    margin: 0;
    padding: 4px;
    border: 0;
    border-radius: 16px;
    background: var(--hcv-video-menu-surface);
    box-shadow: 0 4px 12px #0003, inset 0 0 0 .5px #ffffff12;
    color: var(--hcv-video-ink);
  }
  ${card2} .hcv-video-sound {
    position-anchor: --hcv-video-volume-anchor;
    inline-size: 168px;
    align-items: center;
    gap: 8px;
  }
  ${card2} .hcv-video-sound:popover-open { display: flex; }
  ${card2} .hcv-video-menu {
    position-anchor: --hcv-video-options-anchor;
    inline-size: max-content;
    overflow-y: auto;
    font-size: 13px;
    line-height: 1.43;
  }
  ${card2} .hcv-video-menu-item, ${card2} .hcv-video-menu-label { padding: 4px 8px; }
  ${card2} .hcv-video-menu-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    inline-size: 100%;
    min-block-size: 28px;
    border: 0;
    border-radius: 8px;
    color: inherit;
    background: transparent;
    font: inherit;
    text-align: start;
    cursor: pointer;
  }
  ${card2} .hcv-video-menu-item:is(:hover, :focus-visible) { background: color-mix(in srgb, currentColor 10%, transparent); }
  ${card2} .hcv-video-menu-item[aria-checked="true"]::after {
    content: "";
    inline-size: 14px;
    block-size: 14px;
    background: currentColor;
    mask: ${codexMask("check")} center / contain no-repeat;
  }
  ${card2} .hcv-video-menu-label { display: block; color: var(--hcv-video-secondary); }
  ${card2} .hcv-video-menu hr {
    margin: 4px;
    border: 0;
    border-block-start: 1px solid var(--hcv-video-track);
  }
  ${card2} .hcv-video-status:not([hidden]) { display: block; padding: 0 8px 8px; }
  @container hcv-video-controls (width < 320px) {
    ${card2} .hcv-video-row { block-size: auto; padding-block: 4px; }
    ${card2} .hcv-video-row > .hcv-video-range { order: -1; flex-basis: 100%; }
  }
  `, { surface: cardSelector });
  const root = document.documentElement;
  const forcedColors = window.matchMedia("(forced-colors: active)");
  const players = /* @__PURE__ */ new Map();
  function collect() {
    for (const [video, player] of players) {
      if (video.isConnected && video.parentElement === player.card && video.matches(selector)) continue;
      player.remove();
      players.delete(video);
    }
    for (const video of document.querySelectorAll(selector)) {
      if (players.has(video) || !video.controls) continue;
      const card3 = video.parentElement;
      players.set(video, { card: card3, ...attachPlayer2(card3, video) });
    }
  }
  function clear() {
    for (const { remove } of players.values()) remove();
    players.clear();
  }
  const changes2 = new MutationObserver((records) => {
    if (records.some((record) => movedElementMatches(record, "video"))) collect();
  });
  function reconcile() {
    changes2.disconnect();
    if (!root.matches(active2) || forcedColors.matches) {
      clear();
      return;
    }
    collect();
    changes2.observe(document.body, { childList: true, subtree: true });
  }
  const theme2 = new MutationObserver((records) => {
    if (records.some((record) => record.attributeName === "data-hermes-theme")) reconcile();
    if (records.some((record) => record.attributeName === "lang")) {
      for (const player of players.values()) player.localize();
    }
  });
  theme2.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  forcedColors.addEventListener("change", reconcile);
  reconcile();
  ctx.onDispose(() => {
    theme2.disconnect();
    changes2.disconnect();
    forcedColors.removeEventListener("change", reconcile);
    clear();
  });
}

// source/chat-resources.js
var revealIcon = "svg.tabler-icon-folder-open";
var secondaryAction = `button:has(> :is(svg.tabler-icon-download, ${revealIcon}))`;
var directoryCard = `:has(> button:last-child > ${revealIcon})`;
var previewResourceCard = "div:has(> span:first-child > svg.tabler-icon-device-desktop-analytics):has(> span.truncate[title] + button)";
function registerChatResources(ctx, active2) {
  const thread = `${active2} [data-chat-surface] [data-slot="aui_thread-content"]`;
  const answer2 = `${thread} [data-slot="aui_assistant-message-content"]`;
  const preview3 = `${answer2} ${previewResourceCard}`;
  const site = `${preview3}:has(> span[title]:is([title^="http://" i], [title^="https://" i]))`;
  const directory = `${preview3}${directoryCard}`;
  const file = `${preview3}:not(${site}, ${directory})`;
  const artifact = `${answer2} [data-slot="aui_artifact-card"]`;
  const icon8 = `:is(${preview3}, ${artifact}) > span:first-child`;
  const withPreview = `${preview3}:not(${directoryCard})`;
  const open = `${withPreview} > button:last-child`;
  const trailing = `${preview3} > ${secondaryAction}`;
  const secondary2 = `${preview3} > ${secondaryAction}:not(:last-child)`;
  const reveal = `${preview3} > button:has(> ${revealIcon})`;
  const media2 = `${answer2} .aui-md span[class~="bg-muted/35"]`;
  const image = `${thread} :is([data-slot="aui_embedded-images"], [data-slot="aui_markdown-image"])`;
  const generated2 = `${answer2} [data-slot="aui_generated-image"]`;
  const imageDownload = `:is(${image}, ${generated2}) button:has(> svg.tabler-icon-download)`;
  const imageFocus = `${image} button:focus-visible > img`;
  const forcedColors = window.matchMedia("(forced-colors: active)");
  function openFromCard(event) {
    const target = event.target;
    if (event.defaultPrevented || forcedColors.matches || !(target instanceof Element) || target.closest("button")) return;
    const card2 = target.closest(preview3);
    if (card2 && document.getSelection()?.isCollapsed !== false) card2.lastElementChild.click();
  }
  const style = document.createElement("style");
  style.dataset.hcvChatResources = "";
  style.textContent = `
@media (forced-colors: none) {
  /* fLcv and qO6B in 739301.37a39f26d6.js, Desktop tokens in 9ec44337a842.css. */
  :is(${preview3}, ${artifact}) {
    box-sizing: border-box;
    inline-size: 100%;
    max-inline-size: 100%;
    min-inline-size: 0;
    min-block-size: 64px;
    margin-block: 6px;
    padding: 12px;
    border: 0;
    border-radius: 10px;
    corner-shape: superellipse(1.5);
    box-shadow: inset 0 0 0 .5px var(--hcv-hairline);
    background: color-mix(in oklab, var(--hcv-panel) 50%, transparent);
    color: var(--hcv-text);
    font-family: var(--hcv-ui-font);
  }
  ${preview3} {
    container-type: inline-size;
    display: grid;
    grid-template-columns: 40px minmax(0, 1fr) auto;
    grid-template-rows: 1fr 1fr;
    gap: 0 10px;
  }
  :is(${file}, ${directory}) {
    max-inline-size: 32rem;
    min-block-size: 52px;
    padding: 6px;
  }
  ${directory} { grid-template-rows: 1fr; }
  ${directory} > span[title] { align-self: center; }
  ${artifact} { gap: 10px; }
  @supports (corner-shape: superellipse(1.5)) {
    :is(${preview3}, ${artifact}) { border-radius: 12.5px; }
  }
  ${icon8} {
    inline-size: 40px;
    block-size: 40px;
    border-radius: 10px;
    background: var(--hcv-hover);
    color: var(--hcv-muted);
  }
  ${preview3} > span:first-child {
    grid-area: 1 / 1 / 3 / 2;
  }
  ${preview3} > span:first-child > svg { display: none; }
  ${preview3} > span:first-child::before {
    content: "";
    inline-size: 24px;
    block-size: 24px;
    background: currentColor;
    mask: ${codexMask("resourceDocument")} center / 20px no-repeat;
  }
  ${site} > span:first-child::before { mask-image: ${codexMask("web")}; mask-size: contain; }
  ${directory} > span:first-child::before { mask-image: ${codexMask("folder")}; mask-size: contain; }
  ${artifact} > span:first-child > :is(.codicon-browser, .codicon-symbol-color) {
    inline-size: 24px;
    block-size: 24px;
    background: currentColor;
    mask: ${codexMask("web")} center / contain no-repeat;
    font-size: 0;
  }
  ${artifact} > span:first-child > .codicon-symbol-color { mask-image: ${codexMask("image")}; }
  ${artifact} > span:first-child > :is(.codicon-browser, .codicon-symbol-color)::before { visibility: hidden; }
  ${preview3} > span[title], ${artifact} > span:nth-child(2) > span:first-child {
    color: var(--hcv-text);
    font: 500 var(--conversation-text-font-size, 13px) / 20px var(--hcv-ui-font);
  }
  ${preview3} > span[title] { grid-area: 1 / 2; align-self: end; }
  ${open}, ${artifact} > span:nth-child(2) > span + span {
    color: var(--hcv-muted);
    font: 400 calc(var(--conversation-text-font-size, 13px) - 1px) / 18px var(--hcv-ui-font);
  }
  ${open} {
    grid-area: 2 / 2;
    align-self: start;
    min-inline-size: 0;
    overflow: hidden;
    padding: 0;
    border: 0;
    border-radius: inherit;
    background: transparent;
    text-align: start;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  ${preview3}:has(> button:last-child:not(:disabled)) { cursor: pointer; }
  ${trailing} {
    grid-area: 1 / 3 / 3 / 4;
    min-block-size: 28px;
    padding: 0 8px;
    border: 0;
    border-radius: 8px;
    background: transparent;
    color: var(--hcv-muted);
    font: 400 12px/18px var(--hcv-ui-font);
  }
  ${directory} > button { grid-row: 1; }
  ${reveal} {
    justify-content: center;
    gap: 4px;
    white-space: nowrap;
  }
  @container (max-width: 340px) {
    ${reveal} { min-inline-size: 28px; padding-inline: 0; font-size: 0; gap: 0; }
  }
  ${preview3} > button > svg { inline-size: 16px; block-size: 16px; }
  ${artifact} > span:nth-child(3) {
    max-inline-size: 40%;
    overflow: hidden;
    padding: 4px 8px;
    border-radius: 8px;
    color: var(--hcv-muted);
    font: 400 12px/18px var(--hcv-ui-font);
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  ${artifact}:focus-visible > span:nth-child(3) { opacity: 1; }
  /* GnI8 in 904817.6fbcca27bc.js reveals the trailing action on hover or focus. */
  @media (hover: hover) {
    ${secondary2}:not(:disabled) { opacity: 0; pointer-events: none; }
    ${preview3}:is(:hover, :focus-within) > ${secondaryAction}:not(:last-child):not(:disabled) {
      opacity: 1;
      pointer-events: auto;
    }
    ${preview3}:hover:has(> button:last-child:not(:disabled)),
    ${artifact}:not(:disabled):hover {
      background-image: linear-gradient(var(--hcv-resource-hover), var(--hcv-resource-hover));
      --hcv-resource-hover: color-mix(in oklab, var(--hcv-hover-menu) 30%, transparent);
    }
  }
  @media (hover: none) {
    ${artifact} > span:nth-child(3) { opacity: 1; }
  }
  @media (prefers-reduced-motion: reduce) {
    :is(${preview3}, ${artifact}, ${secondary2}, ${artifact} > span:nth-child(3)) { transition: none; }
  }
  ${withPreview}:has(> button:last-child:focus-visible),
  :is(${artifact}, ${secondary2}, ${reveal}, ${imageDownload}):focus-visible,
  ${generated2} > button:first-of-type:focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${open}:focus-visible { outline: none; }

  ${image} img, ${generated2} { border-radius: 12px; }
  ${image} img {
    border: 0;
    outline: 1px solid light-dark(oklch(0 0 0 / 0.1), oklch(1 0 0 / 0.1));
    outline-offset: -1px;
  }
  ${imageFocus} { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${imageDownload} {
    border: 0;
    border-radius: 8px;
    box-shadow: none;
    background: var(--hcv-panel);
    color: var(--hcv-muted);
  }
  :is(${secondary2}, ${reveal}, ${imageDownload}):not(:disabled):hover {
    background: var(--hcv-selected);
    color: var(--hcv-text);
  }
  ${codexIconRules(`:is(${preview3} > button, ${imageDownload}) > svg.tabler-icon-download`, "download")}
  ${codexIconRules(`${reveal} > ${revealIcon}`, "folderOpen")}

}
`;
  mountStyle(ctx, style, { surface: '[data-slot="aui_assistant-message-content"], [data-slot="aui_user-message-root"]', retainAcrossChatTabs: true });
  registerChatAudio(ctx, active2, `${media2} > audio`);
  registerChatVideo(ctx, active2, `${media2} > video`);
  document.addEventListener("click", openFromCard);
  ctx.onDispose(() => {
    document.removeEventListener("click", openFromCard);
    style.remove();
  });
}

// source/summary-sources-view.js
import { DropdownMenu as DropdownMenu2, DropdownMenuContent as DropdownMenuContent2, DropdownMenuItem as DropdownMenuItem2, DropdownMenuTrigger as DropdownMenuTrigger2, useI18n as useI18n2 } from "@hermes/plugin-sdk";
import { createElement as h5, useRef as useRef2, useState as useState2 } from "react";

// source/summary-section.js
import { createElement as h4, useId } from "react";
function SummarySection({ kind, title, expanded, onToggle, action, children, ...props }) {
  const id2 = useId();
  return h4(
    "section",
    { ...props, "data-hcv-summary-section": kind, "data-collapsed": !expanded || void 0, "aria-label": title },
    h4(
      "header",
      null,
      h4(
        "button",
        {
          type: "button",
          "data-hcv-summary-heading": "",
          "aria-controls": id2,
          "aria-expanded": expanded,
          onClick: onToggle
        },
        h4("span", { title, dir: "auto" }, title),
        h4("span", { "aria-hidden": true, "data-hcv-summary-chevron": "", style: codexIconStyle("down") })
      ),
      action
    ),
    h4(
      "div",
      { id: id2, "data-hcv-summary-disclosure": "", inert: !expanded, "aria-hidden": !expanded },
      h4("div", { "data-hcv-summary-contents": "" }, children)
    )
  );
}
function summarySectionStyles(card2) {
  const section2 = card2 + " > [data-hcv-summary-section]";
  return `
${section2} + [data-hcv-summary-section] {
  border-block-start: .5px solid var(--hcv-hairline);
  margin-block-start: 8px;
  padding-block-start: 8px;
}
${section2}[data-hcv-summary-section="outputs"] + [data-hcv-summary-agents] { border-block-start: 0; padding-block-start: 0; }
${section2} > header { display: flex; align-items: center; gap: 4px; min-block-size: 28px; }
${section2} [data-hcv-summary-heading] {
  display: flex; align-items: center; gap: 6px; min-inline-size: 0; max-inline-size: 100%;
  min-block-size: 24px; padding: 0; border: 0; border-radius: 6px; background: none; cursor: pointer;
  color: var(--hcv-muted); font: inherit; text-align: start;
}
${section2} [data-hcv-summary-heading] > span:first-child { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${section2} [data-hcv-summary-chevron] {
  display: block; inline-size: 12px; block-size: 12px; flex: none; opacity: 0;
}
${section2} [data-hcv-summary-heading]:is(:hover, :focus-visible, [aria-expanded="false"]) [data-hcv-summary-chevron] { opacity: 1; }
${section2}[data-collapsed] [data-hcv-summary-chevron] { rotate: -90deg; }
${section2}[data-collapsed]:dir(rtl) [data-hcv-summary-chevron] { rotate: 90deg; }
${section2} > header > :last-child:not([data-hcv-summary-heading]) { margin-inline-start: auto; }
${section2} [data-hcv-summary-disclosure] {
  display: grid; grid-template-columns: minmax(0, 1fr); grid-template-rows: 1fr; margin-block-start: 2px;
}
${section2}[data-collapsed] [data-hcv-summary-disclosure] { grid-template-rows: 0fr; opacity: 0; margin-block-start: 0; }
${section2} [data-hcv-summary-contents] { min-inline-size: 0; min-block-size: 0; overflow: clip; margin-inline: -8px; padding-inline: 8px; }
@media (prefers-reduced-motion: no-preference) {
  ${section2} [data-hcv-summary-disclosure] {
    transition: grid-template-rows 300ms cubic-bezier(.19, 1, .22, 1), opacity 300ms cubic-bezier(.19, 1, .22, 1);
  }
  ${section2} [data-hcv-summary-chevron] { transition: rotate 300ms cubic-bezier(.19, 1, .22, 1); }
}
`;
}

// source/summary-sources-view.js
var labels2 = {
  ru: {
    title: "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438",
    outputs: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B",
    pullRequests: "\u0417\u0430\u043F\u0440\u043E\u0441\u044B \u043D\u0430 \u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439",
    showAll: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0432\u0441\u0435",
    add: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A",
    addHint: "\u041F\u0440\u0438\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0444\u0430\u0439\u043B\u044B \u0438\u043B\u0438 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u044F",
    attach: "\u041F\u0440\u0438\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0444\u0430\u0439\u043B\u044B \u0438\u043B\u0438 \u043F\u0430\u043F\u043A\u0438",
    plugins: "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u044C \u043F\u043B\u0430\u0433\u0438\u043D\u044B",
    connectors: "\u041A\u043E\u043D\u043D\u0435\u043A\u0442\u043E\u0440\u044B",
    connector: "\u041A\u043E\u043D\u043D\u0435\u043A\u0442\u043E\u0440 Hermes",
    image: "\u0418\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435",
    file: "\u0424\u0430\u0439\u043B",
    folder: "\u041F\u0430\u043F\u043A\u0430",
    link: "\u0421\u0441\u044B\u043B\u043A\u0430",
    attached: "\u041F\u0440\u0438\u043A\u0440\u0435\u043F\u043B\u0435\u043D\u043E \u043A \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0443",
    provided: "\u041F\u0440\u0435\u0434\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u043E \u0432 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0435",
    fromChat: "\u0418\u0437 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u0430",
    empty: "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u043E\u0432",
    loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
    unavailable: "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B"
  },
  en: {
    title: "Sources",
    outputs: "Outputs",
    pullRequests: "Pull requests",
    showAll: "View all",
    add: "Add source",
    addHint: "Attach files or connect apps",
    attach: "Attach files or folders",
    plugins: "Use plugins",
    connectors: "Connectors",
    connector: "Hermes connector",
    image: "Image",
    file: "File",
    folder: "Folder",
    link: "Link",
    attached: "Attached to the conversation",
    provided: "Provided in the conversation",
    fromChat: "From the conversation",
    empty: "No active sources",
    loading: "Loading\u2026",
    unavailable: "Sources unavailable"
  }
};
var composerAdd = '[data-slot="composer-root"] button[aria-haspopup="menu"]:has(> .codicon-add)';
function icon2(name) {
  return h5("span", { "aria-hidden": true, className: "hcv-source-glyph", style: codexIconStyle(name) });
}
function viewAllIcon() {
  return h5(
    "svg",
    { "aria-hidden": true, className: "hcv-sources-all-icon", viewBox: "0 0 20 20", fill: "currentColor" },
    h5("path", { d: "M16.6345 5.83331C16.6345 4.81987 15.813 3.99835 14.7996 3.99835C13.7863 3.99855 12.9646 4.81999 12.9646 5.83331C12.9646 6.84663 13.7863 7.66808 14.7996 7.66827C15.813 7.66827 16.6345 6.84676 16.6345 5.83331ZM3.36499 14.1663C3.36499 15.1798 4.18651 16.0013 5.19995 16.0013C6.21339 16.0013 7.03491 15.1798 7.03491 14.1663C7.03471 13.153 6.21327 12.3314 5.19995 12.3314C4.18663 12.3314 3.36519 13.153 3.36499 14.1663ZM17.9646 5.83331C17.9646 7.58129 16.5475 8.99835 14.7996 8.99835C13.2785 8.99818 12.0078 7.92497 11.7039 6.49445L11.6667 6.49835H11.3347C10.5362 6.49835 9.96426 6.49872 9.54565 6.52081C9.21098 6.53848 9.04089 6.56873 8.96069 6.59113L8.90796 6.60968C8.41777 6.86301 8.2248 7.46527 8.47632 7.95636L8.50757 8.00323C8.55968 8.068 8.68066 8.19148 8.94312 8.4007C9.27097 8.66203 9.73648 8.99501 10.3865 9.45929L11.239 10.0716C11.489 10.2539 11.7044 10.4155 11.8855 10.5599C12.2255 10.8309 12.5425 11.1144 12.7078 11.4368L12.8054 11.6536C13.206 12.6785 12.8306 13.8502 11.9089 14.4515L11.7029 14.5716C11.381 14.7379 10.9584 14.785 10.5242 14.8079C10.0619 14.8323 9.44766 14.8314 8.66479 14.8314H8.33276C8.31992 14.8314 8.30734 14.8282 8.29468 14.8275C7.9907 16.2581 6.72124 17.3314 5.19995 17.3314C3.45197 17.3314 2.03491 15.9143 2.03491 14.1663C2.03511 12.4185 3.45209 11.0013 5.19995 11.0013C6.72066 11.0013 7.99008 12.0743 8.29468 13.5042C8.30731 13.5035 8.31995 13.5013 8.33276 13.5013H8.66479C9.46362 13.5013 10.0362 13.5019 10.4548 13.4798C10.9013 13.4562 11.0544 13.4096 11.0925 13.39L11.1804 13.3382C11.5766 13.0799 11.7385 12.5765 11.5662 12.136L11.5242 12.0433C11.5046 12.0051 11.4062 11.8788 11.0564 11.5999C10.8925 11.4693 10.6943 11.3206 10.4558 11.1468L9.61304 10.5413C8.97593 10.0862 8.47599 9.72927 8.11401 9.44073C7.81659 9.20364 7.53702 8.95681 7.36108 8.68292L7.29272 8.56378C6.70695 7.42066 7.15568 6.0189 8.29663 5.42902L8.42163 5.3714C8.7241 5.25059 9.09524 5.21275 9.47534 5.19269C9.93756 5.16829 10.5518 5.16827 11.3347 5.16827H11.6667L11.7039 5.1712C12.0082 3.74114 13.2788 2.66845 14.7996 2.66827C16.5475 2.66827 17.9646 4.08533 17.9646 5.83331Z" })
  );
}
function connectorRows(connectors) {
  return (connectors ?? []).map(({ name }) => ({ kind: "source", key: name, name }));
}
function sourceLabel(row5, copy7) {
  return row5.name || ({ image: copy7.image, folder: copy7.folder, link: copy7.link }[row5.kind] ?? copy7.file);
}
function sourceDescription(row5, copy7) {
  if (row5.kind === "source") return copy7.connector;
  if (!row5.attached) return copy7.fromChat;
  return row5.kind === "link" ? copy7.provided : copy7.attached;
}
function SourceRow({ row: row5, expanded = false, copy: copy7, onOpenSource, onConnectors }) {
  const name = sourceLabel(row5, copy7);
  const open = row5.kind === "source" ? onConnectors && (() => onConnectors(row5.name)) : row5.action && onOpenSource && (() => onOpenSource(row5));
  const props = { className: "hcv-source-row", title: name };
  const content = h5("span", { className: "hcv-source-leading", "aria-hidden": true }, row5.thumbnail ? h5("img", { className: "hcv-source-thumbnail", src: row5.thumbnail, alt: "", draggable: false }) : icon2(row5.kind));
  const text = h5(
    "span",
    { className: "hcv-source-text" },
    h5("span", { className: "hcv-source-title", dir: "auto" }, name),
    expanded && row5.meta && h5("span", { className: "hcv-source-meta", dir: "auto" }, row5.meta)
  );
  return h5(
    "li",
    { "data-hcv-source-row": row5.kind },
    h5(open ? "button" : "div", open ? { ...props, type: "button", "aria-label": name, onClick: open } : props, content, text),
    expanded && h5("p", { className: "hcv-source-description" }, sourceDescription(row5, copy7))
  );
}
function sourceList(rows, props) {
  return rows.map((row5) => h5(SourceRow, { ...props, key: `${row5.kind}:${row5.key}`, row: row5 }));
}
function openComposerMenu(getChat) {
  const chat3 = getChat?.();
  requestAnimationFrame(() => {
    if (!chat3?.isConnected || getChat() !== chat3) return;
    const add = chat3.querySelector(composerAdd);
    if (!add || add.disabled || add.getAttribute("aria-expanded") === "true") return;
    add.focus({ preventScroll: true });
    add.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
  });
}
function CompactSources({ rows = [], connectors, loading, onExpand, onConnectors, onOpenSource, getChat, disclosure: disclosure2 }) {
  const { locale } = useI18n2();
  const copy7 = labels2[locale] || labels2.en;
  const [menuOpen, setMenuOpen] = useState2(false);
  const movingFocus = useRef2(false);
  const items2 = [...rows, ...connectorRows(connectors)];
  const showMenu = () => setMenuOpen(true);
  function menuAction(action) {
    movingFocus.current = true;
    action();
  }
  const add = h5(
    DropdownMenu2,
    { open: menuOpen, onOpenChange: setMenuOpen, modal: false },
    h5(DropdownMenuTrigger2, { asChild: true }, h5("button", {
      type: "button",
      className: "hcv-sources-add",
      "aria-label": copy7.add,
      title: copy7.addHint
    }, icon2("plus"))),
    h5(
      DropdownMenuContent2,
      {
        align: "end",
        sideOffset: 4,
        "data-hcv-sources-add-menu": "",
        onCloseAutoFocus: (event) => {
          if (movingFocus.current) event.preventDefault();
          movingFocus.current = false;
        }
      },
      h5(DropdownMenuItem2, { disabled: !onConnectors, onSelect: () => menuAction(() => onConnectors()) }, icon2("plugins"), copy7.plugins),
      h5(DropdownMenuItem2, { disabled: !getChat, onSelect: () => menuAction(() => openComposerMenu(getChat)) }, icon2("attach"), copy7.attach)
    )
  );
  return h5(
    SummarySection,
    { ...disclosure2, kind: "sources", title: copy7.title, action: add, "data-hcv-sources-compact": "" },
    items2.length ? [
      h5("ul", { key: "list", "aria-label": copy7.title }, sourceList(items2.slice(0, 3), { copy: copy7, onOpenSource, onConnectors })),
      h5(
        "button",
        { key: "expand", type: "button", className: "hcv-source-row hcv-sources-all", onClick: onExpand },
        h5("span", { className: "hcv-source-leading" }, viewAllIcon()),
        h5("span", null, copy7.showAll)
      )
    ] : loading ? h5("p", { role: "status", className: "hcv-sources-state" }, copy7.loading) : h5("button", { type: "button", className: "hcv-source-row hcv-sources-empty", onClick: showMenu }, copy7.addHint)
  );
}
function CompactSummaryItems({ kind, rows, onOpenSource, disclosure: disclosure2 }) {
  const { locale } = useI18n2();
  const copy7 = labels2[locale] || labels2.en;
  if (!rows.length) return null;
  return h5(
    SummarySection,
    { ...disclosure2, kind, title: copy7[kind], "data-hcv-summary-items": "" },
    h5("ul", { "aria-label": copy7[kind] }, sourceList(rows, { copy: copy7, onOpenSource }))
  );
}
function SourcesPane({ rows = [], connectors, loading, onConnectors, onOpenSource }) {
  const { locale } = useI18n2();
  const copy7 = labels2[locale] || labels2.en;
  const items2 = [...rows, ...connectorRows(connectors)];
  return h5(
    "div",
    { "data-hcv-sources-pane": "" },
    items2.length ? h5("ul", { "aria-label": copy7.title }, ...sourceList(items2, { expanded: true, copy: copy7, onOpenSource, onConnectors })) : h5("p", { role: "status", className: "hcv-sources-state" }, loading ? copy7.loading : connectors == null ? copy7.unavailable : copy7.empty),
    onConnectors && h5("button", { type: "button", className: "hcv-sources-connectors", onClick: () => onConnectors() }, icon2("source"), copy7.connectors)
  );
}
function registerSummarySources(ctx, active2) {
  const compact = `${active2} :is([data-hcv-sources-compact], [data-hcv-summary-items])`;
  const pane = `${active2} [data-hcv-sources-pane]`;
  const view = `${active2} :is([data-hcv-sources-compact], [data-hcv-sources-pane], [data-hcv-summary-items])`;
  const menu = `${active2} [data-hcv-sources-add-menu]`;
  const style = document.createElement("style");
  style.dataset.hcvSummarySources = "";
  style.textContent = `
    ${view} {
      --hcv-source-tertiary: light-dark(rgb(26 28 31 / 50%), rgb(255 255 255 / 50%));
      color: var(--hcv-text); font: 13px/20px var(--hcv-ui-font); text-align: start; min-inline-size: 0;
    }
    ${view} ul { list-style: none; margin: 0; padding: 0; }
    ${view} :is(button, p) { margin: 0; }
    ${view} button { appearance: none; background: transparent; border: 0; color: inherit; font: inherit; text-align: inherit; cursor: pointer; }
    ${view} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
    ${view} .hcv-source-leading { display: grid; place-items: center; flex: 0 0 18px; inline-size: 18px; }
    ${view} .hcv-source-text { display: flex; flex: 1; flex-direction: column; min-inline-size: 0; }
    :is(${view}, ${menu}) .hcv-source-glyph { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; }
    ${view} .hcv-source-thumbnail {
      display: block; inline-size: 18px; block-size: 18px; border-radius: 3px;
      border: 1px solid var(--hcv-hairline); object-fit: cover;
    }
    ${view} .hcv-source-row { inline-size: 100%; min-inline-size: 0; display: flex; align-items: center; }
    ${view} .hcv-sources-state { padding-block: 4px; color: var(--hcv-muted); }

    ${compact} .hcv-sources-add {
      display: grid; place-items: center; inline-size: 24px; block-size: 24px; padding: 0; margin-inline-end: -6px;
      border-radius: 7px; color: color-mix(in srgb, var(--hcv-text) 40%, transparent);
    }
    ${compact} .hcv-sources-add:is(:hover, [data-state="open"]) { color: var(--hcv-text); background: color-mix(in srgb, var(--hcv-text) 8%, transparent); }
    ${compact} [data-hcv-summary-contents] > ul { display: flex; flex-direction: column; }
    ${compact} .hcv-source-row {
      position: relative; isolation: isolate; gap: 12px; min-block-size: 28px;
      padding: 4px 0; border-radius: 6px; color: var(--hcv-muted);
    }
    ${compact} button.hcv-source-row:not(.hcv-sources-all):not(.hcv-sources-empty):hover::before {
      content: ''; position: absolute; z-index: -1; inset: 0 -8px; border-radius: 6px;
      background: color-mix(in srgb, var(--hcv-text) 8%, transparent);
    }
    ${compact} .hcv-source-title { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
    ${compact} :is(.hcv-sources-all, .hcv-sources-empty) { color: color-mix(in srgb, var(--hcv-text) 40%, transparent); }
    ${compact} :is(.hcv-sources-all, .hcv-sources-empty):hover { color: var(--hcv-text); }
    ${compact} .hcv-sources-all-icon { inline-size: 20px; block-size: 20px; max-inline-size: none; }
    ${menu} { min-inline-size: 200px; z-index: calc(var(--z-modal-backdrop, 120) - 1); }

    ${pane} { flex: 1; block-size: 100%; min-block-size: 0; overflow: auto; background: var(--hcv-chat); }
    ${pane} > ul { padding-inline: 16px; }
    ${pane} [data-hcv-source-row] { padding-block: 16px; border-block-end: 1px solid var(--hcv-hairline); }
    ${pane} [data-hcv-source-row]:last-child { border-block-end: 0; }
    ${pane} .hcv-source-row { gap: 8px; padding: 0; border-radius: 8px; }
    ${pane} .hcv-source-leading { block-size: 20px; }
    ${pane} .hcv-source-text { gap: 2px; }
    ${pane} .hcv-source-title { font: 500 13px/18.5714px var(--hcv-ui-font); overflow-wrap: anywhere; }
    ${pane} .hcv-source-meta { font: 12px/16px var(--hcv-ui-font); color: var(--hcv-source-tertiary); word-break: break-all; }
    ${pane} .hcv-source-description { margin-block-start: 12px; padding-inline-start: 24px; font-size: 13px; line-height: 20px; color: var(--hcv-muted); }
    ${pane} .hcv-sources-state { margin: 12px 16px 0; }
    ${pane} .hcv-sources-connectors {
      display: flex; align-items: center; gap: 8px; margin: 0 16px 16px; padding: 4px 8px;
      border-radius: 8px; color: var(--hcv-muted);
    }
    ${pane} .hcv-sources-connectors:hover { color: var(--hcv-text); background: var(--hcv-hover); }
  `;
  mountStyle(ctx, style, { surface: "[data-hcv-sources-compact], [data-hcv-sources-pane], [data-hcv-sources-add-menu], [data-hcv-summary-items]", retainAcrossChatTabs: true });
}

// source/summary-sources.js
var transcript = '[data-slot="aui_thread-content"]';
var filePreview = `[data-slot="aui_assistant-message-content"] ${previewResourceCard} > button:last-child`;
var candidates = [
  '[data-slot="aui_directive-chip"]:is([data-ref="file"], [data-ref="folder"], [data-ref="image"], [data-ref="url"])',
  ':is([data-slot="aui_embedded-images"], [data-slot="aui_generated-image"], [data-slot="aui_markdown-image"]) img',
  '[data-slot="aui_artifact-card"]:is(button, a[href])',
  filePreview,
  ".aui-md a[href]"
].join(", ");
var directiveKinds = /* @__PURE__ */ new Map([["file", "artifacts"], ["folder", "folder"], ["image", "image"]]);
var sourceNodes = 'a[href], img, [data-slot="aui_directive-chip"], [data-slot="aui_artifact-card"], svg.tabler-icon-device-desktop-analytics';
var sourceContainer = 'a[href], [data-slot="aui_directive-chip"], [data-slot="aui_artifact-card"], div:has(> span:first-child > svg.tabler-icon-device-desktop-analytics)';
var userMessage = '[data-slot="aui_user-message-root"]';
var userAttachment = userMessage + ' + div:not([data-slot]):has(> [data-slot="aui_directive-text"])';
function httpLink(value) {
  try {
    const url = new URL(value);
    return ["https:", "http:"].includes(url.protocol) && !url.username && !url.password ? url : null;
  } catch {
    return null;
  }
}
function isPullRequest(link2) {
  return link2?.hostname === "github.com" && /^\/[^/]+\/[^/]+\/pull\/\d+\/?$/.test(link2.pathname) || link2?.hostname === "gitlab.com" && /\/-\/merge_requests\/\d+\/?$/.test(link2.pathname);
}
function sourceFrom(node3) {
  const attached = Boolean(node3.closest(userMessage + ", " + userAttachment));
  if (node3 instanceof HTMLImageElement) {
    const action2 = node3.closest("button");
    const src = node3.currentSrc || node3.getAttribute("src");
    if (!action2 || !src || !node3.complete || !node3.naturalWidth) return null;
    const thumbnail = /^(?:blob:|file:|hermes-[a-z-]+:|data:image\/(?:png|jpe?g|gif|webp|avif|bmp);)/i.test(src) ? src : null;
    const alt = node3.alt.trim() || action2.title?.trim() || "";
    const path = /^(?:[a-z]:[/\\]|[/\\])/i.test(alt) ? alt : null;
    const name2 = path ? path.split(/[/\\]/).at(-1) : alt;
    const section3 = !attached && node3.closest('[data-slot="aui_generated-image"]') ? "outputs" : void 0;
    return { kind: "image", key: src, name: name2, meta: path, thumbnail, attached, action: action2, section: section3 };
  }
  if (node3.matches(filePreview)) {
    const label4 = node3.parentElement?.querySelector(":scope > span[title]");
    const name2 = label4?.textContent.trim();
    return name2 ? {
      kind: "artifacts",
      key: label4.title,
      name: name2,
      meta: label4.title,
      attached,
      action: node3,
      section: attached ? void 0 : "outputs"
    } : null;
  }
  const reference = node3.dataset.directiveId;
  const kind = directiveKinds.get(node3.dataset.ref) || (node3.dataset.slot === "aui_artifact-card" ? "artifacts" : "link");
  const link2 = kind === "link" && httpLink(node3.getAttribute("href") || reference);
  if (kind === "link" && !link2) return null;
  const label3 = node3.querySelector(".truncate")?.textContent.trim() || node3.textContent.trim() || link2?.hostname || null;
  const name = kind === "folder" && label3 && label3 === reference ? label3.split(/[/\\]/).filter(Boolean).at(-1) || label3 : label3;
  const action = node3.matches("button, a[href]") ? node3 : null;
  const section2 = isPullRequest(link2) ? "pullRequests" : !attached && node3.dataset.slot === "aui_artifact-card" ? "outputs" : void 0;
  return { kind, key: reference || link2?.href || name, name, meta: link2?.href || reference, attached, action, section: section2 };
}
function useChatSources(getChat, scopeKey3, enabled) {
  const [snapshot, setSnapshot] = useState3(null);
  useEffect2(() => {
    if (!enabled) return;
    let frame = 0;
    let chat3 = null;
    let body2 = null;
    const labels12 = new MutationObserver(queue);
    const content = new MutationObserver((records) => {
      if (records.some(({ type, target, addedNodes, removedNodes }) => type === "attributes" && target.matches("a, img") || target.closest(sourceContainer) || [addedNodes, removedNodes].some((nodes) => Array.prototype.some.call(
        nodes,
        (node3) => node3 instanceof Element && (node3.matches(sourceNodes) || node3.querySelector(sourceNodes))
      )))) queue();
    });
    const mounts = new MutationObserver((records) => {
      if (!chat3?.isConnected || !body2?.isConnected || records.some((record) => [...record.addedNodes, ...record.removedNodes].some(
        (node3) => node3 instanceof Element && (node3.matches(transcript) || node3.querySelector(transcript))
      ))) queue();
    });
    function collect() {
      frame = 0;
      chat3 = getChat();
      const next = chat3?.querySelector(transcript);
      if (next !== body2) {
        content.disconnect();
        body2?.removeEventListener("load", queue, true);
        body2 = next;
        if (body2) {
          content.observe(body2, { childList: true, subtree: true, attributes: true, attributeFilter: ["href", "src", "alt", "title"] });
          body2.addEventListener("load", queue, true);
        }
      }
      const unique = /* @__PURE__ */ new Map();
      const nodes = [...body2?.querySelectorAll(candidates) || []];
      labels12.disconnect();
      for (const node3 of nodes) {
        const label3 = node3.matches(filePreview) ? node3.parentElement : node3;
        if (!(node3 instanceof HTMLImageElement) && label3) {
          labels12.observe(label3, { characterData: true, subtree: true });
        }
      }
      for (const node3 of nodes.reverse()) {
        const row5 = sourceFrom(node3);
        const key = row5 && `${row5.kind}:${row5.key}`;
        if (key && !unique.has(key)) unique.set(key, row5);
      }
      const rows = [...unique.values()];
      setSnapshot((old) => old?.scopeKey === scopeKey3 && old.rows.length === rows.length && rows.every((row5, i) => row5.action === old.rows[i].action && row5.key === old.rows[i].key && row5.name === old.rows[i].name && row5.thumbnail === old.rows[i].thumbnail && row5.kind === old.rows[i].kind && row5.meta === old.rows[i].meta && row5.attached === old.rows[i].attached && row5.section === old.rows[i].section) ? old : { scopeKey: scopeKey3, rows });
    }
    function queue() {
      if (!frame) frame = requestAnimationFrame(collect);
    }
    mounts.observe(document.body, { childList: true, subtree: true });
    queue();
    return () => {
      if (frame) cancelAnimationFrame(frame);
      mounts.disconnect();
      content.disconnect();
      labels12.disconnect();
      body2?.removeEventListener("load", queue, true);
    };
  }, [getChat, scopeKey3, enabled]);
  return enabled && snapshot?.scopeKey === scopeKey3 ? snapshot.rows : [];
}

// source/subagents.js
import { atom, host as host7, useValue } from "@hermes/plugin-sdk";
import { createElement as h7, useEffect as useEffect4 } from "react";

// source/agent-avatars.js
var shapes = [
  '<circle cx="12" cy="12" r="2.1" fill="currentColor"/><ellipse cx="12" cy="12" rx="7.5" ry="3.7" transform="rotate(-28 12 12)" fill="none" stroke="currentColor" stroke-width="1.65"/>',
  '<path d="M12 4.5l2 5.5 5.5 2-5.5 2-2 5.5-2-5.5-5.5-2 5.5-2z" fill="currentColor"/>',
  '<path d="M7.8 17.5l-2.6-4.3L8 7.3l4.3-1.4 6.5 3.3-.6 5.4-5.2 4.1z" fill="currentColor"/><path d="M8 7.3l3.9 5.1 6.9-3.2m-6.9 3.2 1.1 6.3" fill="none" stroke="var(--badge-bg)" stroke-width="1.2"/>',
  '<path d="M6.3 12a3.5 3.5 0 0 1 5.7-2.7 3.5 3.5 0 0 1 5.7 2.7c0 2.3-2.9 4.3-5.7 5.8-2.8-1.5-5.7-3.5-5.7-5.8z" fill="currentColor"/><circle cx="12" cy="6.1" r="1.15" fill="currentColor"/>'
];
var palettes = [
  [["#39304d", "#d1b5ff"], ["#eae0fb", "#6947aa"]],
  [["#263f4d", "#a0dcf1"], ["#d9edf4", "#27627a"]],
  [["#27443d", "#93e0bb"], ["#d9eee1", "#21684e"]],
  [["#4a2c42", "#f1a7d0"], ["#f3deeb", "#94426e"]],
  [["#4a3b28", "#f4ce91"], ["#f3e9d5", "#875917"]],
  [["#2f3959", "#b4c3ff"], ["#e1e7fb", "#4a5eac"]],
  [["#4b3230", "#ffb4a1"], ["#f5e1d9", "#963e35"]]
];
var agentAvatars = localAssets?.avatars ?? shapes.flatMap(
  (shape) => palettes.map((palette) => palette.map(
    ([background, foreground]) => `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" style="color:${foreground};--badge-bg:${background}"><rect x="1" y="1" width="22" height="22" rx="8" fill="${background}"/>${shape}</svg>`
  ))
);

// source/summary-agents.js
import { CopyButton, host as host6, reasoningEffortLabel, Streamdown } from "@hermes/plugin-sdk";
import { createElement as h6, useEffect as useEffect3, useLayoutEffect as useLayoutEffect2, useRef as useRef3, useState as useState4 } from "react";
var labels3 = {
  ru: {
    title: "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u044B",
    active: "\u0410\u043A\u0442\u0438\u0432\u043D\u044B\u0435",
    done: "\u0413\u043E\u0442\u043E\u0432\u043E",
    noActive: "\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u044B\u0445 \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u043E\u0432",
    back: "\u041D\u0430\u0437\u0430\u0434 \u043A \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u0430\u043C",
    fallback: "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442",
    waitingCount: (count) => new Intl.PluralRules("ru").select(count) === "one" ? count + " \u043E\u0436\u0438\u0434\u0430\u0435\u0442" : count + " \u043E\u0436\u0438\u0434\u0430\u044E\u0442",
    more: (count) => "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0451 " + count,
    worked: (time) => "\u0420\u0430\u0431\u043E\u0442\u0430\u043B \u043D\u0430 \u043F\u0440\u043E\u0442\u044F\u0436\u0435\u043D\u0438\u0438 " + time,
    elapsed: (time) => "\u0420\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0443\u0436\u0435 " + time,
    activity: "\u0410\u043A\u0442\u0438\u0432\u043D\u043E\u0441\u0442\u044C",
    result: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442",
    loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u043E\u0442\u0432\u0435\u0442\u0430\u2026",
    noResult: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043F\u043E\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u0435\u043D",
    copy: "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
    native: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0432 Hermes",
    receipt: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u043E\u0442\u0447\u0451\u0442 \u0432 \u0447\u0430\u0442\u0435",
    status: { running: "\u0420\u0430\u0431\u043E\u0442\u0430\u0435\u0442", queued: "\u041E\u0436\u0438\u0434\u0430\u0435\u0442", dispatched: "\u041F\u0435\u0440\u0435\u0434\u0430\u043D\u043E", failed: "\u041E\u0448\u0438\u0431\u043A\u0430", interrupted: "\u041F\u0440\u0435\u0440\u0432\u0430\u043D\u043E" }
  },
  en: {
    title: "Subagents",
    active: "Active",
    done: "Done",
    noActive: "No active subagents",
    back: "Back to subagents",
    fallback: "Subagent",
    waitingCount: (count) => count + " waiting",
    more: (count) => "Show " + count + " more",
    worked: (time) => "Worked for " + time,
    elapsed: (time) => "Working for " + time,
    activity: "Activity",
    result: "Result",
    loading: "Loading response\u2026",
    noResult: "Result unavailable",
    copy: "Copy",
    native: "Open details in Hermes",
    receipt: "Open report in chat",
    status: { running: "Working", queued: "Waiting", dispatched: "Dispatched", failed: "Failed", interrupted: "Interrupted" }
  }
};
var finished = ({ status: status2 }) => ["completed", "failed", "interrupted"].includes(status2);
var recency = (agent) => agent.updatedAt ?? agent.finishedAt ?? agent.startedAt ?? 0;
var goalLabel = (agent, copy7) => agent.goal || copy7.fallback;
var normalizeProfile = (name) => (name || "default").trim().toLowerCase() || "default";
function formatDuration(seconds) {
  const whole = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(whole / 3600);
  const minutes = Math.floor(whole / 60) % 60;
  return [hours && hours + "h", (hours || minutes) && minutes + "m", whole % 60 + "s"].filter(Boolean).join(" ");
}
function relativeTime(value, now, lang) {
  const minutes = Math.max(0, Math.floor((now - value) / 6e4));
  const days = Math.floor(minutes / 1440);
  const weeks = Math.floor(days / 7);
  const [age, unit] = weeks ? [weeks, "week"] : days ? [days, "day"] : minutes >= 60 ? [Math.floor(minutes / 60), "hour"] : [minutes, "minute"];
  return new Intl.RelativeTimeFormat(lang, { style: "narrow", numeric: "auto" }).format(-age, unit);
}
function AgentAvatar({ agent, dark: dark2, avatarUrl: avatarUrl2 }) {
  return h6("img", {
    "data-hcv-subagent-avatar": "",
    src: avatarUrl2(agent.seed, dark2),
    alt: "",
    draggable: false,
    width: 24,
    height: 24
  });
}
function Glyph({ name }) {
  return h6("span", { "aria-hidden": true, "data-hcv-subagent-glyph": name, style: codexIconStyle(name) });
}
function trailingLabel(agent, now, lang, copy7) {
  if (agent.status === "running" && agent.startedAt) return formatDuration((now - agent.startedAt) / 1e3);
  if (agent.status === "completed" && agent.finishedAt) {
    return h6("time", { dateTime: new Date(agent.finishedAt).toISOString() }, relativeTime(agent.finishedAt, now, lang));
  }
  return copy7.status[agent.status] || null;
}
function AgentGroup({ name, title, agents, limit, empty, copy: copy7, now, lang, dark: dark2, avatarUrl: avatarUrl2, select, trailing }) {
  const [expanded, setExpanded] = useState4(false);
  if (!agents.length && !empty) return null;
  const shown = expanded ? agents : agents.slice(0, limit);
  return h6(
    "section",
    { "data-hcv-subagent-group": name },
    h6("h2", null, h6("span", null, title + " \xB7 " + agents.length), trailing && h6("small", null, trailing)),
    agents.length ? h6("ul", null, shown.map((agent) => {
      const goal = goalLabel(agent, copy7);
      const preview3 = !finished(agent) && (agent.activity?.at(-1) || (agent.status === "running" ? copy7.status.running : ""));
      return h6(
        "li",
        { key: agent.id },
        h6(
          "button",
          {
            type: "button",
            "data-hcv-subagent-row": agent.id,
            "data-status": agent.status,
            onClick: () => select(agent.id)
          },
          h6(AgentAvatar, { agent, dark: dark2, avatarUrl: avatarUrl2 }),
          h6(
            "span",
            { "data-hcv-subagent-row-body": "" },
            h6(
              "span",
              { "data-hcv-subagent-row-title": "" },
              h6("span", { "data-hcv-subagent-name": "", title: goal, dir: "auto" }, goal),
              h6("span", { "data-hcv-subagent-trailing": "" }, trailingLabel(agent, now, lang, copy7))
            ),
            preview3 && h6("span", { "data-hcv-subagent-preview": "", title: preview3, dir: "auto" }, preview3)
          )
        )
      );
    })) : h6("p", { "data-hcv-subagent-empty": "" }, empty),
    !expanded && agents.length > limit && h6("button", { type: "button", "data-hcv-subagent-more": "", onClick: () => setExpanded(true) }, copy7.more(agents.length - limit))
  );
}
function textFromContent(value) {
  if (typeof value === "string") return value.trim();
  if (!Array.isArray(value)) return "";
  return value.filter((part) => part?.type === "text" && typeof part.text === "string").map((part) => part.text).join("\n").trim();
}
function savedResponse(rows) {
  return rows.filter((message) => message?.role === "assistant" && !message.display_kind).map((message) => ({
    text: textFromContent(message.text ?? message.display_content ?? message.content),
    timestamp: message.timestamp
  })).filter((message) => message.text);
}
function liveActivity(history2, live) {
  let overlap = Math.min(history2.length, live.length);
  while (overlap && !history2.slice(-overlap).every((step2, index) => live[index] === step2 || live[index].startsWith(step2 + " \xB7 "))) overlap--;
  return [...history2.slice(0, history2.length - overlap), ...live];
}
function useChildResponse({ subagentId, childSession, status: status2, model }, scope4) {
  const [snapshot, setSnapshot] = useState4(null);
  const key = JSON.stringify([scope4, subagentId, childSession]);
  useEffect3(() => {
    if (!subagentId && !childSession || !scope4) return;
    const [connectionId, profile2, parent] = JSON.parse(scope4);
    if (childSession === parent) return;
    let current = true;
    const sameOwner = () => current && host6.state.activeSessionId.get() === parent && (host6.state.connectionId.get() || null) === connectionId && normalizeProfile(host6.state.profile.get()) === profile2;
    async function read() {
      if (!sameOwner()) return;
      const routes = connectionId && connectionId !== "local" ? await host6.profileRoutes().catch(() => []) : [];
      if (!sameOwner()) return;
      const route = routes.find((entry) => entry.connectionId === connectionId && normalizeProfile(entry.profile) === profile2);
      const targetProfile = route?.targetProfile ?? profile2;
      const owner = { ...connectionId ? { connectionId } : {}, profile: profile2, passive: true, timeoutMs: 8e3 };
      if (subagentId) {
        const stored = host6.state.focusedSessionId?.get() === parent ? host6.state.focusedStoredSessionId?.get() : null;
        try {
          const history3 = await host6.request("session.transcript", {
            session_id: stored || parent,
            profile: targetProfile,
            subagent_id: subagentId,
            order: "latest",
            limit: 100
          }, 8e3);
          if (!sameOwner()) return;
          const rows = history3?.available === true && history3.subagent_id === subagentId && Array.isArray(history3.rows) ? history3.rows : [];
          const steps = rows.filter((row5) => row5?.role === "tool" && typeof row5.name === "string").map((row5) => row5.name).slice(-40);
          const start = rows[0]?.timestamp;
          const end = rows.at(-1)?.timestamp;
          const elapsed = history3?.running === false && history3.next_cursor == null && Number.isFinite(start) && Number.isFinite(end) && end > start ? end - start : void 0;
          const child = rows.length && typeof history3.child_session_id === "string" ? history3.child_session_id : null;
          const saved = { key, status: status2, messages: savedResponse(rows), steps, elapsed, child };
          setSnapshot(saved);
          if (!model && child && child !== parent && window.hermesDesktop?.api) {
            const query2 = new URLSearchParams({ profile: targetProfile });
            const details = await window.hermesDesktop.api({
              ...owner,
              path: "/api/sessions/" + encodeURIComponent(child) + "?" + query2
            }).catch(() => null);
            if (sameOwner() && typeof details?.model === "string") setSnapshot({ ...saved, model: details.model });
          }
          return;
        } catch (error) {
          if (error?.code !== -32601 && !/method not found|unknown method/i.test(error?.message || "")) throw error;
        }
      }
      if (!sameOwner()) return;
      if (!childSession || !window.hermesDesktop?.api) {
        setSnapshot({ key, status: status2, messages: [] });
        return;
      }
      const query = new URLSearchParams({ profile: targetProfile, order: "latest", limit: "80", include_compacted: "true" });
      const result = await window.hermesDesktop.api({
        ...owner,
        path: "/api/sessions/" + encodeURIComponent(childSession) + "/messages?" + query
      });
      if (!sameOwner()) return;
      const history2 = result?.messages ?? result?.data;
      const available = Array.isArray(history2) && (!result.profile || normalizeProfile(result.profile) === normalizeProfile(targetProfile));
      setSnapshot({ key, status: status2, messages: available ? savedResponse(history2) : [] });
    }
    void read().catch(() => {
      if (sameOwner()) setSnapshot({ key, status: status2, messages: [] });
    });
    return () => {
      current = false;
    };
  }, [subagentId, childSession, scope4, status2, key, model]);
  return snapshot?.key === key ? snapshot : null;
}
var markdownComponents = {
  img: ({ alt }) => alt ? h6("span", null, alt) : null,
  a: ({ children, href }) => /^https?:\/\//i.test(href || "") ? h6("a", { href, target: "_blank", rel: "noopener noreferrer" }, children) : h6("span", null, children),
  table: ({ node: node3, ...props }) => h6("div", { "data-hcv-subagent-table": "" }, h6("table", props))
};
function responseMarkdown(text) {
  if (!text.startsWith("{") && !text.startsWith("[")) return text;
  try {
    JSON.parse(text);
    return "```json\n" + text + "\n```";
  } catch {
    return text;
  }
}
function AgentDetail({ agent, scope: scope4, now, copy: copy7, lang, dark: dark2, avatarUrl: avatarUrl2, onBack, nativeActions: nativeActions2, openNativeAgent: openNativeAgent2 }) {
  const back = useRef3(null);
  useLayoutEffect2(() => {
    back.current?.focus({ preventScroll: true });
  }, []);
  const snapshot = useChildResponse(agent, scope4);
  const completed = finished(agent);
  const model = [agent.model || snapshot?.model, agent.effort && reasoningEffortLabel(agent.effort)].filter(Boolean).join(" \xB7 ");
  const elapsed = agent.durationSeconds ?? snapshot?.elapsed ?? (agent.startedAt && ((agent.finishedAt || now) - agent.startedAt) / 1e3);
  const durationLabel = elapsed == null ? null : (completed || snapshot?.elapsed != null ? copy7.worked : copy7.elapsed)(formatDuration(elapsed));
  const statusLabel = copy7.status[agent.status];
  const history2 = snapshot?.steps || [];
  const live = agent.activity || [];
  const activity = !completed || snapshot?.status !== agent.status ? liveActivity(history2, live) : history2.length ? history2 : live;
  const source = snapshot?.messages.length ? "transcript" : agent.summary ? "summary" : void 0;
  const result = source === "transcript" ? snapshot.messages : source === "summary" ? [{ text: agent.summary }] : [];
  const timestamp2 = result.at(-1)?.timestamp;
  const writtenAt = Number.isFinite(timestamp2) && timestamp2 > 0 ? new Date(timestamp2 * 1e3) : null;
  const openable = snapshot?.child ? { ...agent, childSession: snapshot.child, lifecycleChild: true } : agent;
  const destinations = nativeActions2(openable, scope4);
  const readsHistory = agent.subagentId || agent.childSession && window.hermesDesktop?.api;
  const loading = Boolean(readsHistory && (!snapshot || snapshot.status !== agent.status));
  const label3 = goalLabel(agent, copy7);
  const actions = (result.length > 0 || destinations.length > 0) && h6(
    "div",
    { "data-hcv-subagent-actions": "" },
    result.length > 0 && h6(CopyButton, {
      label: copy7.copy,
      text: result.map(({ text }) => text).join("\n\n"),
      appearance: "icon",
      buttonSize: "icon-sm"
    }),
    destinations.map((action) => h6(
      "button",
      {
        key: action,
        type: "button",
        "data-hcv-subagent-native": action,
        "aria-label": copy7[action],
        title: copy7[action],
        onClick: () => openNativeAgent2(openable, scope4, action)
      },
      h6(Glyph, { name: action === "native" ? "open" : "chatTab" })
    )),
    writtenAt && Number.isFinite(writtenAt.valueOf()) && h6(
      "time",
      { dateTime: writtenAt.toISOString() },
      writtenAt.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" })
    )
  );
  return h6(
    "div",
    { "data-hcv-subagent-detail": "" },
    h6(
      "header",
      { "data-hcv-subagent-header": "" },
      h6("button", {
        ref: back,
        type: "button",
        "aria-label": copy7.back,
        title: copy7.back,
        "data-hcv-subagent-back": "",
        onClick: onBack
      }, h6(Glyph, { name: "back" })),
      h6(AgentAvatar, { agent, dark: dark2, avatarUrl: avatarUrl2 }),
      h6("h2", { "data-hcv-subagent-name": "", title: label3, dir: "auto" }, label3),
      model && h6("span", { "data-hcv-subagent-model": "", title: model }, model)
    ),
    h6(
      "div",
      { "data-hcv-subagent-feed": "" },
      h6(
        "div",
        { "data-hcv-subagent-column": "" },
        activity.length ? h6(
          "details",
          { "data-hcv-subagent-activity-log": "" },
          h6("summary", null, durationLabel || copy7.activity, h6(Glyph, { name: "right" })),
          h6("ul", null, activity.map((text, index) => h6("li", { key: index, dir: "auto" }, text)))
        ) : durationLabel && h6("p", { "data-hcv-subagent-meta": "" }, durationLabel),
        h6(
          "div",
          { role: "group", "aria-label": copy7.result, "data-hcv-subagent-result": "", "data-source": source },
          result.length ? result.map(({ text }, index) => h6(
            "div",
            { key: index, dir: "auto" },
            h6(Streamdown, {
              className: "hcv-subagent-markdown",
              components: markdownComponents,
              controls: false,
              mode: "static",
              parseIncompleteMarkdown: false
            }, responseMarkdown(text))
          )) : h6("p", { role: "status", "data-hcv-subagent-empty": "" }, loading ? copy7.loading : !completed && statusLabel ? statusLabel : copy7.noResult)
        ),
        actions
      )
    )
  );
}
function AgentPane({ agents, scope: scope4, lang, dark: dark2, avatarUrl: avatarUrl2, nativeActions: nativeActions2, openNativeAgent: openNativeAgent2 }) {
  const copy7 = labels3[lang];
  const [selected, setSelected] = useState4(null);
  const pane = useRef3(null);
  const returning = useRef3(null);
  const [now, setNow] = useState4(Date.now);
  const agent = agents.find((item) => item.id === selected);
  const running = agents.some(({ status: status2, startedAt }) => status2 === "running" && startedAt);
  const clock3 = running ? 1e3 : agents.some(({ finishedAt }) => finishedAt) ? 6e4 : 0;
  useEffect3(() => {
    if (!clock3) return;
    const update = () => {
      if (document.visibilityState !== "hidden" && pane.current?.checkVisibility({ visibilityProperty: true })) setNow(Date.now());
    };
    update();
    const timer = window.setInterval(update, clock3);
    return () => window.clearInterval(timer);
  }, [clock3]);
  useLayoutEffect2(() => {
    if (!agent && returning.current !== null) {
      const rows = Array.from(pane.current?.querySelectorAll("[data-hcv-subagent-row]") || []);
      const row5 = rows.find((item) => item.dataset.hcvSubagentRow === returning.current) ?? rows[0];
      returning.current = null;
      row5?.focus({ preventScroll: true });
    }
  }, [agent]);
  const ordered2 = [...agents].sort((first, second) => recency(second) - recency(first));
  const active2 = ordered2.filter((item) => !finished(item));
  const done = ordered2.filter(finished);
  const waiting = active2.filter(({ status: status2 }) => status2 === "queued").length;
  const group2 = { copy: copy7, now, lang, dark: dark2, avatarUrl: avatarUrl2, select: setSelected };
  return h6(
    "section",
    { ref: pane, "data-hcv-subagents-pane": "", "aria-label": copy7.title },
    h6(
      "div",
      { "data-hcv-subagent-list": "", hidden: Boolean(agent) },
      h6(
        "div",
        { "data-hcv-subagent-column": "" },
        h6(AgentGroup, {
          ...group2,
          name: "active",
          title: copy7.active,
          agents: active2,
          limit: 4,
          empty: copy7.noActive,
          trailing: waiting ? copy7.waitingCount(waiting) : null
        }),
        h6(AgentGroup, { ...group2, name: "done", title: copy7.done, agents: done, limit: 10 })
      )
    ),
    agent && h6(AgentDetail, {
      key: agent.id,
      agent,
      scope: scope4,
      now,
      copy: copy7,
      lang,
      dark: dark2,
      avatarUrl: avatarUrl2,
      nativeActions: nativeActions2,
      openNativeAgent: openNativeAgent2,
      onBack: () => {
        returning.current = agent.id;
        setSelected(null);
      }
    })
  );
}
function agentPaneStyles(active2) {
  const pane = active2 + " [data-hcv-subagents-pane]";
  const response3 = pane + " [data-hcv-subagent-result]";
  const prose2 = response3 + " .hcv-subagent-markdown";
  const code = prose2 + ' [data-streamdown="code-block"]';
  return `
${pane} {
  display: flex; flex-direction: column; block-size: 100%; min-block-size: 0; min-inline-size: 0;
  color: var(--hcv-text, var(--foreground)); background: var(--hcv-chat, var(--background));
  font-family: var(--hcv-ui-font, var(--font-sans));
  --hcv-agent-muted: var(--hcv-muted, var(--muted-foreground));
  --hcv-agent-tertiary: light-dark(rgb(26 28 31 / 50%), rgb(255 255 255 / 50%));
  --hcv-agent-row-hover: light-dark(rgb(26 28 31 / 5%), rgb(255 255 255 / 6%));
  --hcv-agent-divider: var(--hcv-hairline, var(--border));
}
${pane} [hidden] { display: none !important; }
${pane} :is([data-hcv-subagent-list], [data-hcv-subagent-feed]) { min-block-size: 0; flex: 1; overflow: auto; }
${pane} [data-hcv-subagent-list] { padding: 20px 12px; }
${pane} [data-hcv-subagent-column] { margin-inline: auto; max-inline-size: var(--thread-content-max-width, 48rem); }
${pane} [data-hcv-subagent-group="done"] { margin-block-start: 24px; }
${pane} [data-hcv-subagent-group] h2 {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  margin: 0 0 8px; padding-inline: 8px; color: var(--hcv-agent-tertiary);
  font-size: 13px; font-weight: 430; line-height: 18.5714px;
}
${pane} [data-hcv-subagent-group] h2 > span { min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${pane} [data-hcv-subagent-group] h2 small { flex: none; font-size: 12px; font-variant-numeric: tabular-nums; }
${pane} [data-hcv-subagent-group] ul { display: flex; flex-direction: column; gap: 4px; margin: 0; padding: 0; list-style: none; }
${pane} [data-hcv-subagent-row] {
  display: flex; align-items: flex-start; gap: 12px; min-block-size: 40px; inline-size: 100%;
  padding: 8px; border: 0; border-radius: 10px; background: transparent; text-align: start; cursor: pointer;
}
${pane} [data-hcv-subagent-row]:not(:has([data-hcv-subagent-preview])) { align-items: center; }
${pane} [data-hcv-subagent-avatar] { display: block; inline-size: 24px; block-size: 24px; flex: none; }
${pane} [data-hcv-subagent-row-body] { display: block; min-inline-size: 0; flex: 1; }
${pane} [data-hcv-subagent-row-title] { display: flex; align-items: center; gap: 8px; min-block-size: 24px; font-size: 13px; line-height: 20px; }
${pane} :is([data-hcv-subagent-name], [data-hcv-subagent-model], [data-hcv-subagent-preview]) { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
${pane} [data-hcv-subagent-name] { min-inline-size: 0; flex: 1; unicode-bidi: plaintext; }
${pane} [data-hcv-subagent-trailing] { flex: none; color: var(--hcv-agent-tertiary); font-size: 12px; font-variant-numeric: tabular-nums; white-space: nowrap; }
${pane} [data-hcv-subagent-trailing]:empty { display: none; }
${pane} :is([data-hcv-subagent-empty], [data-hcv-subagent-preview]) { color: var(--hcv-agent-muted); font-size: 13px; line-height: 20px; }
${pane} [data-hcv-subagent-empty] { margin: 0; padding: 4px 8px; color: var(--hcv-agent-tertiary); }
${pane} [data-hcv-subagent-preview] { display: block; unicode-bidi: plaintext; }
${pane} [data-hcv-subagent-more] {
  margin-block-start: 8px; margin-inline-start: 44px; min-block-size: 26px; padding-inline: 6px;
  border-radius: 8px; color: var(--hcv-agent-muted); font-size: 13px; cursor: pointer;
}
${pane} [data-hcv-subagent-detail] { display: flex; flex: 1; flex-direction: column; min-block-size: 0; }
${pane} [data-hcv-subagent-header] {
  display: flex; align-items: center; gap: 8px; min-inline-size: 0; min-block-size: 40px;
  padding: 0 16px; border-block-end: 1px solid var(--hcv-agent-divider); flex: none;
}
${pane} [data-hcv-subagent-header] h2 { margin: 0; font-size: 13px; font-weight: 500; line-height: 20px; }
${pane} [data-hcv-subagent-model] { flex: 0 1 auto; max-inline-size: 50%; color: var(--hcv-agent-tertiary); font-size: 12px; }
${pane} [data-hcv-subagent-back] {
  display: grid; place-items: center; inline-size: 24px; block-size: 24px; flex: none;
  border-radius: 8px; color: var(--hcv-agent-muted); cursor: pointer;
}
${pane} [data-hcv-subagent-glyph] { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; }
${pane} [data-hcv-subagent-back]:dir(rtl) > span { transform: scaleX(-1); }
${pane} [data-hcv-subagent-feed] {
  --codex-chat-font-size: 14px;
  --codex-chat-code-font-size: 12px;
  --thread-content-max-width: 48rem;
  --hcv-agent-prose: light-dark(#1a1c1f, #dfdfdf);
  --hcv-agent-mono: ui-monospace, 'SFMono-Regular', Consolas, 'Liberation Mono', monospace;
  padding: 32px 20px 24px;
}
${pane} :is([data-hcv-subagent-meta], [data-hcv-subagent-activity-log]) {
  margin: 0 0 16px; color: var(--hcv-agent-tertiary); font-size: var(--codex-chat-font-size);
  line-height: 1.5; font-variant-numeric: tabular-nums;
}
${pane} [data-hcv-subagent-activity-log] summary { display: flex; inline-size: fit-content; align-items: center; gap: 4px; list-style: none; cursor: pointer; }
${pane} [data-hcv-subagent-activity-log] summary > span { inline-size: 12px; block-size: 12px; }
${pane} [data-hcv-subagent-activity-log] summary::-webkit-details-marker { display: none; }
${pane} [data-hcv-subagent-activity-log][open] summary > span { rotate: 90deg; }
${pane} [data-hcv-subagent-activity-log] ul { padding-inline-start: 24px; margin: 4px 0; overflow-wrap: anywhere; }
${response3} {
  min-inline-size: 0; color: var(--hcv-agent-prose);
  font-size: var(--codex-chat-font-size); font-weight: 430; line-height: 1.625; overflow-wrap: anywhere;
}
${response3} > div + div { margin-block-start: 16px; }
${prose2} { display: flex; flex-direction: column; gap: 1em; min-inline-size: 0; }
${prose2} > * { margin-block: 0; }
${prose2} p { margin-block: 0; }
${prose2} :is(strong, [data-streamdown="strong"]) { font-weight: 600; }
${prose2} :is(h1, h2, h3, h4, h5, h6) { font-weight: 600; line-height: 1.375; }
${prose2} h1 { font-size: 1.5em; }
${prose2} h2 { font-size: 1.25em; }
${prose2} h3 { font-size: 1.125em; }
${prose2} :is(h4, h5, h6) { font-size: 1em; }
${prose2} :is(ul, ol) { padding-inline-start: 1.5em; }
${prose2} li + li { margin-block-start: .25em; }
${prose2} blockquote { border-inline-start: 2px solid var(--hcv-agent-divider); padding-inline-start: .86em; }
${prose2} a { color: light-dark(#0169cc, #8ec8f8); text-decoration: none; }
${prose2} a:hover { text-decoration: underline; }
${prose2} [data-streamdown="inline-code"] {
  font-family: var(--hcv-agent-mono); font-size: .92em; font-weight: 400;
  padding: 1px 6px; border-radius: 6px; box-decoration-break: clone;
}
${code} {
  min-inline-size: 0; border: 1px solid var(--hcv-agent-divider); border-radius: 10px;
  background: light-dark(#f6f6f6, #202020);
}
${code} [data-streamdown="code-block-header"] {
  padding: 6px 12px; border-block-end: 1px solid var(--hcv-agent-divider);
  font: 400 12px/18px var(--hcv-ui-font); color: var(--hcv-agent-tertiary);
}
${code} [data-streamdown="code-block-body"] {
  border: 0; border-radius: 0; background: transparent; padding: 12px;
  max-inline-size: 100%; overflow: auto;
}
${code} :is(pre, code) {
  margin: 0; background: transparent; font: 400 var(--codex-chat-code-font-size)/1.625 var(--hcv-agent-mono);
}
${prose2} [data-hcv-subagent-table] { margin: 0; min-inline-size: 0; }
${pane} [data-hcv-subagent-actions] { display: flex; flex-wrap: wrap; align-items: center; gap: 4px; margin-block-start: 8px; }
${pane} [data-hcv-subagent-actions] button {
  display: inline-grid; place-items: center; inline-size: 24px; block-size: 24px;
  padding: 0; border-radius: 8px; color: var(--hcv-agent-muted); cursor: pointer;
}
${pane} [data-hcv-subagent-actions] time { font-size: 12px; color: var(--hcv-agent-tertiary); font-variant-numeric: tabular-nums; }
${pane} :is(button, summary):focus-visible { outline: 2px solid var(--hcv-focus, Highlight); outline-offset: -2px; }
${pane} button:is(:hover, :focus-visible) { background: var(--hcv-agent-row-hover); color: var(--hcv-text, var(--foreground)); }
${pane} summary:is(:hover, :focus-visible) { color: var(--hcv-text, var(--foreground)); }
${pane} :is([data-hcv-subagent-row], [data-hcv-subagent-back]):is(:hover, :focus-visible) {
  background: var(--hcv-agent-row-hover);
}
${pane} :is([data-hcv-subagent-row], [data-hcv-subagent-back]):focus-visible { outline-offset: 0; }
@media (forced-colors: active) {
  ${pane} :is(button, summary):focus-visible { outline-color: Highlight; }
  ${pane} [data-hcv-subagent-glyph] { forced-color-adjust: none; color: ButtonText; }
}
`;
}

// source/subagents.js
var surface = "[data-chat-surface]:not([data-hud-shell] *)";
var primary = surface + '[data-composer-target="main"][data-session-anchor="workspace"]';
var delegate = "[data-delegate-card]";
var response = '[data-slot="aui_response-group"]';
var transcript2 = '[data-slot="aui_thread-content"]';
var pair = '[data-slot="aui_turn-pair"]';
var prompt = '[data-slot="aui_user-message-root"][data-message-id]';
var generated = "[data-hcv-agent-rows]";
var agentAvatar = "data-hcv-delegate-avatar";
var notice = '[data-slot="aui_system-message-root"] [data-slot="aui_background-result"]';
var final = (status2) => ["completed", "failed", "interrupted"].includes(status2);
var isActive = ({ status: status2 }) => status2 === "running" || status2 === "queued";
var tidy = (text) => typeof text === "string" ? text.trim().replace(/\s+/g, " ") : "";
var prose = (text) => typeof text === "string" ? text.trim() : "";
var duration = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : void 0;
var timestamp = (value) => Number.isFinite(value) && value > 0 ? value * (value < 1e12 ? 1e3 : 1) : void 0;
var noActivity = Object.freeze([]);
var getPrompt = (turn) => turn?.querySelector(":scope > " + prompt)?.dataset.messageId;
var profile = (value) => tidy(value).toLowerCase() || "default";
var scopeKey2 = (session, connection, name) => session && JSON.stringify([connection || null, profile(name), session]);
var labels4 = {
  ru: {
    title: "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u044B",
    fallback: "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442",
    more: (n) => "\u0435\u0449\u0451 " + n,
    open: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u043E\u0432",
    started: "\u043D\u0430\u0447\u0430\u043B(-\u0438) \u0440\u0430\u0431\u043E\u0442\u0443",
    running: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435",
    queued: "\u043E\u0436\u0438\u0434\u0430\u0435\u0442(-\u044E\u0442) \u0437\u0430\u043F\u0443\u0441\u043A\u0430",
    dispatched: "\u043F\u0435\u0440\u0435\u0434\u0430\u043D(-\u044B) \u0432 \u0440\u0430\u0431\u043E\u0442\u0443",
    completed: "\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B(-\u0438) \u0440\u0430\u0431\u043E\u0442\u0443",
    failed: "\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B(-\u0438) \u0441 \u043E\u0448\u0438\u0431\u043A\u043E\u0439",
    interrupted: "\u043F\u0440\u0435\u0440\u0432\u0430\u043B(-\u0438) \u0440\u0430\u0431\u043E\u0442\u0443",
    status: {
      running: "\u0412 \u0440\u0430\u0431\u043E\u0442\u0435",
      queued: "\u0412 \u043E\u0447\u0435\u0440\u0435\u0434\u0438",
      dispatched: "\u041F\u0435\u0440\u0435\u0434\u0430\u043D\u043E",
      completed: "\u0413\u043E\u0442\u043E\u0432\u043E",
      failed: "\u041E\u0448\u0438\u0431\u043A\u0430",
      interrupted: "\u041F\u0440\u0435\u0440\u0432\u0430\u043D\u043E"
    }
  },
  en: {
    title: "Subagents",
    fallback: "Subagent",
    more: (n) => n + " more",
    open: "Open subagents list",
    started: "started working",
    running: "Working",
    queued: "waiting to start",
    dispatched: "dispatched",
    completed: "finished",
    failed: "finished with errors",
    interrupted: "interrupted",
    status: {
      running: "Working",
      queued: "Queued",
      dispatched: "Dispatched",
      completed: "Done",
      failed: "Failed",
      interrupted: "Interrupted"
    }
  }
};
var language = () => document.documentElement.lang.toLowerCase().startsWith("ru") ? "ru" : "en";
var assetUrls = /* @__PURE__ */ new Map();
function avatarUrl(seed, dark2) {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash = (31 * hash + seed.charCodeAt(i)) % 2147483647;
  const index = hash % agentAvatars.length;
  const key = index * 2 + Number(!dark2);
  if (!assetUrls.has(key)) {
    const svg = agentAvatars[index][dark2 ? 0 : 1];
    assetUrls.set(key, "data:image/svg+xml," + encodeURIComponent(svg));
  }
  return assetUrls.get(key);
}
function shortName(goal, fallback) {
  const name = goal || fallback;
  const chars = Array.from(name);
  return chars.length > 48 ? chars.slice(0, 47).join("") + "\u2026" : name;
}
function resultObject(value) {
  if (value && typeof value === "object") return value;
  if (typeof value !== "string") return null;
  try {
    return JSON.parse(value);
  } catch {
    return null;
  }
}
function settledStatus(value) {
  const status2 = tidy(value);
  if (!status2 || ["ok", "success", "completed"].includes(status2)) return "completed";
  return ["interrupted", "cancelled", "canceled"].includes(status2) ? "interrupted" : "failed";
}
function dispatchIds(result) {
  const ids = result?.subagent_ids;
  const goals = result?.goals;
  if (result?.status !== "dispatched" || !Array.isArray(ids) || !Array.isArray(goals)) return /* @__PURE__ */ new Map();
  const refused = new Set(Array.isArray(result.refused) ? result.refused.map((entry) => entry?.task_index) : []);
  const indexes = Array.from(goals.keys()).filter((index) => !refused.has(index));
  return indexes.length === ids.length ? new Map(indexes.map((index, i) => [index, tidy(ids[i])])) : /* @__PURE__ */ new Map();
}
function readCard(card2, cardIndex) {
  const call = committedFiber(card2)?.return?.memoizedProps;
  const callId = tidy(call?.toolCallId);
  const args = resultObject(call?.args);
  const result = resultObject(call?.result);
  const savedIds = dispatchIds(result);
  const results = Array.isArray(result?.results) ? result.results.map(resultObject) : [];
  const turnId = getPrompt(card2.closest(pair));
  return [...card2.children].flatMap((entry, index) => {
    const scaffold = entry.querySelector(":scope > [data-conversation-scaffold]");
    const button5 = scaffold?.querySelector(":scope > button");
    const glyph3 = scaffold?.firstElementChild;
    if (!button5 || !glyph3) return [];
    const goal = tidy(args?.tasks?.[index]?.goal || index === 0 && args?.goal) || tidy(button5.textContent);
    const native2 = committedFiber(entry)?.return?.memoizedProps?.row;
    const stored = results.find((row5) => row5?.task_index === index) ?? (results[index]?.task_index == null ? results[index] : null);
    const refused = Array.isArray(result?.refused) && result.refused.find((row5) => row5?.task_index === index);
    const outcome = stored || refused;
    const status2 = outcome ? settledStatus(outcome.status) : native2?.status || (glyph3.querySelector('[role="status"]') ? "running" : glyph3.querySelector("svg.text-destructive") ? "failed" : glyph3.querySelector("svg[aria-label]") ? "completed" : "dispatched");
    const nativeSession = tidy(native2?.sessionId);
    const childSession = tidy(stored?.child_session_id || stored?.session_id) || (!stored ? nativeSession : "");
    const subagentId = tidy(stored?.subagent_id) || savedIds.get(index);
    const seed = JSON.stringify(callId ? [callId, index] : [turnId, cardIndex, index, goal]);
    return [{
      id: subagentId || seed,
      seed,
      nativeId: tidy(native2?.id),
      nativeSession,
      goal,
      status: status2,
      childSession,
      subagentId,
      model: tidy(stored ? stored.model : native2?.model),
      durationSeconds: duration(stored ? stored.duration_seconds : native2?.durationSeconds),
      effort: tidy(stored?.reasoning_effort),
      summary: prose(outcome?.summary) || prose(outcome?.error),
      activity: noActivity,
      started: status2 === "running" || status2 === "completed",
      button: button5,
      canOpen: !button5.disabled && (!stored || Boolean(childSession && nativeSession === childSession))
    }];
  });
}
function applyStoredReceipts(rowsByCard) {
  for (const [target, heading] of [...document.querySelectorAll(surface + " " + transcript2 + " " + notice)].map((node3) => [node3, tidy(node3.querySelector("[data-conversation-scaffold] span.truncate")?.textContent)])) {
    const match = /^Subagent (Task|Tasks) (Completed|Failed|Interrupted|Cancelled|Timed Out): (.+)$/.exec(heading);
    if (!match) continue;
    const [, kind, outcome, text] = match;
    const batch = kind === "Tasks" && /^(.*) \((\d+) tasks\)$/.exec(text);
    if (kind === "Tasks" && !batch) continue;
    const goals = batch ? batch[1] : text;
    const count = batch ? Number(batch[2]) : 1;
    const matches = [...rowsByCard].filter(([card2, entries]) => card2.closest(transcript2) === target.closest(transcript2) && Boolean(card2.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING) && entries.length === count && entries.every((row5) => row5.status === "dispatched") && entries.map((row5) => row5.goal).join("; ") === goals);
    if (matches.length !== 1) continue;
    const receipt = committedFiber(target)?.return?.memoizedProps;
    const receiptButton = target.querySelector("[data-conversation-scaffold] button");
    const dateTime = target.querySelector("time[datetime]")?.dateTime;
    for (const row5 of matches[0][1]) {
      row5.started = true;
      row5.status = outcome === "Completed" ? "completed" : outcome === "Cancelled" || outcome === "Interrupted" ? "interrupted" : "failed";
      row5.finishedAt = dateTime ? timestamp(Date.parse(dateTime)) : void 0;
      if (count === 1 && !row5.summary) row5.summary = prose(receipt?.report);
      row5.receiptButton = receiptButton;
    }
  }
}
function eventStatus(event, previous) {
  if (event.type === "subagent.spawn_requested") return "queued";
  if (event.type === "subagent.start") return "running";
  if (event.type !== "subagent.complete") return previous?.started ? previous.status : "running";
  const value = event.payload.status;
  if (["completed", "ok", "success"].includes(value)) return "completed";
  if (["interrupted", "cancelled", "canceled"].includes(value)) return "interrupted";
  return "failed";
}
function eventActivity(event, previous) {
  const activity = previous?.activity || noActivity;
  const { payload, type } = event;
  const additions = [];
  if (type === "subagent.tool" || type === "subagent.progress") {
    const tool = tidy(payload.tool_name);
    const text = tidy(payload.tool_preview || payload.text);
    if (tool || text) additions.push(tool && text && tool !== text ? tool + " \xB7 " + text : text || tool);
  }
  if (type === "subagent.complete" && Array.isArray(payload.output_tail)) {
    for (const item of payload.output_tail) {
      const text = tidy(item?.preview);
      const tool = tidy(item?.tool);
      if (tool || text) additions.push([tool, text].filter(Boolean).join(" \xB7 "));
    }
  }
  const next = [...activity];
  for (const text of additions) {
    const line = text.slice(0, 1e3);
    if (next.at(-1) !== line) next.push(line);
  }
  return next.length === activity.length ? activity : next.slice(-24);
}
function activityRows(agents) {
  return ["started", "queued", "dispatched", "completed", "failed", "interrupted"].map((kind) => [
    kind,
    agents.filter((agent) => agent.status === (kind === "started" ? "running" : kind))
  ]).filter(([, list]) => list.length);
}
function activitySignature(agents, lang, dark2) {
  return JSON.stringify([lang, dark2, agents.map(({ id: id2, seed, goal, status: status2, started }) => [id2, seed, goal, status2, started])]);
}
function renderActivity(state, agents, lang, dark2) {
  const signature = activitySignature(agents, lang, dark2);
  if (signature === state.signature) return;
  state.signature = signature;
  const copy7 = labels4[lang];
  const format = new Intl.ListFormat(lang);
  const rows = activityRows(agents).map(([kind, list]) => {
    const row5 = document.createElement("span");
    row5.setAttribute("data-hcv-agent-activity", kind);
    const icons3 = document.createElement("span");
    icons3.setAttribute("data-hcv-agent-icons", "");
    icons3.setAttribute("aria-hidden", "true");
    const shown = list.length <= 3 ? list : list.slice(0, 2);
    for (const agent of list.slice(0, 4)) {
      const image = document.createElement("img");
      image.src = avatarUrl(agent.seed, dark2);
      image.alt = "";
      image.draggable = false;
      icons3.append(image);
    }
    const names2 = shown.map(({ goal }) => shortName(goal, copy7.fallback));
    if (list.length > shown.length) names2.push(copy7.more(list.length - shown.length));
    const sentence = document.createElement("span");
    sentence.textContent = format.format(names2) + " " + copy7[kind];
    sentence.title = format.format(list.map(({ goal }) => goal || copy7.fallback)) + " " + copy7[kind];
    row5.append(icons3, sentence);
    return row5;
  });
  state.rows.replaceChildren(...rows);
}
function enhanceCard(card2, id2, expanded, key) {
  const rows = document.createElement("button");
  rows.type = "button";
  rows.setAttribute("data-hcv-agent-rows", "");
  const assigned = !card2.id;
  if (assigned) card2.id = "hcv-delegate-" + id2;
  const assignedId = card2.id;
  rows.setAttribute("aria-expanded", String(expanded.has(key)));
  rows.setAttribute("aria-controls", assignedId);
  rows.addEventListener("click", () => {
    const open = rows.getAttribute("aria-expanded") !== "true";
    rows.setAttribute("aria-expanded", String(open));
    if (open) expanded.add(key);
    else expanded.delete(key);
    if (expanded.size > 100) expanded.delete(expanded.values().next().value);
  });
  card2.before(rows);
  return { rows, glyphs: /* @__PURE__ */ new Map(), remove() {
    rows.remove();
    for (const glyph3 of this.glyphs.keys()) {
      glyph3.removeAttribute(agentAvatar);
      glyph3.style.removeProperty("--hcv-delegate-avatar");
    }
    if (assigned && card2.id === assignedId) card2.removeAttribute("id");
  } };
}
function styleDelegateRows(state, agents, dark2) {
  const previous = state.glyphs;
  const next = /* @__PURE__ */ new Map();
  for (const { button: button5, seed } of agents) {
    const glyph3 = button5.previousElementSibling;
    if (!glyph3) continue;
    const image = avatarUrl(seed, dark2);
    if (previous.get(glyph3) !== image) {
      glyph3.setAttribute(agentAvatar, "");
      glyph3.style.setProperty("--hcv-delegate-avatar", 'url("' + image + '")');
    }
    next.set(glyph3, image);
  }
  for (const glyph3 of previous.keys()) {
    if (next.has(glyph3)) continue;
    glyph3.removeAttribute(agentAvatar);
    glyph3.style.removeProperty("--hcv-delegate-avatar");
  }
  state.glyphs = next;
}
function localWatchProfile(agent, scope4) {
  if (!agent.lifecycleChild || !agent.childSession || !scope4 || typeof window.hermesDesktop?.openSessionWindow !== "function") return null;
  const [connection, owner, parent] = JSON.parse(scope4);
  return connection === "local" && agent.childSession !== parent ? owner : null;
}
function nativeActions(agent, scope4) {
  return [
    (agent.canOpen || localWatchProfile(agent, scope4)) && "native",
    agent.receiptButton && "receipt"
  ].filter(Boolean);
}
function openNativeAgent(agent, scope4, action = "native") {
  if (!scope4 || scope4 !== scopeKey2(host7.state.activeSessionId.get(), host7.state.connectionId.get(), host7.state.profile.get())) return;
  if (action === "native") {
    if (agent.canOpen && agent.button?.isConnected && !agent.button.disabled) {
      agent.button.click();
      return;
    }
    const owner = localWatchProfile(agent, scope4);
    if (owner) {
      const errorTitle = language() === "ru" ? "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u0430" : "Could not open subagent details";
      void window.hermesDesktop.openSessionWindow(agent.childSession, { profile: owner, watch: true }).then((result) => {
        if (!result?.ok) throw new Error(result?.error || errorTitle);
      }).catch((error) => host7.notifyError(error, errorTitle));
      return;
    }
  }
  const receipt = agent.receiptButton;
  if (receipt?.isConnected) {
    if (receipt.getAttribute("aria-expanded") !== "true") receipt.click();
    receipt.scrollIntoView({ block: "nearest" });
  }
}
function useScopedRoster(roster) {
  const value = useValue(roster);
  const session = useValue(host7.state.activeSessionId);
  const connection = useValue(host7.state.connectionId);
  const name = useValue(host7.state.profile);
  const scope4 = scopeKey2(session, connection, name);
  return value.scope === scope4 ? value : { ...value, scope: scope4, agents: [] };
}
function SubagentsPane({ roster }) {
  const value = useScopedRoster(roster);
  const gateway = useValue(host7.state.gateway);
  useEffect4(() => {
    if (value.scope && gateway === "open") void roster.refresh(value.scope);
  }, [roster, value.scope, gateway]);
  return h7(AgentPane, { ...value, key: value.scope ?? "draft", avatarUrl, nativeActions, openNativeAgent });
}
function SummarySubagents({ roster, onExpand, disclosure: disclosure2 }) {
  const value = useScopedRoster(roster);
  if (!value.agents.length) return null;
  const { agents, lang, dark: dark2 } = value;
  const copy7 = labels4[lang];
  const working = agents.filter(isActive);
  const done = agents.filter(({ status: status2 }) => status2 === "completed");
  const other = agents.filter(({ status: status2 }) => status2 === "dispatched");
  const issues = agents.filter(({ status: status2 }) => status2 === "failed" || status2 === "interrupted");
  const preview3 = (working.length ? working : done.length ? done : other.length ? other : issues).slice(0, 4);
  const counts = [
    [copy7.running, working],
    [copy7.status.completed, done],
    [copy7.status.dispatched, other],
    [lang === "ru" ? "\u041E\u0448\u0438\u0431\u043A\u0438 \u0438 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0438" : "Errors and interruptions", issues]
  ].filter(([, list]) => list.length).map(([label3, list]) => label3 + ": " + list.length);
  const image = (agent) => h7("img", { key: agent.id, src: avatarUrl(agent.seed, dark2), alt: "", draggable: false });
  const previewContent = [
    h7("span", { key: "avatars", "data-hcv-agent-icons": "", "aria-hidden": true }, preview3.map(image)),
    h7("span", { key: "status", role: "status", "data-hcv-agent-counts": "" }, counts.join(" \xB7 "))
  ];
  return h7(
    SummarySection,
    { ...disclosure2, kind: "agents", title: copy7.title, "data-hcv-summary-agents": "" },
    h7("button", {
      type: "button",
      className: "hcv-context-row",
      title: copy7.open,
      "aria-label": copy7.open,
      "data-hcv-open-subagents": "",
      onClick: onExpand
    }, previewContent)
  );
}
function css(active2) {
  const chat3 = active2 + " " + surface;
  const card2 = active2 + " [data-hcv-context-card] [data-hcv-summary-agents]";
  const rows = chat3 + " " + generated;
  const native2 = rows + " + " + delegate;
  const task = native2 + " > div";
  const line = task + " > [data-conversation-scaffold]";
  const glyph3 = line + " > [" + agentAvatar + "]";
  return [
    "@media (forced-colors: none) {",
    rows + ":is(button) { display: grid; inline-size: fit-content; max-inline-size: 100%; gap: 4px; min-inline-size: 0; border-radius: 6px; text-align: start; cursor: pointer; }",
    rows + ":is(div) { display: grid; gap: 4px; }",
    rows + '[aria-expanded="false"] + ' + delegate + " { display: none; }",
    rows + " [data-hcv-agent-activity] { display: flex; align-items: flex-start; gap: 6px; min-inline-size: 0; color: var(--hcv-activity-text); font-size: var(--hcv-activity-font); font-weight: 430; line-height: 20px; }",
    rows + " [data-hcv-agent-activity] > span:last-child { min-inline-size: 0; overflow-wrap: break-word; }",
    rows + ':is(button) [data-hcv-agent-activity]:last-child::after { content: ""; flex: none; inline-size: 12px; block-size: 12px; background: var(--hcv-activity-glyph); mask: ' + codexMask("right") + " center / contain no-repeat; opacity: 0; }",
    rows + ':is(:hover, :focus-visible, [aria-expanded="true"]) [data-hcv-agent-activity]:last-child::after { opacity: 1; }',
    rows + '[aria-expanded="true"] [data-hcv-agent-activity]:last-child::after { rotate: 90deg; }',
    "@media (prefers-reduced-motion: no-preference) { " + rows + " [data-hcv-agent-activity]:last-child::after { transition: rotate 300ms; } }",
    rows + ":hover [data-hcv-agent-activity], " + rows + ":focus-visible [data-hcv-agent-activity] { color: var(--hcv-text); }",
    active2 + " [data-hcv-agent-icons] { display: inline-flex; flex: none; align-items: center; align-self: flex-start; gap: 4px; min-block-size: var(--conversation-line-height, 21px); }",
    active2 + " [data-hcv-agent-icons] img { inline-size: .875rem; block-size: .875rem; flex: none; }",
    rows + " [data-hcv-agent-icons] { gap: 6px; min-block-size: 20px; }",
    rows + " [data-hcv-agent-icons] img { inline-size: 16px; block-size: 16px; }",
    native2 + " { gap: 4px; margin-inline-start: 8px; padding-inline-start: 16px; border-inline-start: 1px solid var(--hcv-activity-border); }",
    task + " { padding: 0; border: 0; border-radius: 0; }",
    line + " { opacity: 1; gap: 4px; --conversation-tool-font-size: var(--hcv-activity-font); --conversation-scaffold-text: var(--hcv-activity-text); }",
    line + " > .codicon-agent { display: none; }",
    line + " > button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; border-radius: 6px; }",
    glyph3 + " { position: relative; inline-size: 16px; block-size: 16px; }",
    glyph3 + ':not(:has([role="status"], svg.text-destructive)) { background: var(--hcv-delegate-avatar) center / contain no-repeat; }',
    glyph3 + ':not(:has([role="status"], svg.text-destructive)) > * { position: absolute; inline-size: 1px; block-size: 1px; clip-path: inset(50%); overflow: hidden; }',
    card2 + " button[data-hcv-open-subagents] { position: relative; isolation: isolate; gap: 6px; color: var(--hcv-muted); padding: 0; }",
    card2 + " button[data-hcv-open-subagents]:is(:hover, :focus-visible) { background: none; color: var(--hcv-text); }",
    card2 + ' button[data-hcv-open-subagents]:is(:hover, :focus-visible)::before { content: ""; position: absolute; z-index: -1; inset: 0 -8px; border-radius: 8px; background: var(--hcv-summary-row-hover); }',
    card2 + " [data-hcv-agent-icons] { align-self: center; }",
    card2 + " [data-hcv-agent-counts] { min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }",
    card2 + ' [data-hcv-open-subagents]::after { content: ""; margin-inline-start: auto; flex: none; inline-size: 14px; block-size: 14px; background: currentColor; mask: ' + codexMask("right") + " center / contain no-repeat; opacity: 0; }",
    card2 + " [data-hcv-open-subagents]:is(:hover, :focus-visible)::after { opacity: 1; }",
    rows + ":focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }",
    "}"
  ].join("\n") + agentPaneStyles(active2);
}
function registerSubagents(ctx, active2) {
  const empty = { scope: null, agents: [], lang: "en", dark: false };
  const roster = Object.assign(atom(empty), { refresh });
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const enabled = () => root.matches(active2);
  const getScope = () => scopeKey2(host7.state.activeSessionId.get(), host7.state.connectionId.get(), host7.state.profile.get());
  const sheet = document.createElement("style");
  sheet.setAttribute("data-hcv-subagents-style", "");
  sheet.textContent = css(active2);
  mountStyle(ctx, sheet, { surface: "[data-hcv-agent-rows], [data-hcv-agent-icons], [data-hcv-summary-agents], [data-hcv-subagents-pane], [data-hcv-delegate-avatar]" });
  const cards = /* @__PURE__ */ new Map();
  const expanded = /* @__PURE__ */ new Set();
  const runtimeAgents = /* @__PURE__ */ new Map();
  const extra = /* @__PURE__ */ new Map();
  let nextId = 0;
  let frame = 0;
  let rosterSignature = "";
  let snapshot = null;
  let reading = null;
  let disposed = false;
  const queue = () => {
    if (!frame) frame = requestAnimationFrame(reconcile);
  };
  async function refresh(scope4) {
    if (disposed || scope4 !== getScope() || !enabled() || reading?.scope === scope4) return;
    const request = { scope: scope4 };
    reading = request;
    try {
      const result = await host7.request("subagent.list", { session_id: host7.state.activeSessionId.get() }, 5e3);
      if (disposed || reading !== request || scope4 !== getScope() || !Array.isArray(result?.subagents)) return;
      const agents = /* @__PURE__ */ new Map();
      for (const item of result.subagents) {
        const id2 = tidy(item?.subagent_id);
        if (!id2 || !["running", "queued"].includes(item.status)) continue;
        const tool = tidy(item.last_tool);
        const childSession = tidy(item.child_session_id);
        agents.set(id2, {
          id: id2,
          subagentId: id2,
          seed: id2,
          goal: tidy(item.goal),
          status: item.status,
          started: item.status === "running",
          startedAt: timestamp(item.started_at),
          model: tidy(item.model),
          childSession,
          lifecycleChild: Boolean(childSession),
          activity: tool ? [tool] : noActivity
        });
      }
      snapshot = { scope: scope4, agents };
      queue();
    } catch {
    } finally {
      if (reading === request) reading = null;
    }
  }
  for (const type of ["subagent.spawn_requested", "subagent.start", "subagent.tool", "subagent.progress", "subagent.complete"]) {
    ctx.onEvent(type, (event) => {
      if (!event.session_id || !event.payload || !enabled()) return;
      const scope4 = scopeKey2(
        event.session_id,
        event.connectionId || host7.state.connectionId.get(),
        event.profile || host7.state.profile.get()
      );
      if (scope4 !== getScope() && !(event.connectionId && event.profile)) return;
      const payload = event.payload;
      const goal = tidy(payload.goal);
      const subagentId = tidy(payload.subagent_id);
      if (!subagentId && !goal) return;
      const id2 = subagentId || JSON.stringify([payload.delegation_id, payload.parent_id, payload.task_index, goal]);
      const list = runtimeAgents.get(scope4) || /* @__PURE__ */ new Map();
      const previous = list.get(id2);
      if (previous && (final(previous.status) || event.seq != null && previous.seq >= event.seq)) return;
      const status2 = eventStatus(event, previous);
      if (previous?.started && status2 === "queued") return;
      const turn = previous?.turn || (scope4 === getScope() ? getPrompt([...document.querySelectorAll(primary + " " + transcript2 + " " + pair)].at(-1)) : null);
      const time = timestamp(event.timestamp) ?? (event.replayed ? void 0 : Date.now());
      const childSession = tidy(payload.child_session_id) || previous?.childSession;
      list.set(id2, {
        id: id2,
        subagentId,
        goal: goal || previous?.goal || "",
        seed: id2,
        turn,
        status: status2,
        cardId: previous?.cardId,
        seq: event.seq ?? previous?.seq,
        started: previous?.started || status2 === "running" || status2 === "completed",
        startedAt: previous?.startedAt ?? (status2 === "running" ? time : void 0),
        finishedAt: final(status2) ? time : void 0,
        updatedAt: time ?? previous?.updatedAt,
        model: tidy(payload.model) || previous?.model,
        childSession,
        lifecycleChild: Boolean(childSession),
        effort: tidy(payload.reasoning_effort) || previous?.effort,
        durationSeconds: duration(payload.duration_seconds) ?? previous?.durationSeconds,
        summary: prose(payload.summary) || (final(status2) ? prose(payload.text) : "") || previous?.summary,
        activity: eventActivity(event, previous)
      });
      if (list.size > 200) list.delete(list.keys().next().value);
      runtimeAgents.delete(scope4);
      runtimeAgents.set(scope4, list);
      if (runtimeAgents.size > 32) runtimeAgents.delete(runtimeAgents.keys().next().value);
      queue();
    });
  }
  function reconcile() {
    frame = 0;
    const on = enabled();
    const dark2 = root.dataset.hermesMode === "dark";
    const lang = language();
    const scope4 = on ? getScope() : null;
    if (snapshot?.scope !== scope4) snapshot = null;
    const observed = runtimeAgents.get(scope4);
    const live = snapshot ? new Map([...snapshot.agents, ...observed || []]) : observed;
    const claimed = /* @__PURE__ */ new Set();
    const activeCards = new Set(on ? document.querySelectorAll(surface + " " + transcript2 + " " + delegate) : []);
    const enhance = on && contrast.matches;
    for (const [card2, state] of cards) {
      if (!activeCards.has(card2)) {
        state.remove();
        cards.delete(card2);
      }
    }
    const indexInTurn = /* @__PURE__ */ new Map();
    const rowsByCard = /* @__PURE__ */ new Map();
    for (const card2 of activeCards) {
      const turn = card2.closest(pair);
      const index = indexInTurn.get(turn) ?? 0;
      indexInTurn.set(turn, index + 1);
      rowsByCard.set(card2, readCard(card2, index));
    }
    if (rowsByCard.size) applyStoredReceipts(rowsByCard);
    const agentsById = /* @__PURE__ */ new Map();
    for (const [card2, entries] of rowsByCard) {
      const inPrimary = Boolean(card2.closest(primary));
      const promptId = inPrimary && getPrompt(card2.closest(pair));
      if (inPrimary && live) {
        for (const row5 of entries) {
          const available = (agent) => agent && !claimed.has(agent.id) && (agent.cardId === row5.seed || !agent.cardId && (agent.turn ? agent.turn === promptId : !final(row5.status)));
          const sameId = live.get(row5.subagentId || row5.nativeId);
          const matched = sameId && !claimed.has(sameId.id) && (!sameId.cardId || sameId.cardId === row5.seed) ? sameId : !row5.subagentId && [...live.values()].find((agent) => available(agent) && (agent.cardId === row5.seed || promptId && agent.turn === promptId && agent.goal === row5.goal));
          if (!matched) continue;
          matched.cardId = row5.seed;
          claimed.add(matched.id);
          row5.id = matched.id;
          row5.subagentId ||= matched.subagentId;
          row5.started ||= matched.started;
          if (final(matched.status) || !final(row5.status)) row5.status = matched.status;
          row5.startedAt = matched.startedAt;
          row5.finishedAt = matched.finishedAt ?? row5.finishedAt;
          row5.updatedAt = matched.updatedAt;
          row5.model ||= matched.model;
          row5.childSession = matched.childSession || row5.childSession;
          row5.lifecycleChild = matched.lifecycleChild;
          row5.canOpen = !row5.button.disabled && Boolean(row5.childSession && row5.nativeSession === row5.childSession);
          row5.effort ||= matched.effort;
          row5.durationSeconds ??= matched.durationSeconds;
          row5.summary ||= matched.summary;
          row5.activity = matched.activity;
        }
      }
      if (inPrimary) for (const row5 of entries) agentsById.set(row5.id, row5);
      if (!enhance || !entries.length) {
        cards.get(card2)?.remove();
        cards.delete(card2);
        continue;
      }
      if (!cards.has(card2)) {
        const owner = inPrimary ? scope4 : card2.closest(surface)?.dataset.composerSurfaceId;
        const key = JSON.stringify([owner, entries.map(({ seed }) => seed)]);
        cards.set(card2, enhanceCard(card2, ++nextId, expanded, key));
      }
      const state = cards.get(card2);
      if (state.rows.nextElementSibling !== card2) card2.before(state.rows);
      styleDelegateRows(state, entries, dark2);
      renderActivity(state, entries, lang, dark2);
    }
    const withoutCard = live ? [...live.values()].filter((agent) => !claimed.has(agent.id)) : [];
    const agents = [...agentsById.values(), ...withoutCard];
    const groups2 = /* @__PURE__ */ new Map();
    if (enhance && withoutCard.length) {
      const turns = new Map([...document.querySelectorAll(primary + " " + transcript2 + " " + pair)].map((turn) => [getPrompt(turn), turn]));
      for (const agent of withoutCard) {
        const group2 = agent.turn && turns.get(agent.turn)?.querySelector(":scope > " + response);
        if (group2) groups2.set(group2, [...groups2.get(group2) || [], agent]);
      }
    }
    for (const [group2, state] of extra) {
      if (!groups2.has(group2)) {
        state.rows.remove();
        extra.delete(group2);
      }
    }
    for (const [group2, entries] of groups2) {
      if (!extra.has(group2)) {
        const rows = document.createElement("div");
        rows.setAttribute("data-hcv-agent-rows", "");
        group2.append(rows);
        extra.set(group2, { rows });
      }
      renderActivity(extra.get(group2), entries, lang, dark2);
    }
    const signature = scope4 + activitySignature(agents, lang, dark2);
    const prior = roster.get().agents;
    if (signature !== rosterSignature || agents.some((agent, i) => {
      const old = prior[i];
      return !old || agent.button !== old.button || agent.canOpen !== old.canOpen || agent.model !== old.model || agent.childSession !== old.childSession || agent.subagentId !== old.subagentId || agent.lifecycleChild !== old.lifecycleChild || agent.effort !== old.effort || agent.summary !== old.summary || agent.startedAt !== old.startedAt || agent.finishedAt !== old.finishedAt || agent.updatedAt !== old.updatedAt || agent.durationSeconds !== old.durationSeconds || agent.activity !== old.activity || agent.receiptButton !== old.receiptButton;
    })) {
      rosterSignature = signature;
      roster.set({ scope: scope4, agents, lang, dark: dark2 });
    }
  }
  const observer = new MutationObserver((records) => {
    const relevant = [delegate, primary, pair, response, notice].join(", ");
    if (records.some(({ target, type, addedNodes, removedNodes }) => {
      if (target === root) return true;
      if (!enabled()) return false;
      const element7 = target instanceof Element ? target : target.parentElement;
      if (!element7 || element7.closest(generated)) return false;
      if (element7.closest(delegate)) return true;
      if (type !== "childList") return false;
      return [...addedNodes, ...removedNodes].some((node3) => node3 instanceof Element && !node3.matches(generated) && (node3.matches(relevant) || node3.querySelector(relevant)));
    })) queue();
  });
  observer.observe(root, {
    subtree: true,
    childList: true,
    characterData: true,
    attributes: true,
    attributeFilter: ["aria-label", "disabled", "data-hermes-theme", "data-hermes-mode", "data-hermes-codex-visual", "lang"]
  });
  const unsubscribers = [host7.state.activeSessionId, host7.state.connectionId, host7.state.profile].map((state) => state.subscribe(queue));
  contrast.addEventListener("change", queue);
  ctx.onDispose(() => {
    disposed = true;
    observer.disconnect();
    for (const unsubscribe of unsubscribers) unsubscribe();
    contrast.removeEventListener("change", queue);
    cancelAnimationFrame(frame);
    for (const state of cards.values()) state.remove();
    for (const state of extra.values()) state.rows.remove();
    roster.set(empty);
    sheet.remove();
  });
  queue();
  return roster;
}

// source/summary-panes.js
import {
  atom as atom2,
  DropdownMenu as DropdownMenu3,
  DropdownMenuContent as DropdownMenuContent3,
  DropdownMenuItem as DropdownMenuItem3,
  DropdownMenuSeparator as DropdownMenuSeparator2,
  DropdownMenuTrigger as DropdownMenuTrigger3,
  host as host8,
  useI18n as useI18n3,
  useValue as useValue2
} from "@hermes/plugin-sdk";
import { createElement as h8 } from "react";
var workspacePrefix = "hermes-codex-visual-summary-";
var panePrefix = "plugin-workspace:" + workspacePrefix;
var names = {
  ru: { agents: "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u044B", sources: "\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438", changes: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F", files: "\u0424\u0430\u0439\u043B\u044B \u043F\u0440\u043E\u0435\u043A\u0442\u0430", add: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0432\u043A\u043B\u0430\u0434\u043A\u0443" },
  en: { agents: "Subagents", sources: "Sources", changes: "Changes", files: "Project files", add: "Add tab" }
};
var glyphs2 = { agents: "bots", sources: "summarySources", changes: "changes", files: "folder" };
var copy = (locale) => names[locale?.split("-")[0]] || names.en;
var paneId = (kind) => panePrefix + kind;
var paneTab = (kind) => '[data-tree-tab="' + paneId(kind) + '"]';
function icon3(kind) {
  const glyph3 = glyphs2[kind];
  return h8("span", { "aria-hidden": true, "data-hcv-icon": glyph3, style: codexIconStyle(glyph3) });
}
function Picker({ state, open }) {
  const menu = useValue2(state);
  const { locale } = useI18n3();
  if (!menu) return null;
  const select = (kind) => () => open(kind);
  return h8(
    DropdownMenu3,
    { open: true, onOpenChange: (value) => {
      if (!value) state.set(null);
    } },
    h8(DropdownMenuTrigger3, { asChild: true }, h8("span", {
      "aria-hidden": true,
      tabIndex: -1,
      style: { position: "fixed", pointerEvents: "none", ...menu.rect }
    })),
    h8(
      DropdownMenuContent3,
      {
        align: "start",
        sideOffset: 4,
        "data-hcv-summary-picker": "",
        onCloseAutoFocus: (event) => {
          event.preventDefault();
          if (menu.trigger.isConnected) menu.trigger.focus({ preventScroll: true });
        }
      },
      ...["agents", "sources"].map((kind) => h8(
        DropdownMenuItem3,
        { key: kind, onSelect: select(kind) },
        icon3(kind),
        copy(locale)[kind]
      )),
      h8(DropdownMenuSeparator2),
      ...["changes", "files"].map((kind) => h8(
        DropdownMenuItem3,
        { key: kind, onSelect: select(kind) },
        icon3(kind),
        copy(locale)[kind]
      ))
    )
  );
}
function registerSummaryPanes(ctx, active2, views) {
  const menu = atom2(null);
  const registrations = /* @__PURE__ */ new Map();
  let disposed = false;
  const open = (kind) => {
    if (kind === "files") {
      host8.revealPane("files");
      return;
    }
    const render = views[kind];
    if (disposed || !render || !document.documentElement.matches(active2) || typeof host8.openWorkspace !== "function") return;
    const id2 = paneId(kind);
    if (registrations.has(kind)) {
      host8.revealPane(id2);
      return;
    }
    const sibling = [...registrations.keys()].find((key) => document.querySelector(paneTab(key) + '[aria-selected="true"]')) || [...registrations.keys()].find((key) => document.querySelector(paneTab(key)));
    const dock2 = sibling ? { pane: paneId(sibling), pos: "center" } : { pane: "workspace", pos: "right" };
    const dispose = host8.openWorkspace(workspacePrefix + kind, {
      dock: dock2,
      minWidth: "280px",
      title: copy(document.documentElement.lang)[kind],
      render: () => h8("div", { "data-hcv-summary-pane": kind }, render()),
      onClose: () => {
        registrations.delete(kind);
        queue();
      }
    });
    registrations.set(kind, dispose);
    queue();
  };
  const plus = document.createElement("button");
  plus.type = "button";
  plus.dataset.hcvSummaryAddTab = "";
  plus.setAttribute("aria-haspopup", "menu");
  plus.addEventListener("pointerdown", (event) => event.stopPropagation());
  plus.addEventListener("click", () => {
    const { x, y, width, height } = plus.getBoundingClientRect();
    menu.set({ trigger: plus, rect: { left: x, top: y, width, height } });
  });
  let frame = 0;
  function queue() {
    if (!disposed && !frame) frame = requestAnimationFrame(syncStrip);
  }
  function syncStrip() {
    frame = 0;
    if (disposed || !registrations.size) {
      plus.remove();
      return;
    }
    const language2 = copy(document.documentElement.lang);
    for (const kind of registrations.keys()) {
      for (const tab2 of document.querySelectorAll(paneTab(kind))) {
        const caption2 = tab2.querySelector(".pane-tab-content .truncate");
        if (caption2?.childNodes.length === 1 && caption2.firstChild.nodeType === Node.TEXT_NODE && caption2.firstChild.nodeValue !== language2[kind]) caption2.firstChild.nodeValue = language2[kind];
        if (tab2.getAttribute("aria-label") !== language2[kind]) tab2.setAttribute("aria-label", language2[kind]);
      }
    }
    const selected2 = document.querySelector('[data-tree-tab^="' + panePrefix + '"][aria-selected="true"]');
    const list = selected2?.closest("[data-zone-tabstrip]")?.querySelector('[role="tablist"]');
    if (!list || !document.documentElement.matches(active2)) {
      plus.remove();
      return;
    }
    const label3 = copy(document.documentElement.lang).add;
    if (plus.getAttribute("aria-label") !== label3) plus.setAttribute("aria-label", label3);
    if (plus.parentNode !== list || plus !== list.lastElementChild) list.append(plus);
  }
  const close2 = () => {
    menu.set(null);
    for (const dispose of registrations.values()) dispose();
    registrations.clear();
    plus.remove();
  };
  const observer = new MutationObserver(() => {
    if (!document.documentElement.matches(active2)) close2();
    else queue();
  });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  const stripObserver = new MutationObserver((records) => {
    if (!registrations.size) return;
    if (records.some((record) => {
      const target = record.target instanceof Element ? record.target : record.target.parentElement;
      if (!(target instanceof Element)) return false;
      if (record.type === "attributes") return target.matches('[role="tab"][data-tree-tab]');
      if (target.closest("[data-zone-tabstrip]")) return true;
      if (target.closest('[data-slot="aui_thread-content"], [data-hcv-summary-pane]')) return false;
      return movedElementMatches(record, "[data-zone-tabstrip]");
    })) queue();
  });
  stripObserver.observe(document.body, { childList: true, characterData: true, subtree: true, attributes: true, attributeFilter: ["aria-selected", "aria-label"] });
  const summaryTab = '[role="tab"][data-tree-tab^="' + panePrefix + '"]:not([data-vertical])';
  const selectedTab = summaryTab + '[aria-selected="true"]';
  const sideStrip = '[data-zone-tabstrip]:not([data-zone-tabstrip="grp-main"], [data-zone-tabstrip="grp-sessions"])';
  const header2 = active2 + " [data-panel-header]:has(> " + sideStrip + " " + selectedTab + ")";
  const singleRow = active2 + " [data-panel-header]:has(> " + sideStrip + ":not(.absolute) " + selectedTab + ")";
  const strip2 = active2 + " " + sideStrip + ":has(" + selectedTab + ")";
  const track = "[data-tree-split].flex-row > div:has(> [data-tree-group] > [data-panel-header] > " + sideStrip + " " + selectedTab + ")";
  const seam = active2 + " " + track + ' > [data-sash-overlap="trailing"]';
  const line = "light-dark(rgb(26 28 31 / 12%), #2b2b2b)";
  const tab = active2 + " [data-zone-tabstrip] " + summaryTab + "[aria-selected]:has(> .pane-tab-content)";
  const selected = tab + ':is([aria-selected="true"], [data-selected])';
  const closeControl = tab + " > span > button";
  const style = document.createElement("style");
  style.dataset.hcvSummaryPanes = "";
  style.textContent = [
    "@media (forced-colors: none) {",
    active2 + " [data-hcv-summary-pane] { height: 100%; min-height: 0; min-width: 0; overflow: hidden; background: var(--hcv-chat); color: var(--hcv-text); font: 13px/20px var(--hcv-ui-font); }",
    // Right panel and close control in Codex 983280.4074749967.js. Let the
    // host keep its extra controls row when the tab strip wraps below it.
    header2 + " { background: var(--hcv-chat); }",
    singleRow + " { min-block-size: 48px; }",
    header2 + '::after { content: ""; position: absolute; inset-inline: 0; inset-block-end: 0; block-size: .5px; background: ' + line + "; pointer-events: none; }",
    strip2 + " { background: transparent; }",
    strip2 + ":not(.absolute) { block-size: auto; }",
    strip2 + ' > [role="tablist"] { padding-inline-start: 7px; }',
    seam + " > span:first-child { background: " + line + "; opacity: 1; }",
    tab + " { align-self: center; flex: 0 1 220px; min-inline-size: 72px; max-inline-size: 220px; block-size: 30px; min-block-size: 30px; max-block-size: 30px; margin-inline: 0; padding-inline-start: 8px; border-radius: 8px; border-inline-start-color: transparent; background-color: transparent; color: var(--hcv-muted); }",
    tab + "[data-closeable] { --pane-tab-close-width: 32px; padding-inline-end: var(--pane-tab-close-width); }",
    tab + " .pane-tab-content .truncate { color: inherit; font: 430 13px/18.5714px var(--hcv-ui-font); letter-spacing: normal; text-transform: none; }",
    tab + " .pane-tab-content > :first-child { padding-inline: 4px; margin-inline: 0; }",
    tab + ':not([aria-selected="true"], [data-selected]):hover { background-color: light-dark(rgb(26 28 31 / 5%), rgb(255 255 255 / 8%)); color: var(--hcv-text); box-shadow: none; }',
    tab + "[data-selected] { background-color: var(--hcv-selected); color: var(--hcv-text); }",
    tab + '[aria-selected="true"] { background-color: light-dark(var(--hcv-chat), #2a2a2a); color: light-dark(var(--hcv-text), #dfdfdf); box-shadow: inset 0 0 0 .5px light-dark(rgb(26 28 31 / 21%), #4c4c4c); }',
    selected + " > span:has(> button), " + tab + ":focus-visible > span:has(> button) { opacity: 1; pointer-events: auto; }",
    closeControl + " .codicon-close { display: none; }",
    closeControl + '::before { content: ""; inline-size: 14px; block-size: 14px; background: currentColor; mask: ' + codexIconStyle("close").mask + "; }",
    ...Object.keys(views).map((kind) => tab + paneTab(kind) + ' .pane-tab-content::before { content: ""; display: inline-block; inline-size: 16px; block-size: 16px; flex: none; background: currentColor; mask: ' + codexIconStyle(glyphs2[kind]).mask + "; }"),
    active2 + " [data-hcv-summary-picker] [data-hcv-icon] { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; }",
    active2 + " [data-hcv-summary-add-tab] { -webkit-app-region: no-drag; align-self: center; display: grid; place-items: center; flex: none; inline-size: 28px; block-size: 28px; margin-inline-start: 7px; border-radius: " + codexReference.quietControl.radius + "; color: var(--hcv-muted); }",
    active2 + ' [data-hcv-summary-add-tab]::before { content: ""; display: block; inline-size: 16px; block-size: 16px; background: currentColor; mask: ' + codexIconStyle("plus").mask + "; }",
    active2 + " [data-hcv-summary-add-tab]:hover { background: var(--hcv-hover); color: var(--hcv-text); }",
    tab + ":focus-visible, " + active2 + " [data-hcv-summary-add-tab]:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }",
    active2 + " [data-hcv-summary-picker] { min-inline-size: 170px; }",
    "}"
  ].join("\n");
  mountStyle(ctx, style, { surface: '[data-tree-tab^="' + panePrefix + '"]' });
  ctx.onDispose(() => {
    disposed = true;
    observer.disconnect();
    stripObserver.disconnect();
    if (frame) cancelAnimationFrame(frame);
    close2();
    style.remove();
  });
  return {
    open,
    visibility: {
      agents: host8.paneVisibility(paneId("agents")),
      sources: host8.paneVisibility(paneId("sources")),
      changes: host8.paneVisibility(paneId("changes"))
    },
    renderPicker: () => h8(Picker, { state: menu, open })
  };
}

// source/summary-changes.js
import { useI18n as useI18n4 } from "@hermes/plugin-sdk";
import { createElement as h9, useEffect as useEffect5, useId as useId2, useState as useState5 } from "react";
var labels5 = {
  ru: {
    title: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0431\u0435\u0437 \u043A\u043E\u043C\u043C\u0438\u0442\u0430",
    refresh: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C",
    loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
    noProject: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0440\u043E\u0435\u043A\u0442",
    empty: "\u041D\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439",
    unavailable: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439",
    noDiff: "\u041D\u0435\u0442 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439 \u0434\u043B\u044F \u043F\u043E\u043A\u0430\u0437\u0430",
    diffError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0444\u0430\u0439\u043B\u0430"
  },
  en: {
    title: "Uncommitted changes",
    refresh: "Refresh",
    loading: "Loading\u2026",
    noProject: "Select a project",
    empty: "No changes",
    unavailable: "Could not read changed files",
    noDiff: "No changes to display",
    diffError: "Could not open the file diff"
  }
};
async function readReview(route, cwd, connectionId, profile2, params) {
  const query = new URLSearchParams({ path: cwd, scope: "uncommitted", ...params });
  return window.hermesDesktop.api({
    connectionId,
    profile: profile2,
    method: "GET",
    path: "/api/git/review/" + route + "?" + query,
    timeoutMs: 15e3
  });
}
async function readFileDiff(cwd, connectionId, profile2, file, staged) {
  const query = new URLSearchParams({ path: cwd, file });
  const result = await window.hermesDesktop.api({
    connectionId,
    profile: profile2,
    method: "GET",
    path: "/api/git/file-diff?" + query,
    timeoutMs: 15e3
  });
  if (typeof result?.diff !== "string") throw new Error("Diff unavailable");
  if (result.diff || !staged) return result.diff;
  const [index, working] = await Promise.all([true, false].map((value) => readReview("diff", cwd, connectionId, profile2, { file, staged: String(value) })));
  if (typeof index?.diff !== "string" || typeof working?.diff !== "string") throw new Error("Diff unavailable");
  const header2 = working.diff.split(/^@@ /m, 1)[0];
  const synthetic = /^(?:--- \/dev\/null\r?$|Binary files \/dev\/null and )/m.test(header2);
  return [index.diff, synthetic ? "" : working.diff].filter(Boolean).join("\n");
}
function icon4(glyph3) {
  return h9("span", { "aria-hidden": true, className: "hcv-changes-icon", style: codexIconStyle(glyph3) });
}
function DiffText({ text }) {
  if (text.length > 15e4) return h9("pre", { "data-hcv-change-diff": "", tabIndex: 0 }, text);
  return h9("pre", { "data-hcv-change-diff": "", tabIndex: 0 }, text.split("\n").map((line, index, lines) => {
    const type = line.startsWith("@@") ? "hunk" : line.startsWith("+") && !line.startsWith("+++ ") ? "added" : line.startsWith("-") && !line.startsWith("--- ") ? "removed" : void 0;
    return h9("span", { key: index, "data-hcv-diff-line": type }, index < lines.length - 1 ? line + "\n" : line);
  }));
}
function FileDiff({ id: id2, cwd, connectionId, profile: profile2, path, staged, copy: copy7 }) {
  const [result, setResult] = useState5(null);
  useEffect5(() => {
    let live = true;
    void readFileDiff(cwd, connectionId, profile2, path, staged).then(
      (text) => {
        if (live) setResult({ text });
      },
      () => {
        if (live) setResult({});
      }
    );
    return () => {
      live = false;
    };
  }, [cwd, connectionId, profile2, path, staged]);
  return h9("div", { id: id2, className: "hcv-change-detail" }, result?.text ? h9(DiffText, { text: result.text }) : h9("p", { role: "status" }, !result ? copy7.loading : result.text === "" ? copy7.noDiff : copy7.diffError));
}
function RepositoryChanges({ cwd, connectionId, profile: profile2, copy: copy7 }) {
  const diffId = useId2();
  const [revision, setRevision] = useState5(0);
  const [result, setResult] = useState5(null);
  const [selected, setSelected] = useState5(null);
  useEffect5(() => {
    let live = true;
    void readReview("list", cwd, connectionId, profile2).then((value) => {
      const files = Array.isArray(value?.files) ? value.files.filter((file) => typeof file?.path === "string" && file.path) : null;
      if (live) setResult({ revision, files });
    }, () => {
      if (live) setResult({ revision, files: null });
    });
    return () => {
      live = false;
    };
  }, [cwd, connectionId, profile2, revision]);
  const current = result?.revision === revision ? result : null;
  return h9(
    "div",
    { className: "hcv-changes-content" },
    h9(
      "header",
      { className: "hcv-changes-header" },
      h9("span", null, copy7.title),
      h9("button", {
        type: "button",
        className: "hcv-changes-refresh",
        "aria-label": copy7.refresh,
        title: copy7.refresh,
        onClick: () => {
          setSelected(null);
          setRevision((value) => value + 1);
        }
      }, icon4("refresh"))
    ),
    current?.files?.length ? h9("ul", { "aria-label": copy7.title }, current.files.map((file) => {
      const open = selected === file.path;
      return h9(
        "li",
        { key: file.path, "data-hcv-changed-file": "" },
        h9(
          "button",
          {
            type: "button",
            className: "hcv-changes-file",
            title: file.path,
            "aria-label": file.path,
            "aria-expanded": open,
            "aria-controls": open ? diffId : void 0,
            onClick: () => setSelected((previous) => previous === file.path ? null : file.path)
          },
          icon4("right"),
          icon4("artifacts"),
          h9("span", { className: "hcv-changes-path", dir: "auto" }, file.path),
          h9(
            "span",
            { className: "hcv-changes-counts" },
            h9("span", { "data-hcv-count": "added" }, "+" + (file.added || 0)),
            h9("span", { "data-hcv-count": "removed" }, "\u2212" + (file.removed || 0))
          )
        ),
        open && h9(FileDiff, { id: diffId, cwd, connectionId, profile: profile2, path: file.path, staged: file.staged === true, copy: copy7 })
      );
    })) : h9(
      "p",
      { className: "hcv-changes-status", role: "status" },
      !current ? copy7.loading : current.files ? copy7.empty : copy7.unavailable
    )
  );
}
function ChangesPane({ cwd, scope: scope4 }) {
  const { locale } = useI18n4();
  const copy7 = labels5[locale] || labels5.en;
  const connectionId = scope4?.connectionId;
  const profile2 = scope4?.profile;
  return h9("div", { "data-hcv-changes-pane": "" }, cwd && connectionId && profile2 ? h9(RepositoryChanges, { key: JSON.stringify([cwd, connectionId, profile2]), cwd, connectionId, profile: profile2, copy: copy7 }) : h9("p", { className: "hcv-changes-status", role: "status" }, copy7.noProject));
}
function registerSummaryChanges(ctx, active2) {
  const pane = `${active2} [data-hcv-changes-pane]`;
  const style = document.createElement("style");
  style.dataset.hcvSummaryChanges = "";
  style.textContent = `
    ${pane} { block-size: 100%; min-block-size: 0; overflow: auto; background: var(--hcv-chat); color: var(--hcv-text); font: 13px/20px var(--hcv-ui-font); }
    ${pane} .hcv-changes-content { padding: 12px 16px 16px; }
    ${pane} .hcv-changes-header { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-block-size: 28px; margin-block-end: 8px; color: var(--hcv-muted); }
    ${pane} ul { list-style: none; margin: 0; padding: 0; }
    ${pane} li + li { margin-block-start: 2px; }
    ${pane} button { border: 0; background: transparent; color: inherit; font: inherit; cursor: pointer; }
    ${pane} button:focus-visible, ${pane} pre:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
    ${pane} .hcv-changes-icon { display: inline-block; inline-size: 16px; block-size: 16px; flex: none; }
    ${pane} .hcv-changes-refresh { display: grid; place-items: center; inline-size: 24px; block-size: 24px; padding: 0; border-radius: 7px; }
    /* Adapt the Codex full-review file header from 131264.31ce2394bb.js to the Hermes fallback list. */
    ${pane} .hcv-changes-file {
      display: flex; align-items: center; gap: 8px; inline-size: 100%;
      padding: 8px 8px 8px 12px; border-block-end: 1px solid var(--hcv-hairline);
      border-radius: 0; text-align: start; font-size: 14px;
    }
    ${pane} .hcv-changes-file > .hcv-changes-icon:first-child {
      inline-size: 14px; block-size: 14px; rotate: 0deg; color: var(--hcv-muted);
    }
    ${pane} .hcv-changes-file[aria-expanded="true"] > .hcv-changes-icon:first-child { rotate: 90deg; }
    ${pane} .hcv-changes-file > .hcv-changes-icon:nth-child(2) { color: var(--hcv-muted); }
    ${pane} button:hover { background: var(--hcv-hover); }
    ${pane} .hcv-changes-file:hover > .hcv-changes-icon:first-child { color: var(--hcv-text); }
    ${pane} .hcv-changes-path { flex: 1; min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    ${pane} .hcv-changes-counts {
      display: flex; gap: 4px; margin-inline: 4px; line-height: 1;
      font-variant-numeric: tabular-nums; letter-spacing: -.025em;
    }
    ${pane} [data-hcv-count="added"] { color: light-dark(#00a240, #40c977); }
    ${pane} [data-hcv-count="removed"] { color: light-dark(#ba2623, #fa423e); }
    ${pane} [data-hcv-diff-line="added"] { color: light-dark(#008241, #40c977); }
    ${pane} [data-hcv-diff-line="removed"] { color: light-dark(#aa2626, #f28080); }
    ${pane} [data-hcv-diff-line="hunk"] { color: var(--hcv-muted); }
    ${pane} .hcv-change-detail { margin: 1px 0 8px; overflow: hidden; border-radius: 0 0 10px 10px; }
    ${pane} .hcv-change-detail p { padding: 8px 12px; margin: 0; color: var(--hcv-muted); }
    ${pane} [data-hcv-change-diff] { max-block-size: min(55dvh, 480px); overflow: auto; margin: 0; padding: 8px 12px; font: 12px/18px var(--hcv-mono-font, ui-monospace, monospace); tab-size: 4; }
    ${pane} .hcv-changes-status { margin: 12px 16px; color: var(--hcv-muted); }
    ${pane} .hcv-changes-content .hcv-changes-status { margin-inline: 0; }
    @media (prefers-reduced-motion: no-preference) {
      ${pane} .hcv-changes-file > .hcv-changes-icon:first-child { transition: rotate 150ms ease; }
    }
  `;
  mountStyle(ctx, style, { surface: "[data-hcv-changes-pane]" });
}

// source/workspace-actions.js
import {
  atom as atom3,
  Button,
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  host as host9,
  Input,
  TITLEBAR_AREAS as TITLEBAR_AREAS2,
  useValue as useValue3
} from "@hermes/plugin-sdk";
import { createElement as h10, useEffect as useEffect6, useRef as useRef4, useState as useState6 } from "react";
var labels6 = {
  ru: {
    terminalFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B \u0432 \u043F\u0430\u043F\u043A\u0435 \u0447\u0430\u0442\u0430.",
    toTree: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u0434\u0435\u0440\u0435\u0432\u043E",
    toMain: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432 \u043E\u0441\u043D\u043E\u0432\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E",
    select: "\u041A\u0443\u0434\u0430 \u043F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0447\u0430\u0442",
    newTree: "\u041D\u043E\u0432\u043E\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u0434\u0435\u0440\u0435\u0432\u043E",
    branch: "\u0418\u043C\u044F \u043D\u043E\u0432\u043E\u0439 \u0432\u0435\u0442\u043A\u0438",
    main: "\u041E\u0441\u043D\u043E\u0432\u043D\u043E\u0439 \u043A\u0430\u0442\u0430\u043B\u043E\u0433",
    cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
    move: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C",
    loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432\u2026",
    detail: "\u0427\u0430\u0442 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u0441\u044F \u0432 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0439 \u043F\u0430\u043F\u043A\u0435. \u041D\u0435\u0437\u0430\u043A\u043E\u043C\u043C\u0438\u0447\u0435\u043D\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B \u043E\u0441\u0442\u0430\u044E\u0442\u0441\u044F \u0432 \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u043C \u0434\u0435\u0440\u0435\u0432\u0435.",
    busy: "\u0414\u043E\u0436\u0434\u0438\u0442\u0435\u0441\u044C \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u044F \u043E\u0442\u0432\u0435\u0442\u0430 \u0432 \u044D\u0442\u043E\u043C \u0447\u0430\u0442\u0435.",
    unavailable: "\u041F\u0430\u043F\u043A\u0430 \u0438\u043B\u0438 \u043F\u0440\u043E\u0444\u0438\u043B\u044C \u0447\u0430\u0442\u0430 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u044D\u0442\u043E \u043E\u043A\u043D\u043E \u0435\u0449\u0451 \u0440\u0430\u0437.",
    failed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0447\u0430\u0442.",
    listFailed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u0440\u0430\u0431\u043E\u0447\u0438\u0435 \u0434\u0435\u0440\u0435\u0432\u044C\u044F.",
    setup: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
    setupFailed: "\u0427\u0430\u0442 \u043F\u0435\u0440\u0435\u043C\u0435\u0449\u0451\u043D. \u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438.",
    moved: "\u0427\u0430\u0442 \u043F\u0435\u0440\u0435\u043C\u0435\u0449\u0451\u043D"
  },
  en: {
    terminalFailed: "Could not open a terminal in this chat\u2019s folder.",
    toTree: "Move to worktree",
    toMain: "Move to main checkout",
    select: "Move this chat to",
    newTree: "New worktree",
    branch: "New branch name",
    main: "Main checkout",
    cancel: "Cancel",
    move: "Move",
    loading: "Loading worktrees\u2026",
    detail: "The chat will continue in the selected folder. Uncommitted files stay in the original checkout.",
    busy: "Wait for the current reply to finish.",
    unavailable: "The chat folder or profile changed. Reopen this dialog.",
    failed: "Could not move the chat.",
    listFailed: "Could not load worktrees.",
    setup: "Run setup script",
    setupFailed: "The chat moved. The setup script could not start.",
    moved: "Chat moved"
  }
};
var copy2 = () => document.documentElement.matches(":lang(ru)") ? labels6.ru : labels6.en;
var workspacePathKey = (value) => {
  const path = String(value || "").replaceAll("\\", "/").replace(/\/+$/, "");
  return /^[a-z]:|^\/\//i.test(path) ? path.toLowerCase() : path;
};
var localOwner = (owner) => owner?.connectionId === "local" && Boolean(owner.profile);
function gitApi(scope4, cwd, route, body2) {
  const base = { connectionId: scope4.connectionId, profile: scope4.profile, timeoutMs: body2 ? 3e4 : 8e3 };
  const path = "/api/git/" + route;
  return window.hermesDesktop.api(body2 ? { ...base, path, method: "POST", body: { path: cwd, ...body2 } } : { ...base, path: path + "?" + new URLSearchParams({ path: cwd }) });
}
async function readWorkspaceRepository(cwd, scope4) {
  if (!cwd) return null;
  const native2 = localOwner(scope4) ? window.hermesDesktop?.git : null;
  const repo = await native2?.repoStatus?.(cwd).catch(() => null);
  if (repo) return { repo, native: true };
  const fallback = await gitApi(scope4, cwd, "status").catch(() => null);
  return fallback && { repo: fallback, native: false };
}
async function readWorkspaceTrees(cwd, scope4, native2) {
  const result = native2 ? await window.hermesDesktop.git.worktreeList(cwd) : (await gitApi(scope4, cwd, "worktrees"))?.worktrees;
  return Array.isArray(result) ? result : [];
}
function workspaceTreeFor(trees, cwd) {
  const path = workspacePathKey(cwd);
  return trees.reduce((closest, tree) => {
    const root = workspacePathKey(tree.path);
    return root && (path === root || path.startsWith(root + "/")) && (!closest || root.length > workspacePathKey(closest.path).length) ? tree : closest;
  }, null);
}
function ownsChat(target) {
  const owner = host9.state.focusedSessionOwner.get();
  return localOwner(target.owner) && owner?.connectionId === target.owner.connectionId && owner.profile === target.owner.profile && host9.state.activeSessionId.get() === target.runtime && host9.state.focusedSessionId.get() === target.runtime && host9.state.focusedStoredSessionId.get() === target.session && workspacePathKey(host9.state.cwd.get()) === workspacePathKey(target.cwd);
}
var terminalSelector = '[data-pane-host="terminal"]';
var newTerminal = () => document.querySelector(terminalSelector + ' [role="tablist"] > li > button:has(> .codicon-add)');
function dispatchNewTerminal() {
  let custom;
  try {
    custom = JSON.parse(localStorage.getItem("hermes.desktop.keybinds") || "{}");
  } catch {
    return false;
  }
  const chord = "ctrl+shift+" + String.fromCharCode(96);
  const mapped = custom?.["view.newTerminal"];
  if (mapped && !mapped.includes(chord)) return false;
  if (Object.entries(custom || {}).some(([action, keys]) => action !== "view.newTerminal" && Array.isArray(keys) && (keys.includes(chord) || keys.includes(chord.replace("ctrl+", "mod+"))))) return false;
  const event = new KeyboardEvent("keydown", {
    key: "~",
    code: "Backquote",
    ctrlKey: true,
    shiftKey: true,
    bubbles: true,
    cancelable: true
  });
  return !window.dispatchEvent(event);
}
function openWorkspaceTerminal(target) {
  window.setTimeout(() => {
    const draft = !target.session && !target.runtime && !host9.state.focusedStoredSessionId.get() && !host9.state.activeSessionId.get() && localOwner(target.owner) && host9.state.connectionId.get() === target.owner.connectionId && host9.state.profile.get() === target.owner.profile && workspacePathKey(host9.state.cwd.get()) === workspacePathKey(target.cwd);
    if (!draft && !ownsChat(target)) {
      host9.notify({ kind: "error", message: copy2().unavailable });
      return;
    }
    if (host9.paneVisibility("terminal").get() && newTerminal()) {
      newTerminal().click();
      return;
    }
    if (dispatchNewTerminal()) return;
    const nativeTab = document.querySelector('[data-tree-tab="terminal"]');
    if (nativeTab?.getClientRects().length) {
      nativeTab.click();
      return;
    }
    host9.notify({ kind: "error", message: copy2().terminalFailed });
  }, 0);
}
function openWorkspaceReview(getChat) {
  const review = getChat()?.querySelector(".coding-status-bar button:has(> .codicon-git-branch)");
  if (!review || review.disabled) return false;
  if (host9.paneVisibility("review").get()) host9.revealPane("review");
  else review.click();
  return true;
}
function MoveWorkspaceDialog({ target, close: close2, refresh, localEnvironment }) {
  const words3 = copy2();
  const [trees, setTrees] = useState6(null);
  const [choice, setChoice] = useState6("");
  const [branch, setBranch] = useState6("");
  const [error, setError] = useState6("");
  const [pending, setPending] = useState6(false);
  const [setupAvailable, setSetupAvailable] = useState6(false);
  const [runSetup, setRunSetup] = useState6(true);
  const running = useRef4(false);
  const created = useRef4(null);
  const currentTree = workspaceTreeFor(trees || [], target.cwd);
  const isMain = currentTree?.isMain !== false;
  const busy = useValue3(host9.state.busy);
  useEffect6(() => {
    let live = true;
    void readWorkspaceTrees(target.cwd, target.owner, target.nativeGit).then((result) => {
      if (!live) return;
      const all = result.filter((tree) => typeof tree.path === "string" && tree.path);
      const active2 = workspaceTreeFor(all, target.cwd);
      const next = all.filter((tree) => tree !== active2);
      setTrees(all);
      setChoice(next.find((tree) => tree.isMain)?.path || next[0]?.path || "new");
    }, () => {
      if (live) setError(words3.listFailed);
    });
    void localEnvironment?.actions(target.cwd).then((result) => {
      if (live) setSetupAvailable(result.some((action) => action.id === "setup"));
    }, () => {
    });
    return () => {
      live = false;
    };
  }, [target, localEnvironment, words3.listFailed]);
  async function move(event) {
    event.preventDefault();
    if (running.current || !choice || choice === "new" && !branch.trim()) return;
    if (!ownsChat(target)) {
      setError(words3.unavailable);
      return;
    }
    if (host9.state.busy.get()) {
      setError(words3.busy);
      return;
    }
    running.current = true;
    setPending(true);
    setError("");
    try {
      let cwd = choice;
      if (choice === "new") {
        const name = branch.trim();
        if (created.current?.name !== name) {
          const options = { name, branch: name, ...target.branch && { base: target.branch } };
          const tree = target.nativeGit ? await window.hermesDesktop.git.worktreeAdd(target.cwd, options) : await gitApi(target.owner, target.cwd, "worktree/add", options);
          if (!tree?.path) throw new Error(words3.failed);
          created.current = { name, path: tree.path };
        }
        cwd = created.current.path;
      }
      if (!ownsChat(target) || host9.state.busy.get()) throw new Error(words3.unavailable);
      const result = await host9.requestProfile({ ...target.owner, targetProfile: target.owner.profile }, "session.cwd.set", {
        session_id: target.runtime,
        cwd
      }, 1e4);
      if (!result?.cwd) throw new Error(words3.failed);
      refresh();
      host9.notify({ kind: "success", title: words3.moved, message: result.cwd });
      close2();
      if (choice === "new" && setupAvailable && runSetup) {
        void localEnvironment.run({ cwd: result.cwd, id: "setup" }).catch((error2) => host9.notifyError(error2, words3.setupFailed));
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : words3.failed);
    } finally {
      running.current = false;
      setPending(false);
    }
  }
  return h10(
    Dialog,
    { open: true, onOpenChange: (value) => {
      if (!value && !running.current) close2();
    } },
    h10(
      DialogContent,
      {
        "data-hcv-workspace-move": "",
        showCloseButton: !pending,
        blurBackdrop: false,
        onCloseAutoFocus: (event) => {
          if (!target.trigger?.isConnected) return;
          event.preventDefault();
          target.trigger.focus({ preventScroll: true });
        }
      },
      h10(
        "form",
        { onSubmit: move, className: "hcv-workspace-move-form" },
        h10(
          DialogHeader,
          null,
          h10(DialogTitle, null, isMain ? words3.toTree : words3.toMain),
          h10(DialogDescription, null, words3.detail)
        ),
        trees ? h10("label", null, words3.select, h10(
          "select",
          {
            value: choice,
            disabled: pending,
            onChange: (event) => setChoice(event.target.value)
          },
          ...trees.filter((tree) => tree !== currentTree).map((tree) => h10("option", { key: tree.path, value: tree.path }, tree.isMain ? words3.main : tree.branch || tree.path)),
          h10("option", { value: "new" }, words3.newTree)
        )) : h10("p", { role: "status" }, error ? "" : words3.loading),
        choice === "new" && h10("label", null, words3.branch, h10(Input, {
          value: branch,
          disabled: pending,
          placeholder: "worktree",
          onChange: (event) => setBranch(event.target.value)
        })),
        choice === "new" && setupAvailable && h10(
          "label",
          { className: "hcv-move-setup" },
          h10("input", {
            type: "checkbox",
            checked: runSetup,
            disabled: pending,
            onChange: (event) => setRunSetup(event.target.checked)
          }),
          words3.setup
        ),
        (error || busy) && h10("p", { role: "status" }, error || words3.busy),
        h10(
          DialogFooter,
          null,
          h10(Button, { type: "button", variant: "outline", onClick: close2, disabled: pending }, words3.cancel),
          h10(Button, { type: "submit", disabled: !trees || pending || busy || choice === "new" && !branch.trim() }, words3.move)
        )
      )
    )
  );
}
function MoveSlot({ model, close: close2, localEnvironment }) {
  const entry = useValue3(model);
  return entry && h10(MoveWorkspaceDialog, {
    key: entry.key,
    target: entry.target,
    close: close2,
    refresh: entry.refresh,
    localEnvironment
  });
}
function registerWorkspaceActions(ctx, active2, localEnvironment) {
  const model = atom3(null);
  let key = 0;
  const close2 = () => model.set(null);
  const style = document.createElement("style");
  style.textContent = [
    "@media (forced-colors: none) {",
    active2 + " [data-hcv-workspace-move] { max-inline-size: 420px; border-radius: 16px; background: var(--hcv-menu); color: var(--hcv-text); font-family: var(--hcv-ui-font); }",
    active2 + " .hcv-workspace-move-form { display: grid; gap: 16px; }",
    active2 + " .hcv-workspace-move-form label { display: grid; gap: 6px; }",
    active2 + " .hcv-workspace-move-form .hcv-move-setup { display: flex; align-items: center; gap: 8px; }",
    active2 + " .hcv-workspace-move-form select { inline-size: 100%; min-block-size: 36px; padding: 4px 8px; border: 1px solid var(--hcv-hairline); border-radius: 8px; background: var(--hcv-panel); }",
    active2 + ' .hcv-workspace-move-form [role="status"] { overflow-wrap: anywhere; color: var(--hcv-muted); }',
    "}"
  ].join("\n");
  mountStyle(ctx, style, { surface: "[data-hcv-workspace-move]" });
  ctx.register({
    id: "move-workspace",
    area: TITLEBAR_AREAS2.center,
    render: () => h10(MoveSlot, { model, close: close2, localEnvironment })
  });
  const observer = new MutationObserver(() => {
    if (!document.documentElement.matches(active2)) close2();
  });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.onDispose(() => {
    observer.disconnect();
    close2();
    style.remove();
  });
  return {
    openMove(target, refresh) {
      if (target.runtime && target.session && ownsChat(target)) {
        model.set({ key: ++key, target, refresh });
      } else host9.notify({ kind: "error", message: copy2().unavailable });
    }
  };
}

// source/workspace-card.js
var primaryChat = '[data-chat-surface][data-composer-target="main"]';
var connectionsRoute = "/capabilities?tab=connectors";
var minimumWindowWidth = 1120;
var labels7 = {
  ru: {
    card: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0438 \u0438\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438",
    changes: "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F",
    project: "\u041F\u0440\u043E\u0435\u043A\u0442",
    show: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0441\u0432\u043E\u0434\u043A\u0443",
    hide: "\u0421\u043A\u0440\u044B\u0442\u044C \u0441\u0432\u043E\u0434\u043A\u0443",
    pin: "\u0417\u0430\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0441\u0432\u043E\u0434\u043A\u0443",
    unpin: "\u041E\u0442\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u0441\u0432\u043E\u0434\u043A\u0443",
    actions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441\u043E \u0441\u0432\u043E\u0434\u043A\u043E\u0439",
    setup: "\u041D\u0430\u0441\u0442\u0440\u043E\u0438\u0442\u044C \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0435 \u043E\u043A\u0440\u0443\u0436\u0435\u043D\u0438\u0435",
    terminal: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B",
    toTree: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u0434\u0435\u0440\u0435\u0432\u043E",
    toMain: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0432 \u043E\u0441\u043D\u043E\u0432\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0447\u0443\u044E \u043A\u043E\u043F\u0438\u044E",
    projectActions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    actionError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435"
  },
  en: {
    card: "Changes and sources",
    changes: "Changes",
    project: "Project",
    show: "Show summary",
    hide: "Hide summary",
    pin: "Pin summary",
    unpin: "Unpin summary",
    actions: "Summary actions",
    setup: "Set up local environment",
    terminal: "Open terminal",
    toTree: "Move to worktree",
    toMain: "Move to main checkout",
    projectActions: "Project actions",
    actionError: "Could not run the action"
  }
};
function icon5(name) {
  const glyph3 = name === "panel" ? "summaryToggle" : name === "all" ? "summarySources" : name;
  const style = codexIconStyle(glyph3);
  return h11("span", { "aria-hidden": true, "data-hcv-icon": glyph3, style });
}
function currentChat() {
  return [...document.querySelectorAll(primaryChat)].find(
    (node3) => !node3.closest("[hidden], [inert], [data-pane-hidden]") && node3.getClientRects().length > 0 && getComputedStyle(node3).visibility === "visible"
  );
}
function useRoomForCard(eligible) {
  const [room, setRoom] = useState7(false);
  useEffect7(() => {
    if (!eligible) {
      setRoom(false);
      return;
    }
    let chat3 = null;
    let frame = 0;
    const contrast = window.matchMedia("(forced-colors: active)");
    const resize = new ResizeObserver(queue);
    const mutations = new MutationObserver((records) => {
      if (records.some(
        (record) => [...record.addedNodes, ...record.removedNodes].some(
          (node3) => node3 instanceof Element && (node3.matches(primaryChat) || node3.querySelector(primaryChat))
        )
      ))
        queue();
    });
    function measure() {
      frame = 0;
      const visibleChat = currentChat();
      if (visibleChat !== chat3) {
        resize.disconnect();
        chat3 = visibleChat;
        if (chat3) resize.observe(chat3);
      }
      const bounds = chat3?.getBoundingClientRect();
      const offset = parseFloat(document.documentElement.style.getPropertyValue("--hcv-sidebar-right-offset")) || 0;
      setRoom(
        Boolean(
          bounds && !contrast.matches && window.innerWidth >= minimumWindowWidth && window.innerHeight >= 450 && bounds.width >= 750 && Math.abs(window.innerWidth - bounds.right - offset) < 36
        )
      );
    }
    function queue() {
      if (!frame) frame = requestAnimationFrame(measure);
    }
    mutations.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("resize", queue);
    window.addEventListener(toolbarOffsetEvent, queue);
    window.addEventListener("hashchange", queue);
    window.navigation?.addEventListener("currententrychange", queue);
    contrast.addEventListener("change", queue);
    queue();
    return () => {
      if (frame) cancelAnimationFrame(frame);
      resize.disconnect();
      mutations.disconnect();
      window.removeEventListener("resize", queue);
      window.removeEventListener(toolbarOffsetEvent, queue);
      window.removeEventListener("hashchange", queue);
      window.navigation?.removeEventListener("currententrychange", queue);
      contrast.removeEventListener("change", queue);
    };
  }, [eligible]);
  return eligible && room;
}
function useWorkspaceData(draftCwd, enabled) {
  const owner = useValue4(host10.state.focusedSessionOwner);
  const session = useValue4(host10.state.focusedStoredSessionId);
  const activeProfile = useValue4(host10.state.profile);
  const activeConnection = useValue4(host10.state.connectionId);
  const gateway = useValue4(host10.state.gateway);
  const busy = useValue4(host10.state.busy);
  const connectionId = session ? owner?.connectionId : activeConnection;
  const profile2 = session ? owner?.profile : activeProfile;
  const sameScope2 = Boolean(
    profile2 && profile2 === activeProfile && connectionId && connectionId === activeConnection
  );
  const key = JSON.stringify([session, session ? null : draftCwd, connectionId, profile2, activeConnection, activeProfile, gateway]);
  const [snapshot, setSnapshot] = useState7(null);
  const [revision, setRevision] = useState7(0);
  useEffect7(() => {
    if (!enabled || !sameScope2 || gateway !== "open") return;
    let current = true;
    async function read() {
      if (host10.state.connectionId.get() !== connectionId || host10.state.profile.get() !== profile2) return;
      const routes = await host10.profileRoutes().catch(() => []);
      if (!current || host10.state.connectionId.get() !== connectionId || host10.state.profile.get() !== profile2) return;
      const route = routes.find((entry) => entry.connectionId === connectionId && entry.profile === profile2);
      const request = (method, params) => route ? host10.requestProfile(route, method, params, 8e3) : host10.request(method, params, 8e3);
      let cwd = draftCwd;
      let storedBranch = "";
      let root = "";
      if (session) {
        const params = new URLSearchParams({ profile: route?.targetProfile ?? profile2 });
        const row5 = await window.hermesDesktop.api({ connectionId, path: `/api/sessions/${encodeURIComponent(session)}?${params}`, timeoutMs: 8e3 }).catch(() => null);
        cwd = typeof row5?.cwd === "string" ? row5.cwd.trim() : "";
        storedBranch = typeof row5?.git_branch === "string" ? row5.git_branch : "";
        root = typeof row5?.git_repo_root === "string" ? row5.git_repo_root : "";
      }
      if (!current) return;
      const scope4 = { connectionId, profile: profile2 };
      const [project2, sources, repository] = await Promise.allSettled([
        cwd ? request("projects.for_cwd", { cwd }) : Promise.resolve(null),
        request("mcp.servers.status", {}),
        readWorkspaceRepository(cwd, scope4)
      ]);
      if (!current) return;
      const status2 = repository.status === "fulfilled" ? repository.value : null;
      const repo = status2?.repo;
      const worktrees = repo && connectionId === "local" ? await readWorkspaceTrees(cwd, scope4, status2.native).catch(() => []) : [];
      if (!current) return;
      const sourceRows = sources.status === "fulfilled" && Array.isArray(sources.value?.servers) ? sources.value.servers.filter((row5) => typeof row5?.name === "string" && row5.name && !row5.disabled) : null;
      const tree = workspaceTreeFor(worktrees, cwd);
      setSnapshot({
        key,
        cwd,
        root: tree?.path || root || cwd,
        project: project2.status === "fulfilled" ? project2.value?.project?.name : null,
        sources: sourceRows,
        repo,
        nativeGit: status2?.native,
        branch: repo?.branch || storedBranch,
        isWorktree: tree?.isMain === false
      });
    }
    void read().catch(() => {
      if (current) setSnapshot({ key, cwd: "", project: null, sources: null });
    });
    return () => {
      current = false;
    };
  }, [key, sameScope2, gateway, connectionId, profile2, session, draftCwd, enabled, revision, busy]);
  return {
    scope: sameScope2 && gateway === "open" ? { connectionId, profile: profile2 } : null,
    snapshot: snapshot?.key === key ? snapshot : null,
    key,
    refresh: () => setRevision((value) => value + 1)
  };
}
function useRelatedRepositories(scope4, primaryRoot, key, rows, shown) {
  const dirs = JSON.stringify([...new Set(rows.filter((row5) => row5.attached && row5.kind === "folder" && /^(?:[a-z]:[/\\]|\/[^/])/i.test(row5.meta || "")).map((row5) => row5.meta))]);
  const [snapshot, setSnapshot] = useState7(null);
  const connection = scope4?.connectionId;
  const profile2 = scope4?.profile;
  useEffect7(() => {
    if (!shown || !primaryRoot || !connection || !profile2 || dirs === "[]") return;
    let current = true;
    const owner = { connectionId: connection, profile: profile2 };
    const read = async (cwd) => {
      const status2 = await readWorkspaceRepository(cwd, owner);
      if (!current || !status2?.repo) return null;
      const trees = await readWorkspaceTrees(cwd, owner, status2.native).catch(() => []);
      const root = workspaceTreeFor(trees, cwd)?.path || cwd;
      return { cwd: root, repo: status2.repo, branch: status2.repo.branch };
    };
    void Promise.allSettled(JSON.parse(dirs).map(read)).then((results) => {
      if (!current) return;
      const known = /* @__PURE__ */ new Set([workspacePathKey(primaryRoot)]);
      const repos = [];
      for (const result of results) {
        if (result.status !== "fulfilled" || !result.value) continue;
        const repoKey = workspacePathKey(result.value.cwd);
        if (known.has(repoKey)) continue;
        known.add(repoKey);
        repos.push(result.value);
      }
      setSnapshot({ key, dirs, repos });
    });
    return () => {
      current = false;
    };
  }, [connection, profile2, primaryRoot, key, dirs, shown]);
  return snapshot?.key === key && snapshot.dirs === dirs ? snapshot.repos : [];
}
function useSourcesView(data, enabled) {
  const rows = useChatSources(currentChat, data.key, enabled);
  return {
    rows,
    connectors: data.snapshot?.sources,
    loading: Boolean(data.scope && !data.snapshot),
    getChat: currentChat,
    onConnectors: (server) => host10.navigate(server ? connectionsRoute + "&server=" + encodeURIComponent(server) : connectionsRoute),
    onOpenSource: (row5) => {
      if (row5.action?.isConnected && currentChat()?.contains(row5.action)) row5.action.click();
    }
  };
}
function useExpandedWorkspace() {
  const cwd = useValue4(host10.state.cwd)?.trim() || "";
  const primary4 = useValue4(host10.state.activeSessionId);
  const focused = useValue4(host10.state.focusedSessionId);
  const enabled = primary4 === focused;
  const data = useWorkspaceData(cwd, enabled);
  return { data, enabled };
}
function ExpandedSources() {
  const { data, enabled } = useExpandedWorkspace();
  return h11(SourcesPane, useSourcesView(enabled ? data : { key: data.key }, enabled));
}
function ExpandedChanges({ selection }) {
  const { data, enabled } = useExpandedWorkspace();
  const choice = useValue4(selection);
  const cwd = choice?.key === data.key ? choice.cwd : data.snapshot?.cwd;
  return h11(ChangesPane, { cwd: enabled ? cwd : "", scope: enabled ? data.scope : null });
}
function DiffStats({ repo }) {
  if (!repo || !repo.added && !repo.removed && !repo.changed) return null;
  return h11(
    "span",
    { className: "hcv-context-diff" },
    repo.added || repo.removed ? h11(
      Fragment2,
      null,
      h11("span", { className: "hcv-context-added" }, "+" + repo.added),
      h11("span", { className: "hcv-context-removed" }, "\u2212" + repo.removed)
    ) : h11("span", null, repo.changed)
  );
}
function WorkspaceCard({
  id: id2,
  close: close2,
  copy: copy7,
  shown,
  pinned,
  onPin,
  roster,
  panes,
  actions,
  localEnvironment,
  data,
  projectActions,
  disclosure: disclosure2,
  selection
}) {
  const { scope: scope4, snapshot, refresh } = data;
  const sources = useSourcesView(data, shown);
  const runtime = useValue4(host10.state.activeSessionId);
  const session = useValue4(host10.state.focusedStoredSessionId);
  const busy = useValue4(host10.state.busy);
  const related = useRelatedRepositories(scope4, snapshot?.root, data.key, sources.rows, shown && !busy);
  const cwd = snapshot?.cwd || "";
  const local = scope4?.connectionId === "local" && Boolean(cwd);
  const target = { cwd, owner: scope4, runtime, session, nativeGit: snapshot?.nativeGit, branch: snapshot?.branch };
  const title = snapshot?.project || cwd.split(/[/\\]/).filter(Boolean).at(-1) || copy7.project;
  const card2 = useRef5(null);
  const trigger = useRef5(null);
  const [menu, setMenu] = useState7(null);
  function toggleMenu(open) {
    if (!open) {
      setMenu(null);
      return;
    }
    const frame = card2.current?.getBoundingClientRect();
    const anchor = trigger.current?.getBoundingClientRect();
    setMenu(frame && anchor ? { side: anchor.left - frame.left + 8, align: frame.top - anchor.top } : { side: 8, align: 0 });
  }
  function changeRow(repo, folder, primary4) {
    const button5 = h11(
      "button",
      {
        type: "button",
        className: "hcv-context-row hcv-context-changes",
        disabled: !folder || !scope4,
        "aria-label": copy7.changes,
        "data-hcv-branch": repo?.branch || void 0,
        onClick: () => {
          if (primary4 && repo?.nativeGit && openWorkspaceReview(currentChat)) return;
          selection.set(primary4 ? null : { key: data.key, cwd: folder });
          panes.open("changes");
        }
      },
      icon5("changes"),
      h11("span", { className: "hcv-context-label" }, copy7.changes),
      h11(
        "span",
        { className: "hcv-context-change-meta" },
        h11(DiffStats, { repo: repo?.repo }),
        repo?.branch && h11("span", { className: "hcv-context-branch-icon" }, icon5("branch"))
      )
    );
    return repo?.branch ? h11(Tip, { label: repo.branch }, button5) : button5;
  }
  const projectMenu2 = h11(
    DropdownMenu4,
    { open: Boolean(menu), onOpenChange: toggleMenu },
    h11(
      DropdownMenuTrigger4,
      { asChild: true },
      h11(
        "button",
        { ref: trigger, type: "button", className: "hcv-context-icon", "aria-label": copy7.actions },
        icon5("more")
      )
    ),
    h11(
      DropdownMenuContent4,
      {
        side: "left",
        align: "start",
        sideOffset: menu?.side ?? 8,
        alignOffset: menu?.align ?? 0,
        "data-hcv-summary-menu": ""
      },
      localEnvironment && h11(DropdownMenuItem4, { disabled: !local, onSelect: () => {
        void localEnvironment.open({ cwd, projectName: title, trigger: trigger.current });
      } }, icon5("plus"), copy7.setup),
      h11(
        DropdownMenuItem4,
        { disabled: !local, onSelect: () => openWorkspaceTerminal(target) },
        icon5("terminal"),
        copy7.terminal
      ),
      ...projectActions.map((entry) => h11(DropdownMenuItem4, {
        key: entry.id,
        onSelect: () => void localEnvironment.run({ cwd, id: entry.id }).catch((error) => host10.notifyError(error, copy7.actionError))
      }, icon5(entry.icon), entry.label)),
      snapshot?.repo && h11(
        Fragment2,
        null,
        h11(DropdownMenuSeparator3),
        h11(DropdownMenuItem4, {
          disabled: !local || !runtime || !session || busy,
          onSelect: () => actions.openMove({ ...target, trigger: trigger.current }, refresh)
        }, snapshot.isWorktree ? copy7.toMain : copy7.toTree)
      ),
      h11(DropdownMenuSeparator3),
      h11(DropdownMenuItem4, { onSelect: onPin }, icon5(pinned ? "unpin" : "pin"), pinned ? copy7.unpin : copy7.pin),
      h11(DropdownMenuItem4, { onSelect: close2 }, icon5("close"), copy7.hide)
    )
  );
  return h11(
    "aside",
    { ref: card2, id: id2, "data-hcv-context-card": "", "data-pinned": pinned, "aria-label": copy7.card, "aria-hidden": !shown, inert: !shown },
    h11(SummarySection, { ...disclosure2("project"), kind: "project", title, action: projectMenu2 }, changeRow(snapshot, cwd, true)),
    related.map((repo) => {
      const key = workspacePathKey(repo.cwd);
      const name = repo.cwd.split(/[/\\]/).filter(Boolean).at(-1);
      return h11(SummarySection, { ...disclosure2(key), key, kind: "project", title: name }, changeRow(repo, repo.cwd, false));
    }),
    ["pullRequests", "outputs"].map((kind) => h11(CompactSummaryItems, {
      key: kind,
      kind,
      onOpenSource: sources.onOpenSource,
      rows: sources.rows.filter((row5) => row5.section === kind),
      disclosure: disclosure2(kind)
    })),
    h11(SummarySubagents, { roster, disclosure: disclosure2("agents"), onExpand: () => panes.open("agents") }),
    h11(CompactSources, {
      ...sources,
      rows: sources.rows.filter((row5) => !row5.section),
      disclosure: disclosure2("sources"),
      onExpand: () => panes.open("sources")
    })
  );
}
function ProjectActions({ entries, cwd, localEnvironment, copy: copy7 }) {
  const named = entries.filter((entry) => entry.id !== "setup" && entry.id !== "cleanup");
  if (!named.length) return null;
  return h11(
    DropdownMenu4,
    null,
    h11(
      DropdownMenuTrigger4,
      { asChild: true },
      h11(
        "button",
        { type: "button", "data-hcv-project-actions": "", "aria-label": copy7.projectActions },
        icon5(named[0].icon),
        icon5("down")
      )
    ),
    h11(
      DropdownMenuContent4,
      { align: "end", "data-hcv-project-actions-menu": "" },
      ...named.map((entry) => h11(DropdownMenuItem4, {
        key: entry.id,
        onSelect: () => void localEnvironment.run({ cwd, id: entry.id }).catch((error) => host10.notifyError(error, copy7.actionError))
      }, icon5(entry.icon), entry.label))
    )
  );
}
function CardSlot({ storage, roster, panes, actions, localEnvironment, selection }) {
  const { locale } = useI18n5();
  const copy7 = labels7[locale] || labels7.en;
  const workspace = useValue4(host10.paneVisibility("workspace"));
  const files = useValue4(host10.paneVisibility("files"));
  const review = useValue4(host10.paneVisibility("review"));
  const focused = useValue4(host10.state.focusedSessionId);
  const primary4 = useValue4(host10.state.activeSessionId);
  const draftCwd = useValue4(host10.state.cwd)?.trim() || "";
  const data = useWorkspaceData(draftCwd, workspace && focused === primary4);
  const cwd = workspace && focused === primary4 && data.scope?.connectionId === "local" ? data.snapshot?.cwd : "";
  const actionRevision = useValue4(localEnvironment.revision);
  const [savedActions, setSavedActions] = useState7(null);
  const projectActions = savedActions && savedActions.cwd === cwd ? savedActions.entries : [];
  const agents = useValue4(panes.visibility.agents);
  const sources = useValue4(panes.visibility.sources);
  const changes2 = useValue4(panes.visibility.changes);
  const roomy = useRoomForCard(workspace && !files && !review && !agents && !sources && !changes2 && focused === primary4);
  const [pinned, setPinned] = useState7(() => storage.get("summary-pinned", true) !== false);
  const [open, setOpen] = useState7(() => storage.get("summary-pinned", true) !== false);
  const [closed, setClosed] = useState7(null);
  const toggleRef = useRef5(null);
  const cardId = useId3();
  useEffect7(() => {
    if (!cwd) return;
    let live = true;
    void localEnvironment.actions(cwd).then((entries) => {
      if (live) setSavedActions({ cwd, entries });
    }, () => {
    });
    return () => {
      live = false;
    };
  }, [cwd, localEnvironment, actionRevision]);
  useEffect7(() => {
    if (!roomy || !open || pinned) return;
    function onOutside(event) {
      if (event.target instanceof Element && !event.target.closest(
        '[data-hcv-context-card], [data-hcv-context-toggle], [data-hcv-summary-menu], [data-hcv-sources-add-menu], [data-hcv-project-actions], [data-hcv-project-actions-menu], [data-slot="dialog-overlay"]'
      )) setOpen(false);
    }
    function onEscape(event) {
      if (event.key === "Escape" && !event.defaultPrevented && !document.querySelector('[role="menu"][data-state="open"], [role="dialog"][data-state="open"], [popover]:popover-open')) {
        setOpen(false);
        toggleRef.current?.focus({ preventScroll: true });
      }
    }
    document.addEventListener("pointerdown", onOutside, true);
    document.addEventListener("keydown", onEscape, true);
    return () => {
      document.removeEventListener("pointerdown", onOutside, true);
      document.removeEventListener("keydown", onEscape, true);
    };
  }, [roomy, open, pinned]);
  const projectToolbar = h11(ProjectActions, { entries: projectActions, cwd, localEnvironment, copy: copy7 });
  if (!roomy) return projectToolbar;
  function togglePin() {
    storage.set("summary-pinned", !pinned);
    setPinned(!pinned);
  }
  function closeFromMenu() {
    setOpen(false);
    requestAnimationFrame(() => toggleRef.current?.focus({ preventScroll: true }));
  }
  function disclosure2(section2) {
    return {
      expanded: closed?.key !== data.key || !closed.sections.has(section2),
      onToggle: () => setClosed((previous) => {
        const sections = new Set(previous?.key === data.key ? previous.sections : []);
        if (sections.has(section2)) sections.delete(section2);
        else sections.add(section2);
        return { key: data.key, sections };
      })
    };
  }
  return h11(
    Fragment2,
    null,
    projectToolbar,
    h11(Tip, { label: open ? copy7.hide : copy7.show }, h11(
      "button",
      {
        ref: toggleRef,
        type: "button",
        "data-hcv-context-toggle": "",
        "aria-expanded": open,
        "aria-controls": cardId,
        "aria-label": open ? copy7.hide : copy7.show,
        onClick: () => setOpen((visible) => !visible)
      },
      icon5("panel")
    )),
    h11(WorkspaceCard, {
      id: cardId,
      copy: copy7,
      close: closeFromMenu,
      shown: open,
      pinned,
      onPin: togglePin,
      roster,
      panes,
      actions,
      localEnvironment,
      data,
      projectActions,
      disclosure: disclosure2,
      selection
    })
  );
}
function ThemeCardSlot({ themeName: themeName2, panes, ...props }) {
  const theme2 = useTheme2();
  return theme2.themeName === themeName2 ? h11(Fragment2, null, h11(CardSlot, { ...props, panes }), panes.renderPicker()) : null;
}
function registerWorkspaceCard(ctx, themeName2, roster, localEnvironment) {
  if (typeof host10.paneVisibility !== "function" || !host10.state.focusedSessionOwner) return;
  const scope4 = `:root[data-hermes-codex-visual][data-hermes-theme="${CSS.escape(themeName2)}"]`;
  const actions = registerWorkspaceActions(ctx, scope4, localEnvironment);
  const selection = atom4(null);
  const panes = registerSummaryPanes(ctx, scope4, {
    agents: () => h11(SubagentsPane, { roster }),
    sources: () => h11(ExpandedSources),
    changes: () => h11(ExpandedChanges, { selection })
  });
  registerSummarySources(ctx, scope4);
  registerSummaryChanges(ctx, scope4);
  const surfaces = `${scope4} [data-hcv-context-card]`;
  const chat3 = `${scope4} ${primaryChat}`;
  const bounds = `${chat3} > [data-slot="composer-bounds"]`;
  const dock2 = `${chat3} [data-slot="composer-dock"]:not([data-popped-out])`;
  const fallback = `${chat3} [data-slot="composer-root"]:has(> .composer-fallback-surface)`;
  const style = document.createElement("style");
  style.dataset.hcvWorkspaceCard = "";
  style.textContent = `
@property --hcv-summary-progress {
  syntax: "<number>";
  inherits: true;
  initial-value: 0;
}
${scope4} {
  /* A 300px card in Codex at 90% covers the same screen width at the owner's Hermes zoom. */
  --hcv-summary-width: 280px;
  --hcv-summary-layout-inset: calc((var(--hcv-summary-width) + 12px) * var(--hcv-summary-progress));
}
${scope4}:has([data-hcv-context-card][aria-hidden="false"]) { --hcv-summary-progress: 1; }
@media (forced-colors: none) {
  ${chat3} {
    --hcv-summary-composer-width: min(var(--composer-width), 100% - var(--hcv-summary-layout-inset) - 2rem);
  }
  /* Codex shifts the transcript inside the full-width scroll container. */
  ${bounds} [data-slot="aui_thread-viewport"] { padding-right: var(--hcv-summary-layout-inset); }
  ${bounds} > .thread-jump-button { left: calc(50% - var(--hcv-summary-layout-inset) / 2); }
  ${bounds} [data-slot="thread-timeline"] { margin-right: max(10px, var(--hcv-summary-layout-inset)); }
  ${dock2}, ${fallback} { left: calc(50% - var(--hcv-summary-layout-inset) / 2); }
  ${dock2} { width: calc(var(--hcv-summary-composer-width) + 10px); }
  ${fallback} { width: var(--hcv-summary-composer-width); }
}
${scope4} [data-hcv-context-card] {
  position: fixed;
  inset-block-start: var(--hcv-context-card-top, 93px);
  right: calc(8px + var(--hcv-sidebar-right-offset, 0px));
  inline-size: var(--hcv-summary-width);
  max-block-size: calc(100dvh - var(--hcv-context-card-top, 93px) - 8px);
  overflow: auto;
  box-sizing: border-box;
  padding: 12px 18px;
  border: 1px solid color-mix(in srgb, var(--hcv-text) 8%, transparent);
  border-radius: 16px;
  color: var(--hcv-text);
  background: var(--hcv-menu);
  --hcv-summary-row-hover: light-dark(rgb(26 28 31 / 5%), rgb(255 255 255 / 6%));
  text-align: start;
  font: 13px/20px var(--hcv-ui-font);
  font-weight: 400;
  opacity: var(--hcv-summary-progress);
  transform: translateX(calc(100% * (1 - var(--hcv-summary-progress))));
  pointer-events: auto;
  -webkit-app-region: no-drag;
}
${scope4} [data-hcv-context-card][aria-hidden="true"] {
  visibility: hidden;
  pointer-events: none;
}
/* The card sits in the titlebar layer. Its portaled menu must clear that
   layer and still sit below a modal backdrop. Radix copies the menu z-index. */
${scope4} [data-hcv-summary-menu] {
  z-index: calc(var(--z-modal-backdrop, 120) - 1);
  min-inline-size: min(260px, calc(100vw - 16px));
  padding: 4px;
  border-radius: 16px;
  background: var(--hcv-menu);
}
${scope4} [data-hcv-summary-menu] [role="menuitem"] { min-block-size: 28px; border-radius: 8px; }
${surfaces} button.hcv-context-row,
${scope4} [data-hcv-context-card] .hcv-context-icon,
${scope4} [data-hcv-context-toggle] {
  appearance: none;
  margin: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
${scope4} [data-hcv-context-card] button:disabled { opacity: .5; cursor: default; }
${surfaces} button:focus-visible,
${scope4} [data-hcv-context-toggle]:focus-visible { outline: 1px solid var(--hcv-focus); outline-offset: 1px; }
${surfaces} .hcv-context-label {
  min-inline-size: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
${surfaces} .hcv-context-row {
  display: flex;
  align-items: center;
  inline-size: 100%;
  min-block-size: 28px;
  padding: 4px 0;
  gap: 12px;
  text-align: start;
}
${scope4} :is([data-hcv-context-card], [data-hcv-context-toggle], [data-hcv-summary-menu], [data-hcv-project-actions], [data-hcv-project-actions-menu]) [data-hcv-icon] {
  display: inline-block;
  inline-size: 16px;
  block-size: 16px;
  flex: 0 0 auto;
}
${summarySectionStyles(surfaces)}
${surfaces} .hcv-context-changes { position: relative; isolation: isolate; }
${surfaces} .hcv-context-changes:is(:hover, :focus-visible)::before {
  content: ''; position: absolute; inset: 0 -8px; z-index: -1;
  border-radius: 8px; background: var(--hcv-summary-row-hover);
}
${surfaces} .hcv-context-change-meta { display: grid; align-items: center; margin-inline-start: auto; color: var(--hcv-muted); }
${surfaces} .hcv-context-change-meta > * { grid-area: 1/1; justify-self: end; }
${surfaces} .hcv-context-diff { display: flex; gap: 4px; font-variant-numeric: tabular-nums; }
${surfaces} .hcv-context-added { color: light-dark(#008241, #36c676); }
${surfaces} .hcv-context-removed { color: light-dark(#aa2626, #ff5656); }
${surfaces} .hcv-context-branch-icon { display: flex; }
${surfaces} .hcv-context-diff + .hcv-context-branch-icon { opacity: 0; }
${surfaces} .hcv-context-changes:is(:hover, :focus-visible) .hcv-context-diff:has(+ .hcv-context-branch-icon) { opacity: 0; }
${surfaces} .hcv-context-changes:is(:hover, :focus-visible) .hcv-context-branch-icon { opacity: 1; }
${scope4} [data-hcv-context-card] .hcv-context-icon,
${scope4} [data-hcv-context-toggle] {
  display: inline-grid;
  place-items: center;
  inline-size: 24px;
  block-size: 24px;
  padding: 0;
  color: var(--hcv-muted);
  flex: 0 0 auto;
}
${scope4} [data-hcv-context-toggle][aria-expanded="true"] {
  color: var(--hcv-text);
  background: var(--hcv-selected);
}
${scope4} [data-hcv-project-actions] {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding-inline: 6px;
  border-radius: 8px;
  color: var(--hcv-muted);
}
${scope4} [data-hcv-project-actions] [data-hcv-icon="down"] { inline-size: 10px; block-size: 10px; }
${scope4} [data-hcv-project-actions]:is(:hover, [data-state="open"]) {
  color: var(--hcv-text);
  background: var(--hcv-hover);
}
${scope4} [data-hcv-project-actions-menu] { z-index: calc(var(--z-modal-backdrop, 120) - 1); }
@media (hover: hover) and (pointer: fine) {
  ${surfaces} button.hcv-context-row:hover:not(:disabled) { color: var(--hcv-text); }
  ${surfaces} button.hcv-context-icon:hover:not(:disabled),
  ${scope4} [data-hcv-context-toggle]:hover { background: var(--hcv-hover); color: var(--hcv-text); }
}
@media (prefers-reduced-motion: no-preference) {
  /* The Codex panel travel and the chat inset share one interpolated value. */
  ${scope4} { transition: --hcv-summary-progress ${codexReference.summaryTime} var(--hcv-enter); }
  ${scope4} [data-hcv-context-card] { transition: visibility 0s; }
  ${scope4} [data-hcv-context-card][aria-hidden="true"] { transition-delay: ${codexReference.summaryTime}; }
}
`;
  mountStyle(ctx, style, { surface: "[data-hcv-context-card], [data-hcv-context-toggle], [data-hcv-project-actions]", retainAcrossChatTabs: true });
  ctx.register({
    id: "workspace-card",
    area: TITLEBAR_AREAS3.right,
    render: () => h11(ThemeCardSlot, { themeName: themeName2, storage: ctx.storage, roster, panes, actions, localEnvironment, selection })
  });
}

// source/local-environment.js
import { createElement as h12, useRef as useRef6, useState as useState8 } from "react";
import {
  atom as atom5,
  Button as Button2,
  Dialog as Dialog2,
  DialogContent as DialogContent2,
  DialogDescription as DialogDescription2,
  DialogFooter as DialogFooter2,
  DialogHeader as DialogHeader2,
  DialogTitle as DialogTitle2,
  host as host11,
  Popover,
  PopoverContent,
  PopoverTrigger,
  TITLEBAR_AREAS as TITLEBAR_AREAS4,
  useValue as useValue5
} from "@hermes/plugin-sdk";

// source/local-environment-run.js
var sourceTreeVariable = "CODEX_SOURCE_TREE_PATH";
var worktreeVariable = "CODEX_WORKTREE_PATH";
function desktopPlatform() {
  const value = navigator.userAgentData?.platform || navigator.platform;
  if (/^win/i.test(value)) return "win32";
  if (/^mac/i.test(value)) return "darwin";
  if (/^linux/i.test(value)) return "linux";
  return null;
}
function localPathKey(value, platform) {
  if (typeof value !== "string" || /[\x00-\x1f]/.test(value)) return "";
  const path = value.trim();
  if (platform === "win32") {
    const normalized2 = path.replaceAll("\\", "/").toLowerCase();
    if (!/^(?:[a-z]:\/|\/\/[^/.?][^/]*\/[^/]+(?:\/|$))/.test(normalized2)) return "";
    return normalized2.replace(/\/+$/, "");
  }
  return path.startsWith("/") ? path.replace(/\/+$/, "") || "/" : "";
}
async function checkedLocalPath(desktop, value, platform) {
  const key = localPathKey(value, platform);
  if (!key || !desktop?.sanitizeWorkspaceCwd) return null;
  const checked = await desktop.sanitizeWorkspaceCwd(value);
  return !checked?.sanitized && localPathKey(checked?.cwd, platform) === key ? checked.cwd : null;
}
var psLiteral = (value) => `'${value.replaceAll("'", "''")}'`;
var shLiteral = (value) => `'${value.replaceAll("'", "'\\''")}'`;
function powershellPayload(value) {
  let bytes = "";
  for (let index = 0; index < value.length; index++) {
    const unit = value.charCodeAt(index);
    bytes += String.fromCharCode(unit & 255, unit >> 8);
  }
  return btoa(bytes);
}
function terminalCommand({ shell, platform, cwd, source, script, marker: marker4 }) {
  if (platform === "win32" && /^(?:pwsh|powershell|cmd)(?:\.exe)?$/i.test(shell)) {
    const payload = powershellPayload([
      "$ErrorActionPreference = 'Stop'",
      `Set-Location -LiteralPath ${psLiteral(cwd)}`,
      `$env:${sourceTreeVariable} = ${psLiteral(source)}`,
      `$env:${worktreeVariable} = ${psLiteral(cwd)}`,
      `[Console]::WriteLine(${psLiteral(marker4)})`,
      "$global:LASTEXITCODE = 0",
      script,
      "if (-not $?) { exit 1 }",
      "exit $LASTEXITCODE"
    ].join("\n"));
    const args = `-NoLogo -NoProfile -NonInteractive -EncodedCommand ${payload}`;
    if (/^cmd/i.test(shell)) return `"%SystemRoot%\\System32\\WindowsPowerShell\\v1.0\\powershell.exe" ${args} && exit /b 0 || exit /b 1\r`;
    const executable = /^pwsh/i.test(shell) ? "pwsh.exe" : "powershell.exe";
    return `& (Join-Path $PSHOME '${executable}') ${args}; exit $LASTEXITCODE\r`;
  }
  if (platform === "darwin" || platform === "linux") {
    if (!/^(?:bash|zsh|sh|dash|ksh|fish)$/i.test(shell)) return null;
    const program = [
      `cd ${shLiteral(cwd)} || exit 1`,
      `export ${sourceTreeVariable}=${shLiteral(source)} ${worktreeVariable}=${shLiteral(cwd)}`,
      `printf '%s\\n' ${shLiteral(marker4)}`,
      script
    ].join("\n");
    const bytes = new TextEncoder().encode(program);
    const escaped = Array.from(bytes, (byte) => `\\0${byte.toString(8).padStart(3, "0")}`).join("");
    const exit = /^fish$/i.test(shell) ? "exit $status" : "exit $?";
    return `printf '%b' '${escaped}' | /bin/sh; ${exit}\r`;
  }
  return null;
}
var cleanOutput = (value) => value.replace(/\x1b\][^\x07]*(?:\x07|\x1b\\)/g, "").replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, "").replace(/[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]/g, "").replace(/\r\n?/g, "\n");
function runLocalScript({ desktop, platform, cwd, source, script, stillLocal, update }) {
  const marker4 = `HCV_PROJECT_${crypto.randomUUID().replaceAll("-", "")}`;
  const terminal2 = desktop?.terminal;
  let id2, offData, offExit;
  let stopped = false;
  let begun = false;
  let pending = "";
  let output = "";
  const release = () => {
    offData?.();
    offExit?.();
    if (id2) void terminal2.dispose(id2).catch(() => {
    });
    id2 = null;
  };
  const finish = (state, error) => {
    if (stopped) return;
    stopped = true;
    release();
    update({ state, error, output });
  };
  const start = async () => {
    try {
      if (!terminal2 || !stillLocal()) return finish("failed", "path");
      const checked = await checkedLocalPath(desktop, cwd, platform);
      if (stopped) return;
      if (!checked || !stillLocal()) return finish("failed", "path");
      const session = await terminal2.start({ cwd: checked });
      id2 = session.id;
      if (stopped) return release();
      if (!stillLocal() || localPathKey(session.cwd, platform) !== localPathKey(checked, platform)) {
        return finish("failed", "path");
      }
      const command2 = terminalCommand({ shell: session.shell, platform, cwd: checked, source, script, marker: marker4 });
      if (!command2) return finish("failed", "shell");
      if (command2.length > (/^cmd/i.test(session.shell) ? 7500 : 24e3)) return finish("failed", "tooLong");
      offData = terminal2.onData(id2, (value) => {
        if (stopped || typeof value !== "string") return;
        if (!begun) {
          pending += value;
          const at = pending.indexOf(marker4);
          if (at === -1) {
            pending = pending.slice(-marker4.length);
            return;
          }
          begun = true;
          value = pending.slice(at + marker4.length).replace(/^\r?\n/, "");
          pending = "";
        }
        output = (output + cleanOutput(value)).slice(-18e3);
        update({ state: "running", output });
      });
      offExit = terminal2.onExit(id2, (result) => {
        if (!begun) return finish("failed", "start");
        finish(result?.code === 0 ? "done" : "failed", result?.code === 0 ? void 0 : "exit");
      });
      if (!await terminal2.attach(id2) || stopped || !stillLocal()) return finish("failed", "start");
      if (!await terminal2.write(id2, command2)) finish("failed", "start");
    } catch {
      finish("failed", "start");
    }
  };
  void start();
  return () => finish("stopped");
}

// source/local-environment.js
var platforms = ["default", "darwin", "linux", "win32"];
var platformNames = { darwin: "macOS", linux: "Linux", win32: "Windows" };
var icons = { tool: "tools", run: "play", debug: "terminal", test: "check" };
var buttonTypes = Object.keys(icons);
var copy3 = {
  ru: {
    title: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 \u044D\u0442\u043E\u0433\u043E \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    subtitle: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u0435 \u0441\u043A\u0440\u0438\u043F\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0441\u0435\u0439\u0447\u0430\u0441 \u0438 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 \u0435\u0433\u043E \u043F\u043E\u0432\u0442\u043E\u0440\u043D\u043E \u0434\u043B\u044F \u0431\u0443\u0434\u0443\u0449\u0438\u0445 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u0435\u0440\u0435\u0432\u044C\u0435\u0432",
    advanced: "\u0420\u0430\u0441\u0448\u0438\u0440\u0435\u043D\u043D\u044B\u0435 \u043F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B",
    setup: "\u0421\u043A\u0440\u0438\u043F\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
    cleanup: "\u0421\u043A\u0440\u0438\u043F\u0442 \u043E\u0447\u0438\u0441\u0442\u043A\u0438",
    setupHint: "\u0417\u0430\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F \u0432 \u043A\u043E\u0440\u043D\u0435 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u043F\u0440\u0438 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u0434\u0435\u0440\u0435\u0432\u0430.",
    cleanupHint: "\u041C\u043E\u0436\u043D\u043E \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0432 \u043A\u043E\u0440\u043D\u0435 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u043F\u0435\u0440\u0435\u0434 \u043E\u0447\u0438\u0441\u0442\u043A\u043E\u0439 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u0434\u0435\u0440\u0435\u0432\u0430.",
    name: "\u0418\u043C\u044F",
    default: "\u041F\u043E \u0443\u043C\u043E\u043B\u0447\u0430\u043D\u0438\u044E",
    platform: "\u041F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u0430",
    allPlatforms: "\u0412\u0441\u0435 \u043F\u043B\u0430\u0442\u0444\u043E\u0440\u043C\u044B",
    variables: "\u041F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435",
    variablesTitle: "\u041F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435 \u0441\u0440\u0435\u0434\u044B \u0441\u043A\u0440\u0438\u043F\u0442\u0430 \u0443\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0438",
    sourcePath: "\u041F\u0443\u0442\u044C \u043A \u0438\u0441\u0445\u043E\u0434\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0447\u0435\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438",
    worktreePath: "\u041F\u0443\u0442\u044C \u043A \u043D\u043E\u0432\u043E\u043C\u0443 \u0440\u0430\u0431\u043E\u0447\u0435\u043C\u0443 \u0434\u0435\u0440\u0435\u0432\u0443",
    copied: "\u041F\u0435\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u0430",
    actions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F",
    add: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
    remove: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435",
    command: "\u0421\u0446\u0435\u043D\u0430\u0440\u0438\u0439 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439",
    icon: "\u0417\u043D\u0430\u0447\u043E\u043A",
    actionHint: "\u042D\u0442\u0438 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u043C\u043E\u0433\u0443\u0442 \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u0442\u044C \u043B\u044E\u0431\u044B\u0435 \u043A\u043E\u043C\u0430\u043D\u0434\u044B \u0438 \u0431\u0443\u0434\u0443\u0442 \u043E\u0442\u043E\u0431\u0440\u0430\u0436\u0430\u0442\u044C\u0441\u044F \u0432 \u0437\u0430\u0433\u043E\u043B\u043E\u0432\u043A\u0435",
    empty: "\u0414\u043E\u0431\u0430\u0432\u044C\u0442\u0435 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0435, \u0447\u0442\u043E\u0431\u044B \u0437\u0430\u043F\u0443\u0441\u043A\u0430\u0442\u044C \u043A\u043E\u043C\u0430\u043D\u0434\u044B \u0441 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u043F\u0430\u043D\u0435\u043B\u0438 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u043E\u0432",
    tool: "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442",
    run: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C",
    debug: "\u041E\u0442\u043B\u0430\u0434\u0438\u0442\u044C",
    test: "\u0422\u0435\u0441\u0442",
    setupProject: "\u041D\u0430\u0441\u0442\u0440\u043E\u0438\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442",
    save: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
    saved: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u0440\u043E\u0435\u043A\u0442\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B",
    compactPlaceholder: "\u041D\u0430\u043F\u0440\u0438\u043C\u0435\u0440: npm install",
    discardTitle: "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0441\u0440\u0435\u0434\u044B?",
    discardHint: "\u0412\u0430\u0448\u0438 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F \u0432 \u044D\u0442\u043E\u0439 \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u043E\u0439 \u0441\u0440\u0435\u0434\u0435 \u0431\u0443\u0434\u0443\u0442 \u043F\u043E\u0442\u0435\u0440\u044F\u043D\u044B",
    discard: "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C",
    keep: "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435",
    conflict: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u0438\u0441\u044C \u0432 \u0434\u0440\u0443\u0433\u043E\u043C \u043E\u043A\u043D\u0435. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u0444\u043E\u0440\u043C\u0443 \u0437\u0430\u043D\u043E\u0432\u043E.",
    saveError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    actionError: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    runSetup: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
    runCleanup: "\u0417\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442 \u043E\u0447\u0438\u0441\u0442\u043A\u0438",
    starting: "\u0417\u0430\u043F\u0443\u0441\u043A\u0430\u0435\u0442\u0441\u044F\u2026",
    running: "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F\u2026",
    done: "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E",
    failed: "\u041E\u0448\u0438\u0431\u043A\u0430 \u0437\u0430\u043F\u0443\u0441\u043A\u0430",
    stopped: "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E",
    stop: "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C",
    close: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C",
    noOutput: "\u0412\u044B\u0432\u043E\u0434 \u043F\u043E\u044F\u0432\u0438\u0442\u0441\u044F \u0437\u0434\u0435\u0441\u044C",
    path: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u0442\u044C \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443\u044E \u043F\u0430\u043F\u043A\u0443 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    shell: "\u0422\u0435\u0440\u043C\u0438\u043D\u0430\u043B \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u043E\u0431\u043E\u043B\u043E\u0447\u043A\u0443, \u043A\u043E\u0442\u043E\u0440\u0430\u044F \u043D\u0435 \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0434\u043B\u044F \u044D\u0442\u043E\u0433\u043E \u0441\u043A\u0440\u0438\u043F\u0442\u0430",
    start: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u0441\u043A\u0440\u0438\u043F\u0442 \u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0435 Hermes",
    exit: "\u041A\u043E\u043C\u0430\u043D\u0434\u0430 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0430\u0441\u044C \u0441 \u043E\u0448\u0438\u0431\u043A\u043E\u0439",
    tooLong: "\u0421\u043A\u0440\u0438\u043F\u0442 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0434\u043B\u0438\u043D\u043D\u044B\u0439 \u0434\u043B\u044F \u0437\u0430\u043F\u0443\u0441\u043A\u0430 \u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0435"
  },
  en: {
    title: "Set up this project",
    subtitle: "Run a setup script now and reuse it for future worktrees",
    advanced: "Advanced options",
    setup: "Setup script",
    cleanup: "Cleanup script",
    setupHint: "Runs at the project root when setting up a worktree.",
    cleanupHint: "Can run at the project root before worktree cleanup.",
    name: "Name",
    default: "Default",
    platform: "Platform",
    allPlatforms: "All platforms",
    variables: "Variables",
    variablesTitle: "Setup script environment variables",
    sourcePath: "Source workspace path",
    worktreePath: "Worktree path",
    copied: "Variable copied",
    actions: "Actions",
    add: "Add action",
    remove: "Remove action",
    command: "Action script",
    icon: "Icon",
    actionHint: "These actions can run any command and will be displayed in the header",
    empty: "Add an action to run commands from the local toolbar",
    tool: "Tool",
    run: "Run",
    debug: "Debug",
    test: "Test",
    setupProject: "Set up project",
    save: "Save",
    saved: "Project settings saved",
    compactPlaceholder: "For example: npm install",
    discardTitle: "Discard local environment draft?",
    discardHint: "Your changes to this local environment will be lost",
    discard: "Discard",
    keep: "Keep editing",
    conflict: "Settings changed in another window. Reopen the form.",
    saveError: "Could not save the project settings",
    actionError: "This action is unavailable for the project",
    runSetup: "Run setup script",
    runCleanup: "Run cleanup script",
    starting: "Starting\u2026",
    running: "Running\u2026",
    done: "Completed",
    failed: "Could not run",
    stopped: "Stopped",
    stop: "Stop",
    close: "Close",
    noOutput: "Output will appear here",
    path: "Could not verify the local project directory",
    shell: "The terminal shell is unsupported for this script",
    start: "Could not launch the script in the Hermes terminal",
    exit: "The command exited with an error",
    tooLong: "The script is too long for the terminal"
  }
};
var words = () => document.documentElement.matches(":lang(ru)") ? copy3.ru : copy3.en;
var scriptFor = (scripts, platform) => scripts?.[platform]?.trim() ? scripts[platform] : scripts?.default ?? "";
var folderName = (value) => value.split(/[\\/]/).filter(Boolean).at(-1) || value;
var emptyEnvironment = (name) => ({ name, setup: {}, cleanup: {}, actions: [] });
var scriptPlaceholder = {
  setup: 'cd "$CODEX_WORKTREE_PATH"\npip install -r requirements.txt\nnpm install\n./run/setup.sh',
  cleanup: "docker compose down --remove-orphans\nrm -rf .cache/tmp"
};
var windowsPlaceholder = {
  setup: "python -m pip install -r requirements.txt\npnpm install",
  cleanup: "docker compose down --remove-orphans"
};
function icon6(name, className) {
  return h12("span", { "aria-hidden": true, className, "data-hcv-env-icon": "", style: codexIconStyle(name) });
}
function Variables({ t, copyVariable }) {
  return h12(
    Popover,
    null,
    h12(PopoverTrigger, { asChild: true }, h12("button", { type: "button", className: "hcv-env-secondary" }, t.variables)),
    h12(
      PopoverContent,
      { align: "end", sideOffset: 4, "data-hcv-env-vars": "" },
      h12("strong", null, t.variablesTitle),
      [[sourceTreeVariable, t.sourcePath], [worktreeVariable, t.worktreePath]].map(([name, text]) => h12(
        "div",
        { key: name },
        h12("button", {
          type: "button",
          title: name,
          onClick: () => void copyVariable(name)
        }, h12("code", null, name), icon6("copy")),
        h12("span", null, text)
      ))
    )
  );
}
function ScriptEditor({ type, scripts, setScripts, compact, t, copyVariable }) {
  const [platform, setPlatform] = useState8("default");
  const id2 = `hcv-env-${type}`;
  const label3 = t[type];
  const selectWithKeys = (event) => {
    const previous = platforms.indexOf(platform);
    const next = { ArrowLeft: previous + platforms.length - 1, ArrowRight: previous + 1, Home: 0, End: platforms.length - 1 }[event.key];
    if (next === void 0) return;
    event.preventDefault();
    const index = next % platforms.length;
    setPlatform(platforms[index]);
    event.currentTarget.children[index]?.focus();
  };
  const value = scripts[platform] || "";
  const placeholder = compact ? t.compactPlaceholder : (platform === "win32" ? windowsPlaceholder : scriptPlaceholder)[type];
  const field = h12("textarea", {
    id: id2,
    value,
    placeholder,
    spellCheck: false,
    rows: 6,
    maxLength: 6e3,
    onChange: (event) => setScripts({ ...scripts, [platform]: event.target.value })
  });
  return h12(
    "section",
    { className: "hcv-env-script" },
    h12(
      "div",
      { className: "hcv-env-section-title" },
      h12(
        "div",
        null,
        h12("label", { htmlFor: id2 }, label3),
        !compact && h12("p", null, type === "setup" ? t.setupHint : t.cleanupHint)
      ),
      !compact && type === "setup" && h12(Variables, { t, copyVariable })
    ),
    compact ? field : h12(
      "div",
      null,
      h12(
        "div",
        { role: "tablist", "aria-label": `${label3} \xB7 ${t.platform}`, onKeyDown: selectWithKeys, className: "hcv-env-platforms" },
        platforms.map((value2) => h12("button", {
          key: value2,
          id: `${id2}-tab-${value2}`,
          type: "button",
          role: "tab",
          "aria-selected": value2 === platform,
          "aria-controls": `${id2}-platform`,
          tabIndex: value2 === platform ? 0 : -1,
          onClick: () => setPlatform(value2)
        }, platformNames[value2] || t.default))
      ),
      h12("div", { role: "tabpanel", id: `${id2}-platform`, "aria-labelledby": `${id2}-tab-${platform}` }, field)
    )
  );
}
function Actions({ actions, onChange, t }) {
  const update = (id2, patch) => onChange(actions.map((action) => action.id === id2 ? { ...action, ...patch } : action));
  return h12(
    "section",
    { className: "hcv-env-actions" },
    h12(
      "div",
      { className: "hcv-env-section-title" },
      h12("h3", null, t.actions),
      h12("button", {
        type: "button",
        className: "hcv-env-secondary",
        onClick: () => onChange([...actions, { id: crypto.randomUUID(), name: "", command: "", platform: "default", icon: "tool" }])
      }, t.add)
    ),
    h12("p", null, t.actionHint),
    actions.length === 0 ? h12("div", { className: "hcv-env-empty" }, t.empty) : actions.map((action) => h12(
      "div",
      { key: action.id, className: "hcv-env-card hcv-env-action", "data-hcv-env-action": "" },
      h12(
        "div",
        { className: "hcv-env-action-heading" },
        h12(
          "label",
          { className: "hcv-env-field hcv-env-action-icon" },
          t.icon,
          h12(
            "div",
            null,
            icon6(icons[action.icon] || "tools"),
            h12(
              "select",
              { value: action.icon, onChange: (event) => update(action.id, { icon: event.target.value }) },
              buttonTypes.map((type) => h12("option", { value: type, key: type }, t[type]))
            )
          )
        ),
        h12(
          "label",
          { className: "hcv-env-field" },
          t.name,
          h12("input", { value: action.name, maxLength: 100, onChange: (event) => update(action.id, { name: event.target.value }) })
        ),
        h12("button", {
          type: "button",
          "aria-label": t.remove,
          title: t.remove,
          onClick: () => onChange(actions.filter((item) => item.id !== action.id))
        }, icon6("trash"))
      ),
      h12(
        "label",
        { className: "hcv-env-field" },
        t.platform,
        h12(
          "select",
          { value: action.platform, onChange: (event) => update(action.id, { platform: event.target.value }) },
          platforms.map((value) => h12("option", { value, key: value }, platformNames[value] || t.allPlatforms))
        )
      ),
      h12(
        "label",
        { className: "hcv-env-field" },
        t.command,
        h12("textarea", {
          rows: 3,
          maxLength: 6e3,
          spellCheck: false,
          value: action.command,
          placeholder: "npm run dev",
          onChange: (event) => update(action.id, { command: event.target.value })
        })
      )
    ))
  );
}
function EnvironmentDialog({ target, close: close2, save }) {
  const { t, original, platform, trigger, revision, copyVariable } = target;
  const [draft, setDraft] = useState8(original);
  const [advanced, setAdvanced] = useState8(false);
  const [discard, setDiscard] = useState8(false);
  const [saving, setSaving] = useState8(false);
  const [error, setError] = useState8("");
  const heading = useRef6(null);
  const savingRef = useRef6(false);
  const edit3 = (patch) => setDraft((previous) => ({ ...previous, ...patch }));
  const dirty = JSON.stringify(original) !== JSON.stringify(draft);
  const setup = scriptFor(draft.setup, platform);
  const runSetup = Boolean(setup.trim()) && (!revision || scriptFor(original.setup, platform) !== setup);
  const content = [draft.setup, draft.cleanup].some((scripts) => Object.values(scripts).some((value) => value.trim())) || draft.actions.some((action) => action.name.trim() && action.command.trim());
  const complete = draft.actions.every((action) => Boolean(action.name.trim()) === Boolean(action.command.trim()));
  const disabled = saving || !dirty || !draft.name.trim() || !complete || !content && !revision;
  const requestClose = () => {
    if (savingRef.current) return;
    if (dirty) setDiscard(true);
    else close2();
  };
  const submit = async (event) => {
    event.preventDefault();
    if (disabled || savingRef.current) return;
    savingRef.current = true;
    setSaving(true);
    setError("");
    const config = { ...draft, name: draft.name.trim(), actions: draft.actions.filter((action) => action.name.trim()) };
    try {
      await save(target, config, runSetup ? setup : "");
    } catch (error2) {
      setError(error2?.message === "conflict" ? t.conflict : error2?.message === "path" ? t.path : t.saveError);
      savingRef.current = false;
      setSaving(false);
    }
  };
  const setupEditor = h12(ScriptEditor, { type: "setup", scripts: draft.setup, setScripts: (setup2) => edit3({ setup: setup2 }), compact: !advanced, t, copyVariable });
  return h12(
    Dialog2,
    { open: true, onOpenChange: (open) => {
      if (!open) requestClose();
    } },
    h12(
      DialogContent2,
      {
        "data-hcv-local-environment": "",
        "data-hcv-env-advanced": String(advanced),
        bodyClassName: "hcv-env-body",
        overlayClassName: "hcv-env-overlay",
        blurBackdrop: false,
        showCloseButton: !saving,
        onEscapeKeyDown: (event) => {
          if (savingRef.current || discard) event.preventDefault();
        },
        onOpenAutoFocus: (event) => {
          event.preventDefault();
          heading.current?.focus();
        },
        onCloseAutoFocus: (event) => {
          if (trigger?.isConnected) {
            event.preventDefault();
            trigger.focus({ preventScroll: true });
          }
        }
      },
      h12(DialogHeader2, null, h12(DialogTitle2, { ref: heading, tabIndex: -1 }, t.title), h12(DialogDescription2, null, t.subtitle)),
      h12(
        "form",
        { onSubmit: submit, className: "hcv-env-form" },
        h12(
          "fieldset",
          { disabled: saving },
          !advanced && setupEditor,
          h12("button", {
            type: "button",
            className: "hcv-env-disclosure",
            "aria-expanded": advanced,
            "aria-controls": "hcv-env-options",
            onClick: () => setAdvanced((previous) => !previous)
          }, t.advanced, icon6("right")),
          advanced && h12(
            "div",
            { className: "hcv-env-options", id: "hcv-env-options" },
            h12(
              "label",
              { className: "hcv-env-card hcv-env-field" },
              t.name,
              h12("input", { value: draft.name, maxLength: 120, onChange: (event) => edit3({ name: event.target.value }) })
            ),
            setupEditor,
            h12(ScriptEditor, { type: "cleanup", scripts: draft.cleanup, setScripts: (cleanup) => edit3({ cleanup }), t }),
            h12(Actions, { actions: draft.actions, onChange: (actions) => edit3({ actions }), t })
          ),
          error && h12("p", { role: "alert", className: "hcv-env-error" }, error),
          h12(DialogFooter2, null, h12(Button2, { type: "submit", disabled }, runSetup || !revision && !content ? t.setupProject : t.save))
        )
      ),
      h12(
        Dialog2,
        { open: discard, onOpenChange: setDiscard },
        h12(
          DialogContent2,
          { "data-hcv-env-confirm": "", showCloseButton: false, blurBackdrop: false },
          h12(DialogHeader2, null, h12(DialogTitle2, null, t.discardTitle), h12(DialogDescription2, null, t.discardHint)),
          h12(
            DialogFooter2,
            null,
            h12(Button2, { type: "button", variant: "outline", onClick: () => setDiscard(false) }, t.keep),
            h12(Button2, { type: "button", variant: "destructive", onClick: close2 }, t.discard)
          )
        )
      )
    )
  );
}
function TerminalResult({ result, stop, close: close2 }) {
  const { state, title, cwd, output, error, t } = result;
  const running = state === "running" || state === "starting";
  const status2 = error ? t[error] : t[state];
  return h12(
    Dialog2,
    { open: true, onOpenChange: (open) => {
      if (!open && !running) close2();
    } },
    h12(
      DialogContent2,
      { "data-hcv-env-terminal": "", showCloseButton: !running, blurBackdrop: false },
      h12(DialogHeader2, null, h12(DialogTitle2, null, title), h12(DialogDescription2, null, cwd)),
      h12("div", { role: "status", "data-hcv-env-run-state": state }, status2),
      h12("pre", { tabIndex: 0 }, output || t.noOutput),
      h12(DialogFooter2, null, h12(Button2, { type: "button", onClick: running ? stop : close2 }, running ? t.stop : t.close))
    )
  );
}
function EnvironmentSlot({ model, result, close: close2, save, stop, closeResult }) {
  const target = useValue5(model);
  const run = useValue5(result);
  if (target) return h12(EnvironmentDialog, { key: target.key, target, close: close2, save });
  return run ? h12(TerminalResult, { result: run, stop, close: closeResult }) : null;
}
function registerLocalEnvironment(ctx, active2) {
  const root = document.documentElement;
  const model = atom5(null);
  const result = atom5(null);
  const revisionSignal = atom5(0);
  const platform = desktopPlatform();
  const close2 = () => model.set(null);
  const closeResult = () => result.set(null);
  const storageKey2 = (scope4) => `local-environment-v1:${localPathKey(scope4.source, platform)}`;
  const read = (scope4) => ctx.storage.get(storageKey2(scope4), null);
  const sheet = document.createElement("style");
  sheet.dataset.hcvLocalEnvironmentStyles = "";
  sheet.textContent = styles(active2);
  mountStyle(ctx, sheet, { surface: "[data-hcv-local-environment]" });
  let cancelRun, disposed = false;
  let request = 0;
  const local = () => !disposed && host11.state.connectionId.get() === "local";
  const enabled = () => local() && root.matches(active2);
  const notify = (message, kind = "error") => host11.notify({ kind, message });
  const idle = () => !model.get() && !result.get();
  async function scopeFor(cwd) {
    if (!enabled() || !platform) return null;
    const desktop = window.hermesDesktop;
    const directory = await checkedLocalPath(desktop, cwd, platform).catch(() => null);
    if (!directory || !enabled()) return null;
    const owner = { connectionId: "local", profile: host11.state.profile.get() };
    let entries = await readWorkspaceTrees(directory, owner, true).catch(() => []);
    if (!entries.length) entries = await readWorkspaceTrees(directory, owner, false).catch(() => []);
    const current = localPathKey(directory, platform);
    const checkout = entries.reduce((closest, entry) => {
      const key = localPathKey(entry.path, platform);
      return key && (key === current || current.startsWith(`${key}/`)) && key.length > closest.key.length ? { path: entry.path, key } : closest;
    }, { path: directory, key: "" }).path;
    const source = entries.find((entry) => entry.isMain)?.path || checkout;
    const paths = await Promise.all([checkout, source].map((path) => checkedLocalPath(desktop, path, platform).catch(() => null)));
    return enabled() && paths.every(Boolean) ? { cwd: paths[0], source: paths[1] } : null;
  }
  const startRun = ({ cwd, source, script, title, t }) => {
    result.set({ cwd, title, t, output: "", state: "starting" });
    cancelRun = runLocalScript({
      desktop: window.hermesDesktop,
      platform,
      cwd,
      source,
      script,
      stillLocal: local,
      update: (patch) => {
        if (!disposed && result.get()) result.set({ ...result.get(), ...patch });
      }
    });
  };
  async function save(target, config, setup) {
    const scope4 = await scopeFor(target.cwd);
    if (!scope4 || target !== model.get() || storageKey2(scope4) !== storageKey2(target)) throw new Error("path");
    if ((read(scope4)?.revision || "") !== target.revision) throw new Error("conflict");
    const revision = crypto.randomUUID();
    ctx.storage.set(storageKey2(scope4), { revision, config });
    if (read(scope4)?.revision !== revision) throw new Error("save");
    revisionSignal.set(revisionSignal.get() + 1);
    close2();
    if (setup) startRun({ ...scope4, script: setup, title: target.t.setup, t: target.t });
    else notify(target.t.saved, "success");
  }
  function commands(config, t) {
    if (!config) return [];
    return [
      { id: "setup", label: t.runSetup, icon: "tools", script: scriptFor(config.setup, platform) },
      { id: "cleanup", label: t.runCleanup, icon: "trash", script: scriptFor(config.cleanup, platform) },
      ...config.actions.filter((action) => action.platform === "default" || action.platform === platform).map((action) => ({ id: action.id, label: action.name, icon: icons[action.icon] || "tools", script: action.command }))
    ].filter((command2) => command2.script.trim());
  }
  ctx.register({
    id: "local-environment-dialog",
    area: TITLEBAR_AREAS4.center,
    render: () => h12(EnvironmentSlot, { model, result, close: close2, save, stop: () => cancelRun?.(), closeResult })
  });
  ctx.onDispose(() => {
    disposed = true;
    cancelRun?.();
    close2();
    closeResult();
    sheet.remove();
  });
  return {
    revision: revisionSignal,
    async open({ cwd, projectName, trigger }) {
      if (!idle()) return false;
      const key = ++request;
      const t = words();
      const scope4 = await scopeFor(cwd);
      if (key !== request || !idle() || disposed) return false;
      if (!scope4) {
        notify(t.path);
        return false;
      }
      const saved = read(scope4);
      model.set({
        ...scope4,
        key,
        t,
        trigger,
        platform,
        revision: saved?.revision || "",
        original: saved?.config || emptyEnvironment(projectName?.trim() || folderName(scope4.source)),
        copyVariable: async (name) => {
          if (await ctx.os.writeClipboard(name)) notify(t.copied, "success");
        }
      });
      return true;
    },
    async name(cwd) {
      const scope4 = await scopeFor(cwd);
      return scope4 ? read(scope4)?.config.name || "" : "";
    },
    async actions(cwd) {
      const scope4 = await scopeFor(cwd);
      return scope4 ? commands(read(scope4)?.config, words()).map(({ id: id2, label: label3, icon: icon8 }) => ({ id: id2, label: label3, icon: icon8 })) : [];
    },
    async run({ cwd, id: id2 }) {
      if (!idle()) return false;
      const key = ++request;
      const t = words();
      const scope4 = await scopeFor(cwd);
      if (key !== request || !idle() || disposed) return false;
      const command2 = scope4 && commands(read(scope4)?.config, t).find((command3) => command3.id === id2);
      if (!command2) {
        notify(t.actionError);
        return false;
      }
      startRun({ ...scope4, script: command2.script, title: command2.label, t });
      return true;
    }
  };
}
function styles(active2) {
  const form = `${active2} [data-slot="dialog-content"][data-hcv-local-environment]`;
  const vars = `${active2} [data-hcv-env-vars]`;
  const terminal2 = `${active2} [data-hcv-env-terminal]`;
  return `
  ${form}, ${terminal2}, ${active2} [data-hcv-env-confirm] {
    inline-size: min(420px, calc(100vw - 32px)); max-inline-size: none;
    max-block-size: calc(100dvh - 40px); border: 0; border-radius: 20px;
    background: var(--hcv-menu); color: var(--hcv-text); font-family: var(--hcv-ui-font);
  }
  ${form} {
    background: light-dark(var(--hcv-menu), #2a2a2a);
    --hcv-env-field-fill: light-dark(var(--hcv-form-surface), #2d2d2d);
    --hcv-env-card-fill: light-dark(var(--hcv-panel), #232323);
    --hcv-env-control-fill: light-dark(var(--hcv-hover-menu), #333);
  }
  ${active2} .hcv-env-overlay { background: rgb(0 0 0 / 25%); backdrop-filter: none; }
  ${form} .hcv-env-body { display: flex; flex-direction: column; overflow: hidden; gap: 0; padding: 20px; }
  ${form} [data-slot="dialog-header"], ${terminal2} [data-slot="dialog-header"] { gap: 4px; text-align: start; padding-inline-end: 20px; }
  ${form} [data-slot="dialog-title"], ${terminal2} [data-slot="dialog-title"] { font-size: 20px; font-weight: 600; line-height: 26px; }
  ${form} [data-slot="dialog-title"]:focus { outline: none; }
  ${form} [data-slot="dialog-description"], ${terminal2} [data-slot="dialog-description"] { font-size: 14px; line-height: 20px; color: var(--hcv-muted); overflow-wrap: anywhere; }
  ${form} [data-slot="dialog-close-button"] { inset-block-start: 16px; inset-inline-end: 16px; inline-size: 24px; block-size: 24px; border-radius: 8px; }
  ${codexIconRules(`${form} [data-slot="dialog-close-button"] > svg`, "close")}
  ${form} .hcv-env-form { min-block-size: 0; overflow: auto; overscroll-behavior: contain; padding: 44px 13px 0; }
  ${form}[data-hcv-env-advanced="true"] .hcv-env-form { padding-block-start: 28px; }
  ${form} fieldset { display: flex; min-inline-size: 0; flex-direction: column; gap: 16px; }
  ${form} .hcv-env-options { display: flex; flex-direction: column; gap: 10px; }
  ${form} .hcv-env-section-title { display: flex; align-items: start; justify-content: space-between; gap: 8px; }
  ${form} :is(.hcv-env-section-title label, h3, .hcv-env-disclosure) { font-size: 16px; font-weight: 600; line-height: 24px; }
  ${form} p { margin: 0; color: var(--hcv-muted); font-size: 13px; line-height: 18px; }
  ${form} .hcv-env-script { display: flex; flex-direction: column; gap: 12px; }
  ${form}[data-hcv-env-advanced="false"] .hcv-env-script { gap: 14px; }
  ${form}[data-hcv-env-advanced="false"] .hcv-env-script label { font-size: 14px; }
  ${form} :is(input, textarea, select) {
    inline-size: 100%; min-inline-size: 0; padding: 8px 10px;
    border: 1px solid var(--hcv-hairline); border-radius: 8px;
    background: var(--hcv-env-field-fill); color: var(--hcv-text); font: 13px/18px var(--hcv-ui-font);
  }
  ${form} textarea { display: block; min-block-size: 80px; resize: vertical; font: 12px/18px ui-monospace, Consolas, monospace; }
  ${form} .hcv-env-script textarea { block-size: 128px; }
  ${form} textarea::placeholder { color: var(--hcv-muted); opacity: .8; }
  ${form} .hcv-env-disclosure { display: flex; align-items: center; gap: 8px; min-block-size: 40px; text-align: start; border-block-end: 1px solid var(--hcv-hairline); }
  ${form} .hcv-env-disclosure [data-hcv-env-icon] { inline-size: 12px; block-size: 12px; }
  ${form} .hcv-env-disclosure[aria-expanded="true"] [data-hcv-env-icon] { transform: rotate(90deg); }
  ${form} .hcv-env-platforms { display: flex; flex-wrap: wrap; align-items: center; gap: 2px; margin-block-end: 6px; }
  ${form} .hcv-env-platforms button { min-block-size: 24px; padding: 0 8px; border-radius: 999px; color: var(--hcv-muted); font-size: 13px; }
  ${form} .hcv-env-platforms button[aria-selected="true"] { background: var(--hcv-env-control-fill); color: var(--hcv-text); }
  ${form} :is(.hcv-env-secondary, .hcv-env-action-heading button) {
    min-block-size: 28px; padding: 3px 8px; border-radius: 10px; background: var(--hcv-env-control-fill);
    color: var(--hcv-text); font-size: 13px; white-space: nowrap;
  }
  ${form} :is(button, select):not(:disabled) { cursor: pointer; }
  ${form} :is(button, input, textarea, select):focus-visible, ${vars} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${form} .hcv-env-card, ${form} .hcv-env-empty { background: var(--hcv-env-card-fill); border-radius: 16px; padding: 14px 16px; }
  ${form} .hcv-env-field { display: flex; flex-direction: column; gap: 4px; min-inline-size: 0; font-size: 13px; font-weight: 600; }
  ${form} .hcv-env-actions { display: flex; flex-direction: column; gap: 8px; }
  ${form} .hcv-env-empty { padding: 14px 18px; text-align: center; color: var(--hcv-muted); font-size: 13px; line-height: 18px; }
  ${form} .hcv-env-action { display: grid; gap: 10px; }
  ${form} .hcv-env-action-heading { display: grid; grid-template-columns: minmax(0, 112px) minmax(0, 1fr) auto; gap: 6px; align-items: end; }
  ${form} .hcv-env-action-icon > div { position: relative; }
  ${form} .hcv-env-action-icon [data-hcv-env-icon] { position: absolute; inset-block-start: 10px; inset-inline-start: 7px; pointer-events: none; }
  ${form} .hcv-env-action-icon select { padding-inline-start: 25px; }
  ${form} .hcv-env-action-heading button { block-size: 36px; }
  ${form} [data-slot="dialog-footer"] { justify-content: flex-end; margin-block-start: 20px; }
  ${form}[data-hcv-env-advanced="true"] [data-slot="dialog-footer"] { margin-block-start: 4px; }
  ${form} [type="submit"] { min-block-size: 28px; block-size: 28px; padding-inline: 9px; border-radius: 9px; background: var(--hcv-action); color: var(--hcv-ink); font: 13px/18px var(--hcv-ui-font); }
  ${form} [type="submit"]:disabled { opacity: .46; }
  ${form} .hcv-env-error { color: var(--dt-destructive); }
  ${form} [data-hcv-env-icon], ${vars} [data-hcv-env-icon] { display: inline-block; flex: none; inline-size: 16px; block-size: 16px; }
  ${vars} { inline-size: min(320px, var(--radix-popover-content-available-width)); padding: 8px; border-radius: 16px; background: var(--hcv-menu); color: var(--hcv-text); font: 13px/18px var(--hcv-ui-font); }
  ${vars} > div { display: grid; gap: 3px; margin-block-start: 4px; }
  ${vars} > div span:not([data-hcv-env-icon]) { color: var(--hcv-muted); }
  ${vars} button { display: flex; justify-content: space-between; gap: 6px; padding: 5px 8px; border-radius: 7px; background: var(--hcv-hover-menu); text-align: start; overflow-wrap: anywhere; }
  ${terminal2} { inline-size: min(560px, calc(100vw - 32px)); }
  ${terminal2} pre { max-block-size: min(50dvh, 380px); overflow: auto; overscroll-behavior: contain; white-space: pre-wrap; overflow-wrap: anywhere; padding: 12px; border-radius: 10px; background: var(--hcv-panel); font: 12px/18px ui-monospace, Consolas, monospace; }
  ${terminal2} [data-hcv-env-run-state="failed"] { color: var(--dt-destructive); }
  @media (prefers-reduced-motion: no-preference) { ${form} .hcv-env-disclosure [data-hcv-env-icon] { transition: transform 140ms ease-out; } }
`;
}

// source/turns.js
import { host as host12 } from "@hermes/plugin-sdk";
var response2 = '[data-slot="aui_response-group"]';
var assistant = '[data-slot="aui_assistant-message-root"]';
var answer = '[data-slot="aui_assistant-message-content"]';
var duration2 = '[data-slot="aui_turn-duration"]';
var changes = '[data-slot="aui_changed-files"]';
var transcript3 = '[data-slot="aui_thread-content"]';
var promptRoot = '[data-slot="aui_turn-pair"] > [data-slot="aui_user-message-root"][data-message-id]';
var primary2 = '[data-chat-surface][data-composer-target="main"]';
var nativeActivity = ':is([data-slot="aui_response-loading"], [data-slot="aui_turn-activity"][data-state="active"])';
var activeIndicators = `[data-chat-surface] :is(${nativeActivity}, [data-hcv-live-turn])`;
var streaming = '[data-message-streaming="true"]';
var step = ':is([data-conversation-scaffold]:not([role="status"]), [data-slot="tool-block"], [data-slot="aui_reasoning-text"])';
var actionable = ':is([role="alert"], [data-approval-activity-only], [data-approval-stack], [data-clarify-choices], [data-clarify-late-choices], [data-clarify-batch-preview], [data-clarify-batch-question]:not([data-locked]))';
var protectedStep = `:is(${actionable}, [data-slot="aui_artifact-card"], [data-slot="aui_generated-image"], [data-delegate-card], [data-hcv-agent-rows], svg.text-destructive[aria-label])`;
var isRussian = () => document.documentElement.lang.toLowerCase().startsWith("ru");
function make(tag, marker4, text) {
  const node3 = document.createElement(tag);
  node3.setAttribute(`data-hcv-${marker4}`, "");
  node3.setAttribute("data-hcv-generated", "");
  if (text) node3.textContent = text;
  return node3;
}
function updateText(node3, text) {
  if (node3.textContent !== text) node3.textContent = text;
}
function durationSeconds(value) {
  const match = value?.match(/(\d+)(?:\:(\d{2})|s)\s*$/);
  if (!match) return null;
  return match[2] === void 0 ? Number(match[1]) : Number(match[1]) * 60 + Number(match[2]);
}
function formatDuration2(seconds) {
  if (seconds === null) return "";
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor(seconds / 60) % 60;
  const units = hours ? [["hour", hours], ["minute", minutes]] : [["minute", minutes], ["second", seconds % 60]];
  const language2 = document.documentElement.lang || "en";
  return units.filter(([unit, value]) => value > 0 || seconds === 0 && unit === "second").map(([unit, value]) => new Intl.NumberFormat(language2, { style: "unit", unitDisplay: "narrow", unit }).format(value)).join(" ");
}
function renderedMessage(element7) {
  if (!element7) return null;
  const root = committedFiber(element7);
  for (let fiber = root; fiber && (fiber === root || !(fiber.stateNode instanceof Element)); fiber = fiber.return) {
    for (let context = fiber.dependencies?.firstContext; context; context = context.next) {
      const client = context.memoizedValue;
      if (!client?.message?.source) continue;
      try {
        const message = client.message().__internal_getRuntime?.()?.getState();
        if (message?.role === element7.dataset.role && (!element7.dataset.messageId || message.id === element7.dataset.messageId)) {
          return message;
        }
      } catch {
      }
    }
  }
  return null;
}
function savedDuration(prompt2, message) {
  const metadata = message?.metadata?.custom;
  if (!metadata || message.status?.type !== "complete") return null;
  const text = message.content.findLast((part) => part.type === "text" && part.text.trim());
  const end = metadata.timelineCompletedAt ?? (text?.sourceRowId != null ? text.timestamp : null);
  if (!Number.isFinite(end)) return null;
  const start = renderedMessage(prompt2)?.metadata?.custom?.timelineTimestamp;
  return Number.isFinite(start) && start > 0 && end > start ? Math.floor(end - start) : null;
}
function findSteps(group2, roots, final2) {
  const canFold = (node3) => !node3.matches(protectedStep) && !node3.querySelector(protectedStep);
  const earlier = roots.slice(0, roots.indexOf(final2)).filter(canFold);
  const body2 = final2.querySelector(answer);
  const detail = [...body2?.querySelectorAll(step) || []].filter((node3) => !node3.parentElement.closest(step) && canFold(node3));
  const prose2 = [...body2?.querySelectorAll(".aui-md") || []].filter((node3) => !node3.parentElement.closest(step));
  const lastStep = detail.at(-1);
  const commentary = lastStep ? prose2.slice(0, -1).filter(
    (node3) => canFold(node3) && Boolean(node3.compareDocumentPosition(lastStep) & Node.DOCUMENT_POSITION_FOLLOWING)
  ) : [];
  return [...earlier, ...detail, ...commentary].filter((node3) => node3.closest(response2) === group2);
}
function clearSteps(group2, state) {
  for (const node3 of state.steps) node3.removeAttribute("data-hcv-turn-step");
  state.steps.clear();
  state.bar?.remove();
  state.bar = null;
  group2.removeAttribute("data-hcv-turn-folded");
  group2.removeAttribute("data-hcv-turn-summary");
}
function showSummary(group2, state, steps, elapsed, interrupted) {
  const hasSteps = steps.length > 0;
  if (!state.bar || state.bar.tagName === "BUTTON" !== hasSteps) {
    clearSteps(group2, state);
    const bar = make(hasSteps ? "button" : "div", "turn-line");
    if (hasSteps) {
      bar.type = "button";
      bar.setAttribute("aria-expanded", "false");
      group2.setAttribute("data-hcv-turn-folded", "");
      bar.addEventListener("click", () => {
        const open = group2.toggleAttribute("data-hcv-turn-folded") === false;
        bar.setAttribute("aria-expanded", String(open));
      });
    }
    state.bar = bar;
  }
  if (group2.firstElementChild !== state.bar) group2.prepend(state.bar);
  const ru = isRussian();
  let label3 = ru ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E" : "Worked";
  if (interrupted) label3 = ru ? "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E" : "Stopped";
  else if (elapsed) label3 = ru ? `\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u043E \u0437\u0430 ${elapsed}` : `Worked for ${elapsed}`;
  updateText(state.bar, label3);
  group2.setAttribute("data-hcv-turn-summary", "");
  const next = new Set(steps);
  for (const node3 of state.steps) if (!next.has(node3)) node3.removeAttribute("data-hcv-turn-step");
  for (const node3 of next) if (!state.steps.has(node3)) node3.setAttribute("data-hcv-turn-step", "");
  state.steps = next;
}
function clearLive(state) {
  state.live?.row.remove();
  state.live = null;
}
function showLive(root, state, now) {
  if (!state.live) {
    const row6 = make("div", "live-turn");
    const time = make("time", "live-time");
    row6.setAttribute("role", "status");
    time.setAttribute("aria-hidden", "true");
    row6.append(time);
    state.live = { row: row6, time };
  }
  const { row: row5 } = state.live;
  const body2 = root.querySelector(answer);
  if (body2 && body2.nextElementSibling !== row5) body2.after(row5);
  updateLiveTime(state, now);
}
function updateLiveTime(state, now) {
  const seconds = Math.max(0, Math.floor((now - state.startedAt) / 1e3));
  updateText(state.live.time, seconds < 60 ? `${seconds}s` : `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`);
}
function syncThinkingLabels(labels12, enabled) {
  const visible = /* @__PURE__ */ new Set();
  const text = isRussian() ? "\u0414\u0443\u043C\u0430\u044E" : "Thinking";
  for (const row5 of enabled ? document.querySelectorAll(activeIndicators) : []) {
    if (row5.querySelector(':scope > :not(.dither, [aria-hidden="true"], [data-hcv-thinking])')) continue;
    visible.add(row5);
    let label3 = labels12.get(row5);
    if (!label3) {
      label3 = make("span", "thinking");
      const sweep = make("span", "thinking-sweep");
      sweep.setAttribute("aria-hidden", "true");
      label3.append(document.createTextNode(""), sweep);
      labels12.set(row5, label3);
    }
    if (label3.firstChild.data !== text) {
      label3.firstChild.data = text;
      label3.lastElementChild.dataset.hcvThinkingSweep = text;
    }
    if (label3.parentElement !== row5) row5.prepend(label3);
  }
  for (const [row5, label3] of labels12) {
    if (visible.has(row5)) continue;
    label3.remove();
    labels12.delete(row5);
  }
}
function fileNoun(count) {
  if (!isRussian()) return count === 1 ? "file" : "files";
  return { one: "\u0444\u0430\u0439\u043B", few: "\u0444\u0430\u0439\u043B\u0430", many: "\u0444\u0430\u0439\u043B\u043E\u0432" }[new Intl.PluralRules("ru").select(count)] || "\u0444\u0430\u0439\u043B\u043E\u0432";
}
function numbers(parent) {
  const totals = make("span", "files-totals");
  const added = make("span", "files-added");
  const removed = make("span", "files-removed");
  totals.append(added, removed);
  parent.append(totals);
  return { totals, added, removed };
}
function showNumbers({ added, removed }, plus, minus, format) {
  updateText(added, `+${format.format(plus)}`);
  updateText(removed, `${isRussian() ? "\u2013" : "-"}${format.format(minus)}`);
}
function nativeCardCwd(card2) {
  for (let fiber = committedFiber(card2)?.return; fiber; fiber = fiber.return) {
    if (!Array.isArray(fiber.memoizedProps?.parts)) continue;
    for (let context = fiber.dependencies?.firstContext; context; context = context.next) {
      const view = context.memoizedValue;
      if ((view?.kind === "primary" || view?.kind === "tile") && typeof view.$cwd?.get === "function") {
        return view.$cwd.get();
      }
    }
    break;
  }
  return card2.closest(primary2) ? host12.state.cwd.get() : "";
}
function fileDisplayPath(row5, basename, cwd) {
  for (let fiber = committedFiber(row5)?.return; fiber; fiber = fiber.return) {
    const props = fiber.memoizedProps;
    if (typeof fiber.key === "string" && typeof props?.label === "string" && props.children?.type === "button") {
      const path = fiber.key.replaceAll("\\", "/");
      const root = (cwd || "").replaceAll("\\", "/").replace(/\/+$/, "");
      if (!root && !cwd) return path;
      const prefix = root + "/";
      const windows = /^(?:[a-z]:\/|\/\/)/i.test(prefix);
      const within = windows ? path.toLowerCase().startsWith(prefix.toLowerCase()) : path.startsWith(prefix);
      return within ? path.slice(prefix.length) : path;
    }
    if (fiber.stateNode instanceof Element) break;
  }
  return basename;
}
function paintFileRow(row5, path, added, removed, format) {
  const index = path.lastIndexOf("/") + 1;
  updateText(row5.accessiblePath, path);
  updateText(row5.directory, path.slice(0, index));
  updateText(row5.basename, path.slice(index));
  showNumbers(row5.numbers, added, removed, format);
}
function makeFileRow(button5) {
  const accessiblePath = make("span", "file-accessible-path");
  const label3 = make("span", "file-path");
  const directory = make("span", "file-directory");
  const basename = make("span", "file-basename");
  label3.setAttribute("aria-hidden", "true");
  label3.append(directory, basename);
  button5.append(accessiblePath, label3);
  const counts = numbers(button5);
  return { accessiblePath, label: label3, directory, basename, numbers: counts };
}
function clearFileRow(row5) {
  row5.accessiblePath.remove();
  row5.label.remove();
  row5.numbers.totals.remove();
}
function clearFiles(state) {
  const files = state.files;
  if (!files) return;
  files.heading.remove();
  files.open.remove();
  files.more.remove();
  files.checkpoint.remove();
  files.review.removeEventListener("click", files.selectSingle, true);
  for (const row5 of files.rows.values()) clearFileRow(row5);
  files.nativeTitle.removeAttribute("data-hcv-file-native-title");
  if (files.review.getAttribute("aria-label") === files.review.getAttribute("data-hcv-file-review")) {
    if (files.originalReviewLabel === null) files.review.removeAttribute("aria-label");
    else files.review.setAttribute("aria-label", files.originalReviewLabel);
  }
  files.review.removeAttribute("data-hcv-file-review");
  files.card.removeAttribute("data-hcv-file-card");
  files.card.removeAttribute("data-hcv-file-single");
  files.card.removeAttribute("data-hcv-files-open");
  files.card.removeAttribute("data-hcv-files-foldable");
  state.files = null;
}
function showFiles(state, card2) {
  const header2 = card2?.children[0];
  const list = card2?.children[1];
  const nativeTitle = header2?.querySelector(":scope > span");
  const review = header2?.querySelector(":scope > button:not([data-hcv-generated])");
  if (!nativeTitle || !review || !list) return clearFiles(state);
  if (state.files?.card !== card2 || state.files.nativeTitle !== nativeTitle || state.files.review !== review) {
    clearFiles(state);
    const heading2 = make("div", "files-heading");
    const name2 = make("span", "files-title");
    const subtitle = make("span", "files-subtitle");
    heading2.append(name2, subtitle);
    const counts = numbers(subtitle);
    const hover2 = make("span", "files-hover");
    subtitle.append(hover2);
    const open2 = make("button", "files-open");
    open2.type = "button";
    open2.addEventListener("click", () => (state.files?.single || review).click());
    const selectSingle = (event) => {
      const row5 = state.files?.single;
      if (!row5) return;
      event.stopPropagation();
      row5.click();
    };
    review.addEventListener("click", selectSingle, true);
    const more2 = make("button", "files-more");
    more2.type = "button";
    more2.append(make("span", "files-more-label"));
    more2.setAttribute("aria-expanded", "false");
    more2.addEventListener("click", () => {
      more2.setAttribute("aria-expanded", String(card2.toggleAttribute("data-hcv-files-open")));
      updateMoreLabel(state.files);
    });
    const checkpoint2 = make("button", "files-checkpoint");
    checkpoint2.type = "button";
    checkpoint2.addEventListener("click", () => nativeCheckpoint(card2)?.click());
    state.files = {
      card: card2,
      nativeTitle,
      review,
      originalReviewLabel: review.getAttribute("aria-label"),
      heading: heading2,
      name: name2,
      counts,
      hover: hover2,
      open: open2,
      selectSingle,
      more: more2,
      checkpoint: checkpoint2,
      remaining: 0,
      single: null,
      rows: /* @__PURE__ */ new Map()
    };
  }
  const files = state.files;
  const { heading, name, hover, open, more, checkpoint } = files;
  if (heading.parentElement !== header2) nativeTitle.after(heading);
  if (open.parentElement !== header2) header2.prepend(open);
  const rows = new Set(list.querySelectorAll(":scope > button"));
  if (!rows.size) return clearFiles(state);
  const count = rows.size;
  const ru = isRussian();
  const format = new Intl.NumberFormat(document.documentElement.lang || "en");
  const cwd = count > 1 ? nativeCardCwd(card2) : "";
  let plus = 0;
  let minus = 0;
  for (const [row5, display] of files.rows) {
    if (count > 1 && rows.has(row5)) continue;
    clearFileRow(display);
    files.rows.delete(row5);
  }
  for (const row5 of rows) {
    const added = Number(row5.querySelector('[class~="text-(--ui-green)"]')?.textContent.slice(1)) || 0;
    const removed = Number(row5.querySelector('[class~="text-(--ui-red)"]')?.textContent.slice(1)) || 0;
    plus += added;
    minus += removed;
    if (count === 1) continue;
    const basename = row5.querySelector(":scope > span.truncate")?.textContent || "";
    const path = fileDisplayPath(row5, basename, cwd);
    if (!files.rows.has(row5)) files.rows.set(row5, makeFileRow(row5));
    paintFileRow(files.rows.get(row5), path, added, removed, format);
  }
  files.single = count === 1 ? rows.values().next().value : null;
  card2.toggleAttribute("data-hcv-file-single", Boolean(files.single));
  card2.setAttribute("data-hcv-file-card", "");
  nativeTitle.setAttribute("data-hcv-file-native-title", "");
  open.setAttribute("aria-label", ru ? "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u043D\u044B\u0435 \u0444\u0430\u0439\u043B\u044B" : "View changed files");
  updateText(hover, ru ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u0439" : "View changes");
  const reviewLabel = ru ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0438\u0437\u043C\u0435\u043D\u0435\u043D\u0438\u044F" : "View changes";
  review.setAttribute("data-hcv-file-review", reviewLabel);
  review.setAttribute("aria-label", reviewLabel);
  const restore = nativeCheckpoint(card2);
  if (restore) {
    updateText(checkpoint, ru ? "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C" : "Undo");
    checkpoint.title = restore.getAttribute("aria-label");
    if (checkpoint.parentElement !== header2) review.before(checkpoint);
  } else {
    checkpoint.remove();
  }
  if (files.single) {
    const basename = files.single.querySelector(":scope > span.truncate")?.textContent || "";
    updateText(name, ru ? `\u0418\u0437\u043C\u0435\u043D\u0451\u043D ${basename}` : `Edited ${basename}`);
  } else {
    updateText(name, ru ? `\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u043E ${format.format(count)} ${fileNoun(count)}` : `Edited ${format.format(count)} files`);
  }
  showNumbers(files.counts, plus, minus, format);
  if (card2.toggleAttribute("data-hcv-files-foldable", count > 3)) {
    if (more.parentElement !== card2) card2.append(more);
    files.remaining = count - 3;
    updateMoreLabel(files);
  } else {
    card2.removeAttribute("data-hcv-files-open");
    more.setAttribute("aria-expanded", "false");
    more.remove();
  }
}
function nativeCheckpoint(card2) {
  const label3 = isRussian() ? "\u0412\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u0447\u0435\u043A\u043F\u043E\u0438\u043D\u0442" : "Restore checkpoint";
  const turn = card2.closest('[data-slot="aui_turn-pair"]');
  const prompt2 = turn?.querySelector('[data-slot="aui_user-message-root"]');
  return prompt2?.querySelector(`button[aria-label="${label3}"]:not(:disabled)`);
}
function updateMoreLabel({ card: card2, more, remaining }) {
  const expanded = card2.hasAttribute("data-hcv-files-open");
  updateText(more.firstElementChild, expanded ? isRussian() ? "\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u0444\u0430\u0439\u043B\u044B" : "Collapse files" : isRussian() ? `\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0435 ${remaining} ${fileNoun(remaining)}` : `Show ${remaining} more ${fileNoun(remaining)}`);
}
function synchronize(group2, state, now, tail, ownPrompt, completedSeconds, startedAt) {
  const roots = [...group2.querySelectorAll(`:scope > ${assistant}`)];
  const last = roots.at(-1);
  if (!last) {
    clearSteps(group2, state);
    clearLive(state);
    clearFiles(state);
    return;
  }
  const working = Boolean(group2.querySelector(`${streaming}, ${nativeActivity}`));
  const blocked = roots.some((root) => root.matches(actionable) || root.querySelector(actionable));
  const final2 = roots.findLast((root) => root.querySelector('[data-slot="aui_msg-actions"]'));
  if (working && tail) {
    state.startedAt ??= startedAt ?? now;
  } else if (!working) {
    state.startedAt = null;
  }
  if (working && tail && !blocked && last.querySelector(streaming) && !last.querySelector(nativeActivity)) {
    showLive(last, state, now);
  } else {
    clearLive(state);
  }
  if (!working && !blocked && final2) {
    const message = renderedMessage(final2);
    const interrupted = Boolean(message?.metadata?.custom?.interrupted);
    const elapsed = interrupted ? "" : formatDuration2(durationSeconds(final2.querySelector(duration2)?.textContent) ?? completedSeconds ?? savedDuration(ownPrompt, message));
    const steps = findSteps(group2, roots, final2);
    if (elapsed || steps.length) showSummary(group2, state, steps, elapsed, interrupted);
    else clearSteps(group2, state);
  } else {
    clearSteps(group2, state);
  }
  showFiles(state, group2.querySelector(changes));
}
function registerTurnExperience(ctx, active2) {
  const states = /* @__PURE__ */ new Map();
  const thinkingLabels = /* @__PURE__ */ new Map();
  const started = /* @__PURE__ */ new Map();
  const durations = /* @__PURE__ */ new Map();
  const lastBySession = /* @__PURE__ */ new Map();
  const contrast = window.matchMedia("(forced-colors: none)");
  const dirty = /* @__PURE__ */ new Set();
  const live = /* @__PURE__ */ new Set();
  const tails = /* @__PURE__ */ new Set();
  const allGroups = `[data-chat-surface] ${response2}`;
  const user = '[data-slot="aui_user-message-root"]';
  const turnStructure = `${response2}, ${user}`;
  let full = true;
  let frame = 0;
  let clockFrame = 0;
  let timer = 0;
  const sessionKey = (id2) => JSON.stringify([host12.state.connectionId.get(), host12.state.profile.get(), id2]);
  const keyFor = (event) => event.session_id && !event.replayed && document.documentElement.matches(active2) && (!event.connectionId || event.connectionId === host12.state.connectionId.get()) && (!event.profile || event.profile === host12.state.profile.get()) ? sessionKey(event.session_id) : null;
  const primaryPrompt = (event) => event.session_id === host12.state.activeSessionId.get() ? [...document.querySelectorAll(`${primary2} ${promptRoot}`)].at(-1) : null;
  const storedKey = (runtime) => sessionKey(host12.state.focusedSessionId.get() === runtime ? host12.state.focusedStoredSessionId.get() || runtime : runtime);
  const promptText = (prompt2) => prompt2?.querySelector(".composer-human-message")?.textContent.trim();
  ctx.onEvent("message.start", (event) => {
    const key = keyFor(event);
    if (key && !started.has(key)) {
      const prompt2 = primaryPrompt(event);
      const session = storedKey(event.session_id);
      lastBySession.delete(session);
      started.set(key, { at: Date.now(), promptId: prompt2?.dataset.messageId, text: promptText(prompt2), session });
    }
    if (started.size > 64) started.delete(started.keys().next().value);
  });
  ctx.onEvent("message.complete", (event) => {
    const key = keyFor(event);
    const start = key && started.get(key);
    if (!start) return;
    started.delete(key);
    if (event.payload?.error || event.payload?.status && event.payload.status !== "complete") return;
    const prompt2 = primaryPrompt(event);
    const promptId = prompt2?.dataset.messageId || start.promptId;
    if (!promptId) return;
    const seconds = Math.max(1, Math.round((Date.now() - start.at) / 1e3));
    durations.set(JSON.stringify([key, promptId]), seconds);
    const text = promptText(prompt2) || start.text;
    if (text) lastBySession.set(prompt2 ? storedKey(event.session_id) : start.session, { text, seconds });
    if (durations.size > 200) durations.delete(durations.keys().next().value);
    if (lastBySession.size > 64) lastBySession.delete(lastBySession.keys().next().value);
    queue();
  });
  function remove(group2, state) {
    clearSteps(group2, state);
    clearLive(state);
    clearFiles(state);
    live.delete(state);
    states.delete(group2);
  }
  function render() {
    frame = 0;
    const enabled = contrast.matches && document.documentElement.matches(active2);
    if (full || !enabled) {
      const groups2 = enabled ? [...document.querySelectorAll(allGroups)] : [];
      const present = new Set(groups2);
      for (const [group2, state] of states) if (!present.has(group2)) remove(group2, state);
      dirty.clear();
      tails.clear();
      const tailByTranscript = new Map(groups2.map((group2) => [group2.closest(transcript3), group2]));
      for (const [container, group2] of tailByTranscript) {
        const prompt2 = [...container?.querySelectorAll(user) || []].at(-1);
        if (!prompt2 || !(group2.compareDocumentPosition(prompt2) & Node.DOCUMENT_POSITION_FOLLOWING)) tails.add(group2);
      }
      for (const group2 of groups2) dirty.add(group2);
    }
    full = false;
    if (enabled) {
      const now = Date.now();
      const runtime = host12.state.activeSessionId.get();
      const key = runtime && sessionKey(runtime);
      const last = runtime && lastBySession.get(storedKey(runtime));
      const liveStart = key && started.get(key);
      for (const group2 of dirty) {
        if (!group2.isConnected || !group2.matches(allGroups)) continue;
        let state = states.get(group2);
        if (!state) {
          state = { steps: /* @__PURE__ */ new Set(), bar: null, live: null, files: null, startedAt: null };
          states.set(group2, state);
        }
        const tail = tails.has(group2);
        const main = key && group2.closest(primary2);
        const ownPrompt = group2.closest('[data-slot="aui_turn-pair"]')?.querySelector(`:scope > ${user}[data-message-id]`);
        const timeKey = main && ownPrompt && JSON.stringify([key, ownPrompt.dataset.messageId]);
        const recorded = timeKey && durations.get(timeKey) || main && tail && last && last.text === promptText(ownPrompt) && last.seconds;
        synchronize(group2, state, now, tail, ownPrompt, recorded || null, main ? liveStart?.at : void 0);
        if (state.live) live.add(state);
        else live.delete(state);
      }
    }
    dirty.clear();
    syncThinkingLabels(thinkingLabels, enabled);
    if (live.size) {
      if (!timer) timer = window.setInterval(() => {
        if (!clockFrame) clockFrame = requestAnimationFrame(() => {
          clockFrame = 0;
          const now = Date.now();
          if (!contrast.matches || !document.documentElement.matches(active2)) return;
          for (const state of live) if (state.live.row.isConnected) updateLiveTime(state, now);
        });
      }, 1e3);
    } else if (timer) {
      window.clearInterval(timer);
      timer = 0;
    }
  }
  function schedule() {
    if (!frame) frame = requestAnimationFrame(render);
  }
  function queue() {
    full = true;
    schedule();
  }
  const observer = new MutationObserver((records) => {
    const root = document.documentElement;
    if (records.some(({ target }) => target === root)) return queue();
    if (!root.matches(active2)) return;
    for (const { target, type, addedNodes, removedNodes } of records) {
      const element7 = target instanceof Element ? target : target.parentElement;
      if (!element7 || element7.closest("[data-hcv-generated]")) continue;
      const group2 = element7.closest(response2);
      if (type === "characterData") {
        if (group2 && element7.closest(`${changes}, ${duration2}`)) dirty.add(group2);
      } else if (type === "attributes") {
        if (group2) dirty.add(group2);
      } else {
        for (const nodes of [addedNodes, removedNodes]) {
          for (const node3 of nodes) {
            if (node3 instanceof Element && !node3.hasAttribute("data-hcv-generated")) {
              if (node3.matches(turnStructure) || node3.querySelector(turnStructure)) return queue();
              if (group2) dirty.add(group2);
            } else if (group2 && node3.nodeType === Node.TEXT_NODE && element7.closest(`${changes}, ${duration2}`)) {
              dirty.add(group2);
            }
          }
        }
      }
      if (group2 && dirty.has(group2)) {
        for (let parent = group2.parentElement?.closest(response2); parent; parent = parent.parentElement?.closest(response2)) {
          dirty.add(parent);
        }
      }
    }
    if (dirty.size) schedule();
  });
  observer.observe(document.documentElement, {
    childList: true,
    characterData: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-state", "data-message-streaming", "data-hermes-theme", "data-hermes-codex-visual", "lang"]
  });
  contrast.addEventListener("change", queue);
  const unsubscribe = [
    host12.state.activeSessionId,
    host12.state.focusedSessionId,
    host12.state.focusedStoredSessionId,
    host12.state.connectionId,
    host12.state.profile
  ].map((atom7) => atom7.listen(queue));
  queue();
  ctx.onDispose(() => {
    observer.disconnect();
    contrast.removeEventListener("change", queue);
    for (const stop of unsubscribe) stop();
    if (frame) cancelAnimationFrame(frame);
    if (clockFrame) cancelAnimationFrame(clockFrame);
    if (timer) window.clearInterval(timer);
    for (const [group2, state] of states) remove(group2, state);
    syncThinkingLabels(thinkingLabels, false);
  });
}

// source/message-actions.js
import { host as host13 } from "@hermes/plugin-sdk";
var actionBar = '[data-slot="aui_user-bubble-actions"]';
var bubbleSelector = "button.composer-human-message";
var restoreButton = "button:has(> .codicon-discard)";
var rowSelector = "[data-hcv-message-actions]";
var menuSelector = "[data-hcv-message-menu]";
var nativeTimestamp = '[data-slot="timeline-timestamp"]';
var replyRoot = '[data-slot="aui_assistant-message-root"]';
var replyActions = '[data-slot="aui_msg-actions"]';
var replyLane = ":is(.aui-message-actions-desktop, .aui-message-actions-touch)";
var replyCopy = 'button[data-size="icon"]:not(button[data-size="icon"] ~ button[data-size="icon"])';
var replyTip = "[data-hcv-reply-copy-tip]";
var copyIcon = ":is(.tabler-icon-copy, .lucide-copy)";
var labels8 = {
  ru: { copyMessage: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435", copyResponse: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u043E\u0442\u0432\u0435\u0442", messageCopied: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E", copyMessageError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435" },
  en: { copyMessage: "Copy message", copyResponse: "Copy response", messageCopied: "Copied", copyMessageError: "Could not copy the message" }
};
function replyActionLanes(bar) {
  return `:is(${bar}, ${bar} > ${replyLane})`;
}
function userMessage2(bubble, id2) {
  for (let node3 = committedFiber(bubble); node3; node3 = node3.return) {
    const client = node3.memoizedProps?.value;
    if (client?.message?.source !== "thread" || typeof client.subscribe !== "function") continue;
    try {
      const message = client.message();
      const state = message.getState();
      if (state.id === id2 && state.role === "user") return { message, state };
    } catch {
      return null;
    }
  }
  return null;
}
function dateLabel(date) {
  const locale = document.documentElement.lang || void 0;
  const options = { hour: "numeric", minute: "2-digit" };
  const localDay = (day) => Date.UTC(day.getFullYear(), day.getMonth(), day.getDate());
  const age = (localDay(/* @__PURE__ */ new Date()) - localDay(date)) / 864e5;
  if (age > 0 && age < 7) options.weekday = "long";
  else if (age !== 0) Object.assign(options, { day: "numeric", month: "short" });
  return new Intl.DateTimeFormat(locale, options).format(date);
}
function styles2(active2, transcript4) {
  const enhanced3 = `${active2} ${transcript4} ${actionBar}:has(${rowSelector})`;
  const row5 = `${enhanced3} ${rowSelector}`;
  const menu = `${active2} ${menuSelector}`;
  const reply = `${active2} ${transcript4} ${replyRoot}`;
  const footer = `${reply} div:has(> ${replyActions})`;
  const replyBar = `${reply} ${replyActions}`;
  const lane = replyActionLanes(replyBar);
  const replyButton = `${lane} > ${replyCopy}`;
  const tip2 = `${active2} ${replyTip}`;
  return `
@media (forced-colors: none) {
  /* Codex vHM0 and .bubble-vBnidZ (fce177e1b845.css). */
  ${enhanced3} { min-inline-size: 0; }
  ${enhanced3} ${bubbleSelector} {
    inline-size: fit-content;
    margin-inline-start: auto;
    padding: 10px 16px;
    border: 0;
    border-radius: 22px;
    corner-shape: superellipse(1.5);
  }
  ${enhanced3} ${restoreButton},
  ${enhanced3} .human-message-with-todos-wrapper:has(> ${rowSelector} > time:not([hidden])) > ${nativeTimestamp} { display: none; }

  /* Codex y5H2 keeps the action row in flow at opacity zero. */
  ${row5} {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 2px;
    margin: 4px 4px 0;
    min-block-size: 26px;
    color: var(--hcv-muted);
    opacity: 0;
    pointer-events: none;
  }
  ${active2}[data-hermes-mode="dark"] ${rowSelector} { color: #8f8f8f; }
  ${enhanced3}:is(:hover, :focus-within) ${rowSelector} { opacity: 1; pointer-events: auto; }
  ${row5} time {
    margin-inline-end: 6px;
    min-inline-size: 0;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: .75rem;
    line-height: 1rem;
  }
  ${row5} button {
    display: grid;
    place-items: center;
    flex: 0 0 26px;
    block-size: 26px;
    border-radius: 8px;
    color: inherit;
    cursor: pointer;
  }
  ${row5} [hidden] { display: none; }
  ${row5} button:focus-visible { outline: 2px solid var(--hcv-focus); }
  ${row5} button::before {
    content: "";
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: var(--hcv-message-icon) center / contain no-repeat;
  }
  ${row5} [data-hcv-copy-message] { --hcv-message-icon: ${codexMask("messageCopy")}; }
  ${row5} [data-hcv-copy-message][data-copied] { --hcv-message-icon: ${codexMask("messageCopied")}; }
  ${row5} [data-hcv-edit-message] { --hcv-message-icon: ${codexMask("messageEdit")}; }

  /* Codex 26.1111.2228.0: no() in 461952.bb4069593d.js, actionRow-nqqZbm
     and the icon, radius and color tokens in 3b01e25a342d.css / 66582da7ee6b.css. */
  ${footer} { justify-content: flex-start; }
  ${footer} > [data-slot="aui_msg-reactions"]:not([data-reacted]),
  ${lane} > button:not(${replyCopy}) { display: none; }
  ${replyBar} {
    align-items: center;
    justify-content: flex-start;
    min-block-size: 26px;
    margin-block-start: 6px;
    gap: 2px;
    padding-block: 0;
    opacity: 0;
    pointer-events: none;
  }
  ${reply}:is(:hover, :focus-within) ${replyActions} { opacity: 1; pointer-events: auto; }
  ${replyBar} > ${replyLane} { justify-content: flex-start; gap: 2px; }
  ${lane} > time {
    margin-inline: 0 6px;
    padding: 0;
    color: #8f8f8f;
    font: 400 12px/16px var(--hcv-ui-font);
    pointer-events: none;
  }
  ${replyButton} {
    display: grid;
    place-items: center;
    box-sizing: border-box;
    inline-size: 26px;
    block-size: 26px;
    padding: 0;
    border: 1px solid transparent;
    border-radius: 8px;
    corner-shape: superellipse(1.5);
    opacity: 1;
    color: #8f8f8f;
    background: transparent;
    transition: none;
  }
  ${replyButton}:hover:not(:disabled) {
    color: #8f8f8f;
    background: light-dark(rgb(26 28 31 / 5%), rgb(255 255 255 / 8%));
  }
  ${replyButton}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${replyButton} > svg { inline-size: 14px; block-size: 14px; }
  ${codexIconRules(`${replyButton} > ${copyIcon}`, "messageCopy")}
  ${codexIconRules(`${replyButton} > :is(.tabler-icon-check, .lucide-check)`, "messageCopied")}
  /* Tooltip-FE0nMY in 2e662a5288e2.css and the Electron tooltip tokens. */
  ${tip2} {
    position: fixed;
    z-index: 9999;
    inline-size: max-content;
    max-inline-size: min(320px, calc(100vw - 30px));
    padding: ${codexReference.tooltip.padding};
    border: 1px solid color-mix(in oklab, currentColor 5%, transparent);
    border-radius: ${codexReference.tooltip.radius};
    corner-shape: superellipse(1.5);
    background: light-dark(#1a1c1f, #2d2d2d);
    color: #dfdfdf;
    box-shadow: 0 8px 18px #0f172a33;
    font: 430 13px/18px var(--hcv-ui-font);
    letter-spacing: -.15px;
    text-align: center;
    overflow-wrap: break-word;
    transform: translate(-50%, -100%);
    pointer-events: none;
    user-select: none;
  }
  ${tip2}[hidden] { display: none; }
  @supports (corner-shape: superellipse(1.5)) {
    ${replyButton} { border-radius: 10px; }
    ${tip2} { border-radius: 20px; }
  }

  ${menu} {
    position: fixed;
    inset: auto;
    margin: 0;
    padding: 4px;
    max-inline-size: calc(100vw - 16px);
    border: 0;
    border-radius: var(--hcv-dropdown-radius);
    corner-shape: superellipse(1.5);
    background: var(--hcv-dropdown-background);
    color: var(--hcv-dropdown-text);
    box-shadow: var(--hcv-dropdown-shadow);
    backdrop-filter: none;
    font: 13px/20px var(--hcv-ui-font);
  }
  ${menu} button {
    min-block-size: 28px;
    padding-inline: 8px;
    border-radius: var(--hcv-dropdown-row-radius);
    corner-shape: superellipse(1.5);
    cursor: pointer;
  }
  @media (hover: hover) {
    ${row5} button:hover { background: var(--hcv-hover-menu); }
  }
  @media (hover: none) {
    ${row5} { opacity: 1; pointer-events: auto; }
    ${row5} time { opacity: 0; }
    ${enhanced3}:focus-within ${rowSelector} time { opacity: 1; }
    ${replyBar} { opacity: 1; pointer-events: auto; }
  }
}
`;
}
function registerReplyCopyTip(ctx, active2, transcript4) {
  const tip2 = document.createElement("div");
  tip2.dataset.hcvReplyCopyTip = "";
  tip2.setAttribute("aria-hidden", "true");
  tip2.hidden = true;
  document.body.append(tip2);
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: active)");
  const selector = `${replyActionLanes(`${transcript4} ${replyRoot} ${replyActions}`)} > ${replyCopy}`;
  const capture = { capture: true };
  let pointerButton;
  let button5;
  let timer;
  let triggerType;
  let skipDelayUntil = 0;
  const trigger = (target) => root.matches(active2) && !contrast.matches && target instanceof Element ? target.closest('button[data-size="icon"]')?.closest(selector) : null;
  function paint() {
    if (!button5?.isConnected || !button5.checkVisibility({ opacityProperty: true, visibilityProperty: true })) return hide();
    const anchor = button5.getBoundingClientRect();
    const label3 = button5.querySelector(copyIcon) ? ctx.i18n.t("copyResponse") : button5.getAttribute("aria-label");
    if (!label3 || anchor.top < 35 || anchor.bottom > innerHeight) return hide();
    if (tip2.textContent !== label3) tip2.textContent = label3;
    tip2.style.top = `${anchor.top - 5}px`;
    tip2.hidden = false;
    const half = tip2.offsetWidth / 2;
    tip2.style.left = `${Math.min(innerWidth - half - 15, Math.max(half + 15, anchor.left + anchor.width / 2))}px`;
  }
  const copyStatus = new MutationObserver(paint);
  function hide() {
    clearTimeout(timer);
    copyStatus.disconnect();
    button5 = null;
    if (!tip2.hidden) skipDelayUntil = performance.now() + 300;
    tip2.hidden = true;
  }
  function show(target, type, delay) {
    hide();
    button5 = target;
    triggerType = type;
    const open = () => {
      paint();
      if (button5) copyStatus.observe(button5, { attributes: true, attributeFilter: ["aria-label"] });
    };
    if (type === "focus") timer = setTimeout(open, 0);
    else if (delay && performance.now() >= skipDelayUntil) timer = setTimeout(open, delay);
    else open();
  }
  function skipNativeTip(event) {
    if (event.pointerType !== "touch" && !event.buttons && event.cancelable) event.preventDefault();
  }
  function clearPointer() {
    pointerButton?.removeEventListener("pointermove", skipNativeTip);
    pointerButton = null;
  }
  ctx.addEventListener(document, "pointerover", (event) => {
    if (event.pointerType === "touch" || event.buttons) return;
    const target = trigger(event.target);
    if (!target || target === pointerButton) return;
    clearPointer();
    pointerButton = target;
    target.addEventListener("pointermove", skipNativeTip, { passive: false });
    show(target, "pointer", 150);
  }, capture);
  ctx.addEventListener(document, "pointerout", (event) => {
    if (!pointerButton?.contains(event.target) || pointerButton.contains(event.relatedTarget)) return;
    if (triggerType === "pointer") hide();
    clearPointer();
  }, capture);
  ctx.addEventListener(document, "focusin", (event) => {
    const target = trigger(event.target);
    if (!target?.matches(":focus-visible")) return;
    event.stopPropagation();
    show(target, "focus", 0);
  }, capture);
  ctx.addEventListener(document, "focusout", (event) => {
    if (triggerType === "focus" && event.target === button5) hide();
  }, capture);
  ctx.addEventListener(document, "keydown", (event) => {
    if (event.key !== "Escape" || tip2.hidden) return;
    event.preventDefault();
    event.stopPropagation();
    hide();
  }, capture);
  ctx.addEventListener(document, "pointerdown", (event) => {
    if (button5 && !button5.contains(event.target)) hide();
  }, capture);
  ctx.addEventListener(document, "scroll", () => {
    if (button5 && (triggerType === "pointer" || !tip2.hidden)) hide();
  }, capture);
  ctx.addEventListener(window, "blur", hide);
  ctx.addEventListener(window, "resize", hide);
  function reset() {
    hide();
    clearPointer();
    skipDelayUntil = 0;
  }
  ctx.addEventListener(contrast, "change", reset);
  ctx.i18n.onLocaleChange(() => {
    if (!tip2.hidden) paint();
  });
  ctx.onDispose(() => {
    reset();
    tip2.remove();
  });
  return (enabled) => {
    if (!enabled || pointerButton && !pointerButton.isConnected) reset();
    else if (button5 && !button5.checkVisibility()) hide();
  };
}
function registerMessageActions(ctx, active2, transcript4, promptSelector2) {
  ctx.i18n.register(labels8);
  const sheet = document.createElement("style");
  sheet.dataset.hcvMessageActionStyle = "";
  sheet.textContent = styles2(active2, transcript4);
  mountStyle(ctx, sheet, { surface: actionBar + ", " + menuSelector });
  const reconcileReplyTip = registerReplyCopyTip(ctx, active2, transcript4);
  const rows = /* @__PURE__ */ new Map();
  const menu = document.createElement("div");
  menu.popover = "auto";
  menu.dataset.hcvMessageMenu = "";
  const restoreItem = document.createElement("button");
  restoreItem.type = "button";
  menu.append(restoreItem);
  document.body.append(menu);
  let restoreTarget;
  let restoreFocus;
  restoreItem.addEventListener("click", () => {
    menu.hidePopover();
    if (restoreTarget?.isConnected) restoreTarget.click();
  });
  menu.addEventListener("keydown", (event) => {
    if (event.key !== "Escape") return;
    event.preventDefault();
    event.stopPropagation();
    menu.hidePopover();
    restoreFocus?.focus({ preventScroll: true });
  });
  menu.addEventListener("toggle", (event) => {
    if (event.newState === "closed") restoreTarget = restoreFocus = void 0;
  });
  function addRow(bar, bubble, prompt2, messageId) {
    const holder = bubble.closest("[data-context-menu-skip]");
    const row5 = document.createElement("div");
    row5.dataset.hcvMessageActions = "";
    row5.setAttribute("data-context-menu-skip", "");
    const stamp = document.createElement("time");
    const copy7 = document.createElement("button");
    copy7.type = "button";
    copy7.dataset.hcvCopyMessage = "";
    const edit3 = document.createElement("button");
    edit3.type = "button";
    edit3.dataset.hcvEditMessage = "";
    row5.append(stamp, copy7);
    if (bubble.hasAttribute("aria-label")) row5.append(edit3);
    const updateCopy = () => {
      copy7.title = ctx.i18n.t(copy7.hasAttribute("data-copied") ? "messageCopied" : "copyMessage");
      copy7.setAttribute("aria-label", copy7.title);
    };
    const update = () => {
      const data = userMessage2(bubble, messageId);
      const seconds = data?.state.metadata?.custom?.timelineTimestamp;
      const nativeDate = bar.querySelector(`${nativeTimestamp} time`)?.dateTime;
      const date = typeof seconds === "number" && seconds > 0 ? new Date(seconds * 1e3) : new Date(nativeDate);
      stamp.hidden = !Number.isFinite(date.getTime());
      if (!stamp.hidden) {
        const label3 = dateLabel(date);
        if (stamp.textContent !== label3) stamp.textContent = label3;
        stamp.dateTime = date.toISOString();
        stamp.title = date.toLocaleString(document.documentElement.lang || void 0);
      }
      copy7.hidden = !data?.state.content.some((part) => part.type === "text" && part.text.trim());
      if (edit3.isConnected) {
        edit3.title = bubble.getAttribute("aria-label");
        edit3.setAttribute("aria-label", edit3.title);
        edit3.disabled = bubble.disabled;
      }
      updateCopy();
    };
    let copying = false;
    let clearCopied;
    copy7.addEventListener("click", async () => {
      if (copying || copy7.hasAttribute("data-copied")) return;
      const text = userMessage2(bubble, messageId)?.message.getCopyText();
      if (!text?.trim()) return;
      copying = true;
      try {
        const success = await ctx.os.writeClipboard(text);
        if (!row5.isConnected) return;
        if (!success) {
          host13.notify({ kind: "error", message: ctx.i18n.t("copyMessageError") });
          return;
        }
        copy7.setAttribute("data-copied", "");
        updateCopy();
        clearCopied = ctx.setTimeout(() => {
          copy7.removeAttribute("data-copied");
          updateCopy();
        }, 1500);
      } finally {
        copying = false;
      }
    });
    edit3.addEventListener("click", () => {
      if (bubble.isConnected && prompt2.dataset.messageId === messageId) {
        window.getSelection()?.removeAllRanges();
        bubble.click();
      }
    });
    const listeners = new AbortController();
    const options = { signal: listeners.signal };
    bar.addEventListener("pointerenter", update, options);
    bar.addEventListener("focusin", update, options);
    bar.addEventListener("contextmenu", (event) => {
      const native2 = holder.querySelector(restoreButton);
      const inActions = row5.contains(event.target);
      const inBubble = bubble.contains(event.target) && !committedFiber(holder)?.memoizedProps?.onContextMenu;
      if (!native2 || event.defaultPrevented || !inActions && !inBubble || window.getSelection()?.isCollapsed === false) return;
      event.preventDefault();
      event.stopPropagation();
      restoreTarget = native2;
      restoreFocus = event.target.closest("button") || bubble;
      restoreItem.textContent = native2.getAttribute("aria-label");
      menu.showPopover();
      const anchor = restoreFocus.getBoundingClientRect();
      const x = event.clientX || anchor.left;
      const y = event.clientY || anchor.bottom;
      menu.style.left = Math.max(8, Math.min(x, window.innerWidth - menu.offsetWidth - 8)) + "px";
      menu.style.top = Math.max(8, Math.min(y, window.innerHeight - menu.offsetHeight - 8)) + "px";
      restoreItem.focus({ preventScroll: true });
    }, options);
    holder.after(row5);
    update();
    return { row: row5, prompt: prompt2, messageId, bubble, update, remove() {
      clearCopied?.();
      listeners.abort();
      if (bar.contains(restoreFocus ?? null) || bar.contains(restoreTarget ?? null)) menu.hidePopover();
      row5.remove();
    } };
  }
  ctx.i18n.onLocaleChange(() => rows.forEach((state) => state.update()));
  ctx.onDispose(() => {
    rows.forEach((state) => state.remove());
    rows.clear();
    menu.remove();
    sheet.remove();
  });
  return function reconcile(enabled) {
    reconcileReplyTip(enabled);
    const current = new Set(enabled ? document.querySelectorAll(`${transcript4} ${promptSelector2} ${actionBar}`) : []);
    for (const [bar, state] of rows) {
      if (!current.has(bar) || !bar.contains(state.row) || !bar.contains(state.bubble) || state.prompt.dataset.messageId !== state.messageId) {
        state.remove();
        rows.delete(bar);
      }
    }
    for (const bar of current) {
      if (rows.has(bar)) continue;
      const bubble = bar.querySelector(bubbleSelector);
      const prompt2 = bar.closest(promptSelector2);
      const messageId = prompt2.dataset.messageId;
      if (bubble?.closest("[data-context-menu-skip]") && userMessage2(bubble, messageId)) {
        rows.set(bar, addRow(bar, bubble, prompt2, messageId));
      }
    }
  };
}

// source/chat-display.js
var viewportSelector = '[data-slot="aui_thread-viewport"]';
var promptSelector = '[data-slot="aui_user-message-root"][data-message-id]';
var bubbleSelector2 = "button.composer-human-message[aria-label]";
var clampSelector = ".sticky-human-clamp";
var previewSelector = "[data-hcv-message-preview]";
var toggleSelector = "[data-hcv-message-toggle]";
var focusable = 'a[href], button, input, select, textarea, summary, pre, [role="button"], [tabindex], [contenteditable]';
var editSelector = '[data-slot="aui_edit-composer-root"]';
var editFrame = ".ui-prompt-input__container.composer-human-message";
var editInput = '[contenteditable="true"][role="textbox"]';
var lineCount = 20;
var relaxed = 1.625;
var transitionMs = 200;
var fadeDistance = "1rem";
var labels9 = {
  en: { messageShowMore: "Show more", messageShowLess: "Show less", cancelEdit: "Cancel", sendEdit: "Send" },
  ru: { messageShowMore: "\u041F\u043E\u043A\u0430\u0437\u0430\u0442\u044C \u0435\u0449\u0451", messageShowLess: "\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C", cancelEdit: "\u041E\u0442\u043C\u0435\u043D\u0430", sendEdit: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C" }
};
function displayStyles(active2, chat3) {
  const viewport = `${active2} ${chat3} ${viewportSelector}`;
  const bubble = `${viewport} ${promptSelector} ${bubbleSelector2}:has(> ${clampSelector})`;
  const body2 = `${bubble} > ${clampSelector}`;
  const toggle2 = `${viewport} ${toggleSelector}`;
  const ellipsis = `${bubble} > [data-hcv-message-ellipsis]`;
  const frame = `${viewport} ${editSelector} [data-hcv-edit-controls]`;
  const docked2 = `${active2} ${chat3}:has([data-slot="composer-dock"]:not([data-popped-out]))`;
  const scrollJump = `${active2} ${chat3} [data-slot="composer-bounds"] > button.thread-jump-button:not([class~="border-primary/40"])`;
  const scrollJumpIcon = `${scrollJump} > .codicon-arrow-down`;
  const replyError = `${active2} ${chat3} [data-slot="aui_assistant-message-content"] > [role="alert"]:has(> div > .aui-error-action)`;
  const errorHeader = `${replyError} > div:first-child`;
  const errorHeadline = `${errorHeader} > div:first-child`;
  const errorClose = `${errorHeader} > button`;
  const errorDetails = `${errorHeadline} > details`;
  const errorSummary = `${errorDetails} > summary`;
  const errorActions = `${replyError} > div:last-child`;
  const errorButton = `${errorActions} > .aui-error-action`;
  const errorControls = `:is(${errorClose}, ${errorSummary}, ${errorButton})`;
  const modernError = `${active2} ${chat3} [data-slot="aui_error-card"][role="alert"]`;
  return `
@media (forced-colors: none) {
  /* Current Hermes error surface. Adapt the same Codex panel and quiet
     controls used below without replacing native actions or diagnostics. */
  ${modernError} {
    gap: 10px; margin-block-start: 8px; padding: 12px;
    border: 1px solid var(--hcv-hairline); border-radius: 16px;
    background: var(--hcv-panel); color: var(--hcv-text);
    font: 13px/18px var(--hcv-ui-font);
  }
  ${modernError} .aui-error-card-head { gap: 8px; }
  ${modernError} .aui-error-card-icon { color: var(--dt-destructive); }
  ${codexIconRules(`${modernError} .aui-error-card-icon`, "warning")}
  ${modernError} .aui-error-card-title { font-weight: 600; }
  ${modernError} .aui-error-card-body { color: var(--hcv-muted); }
  ${modernError} :is(.aui-error-action, .aui-error-card-toggle, .aui-error-card-close, .aui-error-details-link) {
    border-radius: 8px; font-size: 12px; line-height: 16px;
    color: var(--hcv-muted);
  }
  ${modernError} .aui-error-action { background: var(--hcv-selected); color: var(--hcv-text); }
  ${modernError} .aui-error-details-slab { background: var(--hcv-chat); color: var(--hcv-muted); border-radius: 8px; }
  ${modernError} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${codexIconRules(`${modernError} .aui-error-card-close > svg`, "close")}
  @media (hover: hover) {
    ${modernError} button:hover:not(:disabled) { background: var(--hcv-hover-menu); color: var(--hcv-text); }
  }
  ${replyError} {
    gap: 10px;
    margin-block-start: 8px;
    padding: 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 16px;
    background: var(--hcv-panel);
    color: var(--hcv-text);
    font: 13px/18px var(--hcv-ui-font);
  }
  ${errorHeader} { gap: 8px; }
  ${errorHeader}::before {
    content: "";
    flex: 0 0 16px;
    block-size: 16px;
    margin-block-start: 1px;
    background-color: var(--dt-destructive);
    mask: ${codexMask("warning")} center / contain no-repeat;
  }
  ${errorHeadline} > div:first-child { font-weight: 600; }
  ${errorHeadline} > div + div { margin-block-start: 2px; color: var(--hcv-muted); }
  ${errorDetails} { margin-block-start: 4px; opacity: 1; }
  ${errorSummary} {
    display: flex;
    align-items: center;
    gap: 4px;
    inline-size: fit-content;
    margin-inline-start: -5px;
    padding: 3px 5px;
    border-radius: 8px;
    color: var(--hcv-muted);
    font-size: 12px;
    line-height: 16px;
    list-style: none;
  }
  ${errorSummary}::-webkit-details-marker { display: none; }
  ${errorSummary}::before {
    content: "";
    flex: 0 0 12px;
    block-size: 12px;
    background-color: currentColor;
    mask: ${codexMask("right")} center / contain no-repeat;
  }
  ${errorDetails}[open] > summary::before { rotate: 90deg; }
  ${errorDetails} > div {
    max-block-size: min(12rem, 35vh);
    margin-block-start: 4px;
    overflow: auto;
    padding: 8px;
    border-radius: 8px;
    background: var(--hcv-chat);
    color: var(--hcv-muted);
    font-size: 12px;
    line-height: 17px;
  }
  ${errorActions} { gap: 4px; padding-inline-start: 24px; }
  ${errorButton} {
    min-block-size: 26px;
    max-inline-size: 100%;
    padding: 4px 8px;
    border: 0;
    border-radius: 8px;
    color: var(--hcv-muted);
    font-size: 12px;
    line-height: 16px;
    text-align: start;
    white-space: normal;
  }
  ${errorButton} > svg { flex: none; }
  ${errorButton}:has(> svg.tabler-icon-refresh) { background: var(--hcv-selected); color: var(--hcv-text); }
  ${errorClose} {
    inline-size: 24px;
    block-size: 24px;
    margin-block: -2px 0;
    margin-inline: 0 -2px;
    border-radius: 8px;
    color: var(--hcv-muted);
    opacity: 1;
  }
  ${errorControls}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${codexIconRules(`${errorButton} > svg.tabler-icon-refresh`, "refresh")}
  ${codexIconRules(`${errorButton} > svg.tabler-icon-upload`, "upload")}
  ${codexIconRules(`${errorButton} > svg.tabler-icon-copy`, "copy")}
  ${codexIconRules(`${errorClose} > svg.tabler-icon-x`, "close")}
  @media (hover: hover) {
    ${errorControls}:hover:not(:disabled) { background: var(--hcv-hover-menu); color: var(--hcv-text); }
  }

  /* Codex 26.1111.2228.0: 344734.3322725bda.js uses native thin gutters.
     The overflow-y-auto rules in 66582da7ee6b.css use the border tokens. */
  ${viewport} {
    mask-image: linear-gradient(to bottom, transparent 0, black ${fadeDistance}, black 100%);
    scrollbar-width: thin;
    scrollbar-gutter: stable both-edges;
      scrollbar-color: light-dark(rgb(26 28 31 / 7.8%), rgb(255 255 255 / 8.4%)) transparent;
  }
  ${viewport}:is(:hover, :active) {
      scrollbar-color: light-dark(rgb(26 28 31 / 11.7%), rgb(255 255 255 / 15.6%)) transparent;
  }
  /* wqAy.R and vFsk.w in Codex 344734.3322725bda.js. Keep Hermes's
     measured dock height so the gap also clears its status stack. */
  ${scrollJump} {
    bottom: calc(var(--composer-measured-height) + 1.5rem) !important;
    inline-size: 2rem;
    block-size: 2rem;
    justify-content: center;
    gap: 0;
    padding: 0;
    border: 1px solid light-dark(rgb(26 28 31 / 8%), rgb(255 255 255 / 8%));
    border-radius: 50%;
    background: var(--hcv-chat) padding-box;
    color: light-dark(#1a1c1f, #dfdfdf);
    box-shadow: 0px 2px 4px -1px #00000014;
    backdrop-filter: none;
    cursor: default;
    opacity: 0;
    transform: translateX(-50%);
    animation: none;
    transition: opacity 120ms cubic-bezier(0, 0, .2, 1);
  }
  ${scrollJump}[aria-hidden="false"] { opacity: 1; }
  ${scrollJump}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 2px; }
  ${scrollJump} > span { display: none; }
  ${scrollJumpIcon} { flex: none; inline-size: 20px; block-size: 20px; }
  ${codexIconRules(scrollJumpIcon, "scrollToBottom")}
  @media (prefers-reduced-motion: reduce) {
    ${scrollJump} { transition: none; }
  }
  @media (prefers-contrast: more) {
    ${viewport}, ${viewport}:is(:hover, :active) { scrollbar-color: CanvasText Canvas; }
  }
  /* Codex scrolls the user turn with the transcript. Hermes's clip observer
     can still see the old overlap for a frame on theme changes. */
  ${viewport} [data-slot="aui_user-message-root"] {
    position: relative;
    top: auto;
  }
  ${viewport} [data-sticky-prompt-clip] {
    clip-path: none;
  }
  /* The viewport already excludes the height above the docked editor (queue,
     status stack). Reserve the editor overlap once, plus 12px to its shell.
     Keep the native clearance element and its scroll anchor. */
  ${docked2} [data-slot="aui_thread-content"] {
    --thread-last-message-clearance: calc(var(--composer-surface-measured-height) + 4px);
  }
  ${docked2} [data-slot="aui_thread-content"] > [data-slot="aui_message-group"]:not(:has(~ [data-slot="aui_message-group"])) {
    padding-block-end: 0;
  }
  ${bubble} {
    --human-msg-line-height: ${relaxed};
    line-height: ${relaxed};
    overflow: clip;
  }
  ${body2}, ${body2}[data-clamped="true"] {
    max-height: calc(${lineCount}lh + 1px);
    overflow: clip;
    mask-image: none;
  }
  ${body2}${previewSelector} { max-height: var(--hcv-message-height); }
  ${bubble}:has(> ${previewSelector}) {
    row-gap: 0;
    padding-block-end: calc(10px + 10px + ${relaxed}em);
  }
  ${ellipsis} {
    block-size: 0;
    opacity: 0;
    overflow: hidden;
    user-select: none;
  }
  ${ellipsis}::before { content: '\u2026'; }
  ${body2}[data-hcv-message-preview="collapsed"] + [data-hcv-message-ellipsis] {
    block-size: 1lh;
    opacity: 1;
  }
  ${toggle2} {
    position: absolute;
    z-index: 11;
    inset-inline-start: 16px;
    inset-block-end: 10px;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 0;
    min-block-size: ${relaxed}em;
    border-radius: 4px;
    background: transparent;
    color: var(--hcv-text);
    font: inherit;
    font-size: var(--conversation-text-font-size);
    line-height: ${relaxed};
    cursor: pointer;
    -webkit-app-region: no-drag;
  }
  ${toggle2}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 3px; }
  ${toggle2}::after {
    content: '';
    inline-size: 14px;
    block-size: 14px;
    background: currentColor;
    mask: ${codexMask("down")} center / contain no-repeat;
  }
  ${toggle2}[aria-expanded="true"]::after { rotate: 180deg; }
  /* y5H2 uses rounded-3xl and 12px padding; see 9ec44337a842.css. */
  ${viewport} ${editSelector} .composer-human-message-container {
    --hcv-edit-radius: 20px;
    border-radius: var(--hcv-edit-radius);
    corner-shape: superellipse(1.5);
    background: transparent;
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${viewport} ${editSelector} .composer-human-message-container { --hcv-edit-radius: 25px; }
  }
  ${frame} {
    display: grid;
    grid-template-columns: minmax(0, 1fr) auto auto;
    gap: 8px 6px;
    min-block-size: 0;
    padding: 12px;
    overflow: visible;
    border: 0;
    border-radius: var(--hcv-edit-radius, 20px);
    corner-shape: superellipse(1.5);
    background: light-dark(color-mix(in oklab, var(--hcv-text) 5%, transparent), var(--hcv-bubble));
  }
  ${frame} > ${editInput} {
    grid-column: 1 / -1;
    grid-row: 1;
    min-block-size: 1lh;
    max-block-size: min(40vh, 24rem);
    padding: 0;
    color: var(--hcv-text);
    font-size: 14px;
    line-height: 21px;
    overscroll-behavior: contain;
  }
  ${frame}:has(> ${editInput}:focus-visible) {
    outline: 2px solid var(--hcv-focus);
    outline-offset: 1px;
  }
  ${frame} > :is([data-hcv-edit-cancel], [data-hcv-edit-send]) {
    display: inline-flex;
    position: relative;
    inset: auto;
    grid-row: 2;
    align-items: center;
    justify-content: center;
    min-block-size: 28px;
    block-size: auto;
    inline-size: auto;
    padding: 2px 12px;
    border: 1px solid var(--hcv-stroke);
    border-radius: 999px;
    font: inherit;
    font-size: 12px;
    cursor: pointer;
  }
  ${frame} > [data-hcv-edit-cancel] { grid-column: 2; color: var(--hcv-text); }
  ${frame} > [data-hcv-edit-cancel]:hover { background: var(--hcv-hover); }
  ${frame} > [data-hcv-edit-send] {
    grid-column: 3;
    border-color: transparent;
    background: var(--hcv-action);
    color: var(--hcv-ink);
  }
  ${frame} > [data-hcv-edit-send]:disabled { opacity: .5; cursor: default; }
  ${frame} > [data-hcv-edit-send]:not(:disabled):hover { filter: brightness(.88); }
  ${frame} > [data-hcv-edit-send] > .codicon-arrow-up { display: none; }
  ${frame} > [data-hcv-edit-send]::after { content: attr(data-hcv-edit-send); }
  ${frame} > :is([data-hcv-edit-cancel], [data-hcv-edit-send]):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: 2px;
  }
  @media (hover: hover) and (pointer: fine) {
    ${toggle2}:hover { color: var(--hcv-muted); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${body2}${previewSelector} { transition: max-height ${transitionMs}ms cubic-bezier(.23, 1, .32, 1); }
    ${ellipsis} {
      transition: block-size ${transitionMs}ms cubic-bezier(.23, 1, .32, 1), opacity 120ms var(--hcv-ease);
    }
    ${toggle2}::after { transition: rotate 150ms var(--hcv-ease); }
  }
}
`;
}
function previewHeight(body2, lineHeight) {
  let limit = Math.ceil(lineHeight * (lineCount - 1));
  const fences = body2.querySelectorAll('[data-slot="aui_user-fence"]');
  if (!fences.length) return limit;
  const bounds = body2.getBoundingClientRect();
  const scale = bounds.height / body2.offsetHeight || 1;
  for (const fence of fences) {
    const rect = fence.getBoundingClientRect();
    const top = (rect.top - bounds.top) / scale;
    const bottom = (rect.bottom - bounds.top) / scale;
    if (top < limit && bottom > limit) limit = Math.ceil(bottom);
  }
  return limit;
}
function syncPreviewFocus(state) {
  for (const node3 of state.inert) node3.removeAttribute("inert");
  state.inert.clear();
  if (state.expanded) return;
  const controls2 = state.body.querySelectorAll(focusable);
  if (!controls2.length) return;
  const bounds = state.body.getBoundingClientRect();
  const scale = bounds.height / state.body.offsetHeight || 1;
  const bottom = bounds.top + state.previewHeight * scale;
  for (const node3 of controls2) {
    if (node3.closest("[inert]")) continue;
    const rect = node3.getBoundingClientRect();
    if (node3.matches("a[href]") ? rect.top >= bottom : rect.bottom > bottom) {
      node3.setAttribute("inert", "");
      state.inert.add(node3);
    }
  }
}
function keepToggleVisible(state) {
  if (document.activeElement !== state.toggle) return;
  const toggle2 = state.toggle.getBoundingClientRect();
  const view = state.viewport.getBoundingClientRect();
  const top = view.top + 16;
  if (toggle2.top < top) state.viewport.scrollTop += toggle2.top - top;
  else if (toggle2.bottom > view.bottom) state.viewport.scrollTop += toggle2.bottom - view.bottom;
}
function registerChatDisplay(ctx, active2) {
  const chat3 = "[data-chat-surface]:not([data-hud-shell] *)";
  const messageActions = registerMessageActions(ctx, active2, `${chat3} ${viewportSelector}`, promptSelector);
  const innerSelector = `${chat3} ${viewportSelector} ${promptSelector} ${bubbleSelector2} > ${clampSelector} > div`;
  const editorSelector2 = `${chat3} ${viewportSelector} ${editSelector} ${editFrame}`;
  const root = document.documentElement;
  const forcedColors = matchMedia("(forced-colors: active)");
  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)");
  const states = /* @__PURE__ */ new Map();
  const editors = /* @__PURE__ */ new Map();
  let nextId = 0;
  let frame = 0;
  const stylesheet = document.createElement("style");
  stylesheet.setAttribute("data-hcv-chat-display", "");
  stylesheet.textContent = displayStyles(active2, chat3);
  mountStyle(ctx, stylesheet, chatStyles);
  ctx.i18n.register(labels9);
  function label3(state) {
    if (!state.toggle) return;
    const text = ctx.i18n.t(state.expanded ? "messageShowLess" : "messageShowMore");
    if (state.toggle.textContent !== text) state.toggle.textContent = text;
  }
  function show(state) {
    const value = state.expanded ? "expanded" : "collapsed";
    state.clamp.setAttribute("data-hcv-message-preview", value);
    state.clamp.style.setProperty(
      "--hcv-message-height",
      `${state.expanded ? state.fullHeight : state.previewHeight}px`
    );
    state.toggle.setAttribute("aria-expanded", String(state.expanded));
    label3(state);
    syncPreviewFocus(state);
  }
  function removeDisclosure(state) {
    clearTimeout(state.closeTimer);
    state.toggle?.remove();
    state.toggle = null;
    state.ellipsis?.remove();
    if (state.clamp.id === state.assignedId) state.clamp.removeAttribute("id");
    state.clamp.removeAttribute("data-hcv-message-preview");
    state.clamp.style.removeProperty("--hcv-message-height");
    for (const node3 of state.inert) node3.removeAttribute("inert");
    state.inert.clear();
    state.expanded = false;
  }
  function addDisclosure(state) {
    const toggle2 = document.createElement("button");
    toggle2.type = "button";
    toggle2.setAttribute("data-hcv-message-toggle", "");
    if (!state.clamp.id) {
      state.assignedId = `hcv-message-preview-${++nextId}`;
      state.clamp.id = state.assignedId;
    }
    toggle2.setAttribute("aria-controls", state.clamp.id);
    const ellipsis = document.createElement("span");
    ellipsis.setAttribute("data-hcv-message-ellipsis", "");
    ellipsis.setAttribute("aria-hidden", "true");
    state.toggle = toggle2;
    state.ellipsis = ellipsis;
    state.clamp.after(ellipsis);
    state.clamp.parentElement.after(toggle2);
    toggle2.addEventListener("click", () => {
      clearTimeout(state.closeTimer);
      state.expanded = !state.expanded;
      show(state);
      if (!state.expanded) {
        if (reducedMotion.matches) keepToggleVisible(state);
        else state.closeTimer = setTimeout(() => keepToggleVisible(state), transitionMs);
      }
    });
  }
  function measure(state) {
    if (!state.body.getClientRects().length || !state.viewport.clientHeight) return;
    const lineHeight = Number.parseFloat(getComputedStyle(state.clamp).lineHeight);
    if (!Number.isFinite(lineHeight)) return;
    const fullHeight = state.body.scrollHeight;
    if (!fullHeight) return;
    if (fullHeight <= Math.ceil(lineHeight * lineCount) + 1) {
      if (state.toggle) removeDisclosure(state);
      return;
    }
    state.fullHeight = fullHeight;
    state.previewHeight = previewHeight(state.body, lineHeight);
    if (!state.toggle) addDisclosure(state);
    show(state);
  }
  const sizes = new ResizeObserver((entries) => {
    for (const { target } of entries) {
      const state = states.get(target);
      if (state) measure(state);
    }
  });
  function detach(state) {
    sizes.unobserve(state.body);
    removeDisclosure(state);
    states.delete(state.body);
  }
  function updateEditLabels({ cancel, send: send2 }) {
    cancel.textContent = ctx.i18n.t("cancelEdit");
    send2.setAttribute("data-hcv-edit-send", ctx.i18n.t("sendEdit"));
  }
  function enhanceEdit(container, input, send2) {
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.setAttribute("data-hcv-edit-cancel", "");
    const group2 = container.closest('[data-slot="aui_message-group"]');
    const thread = group2?.parentElement;
    const groupIndex = thread ? [...thread.children].indexOf(group2) : -1;
    let pending = 0;
    cancel.addEventListener("click", () => {
      if (pending) return;
      const escape = () => {
        const handler = committedFiber(input)?.memoizedProps?.onKeyDown;
        if (typeof handler !== "function" || !input.isConnected) return;
        const event = new KeyboardEvent("keydown", { key: "Escape", cancelable: true });
        handler({ key: "Escape", currentTarget: input, nativeEvent: event, preventDefault: () => event.preventDefault() });
      };
      const suggestionOpen = Boolean(container.parentElement.querySelector('[role="listbox"]'));
      escape();
      pending = requestAnimationFrame(() => {
        if (suggestionOpen && input.isConnected) escape();
        pending = requestAnimationFrame(restoreFocus);
      });
      function restoreFocus() {
        pending = 0;
        if (input.isConnected || !thread?.isConnected) return;
        const replacement = group2.isConnected ? group2 : thread.children.item(groupIndex);
        replacement?.querySelector(bubbleSelector2)?.focus({ preventScroll: true });
      }
    });
    const state = { cancel, input, send: send2, dispose() {
      if (container.isConnected) cancelAnimationFrame(pending);
      cancel.remove();
      send2.removeAttribute("data-hcv-edit-send");
      container.removeAttribute("data-hcv-edit-controls");
    } };
    updateEditLabels(state);
    container.setAttribute("data-hcv-edit-controls", "");
    send2.before(cancel);
    return state;
  }
  function reconcile() {
    frame = 0;
    const enabled = root.matches(active2) && !forcedColors.matches;
    messageActions(enabled);
    const current = new Set(enabled ? document.querySelectorAll(innerSelector) : []);
    const currentEditors = new Set(enabled ? document.querySelectorAll(editorSelector2) : []);
    for (const [container, state] of editors) {
      if (!currentEditors.has(container) || !container.contains(state.input) || !container.contains(state.send)) {
        state.dispose();
        editors.delete(container);
      }
    }
    for (const container of currentEditors) {
      if (editors.has(container)) continue;
      const input = container.querySelector(`:scope > ${editInput}`);
      const send2 = container.querySelector(":scope > button[aria-label]:has(> .codicon-arrow-up)");
      if (input && send2) editors.set(container, enhanceEdit(container, input, send2));
    }
    for (const state of states.values()) {
      if (!current.has(state.body) || state.messageId !== state.prompt.dataset.messageId) detach(state);
    }
    for (const body2 of current) {
      if (states.has(body2)) continue;
      const viewport = body2.closest(viewportSelector);
      const prompt2 = body2.closest(promptSelector);
      const state = {
        body: body2,
        viewport,
        prompt: prompt2,
        messageId: prompt2.dataset.messageId,
        clamp: body2.parentElement,
        expanded: false,
        inert: /* @__PURE__ */ new Set()
      };
      states.set(body2, state);
      sizes.observe(body2);
    }
  }
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(reconcile);
  };
  const observer = new MutationObserver((records) => {
    if (records.some((record) => {
      if (record.type === "attributes") return record.target === root || record.target.matches(promptSelector);
      if (!root.matches(active2)) return false;
      if (record.target.closest?.(editSelector)) {
        return record.target.matches(editFrame) || record.target.matches(editSelector);
      }
      if (record.target.closest?.(promptSelector) && !record.target.closest(toggleSelector)) return true;
      return [...record.addedNodes, ...record.removedNodes].some(
        (node3) => node3.nodeType === Node.ELEMENT_NODE && (node3.matches(`${promptSelector}, ${viewportSelector}, ${editSelector}`) || node3.querySelector(`${promptSelector}, ${viewportSelector}, ${editSelector}`))
      );
    })) schedule();
  });
  observer.observe(root, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ["data-hermes-theme", "data-hermes-codex-visual", "data-message-id"]
  });
  forcedColors.addEventListener("change", schedule);
  ctx.i18n.onLocaleChange(() => {
    for (const state of states.values()) label3(state);
    for (const state of editors.values()) updateEditLabels(state);
  });
  ctx.onDispose(() => {
    observer.disconnect();
    cancelAnimationFrame(frame);
    forcedColors.removeEventListener("change", schedule);
    for (const state of states.values()) detach(state);
    for (const state of editors.values()) state.dispose();
    editors.clear();
    sizes.disconnect();
    stylesheet.remove();
  });
  schedule();
}

// source/chat-file-links.js
var scope2 = '[data-chat-surface]:not([data-hud-shell] *) [data-slot="aui_assistant-message-content"] .aui-md';
var marked = "[data-hcv-file-reference]";
var control2 = "[data-hcv-file-reference-control]";
var secondary = "[data-hcv-file-reference-secondary]";
function textOf(value, depth = 0) {
  if (typeof value === "string" || typeof value === "number") return String(value);
  if (depth > 5) return "";
  if (Array.isArray(value)) return value.map((child) => textOf(child, depth + 1)).join("");
  return textOf(value?.props?.children, depth + 1);
}
function nativeControls(card2) {
  const buttons = [...card2.querySelectorAll(":scope > button:not([data-hcv-file-reference-control])")];
  return buttons.length === 2 ? { secondary: buttons[0], preview: buttons[1] } : null;
}
function referenceInfo(card2) {
  const actions = nativeControls(card2);
  if (!actions) return null;
  let target = "";
  for (let node3 = committedFiber(card2)?.return; node3 && !(node3.stateNode instanceof Element); node3 = node3.return) {
    const props = node3.memoizedProps;
    if (typeof props?.target === "string") target ||= props.target;
    if (!target || typeof props?.href !== "string") continue;
    const href = props.href;
    const label3 = textOf(props.children).trim();
    if (!/^(?:#preview[:/]|file:|\/(?!\/)|~\/|[a-z]:[\\/]|\\\\)/i.test(href) || !/^(?:file:|\/(?!\/)|~\/|[a-z]:[\\/]|\\\\)/i.test(target) || /^preview\s*:/i.test(label3) || /(?:^|[\\/])SKILL\.md$/i.test(target)) return null;
    return { target, label: label3 || card2.querySelector(":scope > span[title]")?.textContent.trim() || "", ...actions };
  }
  return null;
}
function registerChatFileLinks(ctx, active2, candidate2) {
  const cardCSS = `${active2} ${scope2} ${marked}`;
  const linkCSS = `${cardCSS} > ${control2}`;
  const secondaryCSS = `${cardCSS} > ${secondary}`;
  mountCSS(ctx, "data-hcv-chat-file-reference-style", `
    ${cardCSS} { display: contents !important; }
    ${cardCSS} > :not(${control2}):not(${secondary}) { display: none !important; }
    ${linkCSS} {
      display: inline; padding: 0; border: 0; background: transparent;
      color: light-dark(#0169cc, #99ceff); font: inherit; font-weight: 500;
      text-align: start; white-space: normal; cursor: pointer;
    }
    ${linkCSS} > [data-hcv-file-reference-label] { overflow-wrap: break-word; }
    ${linkCSS} > [aria-hidden="true"] {
      box-sizing: content-box; vertical-align: middle; align-items: center; display: inline-flex;
      block-size: 1em; padding-inline-end: 3px; transform: translateY(calc(.5ex - .5cap));
    }
    ${linkCSS} > [aria-hidden="true"]::before {
      content: ""; inline-size: 16px; block-size: 16px; background: currentColor;
      mask: ${codexMask("inlineFileDocument")} center / contain no-repeat;
    }
    ${linkCSS}:is(:hover, :focus-visible) > [data-hcv-file-reference-label] {
      text-decoration: underline dashed .5px; text-underline-offset: 2px;
    }
    ${linkCSS}:focus-visible, ${secondaryCSS}:focus-visible {
      outline: 2px solid var(--hcv-focus); outline-offset: 2px; border-radius: 2px;
    }
    ${linkCSS}:disabled { cursor: default; opacity: .6; }
    ${secondaryCSS} {
      display: inline-flex !important; visibility: hidden; opacity: 0 !important;
      pointer-events: none !important; inline-size: 0; block-size: 0; min-inline-size: 0;
      min-block-size: 0; margin: 0; padding: 0 !important;
      border: 0; background: transparent; color: var(--hcv-muted); font-size: 0; line-height: 0;
      vertical-align: middle; align-items: center; justify-content: center; overflow: hidden;
    }
    ${cardCSS}:is(:hover, :focus-within) > ${secondary} {
      visibility: visible; opacity: 1 !important; pointer-events: auto !important;
      inline-size: 20px; block-size: 20px; margin-inline-start: 3px;
    }
    ${secondaryCSS} > svg { inline-size: 14px; block-size: 14px; flex: none; }
  `, chatStyles);
  const pending = /* @__PURE__ */ new Set();
  const forcedColors = window.matchMedia("(forced-colors: active)");
  let frame = 0;
  let connected = false;
  function clear(card2) {
    card2.querySelector(`:scope > ${control2}`)?.remove();
    for (const node3 of card2.querySelectorAll(`:scope > ${secondary}`)) node3.removeAttribute("data-hcv-file-reference-secondary");
    card2.removeAttribute("data-hcv-file-reference");
  }
  function update(card2) {
    const info = referenceInfo(card2);
    if (!info?.label) return clear(card2);
    let button5 = card2.querySelector(`:scope > ${control2}`);
    if (!button5) {
      button5 = document.createElement("button");
      button5.type = "button";
      button5.setAttribute("data-hcv-file-reference-control", "");
      const icon8 = document.createElement("span");
      icon8.setAttribute("aria-hidden", "true");
      const label3 = document.createElement("span");
      label3.setAttribute("data-hcv-file-reference-label", "");
      button5.append(icon8, label3);
      button5.addEventListener("click", (event) => {
        if (event.detail > 0 && document.getSelection()?.isCollapsed === false) return;
        nativeControls(card2)?.preview.click();
      });
      card2.insertBefore(button5, info.secondary);
    }
    for (const node3 of card2.querySelectorAll(`:scope > ${secondary}`)) {
      if (node3 !== info.secondary) node3.removeAttribute("data-hcv-file-reference-secondary");
    }
    info.secondary.setAttribute("data-hcv-file-reference-secondary", "");
    button5.disabled = info.preview.disabled;
    button5.title = info.target;
    if (button5.lastChild.textContent !== info.label) button5.lastChild.textContent = info.label;
    card2.setAttribute("data-hcv-file-reference", "");
  }
  function queueCard(node3) {
    const element7 = node3 instanceof Element ? node3 : node3?.parentElement;
    if (!element7 || element7.closest(control2)) return;
    const card2 = element7.closest(`:is(${candidate2}, ${marked})`);
    if (card2?.closest(scope2)) pending.add(card2);
  }
  function collect(node3) {
    if (!(node3 instanceof Element) || node3.closest(control2)) return;
    queueCard(node3);
    if (node3.closest(scope2) || node3.querySelector(scope2)) {
      for (const item of node3.querySelectorAll(candidate2)) if (item.closest(scope2)) pending.add(item);
    }
  }
  function flush() {
    frame = 0;
    for (const card2 of pending) if (card2.isConnected && card2.closest(scope2)) update(card2);
    pending.clear();
  }
  function schedule() {
    if (pending.size && !frame) frame = requestAnimationFrame(flush);
  }
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      const node3 = record.target instanceof Element ? record.target : record.target.parentElement;
      if (node3?.closest(control2)) continue;
      queueCard(node3);
      if (record.type === "childList") for (const added of record.addedNodes) collect(added);
    }
    schedule();
  });
  function sync() {
    const enabled = document.documentElement.matches(active2) && !forcedColors.matches;
    if (connected === enabled) return;
    connected = enabled;
    observer.disconnect();
    cancelAnimationFrame(frame);
    frame = 0;
    pending.clear();
    if (enabled) {
      collect(document.body);
      schedule();
      observer.observe(document.body, {
        childList: true,
        characterData: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["title", "disabled"]
      });
    } else {
      for (const card2 of document.querySelectorAll(marked)) clear(card2);
    }
  }
  const theme2 = new MutationObserver(sync);
  theme2.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.addEventListener(forcedColors, "change", sync);
  sync();
  ctx.onDispose(() => {
    observer.disconnect();
    theme2.disconnect();
    cancelAnimationFrame(frame);
    pending.clear();
    for (const card2 of document.querySelectorAll(marked)) clear(card2);
  });
}

// source/chat-images.js
var chat = "[data-chat-surface]:not([data-hud-shell] *)";
var attachments = '[data-slot="composer-attachments"]';
var nativePill = 'div[class~="group/attachment"]';
var picture = "> button:first-child > span:first-child > :is(img, svg.tabler-icon-photo)";
var pill = `${nativePill}:has(${picture})`;
var row2 = '[data-tool-row][data-slot="tool-block"]';
var group = '[data-tool-group][data-slot="tool-block"]';
var summary = "[data-tool-summary]";
var analysis = "[data-hcv-viewed-image]";
var analysisGroup = "[data-hcv-viewed-image-group]";
var strip = "[data-hcv-image-strip]";
var label = "[data-hcv-viewed-image-label]";
var stepTitle = '[class~="text-(--conversation-scaffold-text)"]';
var nativeDialog = '[data-slot="dialog-content"][data-variant="media-lightbox"]';
var enhanced = "[data-hcv-image-viewer]";
var lightboxImage = 'div[class~="group/lightbox"] > img';
var zoom = 'div[class~="fixed"][class~="bottom-4"]';
var close = "[data-hcv-image-close]";
var pager = "[data-hcv-image-page]";
var scrim = '[data-slot="dialog-overlay"]';
var dialogFocusRestored = "focusScope.autoFocusOnUnmount";
function mask(name, fallback) {
  const original = localAssets?.icons[name];
  if (original) return svgMask(original);
  return fallback === "minus" ? svgMask('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 12h14" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>') : codexMask(fallback);
}
var viewedLabel = (count, ru) => {
  if (!ru) return count === 1 ? "Viewed an image" : `Viewed ${count} images`;
  if (count === 1) return "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435";
  const plural = new Intl.PluralRules("ru").select(count);
  return `\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E ${count} ${{ one: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435", few: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F", many: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439" }[plural]}`;
};
var disclosureButton = (step2) => step2.querySelector(":scope > :first-child button[aria-expanded]");
var successfulVision = (entry) => {
  const part = committedFiber(entry)?.return?.memoizedProps?.part;
  const toggle2 = disclosureButton(entry);
  return part?.toolName === "vision_analyze" && part.result !== void 0 && !part.isError && !part.interrupted && toggle2 && !toggle2.querySelector('svg[aria-label], [role="status"]');
};
function hasPhotoOnly(entry) {
  const output = entry.children[1];
  return output?.querySelector(':scope > div > [data-slot="aui_markdown-image"]') && Array.from(output.children).every((child) => child.matches("button") || child.querySelector(':scope > [data-slot="aui_markdown-image"]'));
}
function viewerOwner(dialog2) {
  let changeOpen, kind;
  for (let fiber = committedFiber(dialog2); fiber; fiber = fiber.return) {
    const props = fiber.memoizedProps;
    if (!changeOpen && props?.copy?.resetZoom && typeof props.onOpenChange === "function") changeOpen = props.onOpenChange;
    if (!changeOpen) continue;
    if (props?.attachment?.kind === "image") kind = "draft";
    if (props?.part?.toolName === "vision_analyze") kind = "activity";
    if (kind && fiber.stateNode instanceof Element && fiber.stateNode.matches(kind === "draft" ? '[data-slot="composer-surface"]:not([data-hud-shell] *)' : chat)) {
      return { kind, changeOpen };
    }
  }
  return null;
}
function registerChatImages(ctx, active2) {
  const root = document.documentElement;
  const composer2 = `${active2} [data-slot="composer-surface"]:not([data-hud-shell] *)`;
  const rail = `${composer2} ${attachments}:has(> ${nativePill} ${picture})`;
  const card2 = `${composer2} ${attachments} > ${pill}`;
  const open = `${card2} > button:first-child`;
  const remove = `${card2} > button:nth-child(2)`;
  const step2 = `${active2} ${chat} ${row2}${analysis}`;
  const run = `${active2} ${chat} ${group}${analysisGroup}`;
  const header2 = `:is(${step2} > div:first-child, ${run} > ${summary})`;
  const toggle2 = `${header2} > div > button[aria-expanded]`;
  const caret = `${toggle2} > span:nth-child(2) > .codicon-chevron-right`;
  const stepLabel = `${header2} ${label}`;
  const rowIcon = `${step2} > div:first-child span.self-center > :is(svg, .codicon)`;
  const body2 = `${step2}[data-tool-open] > div:nth-child(2)`;
  const thumb2 = `${body2} > div > [data-slot="aui_markdown-image"]`;
  const gallery = `${run} > ${summary}:has(button[aria-expanded="true"]) + ${strip}`;
  const dialog2 = `${active2} ${nativeDialog}${enhanced}`;
  const save = `${dialog2} div[class~="group/lightbox"] > button`;
  const exit = `${dialog2} > ${close}`;
  const turnPage = `${dialog2} > ${pager}`;
  const zoomBar = `${dialog2} > ${zoom}`;
  const draft = `${dialog2}[data-hcv-image-viewer="draft"]`;
  const activity = `${dialog2}[data-hcv-image-viewer="activity"]`;
  const buttons = `${dialog2} :where(div[class~="group/lightbox"] > button, ${close}, ${pager})`;
  const symbol = (selector, glyph3, fallback, size) => `
    ${selector}::before {
      content: ""; display: block; inline-size: ${size}px; block-size: ${size}px;
      background: currentColor; mask: ${mask(glyph3, fallback)} center / contain no-repeat;
    }`;
  mountCSS(ctx, "data-hcv-chat-images", `
    ${close}, ${pager}, ${label} { display: none; }
    @media (forced-colors: none) {
      ${rail} {
        flex-wrap: nowrap; align-items: end; gap: 8px; padding: 4px;
        overflow-x: auto; overflow-y: hidden; scrollbar-width: none;
      }
      ${card2} { inline-size: 122px; block-size: 122px; border-radius: 10px; }
      ${open} {
        display: block; position: relative; inline-size: 100%; block-size: 100%;
        border: 0; padding: 0; border-radius: inherit; overflow: hidden;
        background: var(--hcv-hover); box-shadow: none;
      }
      ${open} > span:first-child {
        inline-size: 100%; block-size: 100%; border: 0; border-radius: inherit; background: transparent;
      }
      ${open} > span:nth-child(2) { display: none; }
      ${open} > span:first-child > img { display: block; inline-size: 100%; block-size: 100%; object-fit: cover; }
      ${open}::after {
        content: ""; position: absolute; inset: 0; border-radius: inherit; pointer-events: none;
        box-shadow: inset 0 0 0 1px light-dark(#0d0d0d1a, #ffffff1a);
      }
      ${card2}:is(:hover, :focus-within) > button:first-child::after {
        background: color-mix(in srgb, var(--hcv-text) 5%, transparent);
        box-shadow: inset 0 0 0 1px light-dark(#0d0d0d26, #fff3);
      }
      ${remove} {
        inset: -2px -2px auto auto; inline-size: 16px; block-size: 16px;
        border: 0; background: var(--hcv-text); color: var(--hcv-composer);
        box-shadow: 0 0 0 2px var(--hcv-bg, var(--hcv-composer)), 0 1px 2px -1px #00000014;
        opacity: 0; pointer-events: none; transition: none;
      }
      ${remove}:hover { background: color-mix(in srgb, var(--hcv-text) 80%, transparent); color: var(--hcv-composer); }
      ${card2}:hover > button:nth-child(2), ${card2}:has(:focus-visible) > button:nth-child(2) {
        opacity: 1; pointer-events: auto;
      }
      ${remove} > * { display: none; }
      ${symbol(remove, "composerRemoveImage", "close", 12)}
      ${open}:focus-visible, ${remove}:focus-visible {
        outline: 2px solid var(--hcv-focus); outline-offset: -2px;
      }
      @media (hover: none) { ${remove} { opacity: 1; pointer-events: auto; } }
      ${active2} [data-hcv-image-path-tip] { visibility: hidden; }

      ${header2} { --conversation-scaffold-text: light-dark(#6c6c6c, #8b8b8b); opacity: 1; }
      ${toggle2} { align-items: center; gap: 4px; border-radius: 8px; }
      ${toggle2} > span:first-child > span:first-child { gap: 8px; }
      ${stepLabel} {
        display: block; min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        color: var(--conversation-scaffold-text);
      }
      ${stepLabel} ~ ${stepTitle} { display: none; }
      ${rowIcon} {
        mask: ${mask("viewedImages", "image")} center / contain no-repeat;
        color: light-dark(#6c6c6c, #8b8b8b);
      }
      ${run} > ${summary} ${label} { position: relative; padding-inline-start: 24px; }
      ${symbol(`${run} > ${summary} ${label}`, "viewedImages", "image", 16)}
      ${run} > ${summary} ${label}::before {
        position: absolute; inset-inline-start: 0; inset-block-start: 50%; translate: 0 -50%;
        color: light-dark(#6c6c6c, #8b8b8b);
      }
      ${caret} {
        inline-size: 14px !important; block-size: 14px !important;
        color: var(--conversation-scaffold-text);
        mask: ${mask("viewedImageChevron", "right")} center / contain no-repeat;
        rotate: none; transform: rotate(0deg);
        transition: transform 300ms var(--hcv-ease);
      }
      ${toggle2}[aria-expanded="true"] > span:nth-child(2) > .codicon-chevron-right { transform: rotate(90deg); }
      ${toggle2}[aria-expanded="false"]:not(:hover, :focus-visible) > span:nth-child(2) { opacity: 0; }
      ${toggle2}[aria-expanded="true"] > span:nth-child(2) { opacity: 1; }
      ${body2} { margin-block-start: 8px; padding-block-end: 4px; }
      ${thumb2} {
        inline-size: 80px !important; block-size: 80px; margin: 0;
        border: 1px solid light-dark(#0d0d0d26, #fff3); border-radius: 10px; overflow: hidden;
      }
      ${thumb2} > span, ${thumb2} [data-slot="aui_zoomable-image"] > button:first-child { inline-size: 100%; block-size: 100%; }
      ${thumb2} img { inline-size: 100%; block-size: 100%; object-fit: cover; border-radius: 8px; box-shadow: none; }
      ${thumb2} [data-slot="aui_zoomable-image"] > button:nth-child(2) { display: none; }
      ${gallery} {
        display: flex; align-items: start; gap: 8px; overflow: auto hidden; scrollbar-width: none;
        margin: 0; padding: 4px 0; border: 0;
      }
      ${gallery} > ${analysis} { flex: 0 0 80px; }
      ${gallery} > ${analysis} > div:first-child { display: none; }
      ${gallery} > ${analysis} > div:nth-child(2) { margin: 0; padding: 0; }
      ${gallery} > ${analysis} > div:nth-child(2) > button { display: none; }
      @keyframes hcv-image-details-in { from { opacity: 0; block-size: 0; } to { block-size: auto; } }
      ${step2}:not(${strip} *)[data-tool-open] > div:nth-child(2),
      ${gallery} { interpolate-size: allow-keywords; animation: hcv-image-details-in 300ms ${codexReference.enter} both; }

      ${active2} ${scrim}:has(+ ${nativeDialog}[data-hcv-image-viewer="activity"]) { background: rgb(0 0 0 / .9); backdrop-filter: none; }
      ${active2} ${scrim}:has(+ ${nativeDialog}[data-hcv-image-viewer="draft"]) { background: rgb(0 0 0 / .62); backdrop-filter: blur(2px); }
      ${dialog2} {
        --hcv-image-control-fill: light-dark(#ededed, #282828);
        --hcv-image-control-ink: light-dark(#0d0d0d, #dfdfdf);
        --hcv-image-side: clamp(16px, 4vw, 32px);
        --hcv-image-top: 96px;
        --hcv-image-bottom: 32px;
        --hcv-image-controls-space: 64px;
        display: grid; position: fixed; inset: 0; translate: none; transform: none;
        inline-size: 100%; max-inline-size: none; block-size: 100%; max-block-size: none;
        grid-template-rows: minmax(0, 1fr) auto; gap: 20px;
        padding: var(--hcv-image-top) var(--hcv-image-side) var(--hcv-image-bottom);
        border: 0; border-radius: 0; overflow: hidden; pointer-events: none !important;
      }
      ${draft} {
        --hcv-image-top: 48px; --hcv-image-bottom: 72px; --hcv-image-controls-space: 0px;
        --hcv-image-control-fill: light-dark(#ededed, #2d2d2d); grid-template-rows: minmax(0, 1fr);
        --hcv-image-controls-edge: max(12px, calc(100vw - env(titlebar-area-x, 0px) - env(titlebar-area-width, 100vw) + 8px));
      }
      @media (max-height: 500px) {
        ${activity} { --hcv-image-top: 76px; --hcv-image-bottom: 12px; --hcv-image-controls-space: 52px; gap: 8px; }
        ${draft} { --hcv-image-bottom: 30px; }
      }
      ${dialog2} > div:first-child {
        display: grid; place-items: center; overflow: clip; padding: 0; border-radius: 0;
      }
      ${dialog2} ${lightboxImage} {
        max-inline-size: calc(100vw - 2 * var(--hcv-image-side));
        max-block-size: calc(100dvh - var(--hcv-image-top) - var(--hcv-image-bottom) - var(--hcv-image-controls-space));
        border-radius: 10px; box-shadow: none; pointer-events: auto;
      }
      ${dialog2} div[class~="group/lightbox"] { display: grid; place-items: center; min-block-size: 0; max-block-size: 100%; position: static; }
      ${buttons}, ${zoomBar} {
        color: var(--hcv-image-control-ink); background: var(--hcv-image-control-fill);
        border: 0; border-radius: 999px; pointer-events: auto; backdrop-filter: none;
        box-shadow: 0 2px 4px -1px #00000014, 0 0 0 1px #0000000d;
        -webkit-app-region: no-drag;
      }
      ${buttons} {
        display: grid; place-items: center; position: fixed; z-index: 2;
        inset-block-start: 48px; inset-inline-end: 12px;
        block-size: 40px; inline-size: 40px; padding: 0; opacity: 1;
        transition: transform 150ms ease; cursor: pointer;
      }
      ${save} { inset-inline-end: 60px; }
      ${dialog2}:has(> ${pager}) { --hcv-image-side: clamp(44px, 6vw, 72px); }
      ${turnPage} { inset-block: 50% auto; inset-inline: auto 12px; translate: 0 -50%; }
      ${turnPage}[data-hcv-image-page="previous"] { inset-inline: 12px auto; }
      ${turnPage}[data-hcv-image-page="previous"]::before { scale: -1 1; }
      ${draft} :is(${close}, div[class~="group/lightbox"] > button) { inset-block-start: 7px; block-size: 34px; inline-size: 34px; }
      ${draft} > ${close} { inset-inline-end: var(--hcv-image-controls-edge); }
      ${draft} div[class~="group/lightbox"] > button { inset-inline-end: calc(var(--hcv-image-controls-edge) + 42px); }
      ${buttons}:hover { background: light-dark(#fff, #353535); outline: 1px solid var(--hcv-focus); }
      ${buttons}:active { transform: scale(.95); }
      ${save} > svg, ${zoomBar} > button:is(:first-child, :last-child) > svg { display: none; }
      ${symbol(save, "imagePreviewDownload", "download", 16)}
      ${symbol(exit, "imagePreviewClose", "close", 18)}
      ${symbol(turnPage, "viewedImageChevron", "right", 18)}
      ${zoomBar} { position: static; translate: none; justify-self: center; gap: 4px; padding: 4px; }
      ${zoomBar} > button:is(:first-child, :last-child) {
        display: grid; place-items: center; inline-size: 36px; block-size: 36px;
        border-radius: 50%; background: color-mix(in srgb, currentColor 10%, transparent); color: inherit;
      }
      ${zoomBar} > button:nth-child(2) { min-inline-size: 64px; font: 400 14px / 20px ${codexReference.font}; font-variant-numeric: tabular-nums; color: inherit; }
      ${draft} > ${zoom} { position: fixed; inset: 7px calc(var(--hcv-image-controls-edge) + 82px) auto auto; z-index: 2; }
      @media (max-width: 520px) {
        ${draft} > ${zoom} { inset: auto auto 12px 50%; translate: -50% 0; }
      }
      ${draft} > ${zoom} > button:is(:first-child, :last-child) { inline-size: 26px; block-size: 26px; }
      ${draft} > ${zoom} > button:nth-child(2) { min-inline-size: 48px; }
      ${symbol(`${zoomBar} > button:first-child`, "imagePreviewMinus", "minus", 16)}
      ${symbol(`${zoomBar} > button:last-child`, "imagePreviewPlus", "plus", 16)}
      :is(${buttons}, ${zoomBar} > button):focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
      @keyframes hcv-image-fade { from { opacity: 0; } }
      @keyframes hcv-image-fade-out { to { opacity: 0; } }
      ${dialog2}[data-state="open"] { animation: hcv-image-fade ${codexReference.enterTime} ${codexReference.enter} both; }
      ${dialog2}[data-state="closed"] { animation: hcv-image-fade-out ${codexReference.exitTime} ${codexReference.exit} both; }
      @media (prefers-reduced-motion: reduce) {
        ${caret}, ${buttons} { transition: none; }
        ${gallery}, ${body2}, ${dialog2}[data-state], ${active2} ${scrim}:has(+ ${nativeDialog}${enhanced}) { animation: none; }
      }
    }
  `, chatStyles);
  const marked3 = /* @__PURE__ */ new Set();
  const pending = /* @__PURE__ */ new Set();
  const selectors = `${row2}, ${group}, ${nativeDialog}, ${attachments} > ${pill}`;
  const markedSelector = `${analysis}, ${analysisGroup}, ${strip}, ${label}, ${enhanced}, ${close}, ${pager}, [data-hcv-image-path-tip]`;
  const colors = matchMedia("(forced-colors: active)");
  let frame = 0;
  let prune = false;
  let opener = null;
  let nextImage = null;
  const dialogKeys = /* @__PURE__ */ new WeakMap();
  const dialogFocus = /* @__PURE__ */ new WeakMap();
  function mark2(node3, attribute, value = "") {
    if (node3.getAttribute(attribute) !== value) node3.setAttribute(attribute, value);
    marked3.add(node3);
  }
  function decorate(button5, count) {
    const original = button5?.querySelector(stepTitle);
    if (!original) return false;
    let text = original.previousElementSibling;
    if (!text?.matches(label)) {
      text = document.createElement("span");
      text.setAttribute("data-hcv-viewed-image-label", "");
      original.before(text);
      marked3.add(text);
    }
    const content = viewedLabel(count, root.matches(":lang(ru)"));
    if (text.textContent !== content) text.textContent = content;
    return true;
  }
  function addViewerControls(node3, owner) {
    mark2(node3, "data-hcv-image-viewer", owner.kind);
    const ru = root.matches(":lang(ru)");
    if (!node3.hasAttribute("aria-label")) {
      node3.setAttribute("aria-label", ru ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F" : "Image preview");
      mark2(node3, "data-hcv-image-dialog-label");
    }
    const closeViewer = () => (viewerOwner(node3) ?? owner).changeOpen(false);
    const add = (attribute, value, description, action) => {
      const button5 = document.createElement("button");
      button5.type = "button";
      button5.setAttribute("aria-label", description);
      button5.setAttribute(attribute, value);
      button5.addEventListener("click", (event) => {
        event.stopPropagation();
        action();
      });
      node3.append(button5);
      marked3.add(button5);
      return button5;
    };
    add("data-hcv-image-close", "", ru ? "\u0417\u0430\u043A\u0440\u044B\u0442\u044C" : "Close", closeViewer);
    const trigger = opener;
    opener = null;
    if (trigger) {
      const onRestore = () => {
        if (nextImage?.from !== node3) return;
        const { target } = nextImage;
        nextImage = null;
        queueMicrotask(() => {
          if (!root.matches(active2) || colors.matches || !target.isConnected || !target.getClientRects().length || document.querySelector('[role="dialog"][data-state="open"]')) return;
          target.focus({ preventScroll: true });
          target.click();
        });
      };
      dialogFocus.set(node3, onRestore);
      node3.addEventListener(dialogFocusRestored, onRestore, { once: true });
    }
    const container = owner.kind === "draft" ? trigger?.closest(attachments) : trigger?.closest(strip);
    const candidates2 = container && [...container.querySelectorAll(owner.kind === "draft" ? `:scope > ${pill} > button:first-child:not(:disabled)` : '[data-slot="aui_zoomable-image"] > button:first-child:not(:disabled)')];
    const index = candidates2?.indexOf(trigger) ?? -1;
    if (index < 0) return;
    const pairs = [
      [candidates2[index - 1], "previous", "ArrowLeft", ru ? "\u041F\u0440\u0435\u0434\u044B\u0434\u0443\u0449\u0435\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435" : "Previous image"],
      [candidates2[index + 1], "next", "ArrowRight", ru ? "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0435\u0435 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435" : "Next image"]
    ];
    const arrowKeys = /* @__PURE__ */ new Map();
    for (const [target, direction, key, description] of pairs) {
      if (!target) continue;
      const pageImage = () => {
        if (nextImage || node3.dataset.state !== "open") return;
        nextImage = { from: node3, target };
        closeViewer();
      };
      add("data-hcv-image-page", direction, description, pageImage);
      arrowKeys.set(key, pageImage);
    }
    if (arrowKeys.size) {
      const onKey = (event) => {
        const pageImage = arrowKeys.get(event.key);
        if (!pageImage || event.defaultPrevented || event.altKey || event.ctrlKey || event.shiftKey || event.metaKey) return;
        event.preventDefault();
        pageImage();
      };
      dialogKeys.set(node3, onKey);
      node3.addEventListener("keydown", onKey);
    }
  }
  function flush() {
    frame = 0;
    for (const node3 of pending) {
      if (!node3.isConnected) continue;
      if (node3.matches(row2) && node3.closest(chat)) {
        if (successfulVision(node3) && decorate(disclosureButton(node3), 1)) mark2(node3, "data-hcv-viewed-image");
        else {
          node3.removeAttribute("data-hcv-viewed-image");
          marked3.delete(node3);
          node3.querySelector(label)?.remove();
        }
      } else if (node3.matches(group) && node3.closest(chat)) {
        const heading = node3.querySelector(`:scope > ${summary}`);
        const button5 = heading?.querySelector("button[aria-expanded]");
        const count = Number(button5?.querySelector(stepTitle)?.textContent.match(/^Analyzed (\d+) images$/)?.[1]);
        const details = heading?.nextElementSibling;
        if (count > 1 && decorate(button5, count)) mark2(node3, "data-hcv-viewed-image-group");
        else {
          node3.removeAttribute("data-hcv-viewed-image-group");
          marked3.delete(node3);
          heading?.querySelector(label)?.remove();
          details?.removeAttribute("data-hcv-image-strip");
          marked3.delete(details);
          continue;
        }
        const rows = details && !details.hasAttribute("data-tool-ticker") ? Array.from(details.children) : [];
        const eligible = count > 1 && rows.length === count && rows.every((item) => item.matches(row2) && successfulVision(item));
        if (eligible && rows.every(hasPhotoOnly)) {
          mark2(details, "data-hcv-image-strip");
        } else {
          details?.removeAttribute("data-hcv-image-strip");
          marked3.delete(details);
          if (eligible) {
            for (const item of rows) {
              const inner = disclosureButton(item);
              if (inner?.getAttribute("aria-expanded") === "false") inner.click();
            }
          }
        }
      } else if (node3.matches(nativeDialog) && !node3.matches(enhanced)) {
        const owner = viewerOwner(node3);
        if (owner && node3.querySelector(lightboxImage)) addViewerControls(node3, owner);
      } else if (node3.matches(pill) && node3.closest(attachments)) {
        const tooltip = document.getElementById(node3.getAttribute("aria-describedby"));
        const container = tooltip?.closest('[data-slot="tooltip-content"]');
        if (container) mark2(container, "data-hcv-image-path-tip");
      }
    }
    pending.clear();
    if (prune) {
      prune = false;
      for (const node3 of marked3) if (!node3.isConnected) marked3.delete(node3);
      if (opener && !opener.isConnected) opener = null;
      if (nextImage && !nextImage.target.isConnected) nextImage = null;
    }
  }
  function collect(node3) {
    if (!(node3 instanceof Element)) return;
    if (node3.matches(selectors)) pending.add(node3);
    for (const child of node3.querySelectorAll(selectors)) pending.add(child);
  }
  function queue() {
    if (!frame && (pending.size || prune)) frame = requestAnimationFrame(flush);
  }
  const changes2 = new MutationObserver((records) => {
    for (const { target, addedNodes, removedNodes, type } of records) {
      const element7 = target instanceof Element ? target : target.parentElement;
      const parent = element7?.closest(selectors);
      if (parent) pending.add(parent);
      const toolRun = parent?.matches(row2) && parent.closest(group);
      if (toolRun) pending.add(toolRun);
      if (type === "childList") {
        for (const child of addedNodes) collect(child);
        if (!prune && marked3.size) for (const child of removedNodes) {
          if (child instanceof Element && (marked3.has(child) || child.querySelector(markedSelector))) {
            prune = true;
            break;
          }
        }
      }
    }
    queue();
  });
  function clear() {
    changes2.disconnect();
    cancelAnimationFrame(frame);
    frame = 0;
    prune = false;
    opener = nextImage = null;
    pending.clear();
    for (const node3 of marked3) {
      if (node3.matches(`${label}, ${close}, ${pager}`)) node3.remove();
      else {
        if (dialogKeys.has(node3)) node3.removeEventListener("keydown", dialogKeys.get(node3));
        if (dialogFocus.has(node3)) node3.removeEventListener(dialogFocusRestored, dialogFocus.get(node3));
        if (node3.hasAttribute("data-hcv-image-dialog-label")) node3.removeAttribute("aria-label");
        for (const attribute of [
          "data-hcv-viewed-image",
          "data-hcv-viewed-image-group",
          "data-hcv-image-strip",
          "data-hcv-image-viewer",
          "data-hcv-image-dialog-label",
          "data-hcv-image-path-tip"
        ]) node3.removeAttribute(attribute);
      }
    }
    marked3.clear();
  }
  function sync() {
    clear();
    if (!root.matches(active2) || colors.matches) return;
    changes2.observe(document.body, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["aria-expanded", "aria-describedby"]
    });
    collect(document.body);
    flush();
  }
  const theme2 = new MutationObserver(sync);
  theme2.observe(root, { attributes: true, attributeFilter: ["lang", "data-hermes-theme"] });
  colors.addEventListener("change", sync);
  ctx.addEventListener(document, "click", (event) => {
    if (!root.matches(active2) || colors.matches) return;
    const button5 = event.target instanceof Element ? event.target.closest("button") : null;
    opener = button5?.matches(`${card2} > button:first-child, ${gallery} [data-slot="aui_zoomable-image"] > button:first-child`) ? button5 : null;
  }, { capture: true });
  sync();
  ctx.onDispose(() => {
    theme2.disconnect();
    colors.removeEventListener("change", sync);
    clear();
  });
}

// source/chat-reasoning.js
var surface2 = "[data-chat-surface]:not([data-hud-shell] *)";
var bodySlot = '[data-slot="aui_thinking-body"]';
var textSlot = '[data-slot="aui_reasoning-text"]';
function registerChatReasoning(ctx, active2) {
  const body2 = `${active2} ${surface2} ${bodySlot}`;
  const text = `${body2} ${textSlot}`;
  const flow = `:is(${text}, ${text} > div)`;
  const heading = ":is(h1, h2, h3, h4, h5, h6)";
  const headingBlock = `:is(${heading}, div:has(> ${heading}))`;
  mountCSS(ctx, "data-hcv-chat-reasoning-style", `
    @media (forced-colors: none) {
      ${body2} {
        margin: 0; padding: 0; max-block-size: 8.75rem;
        overflow-y: auto; overflow-x: hidden;
        scrollbar-width: thin;
        scrollbar-color: color-mix(in srgb, var(--hcv-text) 30%, transparent) transparent;
      }
      ${text} {
        --paragraph-gap: 4px;
        --dt-line-height: 1.625;
        --hcv-thought-text: var(--hcv-chat-prose, var(--hcv-text));
        color: color-mix(in oklab, var(--hcv-thought-text) 60%, transparent);
        font: 430 var(--hcv-activity-font, 14px)/1.625 ${codexReference.font};
        overflow-wrap: anywhere;
      }
      ${text} :where(p, li, blockquote, h1, h2, h3, h4, h5, h6) {
        font-size: inherit; line-height: 1.625;
        margin-block: 0;
      }
      ${text} :is(p, li, blockquote, h1, h2, h3, h4, h5, h6, strong, em, a, code) {
        color: color-mix(in oklab, var(--hcv-thought-text) 50%, transparent);
      }
      ${text} :is(strong, b, h1, h2, h3, h4, h5, h6) { font-weight: 600; }
      ${flow} > p + p,
      ${flow} > ${headingBlock} + * { margin-block-start: 4px; }
      ${flow} > ${headingBlock}:not(:first-child) { margin-block-start: 8px; }
      ${text} :is(ul, ol) { margin-block: 0; }
      ${text} ul { padding-inline-start: 1rem; }
      ${text} ol { padding-inline-start: 2rem; }
      ${text} p:has(code) { padding-block: 2px; }
      ${text} code:not(pre code) {
        font-family: var(--hcv-activity-mono, monospace);
        font-size: .92em; font-weight: 400; padding: 1px 6px; border-radius: 6px;
        box-decoration-break: clone;
        background: var(--ui-inline-code-background);
      }
      ${text} pre { overflow-x: auto; }
      @supports (animation-timeline: scroll(self block)) {
        ${body2} {
          mask-image: linear-gradient(to bottom, transparent, black var(--hcv-thought-fade-top, 0px)
            calc(100% - var(--hcv-thought-fade-bottom, 0px)), transparent);
          animation: hcv-thought-scroll-fade linear both;
          animation-timeline: scroll(self block);
        }
      }
    }
    @property --hcv-thought-fade-top { syntax: "<length>"; inherits: false; initial-value: 0px; }
    @property --hcv-thought-fade-bottom { syntax: "<length>"; inherits: false; initial-value: 0px; }
    @keyframes hcv-thought-scroll-fade {
      0%, 1% { --hcv-thought-fade-top: 0px; --hcv-thought-fade-bottom: 16px; }
      99%, 100% { --hcv-thought-fade-top: 16px; --hcv-thought-fade-bottom: 0px; }
    }
  `, { surface: bodySlot, retainAcrossChatTabs: true });
}

// source/chat-skills.js
var scope3 = '[data-chat-surface]:not([data-hud-shell] *) [data-slot="aui_assistant-message-content"]';
var candidate = 'div:has(> span[title$="SKILL.md" i]):has(> button:last-child)';
var marked2 = "[data-hcv-skill-card]";
var link = "[data-hcv-skill-link]";
var label2 = "[data-hcv-skill-label]";
var preview2 = (card2) => card2.querySelector(":scope > button:last-child");
function plainText(value, depth = 0) {
  if (typeof value === "string") return value;
  if (depth > 4) return "";
  if (Array.isArray(value)) return value.map((child) => plainText(child, depth + 1)).join("");
  return plainText(value?.props?.children, depth + 1);
}
function displayName(value) {
  const text = plainText(value).trim();
  if (!text.startsWith("$")) return text;
  const question = text.indexOf("?");
  if (question < 0) return text.slice(1);
  const fields2 = new URLSearchParams(text.slice(question + 1));
  return fields2.get("label")?.trim() || (fields2.has("label") || fields2.has("icon") ? text.slice(1, question) : text.slice(1));
}
function skillLinkInfo(card2) {
  let target = "";
  for (let node3 = committedFiber(card2)?.return; node3 && !(node3.stateNode instanceof Element); node3 = node3.return) {
    const props = node3.memoizedProps;
    if (typeof props?.target === "string") target ||= props.target;
    if (target && typeof props?.href === "string") {
      const leaf = /(?:^|[\\/])SKILL\.md$/i.test(target);
      const file = /^(?:file:\/\/\/|[a-z]:[\\/]|\/(?!\/)|~[\\/]|\.{1,2}[\\/])/i.test(target);
      if (!leaf || !file || !preview2(card2)) return null;
      const name = displayName(props.children) || target.split(/[\\/]/).at(-2) || "SKILL.md";
      return { name, target };
    }
  }
  return null;
}
function registerChatSkills(ctx, active2) {
  const cardCSS = `${active2} ${scope3} ${marked2}`;
  const linkCSS = `${cardCSS} > ${link}`;
  mountCSS(ctx, "data-hcv-chat-skill-style", `
    ${cardCSS} { display: contents; }
    ${cardCSS} > :not(${link}) { display: none !important; }
    ${linkCSS} {
      display: inline; padding: 0; color: light-dark(#0169cc, #99ceff) !important;
      font-weight: 500; white-space: nowrap; cursor: pointer; text-decoration: none !important;
    }
    ${linkCSS} > ${label2} { white-space: normal; overflow-wrap: break-word; }
    ${linkCSS} > [aria-hidden] {
      box-sizing: content-box; vertical-align: middle; align-items: center; display: inline-flex;
      block-size: 1em; padding-inline-end: 3px; transform: translateY(calc(.5ex - .5cap));
    }
    ${linkCSS} > [aria-hidden]::before {
      content: ""; inline-size: 16px; block-size: 16px; background: currentColor;
      mask: ${codexMask("chatSkill")} center / contain no-repeat;
    }
    ${linkCSS}:is(:hover, :focus-visible) > ${label2} { text-decoration: underline; text-underline-offset: 2px; }
    ${linkCSS}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 2px; border-radius: 2px; }
    @media (forced-colors: active) { ${linkCSS} > [aria-hidden]::before { background: LinkText; forced-color-adjust: none; } }
  `, chatStyles);
  const pending = /* @__PURE__ */ new Set();
  let frame = 0;
  function clear(card2) {
    card2.querySelector(`:scope > ${link}`)?.remove();
    card2.removeAttribute("data-hcv-skill-card");
  }
  function update(card2) {
    const info = skillLinkInfo(card2);
    if (!info) return clear(card2);
    let anchor = card2.querySelector(`:scope > ${link}`);
    if (!anchor) {
      anchor = document.createElement("a");
      anchor.setAttribute("data-hcv-skill-link", "");
      const icon8 = document.createElement("span");
      icon8.setAttribute("aria-hidden", "true");
      const text = document.createElement("span");
      text.setAttribute("data-hcv-skill-label", "");
      anchor.append(icon8, text);
      const open = (event) => {
        event.preventDefault();
        preview2(card2)?.click();
      };
      anchor.addEventListener("click", open);
      anchor.addEventListener("keydown", (event) => {
        if (event.key === "Enter" && !event.repeat) open(event);
      });
      card2.prepend(anchor);
    }
    const href = "#preview/" + encodeURIComponent(info.target);
    if (anchor.getAttribute("href") !== href) {
      anchor.setAttribute("href", href);
      anchor.title = info.target;
    }
    if (anchor.lastChild.textContent !== info.name) anchor.lastChild.textContent = info.name;
    card2.setAttribute("data-hcv-skill-card", "");
  }
  function collect(node3) {
    if (!(node3 instanceof Element) || node3.closest(link)) return;
    const card2 = node3.closest(`:is(${candidate}, ${marked2})`);
    if (card2?.closest(scope3)) pending.add(card2);
    if (node3.closest(scope3) || node3.querySelector(scope3)) {
      for (const entry of node3.querySelectorAll(candidate)) if (entry.closest(scope3)) pending.add(entry);
    }
  }
  function flush() {
    frame = 0;
    for (const card2 of pending) if (card2.isConnected && card2.closest(scope3)) update(card2);
    pending.clear();
  }
  const schedule = () => {
    if (pending.size && !frame) frame = requestAnimationFrame(flush);
  };
  const enabled = () => document.documentElement.matches(active2);
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === "attributes") collect(record.target);
      else for (const node3 of record.addedNodes) collect(node3);
    }
    schedule();
  });
  function sync() {
    observer.disconnect();
    cancelAnimationFrame(frame);
    frame = 0;
    pending.clear();
    if (enabled()) {
      collect(document.body);
      schedule();
      observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["title"] });
    } else {
      for (const card2 of document.querySelectorAll(marked2)) clear(card2);
    }
  }
  const theme2 = new MutationObserver(sync);
  theme2.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  sync();
  ctx.onDispose(() => {
    observer.disconnect();
    theme2.disconnect();
    cancelAnimationFrame(frame);
    pending.clear();
    for (const card2 of document.querySelectorAll(marked2)) clear(card2);
  });
}

// source/chat-activity-labels.js
var commandTools = /* @__PURE__ */ new Set(["terminal", "execute_code"]);
var skillTools = /* @__PURE__ */ new Set(["skill_view", "skills_list"]);
var editTools = /* @__PURE__ */ new Set(["write_file", "edit_file", "patch"]);
var exploreTools = /* @__PURE__ */ new Map([["read_file", "activityRead"], ["search_files", "activitySearch"], ["list_files", "folder"]]);
var otherTools = /* @__PURE__ */ new Map([
  ["web_search", { kind: "web-search", icon: "activitySearch" }],
  ["web_extract", { kind: "web-read", icon: "activityRead" }],
  ["session_search_recall", { kind: "history", icon: "activitySearch" }],
  ["vision_analyze", { kind: "image", icon: "activityImage" }]
]);
var russianPlurals2 = new Intl.PluralRules("ru");
var activityList = {
  ru: new Intl.ListFormat("ru", { type: "conjunction" }),
  en: new Intl.ListFormat("en", { type: "unit" })
};
var chromeTool = /^mcp_(?:chrome(?:_devtools|_extension|_internal|_dev|devtools)?|chrome-devtools)_/;
var browserTool = /^mcp_browser(?:_use)?_/;
var shortTitle = (value) => {
  if (typeof value !== "string") return "";
  const title = value.trim().replace(/\s+/g, " ");
  return title.length <= 80 ? title : title.slice(0, 79).trimEnd() + "\u2026";
};
function object(value) {
  if (typeof value === "string" && value.length <= 256 * 1024 && value.trimStart().startsWith("{")) {
    try {
      value = JSON.parse(value);
    } catch {
      return {};
    }
  }
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
function siteOrigin(value) {
  if (typeof value !== "string" || value.length > 4096) return "";
  try {
    const url = new URL(value);
    if (/^https?:$/.test(url.protocol) && !url.username && !url.password && !url.port && /\.[a-z]{2,63}$/i.test(url.hostname) && !/\.(?:local|localhost|internal|invalid|test|example|onion|lan|arpa)$/i.test(url.hostname)) {
      return url.origin;
    }
  } catch {
  }
  return "";
}
function describeActivity(part) {
  const name = part.toolName;
  if (typeof name !== "string" || !commandTools.has(name) && !skillTools.has(name) && !editTools.has(name) && !exploreTools.has(name) && !otherTools.has(name) && !name.startsWith("browser_") && !name.startsWith("mcp_")) return null;
  const result = object(part.result);
  const args = object(part.args);
  const meta = object(result._meta);
  const surface5 = object(meta["codex/toolSurface"]);
  const failed = part.isError || part.interrupted || part.status?.type === "incomplete" || result.isError === true || Boolean(result.error) || result.success === false || commandTools.has(name) && typeof result.exit_code === "number" && result.exit_code !== 0;
  const blocked = part.status?.type === "requires-action";
  const pending = part.result === void 0 && part.completedAt == null;
  const state = { failed, blocked, pending };
  const chrome = chromeTool.test(name) || surface5.kind === "browserUse" && surface5.backend === "chrome";
  const web = chrome || name.startsWith("browser_") || browserTool.test(name) || surface5.kind === "browserUse";
  if (web) {
    const target2 = surface5.kind === "browserUse" ? meta.browser_use?.url ?? surface5.screenshot?.pageUrl : void 0;
    const navigation = name === "browser_navigate" || chrome && /_(?:new_page|navigate_page)$/.test(name);
    const origin = !failed && !pending ? siteOrigin(target2 ?? (navigation ? result.url ?? args.url : void 0)) : "";
    const title = /(?:^|_)(?:js|run_code)$/.test(name) ? shortTitle(args.title) : "";
    return { ...state, kind: chrome ? "chrome" : "browser", icon: "activityBrowser", origin, title };
  }
  if (commandTools.has(name)) {
    const command2 = args.command ?? args.code;
    return { ...state, kind: "command", icon: "activityTerminal", command: typeof command2 === "string" ? command2 : "" };
  }
  const target = args.path || args.file_path;
  const path = typeof target === "string" ? target.split(/[\\/]/).filter(Boolean).at(-1) : "";
  if (editTools.has(name)) {
    const created = result.created === true || typeof result.diff === "string" && /^--- \/dev\/null\s*$/m.test(result.diff);
    const reported = [result.files_modified, result.files_created, result.files_deleted].flatMap((paths2) => Array.isArray(paths2) ? paths2.filter((value) => typeof value === "string" && value.trim()) : []);
    const paths = reported.length ? reported : typeof target === "string" && target.trim() ? [target] : [];
    return { ...state, kind: "edit", icon: "activityEdit", created, paths };
  }
  if (otherTools.has(name)) {
    return { ...state, ...otherTools.get(name), query: shortTitle(args.query || args.pattern) };
  }
  if (exploreTools.has(name)) {
    return { ...state, kind: "read", icon: exploreTools.get(name), path, query: shortTitle(args.pattern), exploreTool: name };
  }
  if (skillTools.has(name)) return { ...state, kind: "skill", icon: "chatSkill" };
  if (name.startsWith("mcp_")) {
    const title = /^mcp_(?:cua_repl|unified_computer_use)_js$/.test(name) ? shortTitle(args.title) : "";
    return { ...state, kind: "integration", icon: "activityIntegration", title };
  }
  return null;
}
function activityPresentation(parts, live, russian, detail = false, summary2 = false) {
  const items2 = parts.map((part) => describeActivity(part) ?? (russian && summary2 ? {
    kind: "integration",
    icon: "activityIntegration",
    failed: part.isError || part.interrupted
  } : null));
  const known = items2.filter(Boolean);
  const failed = known.some((item) => item.failed);
  if (!known.length || known.some((item) => item.blocked) || failed && (!summary2 || !russian)) return null;
  const primary4 = known.find((item) => item.kind === "edit") ?? known.find((item) => item.kind === "browser" || item.kind === "chrome") ?? items2[0];
  if (!primary4) return null;
  const site = known.find((item) => item.kind === primary4.kind && item.origin)?.origin;
  const fallback = { icon: primary4.icon, site };
  if (known.length !== items2.length || (primary4.kind === "skill" || primary4.kind === "image") && known.every((item) => item.kind === primary4.kind)) return fallback;
  const latest = known.at(-1);
  const title = live ? latest.title : known.length === 1 ? primary4.title : "";
  if (title) return { ...fallback, label: title };
  const has = (kind) => known.some((item) => item.kind === kind);
  const commandCount = known.filter((item) => item.kind === "command").length;
  const sourceCount = known.filter((item) => item.kind === "integration").length;
  const edits = known.filter((item) => item.kind === "edit");
  const editCount = new Set(edits.flatMap((item) => item.paths.map((path) => path.replaceAll("\\", "/")))).size + edits.filter((item) => !item.paths.length).length;
  const one = (count) => russian ? russianPlurals2.select(count) === "one" : count === 1;
  const segments = [];
  if (!live && detail && commandCount === 1 && primary4.command) {
    return { ...fallback, label: primary4.command };
  }
  if (!live && known.length === 1 && commandCount === 1 && primary4.command) {
    const label4 = russian ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D\u0430 \u043A\u043E\u043C\u0430\u043D\u0434\u0430 " : "Ran command ";
    return { ...fallback, label: label4 + primary4.command };
  }
  if (!live && known.length === 1 && primary4.kind === "read") {
    const label4 = primary4.exploreTool === "search_files" ? russian ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0435\u043D \u043F\u043E\u0438\u0441\u043A" : "Searched for" : primary4.exploreTool === "list_files" ? russian ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043B \u043F\u0430\u043F\u043A\u0443" : "Listed files in" : russian ? "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u043B" : "Read";
    const target = primary4.query || primary4.path;
    const inPath = primary4.exploreTool === "search_files" && primary4.query && primary4.path;
    if (target) return { ...fallback, label: label4 + " " + target + (inPath ? (russian ? " \u0432 " : " in ") + primary4.path : "") };
  }
  if (detail && primary4.kind === "edit") {
    return { ...fallback, prefix: !live && russian ? primary4.created ? "\u0421\u043E\u0437\u0434\u0430\u043D\u043E " : "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u043E " : "" };
  }
  if (live) {
    const working = {
      chrome: russian ? "Chrome \u0432\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442 \u043A\u043E\u043C\u0430\u043D\u0434\u044B" : "Using Chrome",
      browser: russian ? "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0435\u0442 \u0431\u0440\u0430\u0443\u0437\u0435\u0440" : "Using the browser",
      command: russian ? "\u0412\u044B\u043F\u043E\u043B\u043D\u044F\u0435\u0442\u0441\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430" : "Running command",
      integration: russian ? "\u0412\u044B\u0437\u044B\u0432\u0430\u0435\u0442 \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442" : "Calling a tool",
      edit: russian ? "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u0443\u0435\u0442 \u0444\u0430\u0439\u043B\u044B" : "Editing files",
      read: russian ? "\u0427\u0438\u0442\u0430\u0435\u0442 \u0444\u0430\u0439\u043B\u044B" : "Reading files",
      skill: russian ? "\u0427\u0438\u0442\u0430\u0435\u0442 \u0441\u043A\u0438\u043B\u043B" : "Reading a skill",
      image: russian ? "\u0421\u043C\u043E\u0442\u0440\u0438\u0442 \u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F" : "Viewing images",
      history: russian ? "\u0418\u0449\u0435\u0442 \u0432 \u0438\u0441\u0442\u043E\u0440\u0438\u0438" : "Searching chat history",
      "web-search": russian ? "\u0418\u0449\u0435\u0442 \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0435" : "Searching the web",
      "web-read": russian ? "\u0427\u0438\u0442\u0430\u0435\u0442 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B" : "Reading pages"
    };
    return { ...fallback, label: working[latest.kind] };
  }
  if (editCount) {
    segments.push(russian ? editCount === 1 ? "\u041E\u0442\u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043B \u0444\u0430\u0439\u043B" : "\u041E\u0442\u0440\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u043B \u0444\u0430\u0439\u043B\u044B" : editCount === 1 ? "Edited a file" : "Edited files");
  }
  if (has("read")) segments.push(russian ? "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u043B \u0444\u0430\u0439\u043B\u044B" : "Read files");
  if (has("skill")) segments.push(russian ? "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u043B \u0441\u043A\u0438\u043B\u043B" : "Read a skill");
  if (has("history")) segments.push(russian ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u043F\u043E\u0438\u0441\u043A \u043F\u043E \u0438\u0441\u0442\u043E\u0440\u0438\u0438" : "Searched chat history");
  if (has("web-search")) segments.push(russian ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u043F\u043E\u0438\u0441\u043A \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442\u0435" : "Searched the web");
  if (has("web-read")) segments.push(russian ? "\u041F\u0440\u043E\u0447\u0438\u0442\u0430\u043B \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B" : "Read pages");
  if (has("image")) {
    const count = known.filter((item) => item.kind === "image").length;
    const noun = { one: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435", few: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u044F", many: "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439" }[russianPlurals2.select(count)];
    segments.push(russian ? "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043D\u043E " + (count === 1 ? "\u0438\u0437\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435" : count + " " + noun) : count === 1 ? "Viewed an image" : "Viewed " + count + " images");
  }
  if (has("browser")) {
    segments.push(russian ? "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043B \u0431\u0440\u0430\u0443\u0437\u0435\u0440" : "Used the browser");
    if (has("chrome")) segments.push(russian ? "Chrome \u0432\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u043A\u043E\u043C\u0430\u043D\u0434\u044B" : "used Chrome");
  } else if (has("chrome")) {
    segments.push(russian ? "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0430 \u0438\u043D\u0442\u0435\u0433\u0440\u0430\u0446\u0438\u044F Chrome" : "Used the Chrome integration");
  }
  if (sourceCount) segments.push(russian ? sourceCount === 1 ? "\u0412\u044B\u0437\u0432\u0430\u043B \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442" : "\u0412\u044B\u0437\u0432\u0430\u043B \u0438\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B" : sourceCount === 1 ? "Called a tool" : "Called tools");
  if (commandCount) segments.push(russian ? one(commandCount) ? "\u0412\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u043A\u043E\u043C\u0430\u043D\u0434\u0443" : "\u0412\u044B\u043F\u043E\u043B\u043D\u0438\u043B \u043A\u043E\u043C\u0430\u043D\u0434\u044B" : one(commandCount) ? "Ran a command" : "Ran commands");
  const ordered2 = segments.map(
    (text, index) => index && !text.startsWith("Chrome") ? text[0].toLowerCase() + text.slice(1) : text
  );
  const label3 = editCount || has("read") ? activityList[russian ? "ru" : "en"].format(ordered2) : ordered2.join(russian ? " \u0438 " : " and ");
  return { ...fallback, label: failed ? label3 + " \xB7 \u0435\u0441\u0442\u044C \u043E\u0448\u0438\u0431\u043A\u0438" : label3 };
}

// source/chat-activity-details.js
var terminal = "data-hcv-terminal-details";
var command = "data-hcv-terminal-command";
var header = "data-hcv-terminal-header";
var status = "data-hcv-terminal-status";
var native = "data-hcv-tool-native-caption";
var caption = "data-hcv-tool-caption";
var sectionLabels = /* @__PURE__ */ new Map([
  ["Search", "\u041F\u043E\u0438\u0441\u043A"],
  ["Search results", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u043F\u043E\u0438\u0441\u043A\u0430"],
  ["File content", "\u0421\u043E\u0434\u0435\u0440\u0436\u0438\u043C\u043E\u0435 \u0444\u0430\u0439\u043B\u0430"],
  ["stdout", "\u0421\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u044B\u0439 \u0432\u044B\u0432\u043E\u0434"],
  ["stderr", "\u041F\u043E\u0442\u043E\u043A \u043E\u0448\u0438\u0431\u043E\u043A"],
  ["Output", "\u0412\u044B\u0432\u043E\u0434"],
  ["Arguments", "\u0410\u0440\u0433\u0443\u043C\u0435\u043D\u0442\u044B"],
  ["Result", "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442"]
]);
function setCaption(element7, value) {
  const current = element7.nextElementSibling;
  const old = current?.hasAttribute(caption) ? current : null;
  if (!value) {
    element7.removeAttribute(native);
    old?.remove();
    return;
  }
  const label3 = old ?? document.createElement(element7.localName);
  label3.setAttribute(caption, "");
  label3.className = element7.className;
  if (label3.textContent !== value) label3.textContent = value;
  if (!old) element7.after(label3);
  element7.setAttribute(native, "");
}
function updateActivityDetails(row5, tool, russian) {
  if (!row5.hasAttribute("data-tool-open")) return;
  const body2 = row5.children[1];
  if (!body2?.matches("div")) return;
  for (const label3 of body2.querySelectorAll('p[class~="tracking-[0.08em]"], p[class~="wrap-anywhere"] > span.font-medium:first-child')) {
    if (!label3.hasAttribute(caption)) setCaption(label3, russian && sectionLabels.get(label3.textContent.trim()));
  }
  if (!["terminal", "read_file"].includes(tool)) return;
  if (tool === "read_file") {
    body2.setAttribute(terminal, "file");
    return;
  }
  const transcript4 = body2.querySelector(":scope > div.font-mono:has(> code.min-w-0)");
  if (!transcript4) return;
  body2.setAttribute(terminal, "shell");
  transcript4.setAttribute(command, "");
  let title = body2.querySelector(`:scope > [${header}]`);
  if (!title) {
    title = document.createElement("div");
    title.setAttribute(header, "");
    body2.prepend(title);
  }
  const titleText = russian ? "\u0422\u0435\u0440\u043C\u0438\u043D\u0430\u043B" : "Shell";
  if (title.textContent !== titleText) title.textContent = titleText;
  const exit = transcript4.querySelector(":scope > span.tabular-nums");
  const code = /^exit (-?\d+)$/.exec(exit?.textContent.trim() ?? "")?.[1];
  if (code === void 0) return;
  setCaption(exit, code === "0" ? russian ? "\u0423\u0441\u043F\u0435\u0445" : "Success" : (russian ? "\u041A\u043E\u0434 \u0432\u044B\u0445\u043E\u0434\u0430 " : "Exit code ") + code);
  exit.nextElementSibling.setAttribute(status, code === "0" ? "success" : "error");
}
function clearActivityDetails() {
  for (const name of [terminal, command, native]) {
    for (const node3 of document.querySelectorAll(`[${name}]`)) node3.removeAttribute(name);
  }
  for (const node3 of document.querySelectorAll(`[${header}], [${caption}]`)) node3.remove();
}
function registerActivityDetails(ctx, chat3, output) {
  const shell = `${output}[${terminal}="shell"]`;
  const shellRow = `${chat3} [data-tool-open][data-tool-row]:has(> [${terminal}="shell"])`;
  const file = `${output}[${terminal}="file"]`;
  const size = "calc(var(--hcv-activity-font) - 1px)";
  mountCSS(ctx, "data-hcv-chat-activity-detail-style", `
@media (forced-colors: none) {
  ${chat3} [${native}] { display: none; }
  ${file} pre { scrollbar-width: thin; }
  ${shellRow} { position: relative; }
  ${shellRow}::after {
    content: ''; position: absolute; pointer-events: none;
    inset-block: calc(var(--hcv-activity-line) + 12px) 0; inset-inline-start: 8px;
    border-inline-start: 1px solid var(--hcv-activity-border);
  }
  ${shell} {
    grid-template-columns: minmax(0, 1fr);
    inline-size: calc(100% - 24px);
    margin-block-start: 12px; margin-inline-start: 24px;
    padding: 0; gap: 0; border-radius: 10px;
    background: light-dark(#f5f5f5, #2a2a2a);
    border: 1px solid light-dark(#d9d9d9, #4c4c4c);
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${shell} { border-radius: 12.5px; corner-shape: superellipse(1.5); }
  }
  ${shell} > [${header}] {
    grid-row: 1; padding: 4px 8px;
    font: 430 13px/1.5 ${codexReference.font}; color: var(--hcv-activity-text);
  }
  ${shell} > button { grid-row: 1; inset-block-start: 4px; inset-inline-end: 8px; }
  ${shell} > [${command}] { display: contents; }
  ${shell} > [${command}] > code {
    grid-row: 2; display: block; max-block-size: calc(${size} * 1.5 * 2 + 8px);
    padding: 8px 32px 0 8px; overflow: auto; scrollbar-width: thin;
    font-size: ${size}; line-height: 1.5; color: var(--hcv-chat-prose, var(--hcv-text));
  }
  ${shell} > [${command}] > code > span { color: inherit; }
  ${shell} > div:has(pre) {
    grid-row: 3; min-inline-size: 0; max-block-size: 144px; overflow: auto;
    scrollbar-width: thin;
  }
  ${shell}:has(> button) > div pre, ${shell} > div pre {
    max-block-size: none; padding: 8px; background: transparent; border-radius: 0;
    overflow: visible; white-space: pre; overflow-wrap: normal;
    font-size: ${size}; font-weight: 500; line-height: 1.5;
  }
  ${shell} [${status}] {
    grid-row: 4; justify-self: end; display: inline-flex; align-items: center; gap: 4px;
    padding: 2px 10px 4px; border: 0; background: transparent;
    color: var(--hcv-activity-text);
    font: 430 var(--hcv-activity-font)/1.5 ${codexReference.font};
  }
  ${shell} [${status}="success"]::before {
    content: ''; inline-size: 12px; block-size: 12px;
    background: currentColor; mask: ${codexMask("shellSuccess")} center / contain no-repeat;
  }
  @media (prefers-contrast: more) {
    ${shell} { border-color: currentColor; }
  }
}
  `, { surface: '[data-slot="tool-block"]', retainAcrossChatTabs: true });
}

// source/chat-disclosure-motion.js
var disclosureMotion = "data-hcv-activity-motion";
var marker2 = disclosureMotion;
var closing = "closing";
var duration3 = 300;
var flat = {
  blockSize: "0px",
  paddingBlockStart: "0px",
  paddingBlockEnd: "0px",
  borderBlockStartWidth: "0px",
  borderBlockEndWidth: "0px",
  marginBlockStart: "0px",
  marginBlockEnd: "0px",
  opacity: "0"
};
function frameOf(panel2) {
  const css2 = getComputedStyle(panel2);
  return { ...Object.fromEntries(Object.keys(flat).map((property) => [property, css2[property]])), translate: css2.translate };
}
function registerDisclosureMotion(ctx, enabled, getPanels, prepare) {
  const preference = matchMedia("(prefers-reduced-motion: no-preference)");
  const current = /* @__PURE__ */ new Map();
  function clear(button5, state) {
    current.delete(button5);
    cancelAnimationFrame(state.frame);
    button5.removeAttribute(marker2);
    for (const { panel: panel2, animation } of state.panels) {
      animation.cancel();
      panel2.removeAttribute(marker2);
    }
  }
  function play(button5, panels, phase, from) {
    const turn = button5.hasAttribute("data-hcv-turn-line");
    panels = panels.filter((panel2) => panel2.getClientRects().length > 0);
    const ends = panels.map((panel2) => frameOf(panel2));
    const state = { phase, panels: [], frame: 0 };
    current.set(button5, state);
    button5.setAttribute(marker2, phase);
    for (const [index, panel2] of panels.entries()) {
      panel2.setAttribute(marker2, phase);
      const end = ends[index];
      const folded = turn ? { ...flat, translate: "0 -8px" } : flat;
      const frames = phase === closing ? [from?.get(panel2) ?? end, folded] : [from?.get(panel2) ?? folded, end];
      const quickExit = turn && phase === closing;
      const animation = panel2.animate(frames, {
        duration: quickExit ? 150 : duration3,
        easing: quickExit ? "cubic-bezier(.23,1,.32,1)" : codexReference.enter,
        fill: "both"
      });
      state.panels.push({ panel: panel2, animation });
    }
    void Promise.all(state.panels.map(({ animation }) => animation.finished)).then(() => {
      if (current.get(button5) !== state) return;
      if (phase === closing && button5.isConnected && button5.getAttribute("aria-expanded") === "true") button5.click();
      clear(button5, state);
    }, () => {
    });
  }
  ctx.addEventListener(document, "click", (event) => {
    if (!event.isTrusted || !enabled() || !preference.matches || !(event.target instanceof Element)) return;
    const button5 = event.target.closest("button[aria-expanded]:not(:disabled)");
    if (!button5 || button5.closest("[hidden], [data-pane-hidden], [inert]")) return;
    const panels = getPanels(button5);
    if (!panels) return;
    const previous = current.get(button5);
    const from = previous?.panels.length ? new Map(previous.panels.map(({ panel: panel2 }) => [panel2, frameOf(panel2)])) : null;
    if (previous) clear(button5, previous);
    const reverse = previous?.phase === closing;
    if (button5.getAttribute("aria-expanded") === "true" && panels.length) {
      for (const [child, state2] of current) if (panels.some((panel2) => panel2.contains(child))) clear(child, state2);
      event.preventDefault();
      event.stopImmediatePropagation();
      play(button5, panels, reverse ? "opening" : closing, from);
      return;
    }
    const state = { phase: "opening", panels: [], frame: 0 };
    current.set(button5, state);
    state.frame = requestAnimationFrame(() => {
      current.delete(button5);
      if (!enabled() || !preference.matches || !button5.isConnected || button5.getAttribute("aria-expanded") !== "true") return;
      prepare();
      const mounted = getPanels(button5);
      if (mounted?.length) play(button5, mounted, "opening");
    });
  }, true);
  function finish() {
    for (const [button5, state] of current) {
      if (state.phase === closing && button5.isConnected && button5.getAttribute("aria-expanded") === "true") button5.click();
      clear(button5, state);
    }
  }
  ctx.addEventListener(preference, "change", finish);
  const observer = new MutationObserver(() => {
    if (!enabled()) finish();
  });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.onDispose(() => {
    observer.disconnect();
    finish();
  });
}

// source/chat-activity-groups.js
var activityGroup = "data-hcv-activity-group";
var activityMember = "data-hcv-activity-member";
var nativeSummary = ":scope > [data-tool-summary] button[aria-expanded]";
var ordinaryKinds = /* @__PURE__ */ new Set(["edit", "read", "command"]);
function activityGroups(partsFor) {
  const byMessage = /* @__PURE__ */ new Map();
  const groupPanels = /* @__PURE__ */ new WeakMap();
  function setNativeOpen(state, button5, open) {
    if (!button5 || button5.disabled) return;
    const value = String(open);
    const current = button5.getAttribute("aria-expanded");
    if (current == null || current === value) return;
    let change = state.changed.get(button5);
    if (!change) {
      change = { original: current, touched: false };
      change.onClick = (event) => {
        if (event.isTrusted || button5.getAttribute(disclosureMotion) === "closing") change.touched = true;
      };
      state.changed.set(button5, change);
      button5.addEventListener("click", change.onClick, true);
    }
    change.expected = value;
    button5.click();
  }
  function setOpen(state, open) {
    state.button.setAttribute("aria-expanded", String(open));
    if (open && state.initiallyClosed) {
      for (const node3 of state.nodes) {
        if (node3.matches("[data-file-edit]")) setNativeOpen(state, node3.querySelector("button[aria-expanded]"), false);
      }
      state.initiallyClosed = false;
    }
    for (const [index, node3] of state.nodes.entries()) {
      node3.setAttribute(activityMember, open ? index === 0 ? "first" : "next" : "closed");
      setNativeOpen(state, node3.querySelector(nativeSummary), open);
    }
  }
  function remove(state) {
    state.header.remove();
    for (const node3 of state.nodes) node3.removeAttribute(activityMember);
    for (const [button5, change] of state.changed) {
      button5.removeEventListener("click", change.onClick, true);
      if (button5.isConnected && !change.touched && change.original !== change.expected && button5.getAttribute("aria-expanded") === change.expected) button5.click();
    }
  }
  function create(nodes) {
    const header2 = document.createElement("div");
    header2.setAttribute(activityGroup, "");
    header2.setAttribute("data-conversation-scaffold", "");
    const button5 = document.createElement("button");
    button5.type = "button";
    const title = document.createElement("span");
    const label3 = document.createElement("span");
    const caret = document.createElement("span");
    caret.setAttribute("aria-hidden", "true");
    title.append(label3);
    button5.append(title, caret);
    header2.append(button5);
    const wasOpen = nodes.some((node3) => node3.contains(document.activeElement) || node3.querySelector('[data-tool-summary] button[aria-expanded="true"]'));
    const state = { header: header2, button: button5, label: label3, nodes, initiallyClosed: !wasOpen, changed: /* @__PURE__ */ new Map() };
    groupPanels.set(button5, nodes);
    nodes[0].before(header2);
    button5.addEventListener("click", () => setOpen(state, button5.getAttribute("aria-expanded") !== "true"));
    setOpen(state, wasOpen);
    return state;
  }
  function sync(message, russian) {
    const previous = byMessage.get(message) ?? [];
    if (!previous.length && !message.querySelector(":scope > [data-tool-row]")) return;
    const ranges = [];
    let entries = [];
    function settle() {
      const items2 = entries;
      entries = [];
      if (items2.length < 2 || !items2.some((item) => item.edit)) return;
      const nodes = items2.map((item) => item.node);
      const view = activityPresentation(items2.flatMap((item) => item.parts), false, russian);
      if (!view?.label) return;
      const state = previous.find((item) => item.nodes.length === nodes.length && item.nodes.every((node3, index) => node3 === nodes[index]));
      ranges.push({ state, nodes, view });
    }
    for (const node3 of message.children) {
      if (node3.hasAttribute(activityGroup)) continue;
      const parts = partsFor(node3);
      const entriesForNode = parts.map(describeActivity);
      if (!parts.length || node3.matches('[aria-hidden="true"], [inert]') || entriesForNode.some((item) => !item || !ordinaryKinds.has(item.kind) || item.pending || item.failed || item.blocked)) {
        settle();
        continue;
      }
      entries.push({ node: node3, parts, edit: entriesForNode.some((item) => item.kind === "edit") });
    }
    for (const state of previous) if (!ranges.some((range2) => range2.state === state)) remove(state);
    const next = ranges.map(({ state, nodes, view }) => {
      const group2 = state ?? create(nodes);
      group2.header.setAttribute(activityGroup, view.icon);
      if (group2.label.textContent !== view.label) group2.label.textContent = view.label;
      return group2;
    });
    if (next.length) byMessage.set(message, next);
    else byMessage.delete(message);
  }
  function prune() {
    for (const [message, states] of byMessage) {
      if (message.isConnected) continue;
      for (const state of states) remove(state);
      byMessage.delete(message);
    }
  }
  function clear() {
    for (const states of byMessage.values()) for (const state of states) remove(state);
    byMessage.clear();
  }
  return { sync, prune, clear, panels: (button5) => groupPanels.get(button5) };
}

// source/chat-activity.js
var surface3 = "[data-chat-surface]:not([data-hud-shell] *)";
var rowSelector2 = '[data-tool-row][data-slot="tool-block"]';
var summarySelector = "[data-tool-group] > [data-tool-summary]";
var activitySelector = `${rowSelector2}, ${summarySelector}`;
var messageContent = '[data-slot="aui_assistant-message-content"]';
var thinkingSelector = '[data-slot="aui_thinking-disclosure"]';
var thinkingBody = '[data-slot="aui_thinking-body"]';
var receiptSelector = '[data-slot="aui_system-message-root"] [data-slot="aui_background-result"]';
var labelSelector = `${activitySelector}, ${thinkingSelector}, ${receiptSelector}`;
var iconAttribute = "data-hcv-activity-icon";
var nativeLabel = "data-hcv-activity-native-label";
var customLabel = "data-hcv-activity-label";
var editPrefix = "data-hcv-activity-edit-prefix";
var favicon = "data-hcv-activity-favicon";
var toolIcons = /* @__PURE__ */ new Map([
  ["terminal", "activityTerminal"],
  ["execute_code", "activityTerminal"],
  ["read_file", "activityRead"],
  ["list_files", "folder"],
  ["search_files", "activitySearch"],
  ["web_search", "activitySearch"],
  ["session_search_recall", "activitySearch"],
  ["write_file", "activityEdit"],
  ["edit_file", "activityEdit"],
  ["patch", "activityEdit"],
  ["vision_analyze", "activityImage"],
  ["image_generate", "activityImage"]
]);
function nativeIcon(entry, part) {
  if (entry.hasAttribute("data-tool-summary")) {
    const verb = entry.querySelector("button")?.textContent.trim().split(/\s/, 1)[0];
    if (["Edited", "Editing"].includes(verb)) return "activityEdit";
    if (["Explored", "Exploring"].includes(verb)) return "activityRead";
    if (["Ran", "Running"].includes(verb)) return "activityTerminal";
    if (["Used", "Using"].includes(verb)) return "activityIntegration";
    return null;
  }
  const name = part?.toolName;
  return toolIcons.get(name) ?? (name?.startsWith("mcp_") ? "activityIntegration" : null);
}
function runParts(summary2) {
  let first, last;
  for (let fiber = committedFiber(summary2.parentElement); fiber; fiber = fiber.return) {
    if (fiber.stateNode instanceof Element && fiber.stateNode.hasAttribute("data-role")) break;
    const props = fiber.memoizedProps;
    if (first === void 0 && Number.isInteger(props?.startIndex) && Number.isInteger(props?.endIndex)) {
      first = Math.max(0, props.startIndex);
      last = props.endIndex;
    }
    if (first === void 0) continue;
    for (let context = fiber.dependencies?.firstContext; context; context = context.next) {
      const client = context.memoizedValue;
      if (!client?.message?.source) continue;
      try {
        const { content } = client.message().__internal_getRuntime()?.getState() || {};
        if (Array.isArray(content)) return content.slice(first, last + 1).filter((part) => part.type === "tool-call");
      } catch {
      }
    }
  }
  return [];
}
var rowProps = (row5) => committedFiber(row5)?.return?.memoizedProps;
var directSummary = ":scope > [data-tool-summary]";
function partsForBlock(block2) {
  if (block2.matches(rowSelector2)) {
    const part = rowProps(block2)?.part;
    return part?.toolName ? [part] : [];
  }
  if (!block2.matches("[data-tool-group]")) return [];
  const summary2 = block2.querySelector(directSummary);
  if (summary2) return rowProps(summary2)?.live ? [] : runParts(summary2);
  const row5 = block2.querySelector(`:scope > div > ${rowSelector2}`);
  return row5 ? partsForBlock(row5) : [];
}
var findTitle = (entry, summary2) => (summary2 ? entry : entry.firstElementChild)?.querySelector(":scope > div > button > span:first-child > span:first-child");
function thoughtLabel(text) {
  if (text === "Thinking" || text === "\u0414\u0443\u043C\u0430\u0435\u0442") return "\u0414\u0443\u043C\u0430\u044E";
  if (["\u041F\u043E\u043C\u044B\u0441\u043B\u0438\u043B", "\u041A\u0440\u0430\u0442\u043A\u043E \u043F\u043E\u0434\u0443\u043C\u0430\u043B", "Thought", "Thought briefly"].includes(text)) return "\u0414\u0443\u043C\u0430\u043B";
  if (text.startsWith("\u0414\u0443\u043C\u0430\u043B ") && !text.startsWith("\u0414\u0443\u043C\u0430\u043B \u043D\u0430 \u043F\u0440\u043E\u0442\u044F\u0436\u0435\u043D\u0438\u0438 ")) {
    return "\u0414\u0443\u043C\u0430\u043B \u043D\u0430 \u043F\u0440\u043E\u0442\u044F\u0436\u0435\u043D\u0438\u0438 " + text.slice("\u0414\u0443\u043C\u0430\u043B ".length);
  }
  return "";
}
var receiptStatuses = /* @__PURE__ */ new Map([
  ["Completed", ["\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443", "\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u0443"]],
  ["Finished with Issues", ["\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0441 \u043E\u0448\u0438\u0431\u043A\u0430\u043C\u0438", "\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u0443 \u0441 \u043E\u0448\u0438\u0431\u043A\u0430\u043C\u0438"]],
  ["Failed", ["\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443 \u0441 \u043E\u0448\u0438\u0431\u043A\u043E\u0439", "\u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u0443 \u0441 \u043E\u0448\u0438\u0431\u043A\u0430\u043C\u0438"]],
  ["Incomplete", ["\u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B \u0440\u0430\u0431\u043E\u0442\u0443", "\u043D\u0435 \u0437\u0430\u0432\u0435\u0440\u0448\u0438\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u0443"]],
  ["Interrupted", ["\u043F\u0440\u0435\u0440\u0432\u0430\u043B \u0440\u0430\u0431\u043E\u0442\u0443", "\u043F\u0440\u0435\u0440\u0432\u0430\u043B\u0438 \u0440\u0430\u0431\u043E\u0442\u0443"]],
  ["Cancelled", ["\u043E\u0442\u043C\u0435\u043D\u0438\u043B \u0437\u0430\u0434\u0430\u0447\u0443", "\u043E\u0442\u043C\u0435\u043D\u0438\u043B\u0438 \u0437\u0430\u0434\u0430\u0447\u0438"]],
  ["Timed Out", ["\u043D\u0435 \u0443\u043B\u043E\u0436\u0438\u043B\u0441\u044F \u0432\u043E \u0432\u0440\u0435\u043C\u044F", "\u043D\u0435 \u0443\u043B\u043E\u0436\u0438\u043B\u0438\u0441\u044C \u0432\u043E \u0432\u0440\u0435\u043C\u044F"]],
  ["Stalled", ["\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B\u0441\u044F", "\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u043B\u0438\u0441\u044C"]]
]);
function receiptLabel(text) {
  const match = /^Subagent (Task|Tasks) ([^:]+): (.+)$/.exec(text);
  if (!match) return "";
  const [, kind, outcome, goal] = match;
  const plural = kind === "Tasks";
  const target = plural ? goal.replace(/ \((\d+) tasks\)$/, " ($1)") : goal;
  if (outcome === "Unknown") return (plural ? "\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u043E\u0432" : "\u0421\u0442\u0430\u0442\u0443\u0441 \u0441\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u0430") + " \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D \xB7 " + target;
  const status2 = receiptStatuses.get(outcome)?.[Number(plural)];
  if (!status2) return "";
  const subject = plural ? "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442\u044B" : "\u0421\u0443\u0431\u0430\u0433\u0435\u043D\u0442";
  return subject + " " + status2 + " \xB7 " + target;
}
function registerChatActivity(ctx, active2) {
  const chat3 = `${active2} ${surface3}`;
  const row5 = `${chat3} ${rowSelector2}`;
  const summary2 = `${chat3} ${summarySelector}`;
  const group2 = `${chat3} [data-tool-group][data-slot="tool-block"]`;
  const toggle2 = `:is(${row5} > :first-child, ${summary2}) > div > button`;
  const title = `${toggle2} > span:first-child > span:first-child`;
  const glyph3 = `${title} > span:first-child:has(> :is(svg, .codicon, [role="status"]))`;
  const thinking = `${chat3} ${thinkingSelector}`;
  const receipt = `${chat3} ${receiptSelector}`;
  const thoughtToggle = `${thinking} > div:first-child > button`;
  const receiptToggle = `${receipt} > [data-conversation-scaffold] > div > button`;
  const overall = `${chat3} [${activityGroup}]`;
  const overallToggle = `${overall} > button`;
  const turnToggle = `${chat3} button[data-hcv-turn-line]`;
  const controls2 = `:is(${toggle2}, ${thoughtToggle}, ${receiptToggle}, ${overallToggle})`;
  const caretBox = `${controls2}[aria-expanded] > span:nth-child(2)`;
  const caret = `:is(${caretBox} > .codicon-chevron-right, ${overallToggle} > span:nth-child(2))`;
  const motionPanel = `${chat3} :not(button)[${disclosureMotion}]`;
  const children = `${summary2}:has(button[aria-expanded="true"]) + div:not([data-tool-ticker])`;
  const clusterMember = `${chat3} [${activityMember}]:not([${activityMember}="closed"])`;
  const clusterChildren = `${clusterMember}[data-tool-group] > [data-tool-summary]:has(button[aria-expanded="true"]) + div:not([data-tool-ticker])`;
  const output = `${row5}[data-tool-open]:not([data-file-edit]) > :nth-child(2)`;
  const preview3 = `${output} > div:has(> [data-slot="aui_markdown-image"])`;
  const thumb2 = `${preview3} [data-slot="aui_markdown-image"]:has(img)`;
  const copy7 = `${output} > button[class~="group-hover/tool-block:opacity-100"]`;
  const icons3 = [.../* @__PURE__ */ new Set([...toolIcons.values(), "activityIntegration", "activityBrowser", "chatSkill"])];
  const style = document.createElement("style");
  style.setAttribute("data-hcv-chat-activity-style", "");
  style.textContent = `
@media (forced-colors: none) {
  ${chat3} {
    --hcv-activity-text: light-dark(#5d5d5d, #8b8b8b);
    --hcv-activity-glyph: color-mix(in oklab, var(--hcv-text) 60%, transparent);
    --hcv-activity-border: light-dark(#0d0d0d1a, #ffffff1f);
    --hcv-activity-font: var(--codex-chat-font-size, 14px);
    --hcv-activity-line: calc(var(--hcv-activity-font) * 1.5);
    --hcv-activity-mono: ui-monospace, "SFMono-Regular", "SF Mono", menlo, consolas, "Liberation Mono", monospace;
  }
  :is(${row5}, ${summary2}) {
    --conversation-tool-font-size: var(--hcv-activity-font);
    --conversation-scaffold-text: var(--hcv-activity-text);
    --conversation-scaffold-meta: var(--hcv-activity-text);
    --ui-text-tertiary: var(--hcv-activity-text);
    opacity: 1;
    font-family: ${codexReference.font};
    font-weight: 430;
    line-height: 1.5;
  }
  ${row5}:not([data-file-edit]), ${row5}:not([data-file-edit]) > :first-child {
    border: 0;
    border-radius: 0;
    background: transparent;
    padding: 0;
  }
  ${chat3} ${messageContent} { --scaffold-block-gap: 12px; }
  ${group2} { --tool-row-gap: 0px; }
  ${children} {
    position: relative; gap: 12px;
    padding-block-start: 12px; padding-inline-start: 24px;
  }
  ${children}::before, ${clusterMember}::before {
    content: ""; position: absolute; pointer-events: none;
    inset-block: 12px 0; inset-inline-start: 8px;
    border-inline-start: 1px solid var(--hcv-activity-border);
  }
  ${controls2} { align-items: center; gap: 4px; padding: 0; border-radius: 6px; }
  ${controls2}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${toggle2}:not(:disabled):is(:hover, :focus-visible) { --conversation-scaffold-text: var(--hcv-text); }
  ${title} { gap: 8px; }
  ${glyph3} { inline-size: 16px; block-size: 16px; color: var(--hcv-activity-glyph); }
  ${chat3} [${nativeLabel}] { display: none; }
  ${title} > [${customLabel}] {
    display: block; min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    font-size: var(--hcv-activity-font); line-height: 1.5; color: var(--conversation-scaffold-text);
  }
  ${title} > [${editPrefix}]::before { content: attr(${editPrefix}); }
  :is(${thoughtToggle}, ${receiptToggle}, ${overallToggle}) {
    --conversation-tool-font-size: var(--hcv-activity-font);
    --conversation-line-height: var(--hcv-activity-line);
    font: 430 var(--hcv-activity-font)/var(--hcv-activity-line) ${codexReference.font};
  }
  ${thinking} { opacity: 1; }
  ${thoughtToggle} { --conversation-scaffold-text: color-mix(in oklab, var(--hcv-chat-prose, var(--hcv-text)) 30%, transparent); }
  ${thinking} > div:first-child > span:last-child span[class~="tabular-nums"] {
    font: 430 var(--hcv-activity-font)/var(--hcv-activity-line) ${codexReference.font};
    color: color-mix(in oklab, var(--hcv-chat-prose, var(--hcv-text)) 30%, transparent);
    letter-spacing: normal;
  }
  ${thoughtToggle}:is(:hover, :focus-visible) {
    --conversation-scaffold-text: var(--hcv-chat-prose, var(--hcv-text)) !important;
  }
  ${receipt} { --conversation-scaffold-text: var(--hcv-activity-text); }
  ${receipt} > [data-conversation-scaffold] { opacity: 1; }
  :is(${thoughtToggle}, ${receiptToggle}) [${customLabel}] {
    min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    color: var(--conversation-scaffold-text);
  }
  ${title} > img[${favicon}] {
    inline-size: 16px; block-size: 16px; flex: none; border-radius: 4px; object-fit: contain;
  }
  ${title}:has(> img[${favicon}]) > span:first-of-type:has(> :is(svg[aria-hidden="true"], .codicon)) { display: none; }
  ${glyph3} > :is(svg, .codicon):not([aria-label]) { color: inherit; }
  /* Keep the live status accessible, but use the same browser glyph before
     and after completion instead of Hermes' animated decorative frames. */
  ${glyph3}:is(${row5}[${iconAttribute}="activityBrowser"] *):has(> [role="status"]) {
    background: var(--hcv-activity-glyph);
    mask: var(--hcv-activity-icon) center / contain no-repeat;
  }
  ${glyph3}:is(${row5}[${iconAttribute}="activityBrowser"] *) > [role="status"] > .glyph-spinner {
    opacity: 0;
  }
  ${caretBox} { opacity: 0; flex: none; }
  ${controls2}[aria-expanded="true"]:not([${disclosureMotion}="closing"]) > span:nth-child(2),
  ${controls2}[aria-expanded]:is(:hover, :focus-visible) > span:nth-child(2) { opacity: 1; }
  ${controls2}[aria-expanded="true"]:not([${disclosureMotion}="closing"]) { --hcv-arrow-angle: 90deg; }
  ${caret} {
    inline-size: 14px !important; block-size: 14px !important; color: var(--hcv-activity-glyph);
    rotate: none; transform: rotate(var(--hcv-arrow-angle, 0deg));
  }
  ${thoughtToggle}[aria-expanded] > span:nth-child(2) > .codicon-chevron-right { color: var(--hcv-activity-text); }
  ${thoughtToggle}:focus-visible > span:nth-child(2) > .codicon-chevron-right { color: var(--hcv-chat-prose, var(--hcv-text)); }
  ${codexIconRules(caret, "turnDisclosure")}
  ${turnToggle}[${disclosureMotion}="closing"][aria-expanded="true"]::after { transform: rotate(0deg); }
  ${motionPanel} { box-sizing: border-box; min-block-size: 0; overflow: hidden; }
  ${motionPanel}[${disclosureMotion}="closing"] { pointer-events: none; }
  ${overall} { opacity: 1; color: var(--hcv-activity-text); }
  ${overall}:not(:first-child) { margin-block-start: 12px; }
  ${overallToggle} { display: inline-flex; max-inline-size: 100%; text-align: start; cursor: pointer; }
  ${overallToggle}:is(:hover, :focus-visible) { color: var(--hcv-text); }
  ${overallToggle} > span:first-child {
    display: flex; align-items: center; gap: 8px; min-inline-size: 0; overflow: hidden;
  }
  ${overallToggle} > span:first-child > span {
    min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  ${overallToggle} > span:first-child::before {
    content: ""; inline-size: 16px; block-size: 16px; flex: none;
    background: var(--hcv-activity-glyph); mask: var(--hcv-activity-icon) center / contain no-repeat;
  }
  ${chat3} [${activityMember}="closed"] { display: none; }
  ${clusterMember} {
    position: relative; margin-block: 0 !important;
    padding-block: 12px 0; padding-inline: 24px 0 !important;
  }
  ${clusterMember}[${activityMember}="next"]::before { inset-block-start: 0; }
  ${clusterMember} > [data-tool-summary]:has(button[aria-expanded="true"]) { display: none; }
  ${clusterChildren} { padding: 0; }
  ${clusterChildren}::before { content: none; }
  ${icons3.map((icon8) => `
    ${chat3} :is([${iconAttribute}="${icon8}"], [${activityGroup}="${icon8}"]) { --hcv-activity-icon: ${codexMask(icon8)}; }
  `).join("")}
  ${glyph3}:is(${row5}[${iconAttribute}] *) > :is(svg[aria-hidden="true"], .codicon):not([aria-label]) {
    inline-size: 16px !important;
    block-size: 16px !important;
    background-color: currentColor;
    mask: var(--hcv-activity-icon) center / contain no-repeat;
  }
  ${glyph3}:is(${row5}[${iconAttribute}] *) > svg[aria-hidden="true"] > *,
  ${glyph3}:is(${row5}[${iconAttribute}] *) > .codicon:not([aria-label])::before { visibility: hidden; }
  :is(
    ${title}:is(${summary2}[${iconAttribute}] *),
    ${title}:is(${row5}[${iconAttribute}] *):not(:has(> span:first-child > :is(svg, .codicon, [role="status"])))
  ):not(:has(> img[${favicon}]))::before {
    content: "";
    flex: none;
    inline-size: 16px;
    block-size: 16px;
    background: var(--hcv-activity-glyph);
    mask: var(--hcv-activity-icon) center / contain no-repeat;
  }
  ${output} { margin-block-start: 4px; padding: 0; gap: 4px; }
  ${output} :is(pre, code, .font-mono) { font-family: var(--hcv-activity-mono); font-size: 12px; line-height: 1.5; }
  ${output} pre, ${output} > .font-mono {
    border: 0;
    border-radius: 6px;
    background: var(--hcv-hover);
    padding: 8px 12px;
  }
  ${output}:has(> button) pre, ${output}:has(> button) > .font-mono { padding-inline-end: 36px; }
  ${output} > button { inset-block-start: 4px; inset-inline-end: 8px; color: var(--hcv-activity-text); }
  /* PuGl in 461952.bb4069593d.js uses a hover/focus copy action with duration-basic. */
  ${codexIconRules(`${copy7} > svg.tabler-icon-copy`, "copy")}
  ${codexIconRules(`${copy7} > svg.tabler-icon-check`, "messageCopied")}
  @media (hover: hover) {
    ${copy7} { opacity: 0; }
    ${output}:hover > button[class~="group-hover/tool-block:opacity-100"], ${copy7}:focus-visible { opacity: 1; }
  }
  @media (hover: none) { ${copy7} { opacity: 1; } }
  @media (prefers-reduced-motion: no-preference) {
    ${copy7} { transition: opacity 150ms var(--hcv-ease); }
    ${caret} { transition: transform 300ms cubic-bezier(.4,0,.2,1); }
  }
  ${preview3} { border: 0; border-radius: 0; }
  ${thumb2} {
    inline-size: 80px !important;
    block-size: 80px;
    aspect-ratio: 1 !important;
    margin: 0;
    border: 1px solid light-dark(#0d0d0d26, #ffffff33);
    border-radius: 10px;
  }
  ${thumb2} > span { inline-size: 100%; block-size: 100%; }
  ${thumb2} img { inline-size: 100%; block-size: 100%; object-fit: cover; border-radius: 8px; box-shadow: none; }
  ${thumb2} [data-slot="aui_zoomable-image"] > button:has(> svg.tabler-icon-download) {
    inset-inline-end: 4px;
    inset-block-start: 4px;
    inline-size: 24px;
    block-size: 24px;
  }
  ${thumb2} :focus-visible, ${thumb2} button:focus-visible > img { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  @media (prefers-reduced-motion: reduce) { :is(${caret}, ${copy7}) { transition: none; } }
}
`;
  mountStyle(ctx, style, { surface: `[data-slot="tool-block"], ${thinkingSelector}, ${receiptSelector}` });
  const pending = /* @__PURE__ */ new Set();
  const pendingMessages = /* @__PURE__ */ new Set();
  const groups2 = activityGroups(partsForBlock);
  const siteEntries = /* @__PURE__ */ new WeakMap();
  const siteIcons = /* @__PURE__ */ new Map();
  const forcedColors = window.matchMedia("(forced-colors: active)");
  const enabled = () => document.documentElement.matches(active2) && !forcedColors.matches;
  registerDisclosureMotion(ctx, enabled, (button5) => {
    if (button5.matches(overallToggle)) return groups2.panels(button5);
    if (button5.matches(turnToggle)) {
      const response3 = button5.parentElement;
      return [...response3.querySelectorAll("[data-hcv-turn-step]")].filter((node3) => !node3.parentElement.closest("[data-hcv-turn-step]"));
    }
    if (!button5.matches(`:is(${toggle2}, ${thoughtToggle}, ${receiptToggle})`)) return null;
    const header2 = button5.closest(`:is(${rowSelector2}, [data-tool-summary], ${thinkingSelector}, ${receiptSelector})`);
    if (header2.matches("[data-tool-summary]")) {
      const next = header2.nextElementSibling;
      return next && !next.hasAttribute("data-tool-ticker") ? [next] : [];
    }
    return [...header2.children].slice(1);
  }, () => {
    if (!frame) return;
    cancelAnimationFrame(frame);
    flush();
  });
  let frame = 0;
  let disposed = false;
  let connected;
  function clearLabel(title2) {
    title2?.querySelector(`:scope > [${nativeLabel}]`)?.removeAttribute(nativeLabel);
    title2?.querySelector(`:scope > [${customLabel}]`)?.remove();
  }
  function setLabel(title2, native2, value) {
    if (!native2 || !value) return clearLabel(title2);
    let label3 = title2.querySelector(`:scope > [${customLabel}]`);
    if (!label3) {
      label3 = document.createElement("span");
      label3.setAttribute(customLabel, "");
      native2.after(label3);
    }
    if (label3.textContent !== value) label3.textContent = value;
    native2.setAttribute(nativeLabel, "");
  }
  function setToolLabel(title2, view) {
    const native2 = title2?.querySelector(':scope > span[class~="whitespace-nowrap"][class~="max-w-full"]');
    if (native2?.matches(".text-destructive, .text-amber-700")) return clearLabel(title2);
    if (view?.prefix) native2?.setAttribute(editPrefix, view.prefix);
    else native2?.removeAttribute(editPrefix);
    setLabel(title2, native2, view?.label);
  }
  function showSite(title2, data) {
    const current = title2.querySelector(`:scope > img[${favicon}]`);
    if (!data) return current?.remove();
    if (current?.getAttribute("src") === data) return;
    const img = current || document.createElement("img");
    img.setAttribute(favicon, "");
    img.setAttribute("aria-hidden", "true");
    img.alt = "";
    img.draggable = false;
    img.src = data;
    if (!current) title2.prepend(img);
  }
  const sites = new IntersectionObserver((records) => {
    for (const { target: entry, isIntersecting } of records) {
      if (!isIntersecting || !enabled()) continue;
      sites.unobserve(entry);
      const state = siteEntries.get(entry);
      const resolve = window.hermesDesktop?.resolveFavicon;
      if (!state || !resolve) continue;
      let task = siteIcons.get(state.site);
      if (!task) {
        if (siteIcons.size >= 64) siteIcons.delete(siteIcons.keys().next().value);
        task = Promise.resolve().then(() => resolve(state.site)).then(
          (src) => /^data:image\/(?:png|gif|jpe?g|webp|svg\+xml|x-icon|vnd\.microsoft\.icon|avif);base64,/i.test(src || "") ? src : ""
        ).catch(() => "");
        siteIcons.set(state.site, task);
      }
      void task.then((src) => {
        if (!disposed && enabled() && entry.isConnected && siteEntries.get(entry) === state) showSite(state.title, src);
      });
    }
  });
  function setSite(entry, title2, site) {
    const previous = siteEntries.get(entry);
    if (previous?.site === site && previous?.title === title2) return;
    if (previous) {
      showSite(previous.title, "");
      sites.unobserve(entry);
      siteEntries.delete(entry);
    }
    if (site && title2) {
      siteEntries.set(entry, { site, title: title2 });
      sites.observe(entry);
    }
  }
  function queue(entry) {
    pending.add(entry);
    if (entry.matches(activitySelector)) {
      const owner = entry.closest(messageContent);
      if (owner) pendingMessages.add(owner);
    }
  }
  function collect(node3) {
    if (!(node3 instanceof Element)) return;
    const parent = node3.closest(labelSelector);
    if (parent) queue(parent);
    else for (const entry of node3.querySelectorAll(labelSelector)) queue(entry);
  }
  function flush() {
    frame = 0;
    const russian = document.documentElement.lang.toLowerCase().startsWith("ru");
    groups2.prune();
    for (const message of pendingMessages) {
      if (message.isConnected && message.closest(surface3)) groups2.sync(message, russian);
    }
    pendingMessages.clear();
    for (const entry of pending) {
      if (!entry.isConnected || !entry.closest(surface3)) continue;
      if (entry.matches(thinkingSelector) || entry.matches(receiptSelector)) {
        const thinking2 = entry.matches(thinkingSelector);
        const title3 = (thinking2 ? entry : entry.firstElementChild)?.querySelector(":scope > div > button > span:first-child > span:first-child");
        const native2 = thinking2 ? title3?.firstElementChild : title3?.querySelector(":scope > span.truncate");
        const text = native2?.textContent.trim();
        const localized = russian && text && (thinking2 ? thoughtLabel(text) : receiptLabel(text));
        setLabel(title3, native2, localized);
        continue;
      }
      const summary3 = entry.hasAttribute("data-tool-summary");
      const props = rowProps(entry);
      const part = props?.part;
      if (!summary3 && part) updateActivityDetails(entry, part.toolName, russian);
      const live = summary3 ? props?.live : Boolean(part && part.result === void 0 && part.completedAt == null && entry.closest('[data-message-streaming="true"]'));
      const parts = summary3 ? runParts(entry) : part?.toolName ? [part] : [];
      const view = activityPresentation(parts, live, russian, !summary3 && (entry.closest(`[${activityMember}]`) || entry.closest("[data-tool-group]")?.querySelector(directSummary) || ["write_file", "edit_file", "patch"].includes(part?.toolName)), summary3);
      const icon8 = view?.icon ?? nativeIcon(entry, part);
      if (icon8) entry.setAttribute(iconAttribute, icon8);
      else entry.removeAttribute(iconAttribute);
      const title2 = findTitle(entry, summary3);
      setToolLabel(title2, view);
      setSite(entry, title2, view?.site);
    }
    pending.clear();
  }
  const observer = new MutationObserver((records) => {
    for (const { target, addedNodes, removedNodes } of records) {
      const element7 = target instanceof Element ? target : target.parentElement;
      if (!element7 || element7.closest(thinkingBody)) continue;
      if (element7.matches(messageContent)) pendingMessages.add(element7);
      const entry = element7.closest(labelSelector);
      if (entry) queue(entry);
      else for (const node3 of addedNodes) collect(node3);
      for (const node3 of removedNodes) {
        if (!(node3 instanceof Element) || node3.isConnected) continue;
        if (siteEntries.has(node3)) setSite(node3);
        for (const entry2 of node3.querySelectorAll(activitySelector)) if (siteEntries.has(entry2)) setSite(entry2);
      }
    }
    if ((pending.size || pendingMessages.size) && !frame) frame = requestAnimationFrame(flush);
  });
  function clearActivity() {
    groups2.clear();
    clearActivityDetails();
    for (const entry of document.querySelectorAll(`[${iconAttribute}]`)) {
      siteEntries.delete(entry);
      entry.removeAttribute(iconAttribute);
    }
    for (const node3 of document.querySelectorAll(`[${nativeLabel}]`)) node3.removeAttribute(nativeLabel);
    for (const node3 of document.querySelectorAll(`[${editPrefix}]`)) node3.removeAttribute(editPrefix);
    for (const node3 of document.querySelectorAll(`[${customLabel}], img[${favicon}]`)) node3.remove();
  }
  function sync() {
    const next = enabled();
    if (connected === next) return;
    connected = next;
    observer.disconnect();
    sites.disconnect();
    cancelAnimationFrame(frame);
    frame = 0;
    pending.clear();
    pendingMessages.clear();
    if (next) {
      collect(document.body);
      flush();
      observer.observe(document.body, { childList: true, characterData: true, subtree: true });
    } else clearActivity();
  }
  const theme2 = new MutationObserver((records) => {
    sync();
    if (connected && records.some((record) => record.attributeName === "lang")) {
      collect(document.body);
      if (!frame) frame = requestAnimationFrame(flush);
    }
  });
  theme2.observe(document.documentElement, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  ctx.addEventListener(forcedColors, "change", sync);
  sync();
  ctx.onDispose(() => {
    disposed = true;
    observer.disconnect();
    theme2.disconnect();
    sites.disconnect();
    cancelAnimationFrame(frame);
    clearActivity();
    style.remove();
  });
  registerChatImages(ctx, active2);
  registerActivityDetails(ctx, chat3, output);
  registerChatReasoning(ctx, active2);
  registerChatSkills(ctx, active2);
}

// source/chat-tables.js
import { host as host14 } from "@hermes/plugin-sdk";
var nativeTable = [
  '[data-chat-surface]:not([data-hud-shell] *) [data-slot="aui_assistant-message-content"] .aui-md-table > table',
  "[data-hcv-subagent-result] [data-hcv-subagent-table] > table"
].join(", ");
var tableMark = "data-hcv-markdown-table";
var wrapMark = "data-hcv-table-scroll";
var toolbarMark = "data-hcv-table-toolbar";
var dialogMark = "data-hcv-table-dialog";
var columnMark = "data-hcv-table-column";
var control3 = "[data-md-col-handle], [data-hcv-table-toolbar]";
var interactive = 'a[href], button, [role="button"]';
var labels10 = {
  ru: {
    copy: "\u041A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443",
    copied: "\u0421\u043A\u043E\u043F\u0438\u0440\u043E\u0432\u0430\u043D\u043E",
    expand: "\u0420\u0430\u0437\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u0442\u0430\u0431\u043B\u0438\u0446\u0443",
    preview: "\u041F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0442\u0430\u0431\u043B\u0438\u0446\u044B",
    close: "\u0417\u0430\u043A\u0440\u044B\u0442\u044C \u043F\u0440\u0435\u0434\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440 \u0442\u0430\u0431\u043B\u0438\u0446\u044B",
    scroll: "\u041F\u0440\u043E\u043A\u0440\u0443\u0447\u0438\u0432\u0430\u0435\u043C\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430"
  },
  en: {
    copy: "Copy table",
    copied: "Copied",
    expand: "Expand table",
    preview: "Table preview",
    close: "Close table preview",
    scroll: "Scrollable table"
  }
};
var strings = () => document.documentElement.lang.toLowerCase().startsWith("ru") ? labels10.ru : labels10.en;
function make2(tag, marker4, value = "") {
  const element7 = document.createElement(tag);
  element7.setAttribute(marker4, value);
  return element7;
}
function button(action, label3) {
  const element7 = make2("button", "data-hcv-table-action", action);
  element7.type = "button";
  element7.setAttribute("aria-label", label3);
  return element7;
}
function copyOf(table) {
  const clone = table.cloneNode(true);
  for (const node3 of clone.querySelectorAll(control3)) node3.remove();
  for (const node3 of clone.querySelectorAll("[id]")) node3.removeAttribute("id");
  clone.removeAttribute("id");
  return clone;
}
function markColumns(table) {
  const rows = [...table.rows];
  const longest = [];
  for (const row5 of rows) {
    for (const cell of row5.cells) {
      const index = cell.cellIndex;
      longest[index] = Math.max(longest[index] || 0, cell.textContent.length);
      if (cell.tagName === "TD") cell.toggleAttribute("data-hcv-table-number", /^\d+$/.test(cell.textContent));
    }
  }
  const sizes = longest.map((length) => length <= 40 ? "sm" : length <= 100 ? "md" : length <= 160 ? "lg" : "xl");
  for (const row5 of rows) for (const cell of row5.cells) {
    const size = sizes[cell.cellIndex];
    if (cell.getAttribute(columnMark) !== size) cell.setAttribute(columnMark, size);
  }
}
function markdownSource(table) {
  let fiber = committedFiber(table);
  while (fiber && fiber.memoizedProps?.node?.tagName !== "table") fiber = fiber.return;
  const node3 = fiber?.memoizedProps?.node;
  if (node3?.tagName !== "table") return null;
  const start = node3.position?.start?.offset;
  const end = node3.position?.end?.offset;
  if (!Number.isInteger(start) || !Number.isInteger(end)) return null;
  for (; fiber; fiber = fiber.return) {
    const props = fiber.memoizedProps;
    const markdown = Number.isInteger(props?.index) ? props.content : props?.mode === "static" ? props.children : null;
    if (typeof markdown !== "string" || end > markdown.length) continue;
    const source = markdown.slice(start, end);
    if (source.includes("|") || /^<table[\s>]/i.test(source)) return source;
  }
  return null;
}
function renderedMarkdown(table) {
  const rows = Array.from(table.rows, (row5) => Array.from(row5.cells));
  if (!rows.length) return "";
  const pipeRow = (cells) => "| " + cells.join(" | ") + " |";
  const cellText = (cell) => cell.textContent.trim().replaceAll("\\", "\\\\").replaceAll("|", "\\|").replace(/\s+/g, " ");
  const alignment = { left: ":---", center: ":---:", right: "---:" };
  return [
    pipeRow(rows[0].map(cellText)),
    pipeRow(rows[0].map((cell) => alignment[cell.style.textAlign || cell.getAttribute("align")] || "---")),
    ...rows.slice(1).map((row5) => pipeRow(row5.map(cellText)))
  ].join("\n");
}
function clipboardHtml(table) {
  for (const node3 of table.querySelectorAll('span[data-streamdown="strong"], span[data-streamdown="em"]')) {
    const emphasis = document.createElement(node3.dataset.streamdown);
    emphasis.append(...node3.childNodes);
    node3.replaceWith(emphasis);
  }
  for (const element7 of [table, ...table.querySelectorAll("*")]) {
    for (const name of ["node", tableMark, columnMark, "data-hcv-table-number"]) element7.removeAttribute(name);
  }
  return table.outerHTML;
}
function writeRichCopy(text, html) {
  let copied = false;
  const onCopy = (event) => {
    if (!event.clipboardData) return;
    event.clipboardData.setData("text/plain", text);
    event.clipboardData.setData("text/html", html);
    event.preventDefault();
    event.stopImmediatePropagation();
    copied = true;
  };
  window.addEventListener("copy", onCopy, true);
  try {
    return document.execCommand("copy") && copied;
  } catch {
    return false;
  } finally {
    window.removeEventListener("copy", onCopy, true);
  }
}
function tableCss(active2) {
  const scroll = `${active2} [${wrapMark}]`;
  const toolbar2 = `${active2} [${toolbarMark}]`;
  const dialog2 = `${active2} [${dialogMark}]`;
  const table = `${active2} [${tableMark}]`;
  const action = `${active2} [data-hcv-table-action]`;
  const tip2 = `${active2} [data-hcv-table-tip]`;
  return `
  :is(${scroll}, ${dialog2}, ${tip2}) {
    --hcv-table-chat-font: var(--codex-chat-font-size, 14px);
    --hcv-table-space: calc(var(--hcv-table-chat-font) / 4);
    --hcv-table-width-unit: calc(var(--thread-content-max-width, 48rem) / 24);
    --hcv-table-text: light-dark(#1a1c1f, #dfdfdf);
    --hcv-table-row-border: light-dark(#1a1c1f0f, #dfdfdf0d);
    --hcv-table-header-border: light-dark(#1a1c1f26, #dfdfdf2e);
    --hcv-table-dialog-border: light-dark(#0d0d0d1a, #ffffff1f);
    --hcv-table-preview: light-dark(#f9f9f9, #2d2d2d);
    font-family: ${codexReference.font};
    color: var(--hcv-table-text);
  }
  ${scroll} {
    box-sizing: border-box;
    inline-size: 100%;
    max-inline-size: 100%;
    position: relative;
    border: 0;
    border-radius: 0;
    margin: calc(var(--hcv-table-space) * 4) 0 0;
    background: transparent;
    overflow: auto hidden;
    scrollbar-width: thin;
  }
  ${scroll}[data-overlay-surface] {
    background-color: transparent !important;
    backdrop-filter: none !important;
  }
  ${table} {
    border: 0;
    border-collapse: separate;
    border-spacing: 0;
    table-layout: auto;
    inline-size: fit-content;
    min-inline-size: 100%;
    max-inline-size: none;
    margin: 0;
    text-align: start;
    color: inherit;
    font: 400 max(var(--codex-chat-code-font-size, 12px), calc(var(--hcv-table-chat-font) * .875)) /
      calc(var(--hcv-table-chat-font) * 1.625) ${codexReference.font};
    overflow-wrap: anywhere;
  }
  ${scroll} > [${tableMark}]:has(> colgroup) { inline-size: 100%; table-layout: fixed; }
  ${table} :is(thead, tbody, tr, th, td) { margin: 0; border: 0; background: transparent; color: inherit; }
  ${table} :is(th, td) {
    box-sizing: border-box;
    padding: 0 calc(var(--hcv-table-space) * 6) 0 0;
    padding-inline-start: 0;
    padding-inline-end: calc(var(--hcv-table-space) * 6);
    text-align: start;
    vertical-align: top;
    white-space: normal;
    font: inherit;
  }
  ${table} :is(th, td)[align="left"] { text-align: left; }
  ${table} :is(th, td)[align="center"] { text-align: center; }
  ${table} :is(th, td)[align="right"] { text-align: right; }
  ${table} thead th {
    padding-block: calc(var(--hcv-table-space) * 2);
    border-block-end: 1px solid var(--hcv-table-header-border);
    font-weight: 600;
    line-height: calc(var(--hcv-table-space) * 4);
  }
  ${table} th > span:first-child { white-space: normal; overflow: visible; }
  ${table} th:last-child { padding-inline-end: calc(var(--hcv-table-space) * 10); }
  ${table} tbody td { padding-block: calc(var(--hcv-table-space) * 2.5); }
  ${table} tbody tr:not(:last-child) td { border-block-end: 1px solid var(--hcv-table-row-border); }
  ${table} tbody tr:last-child td { padding-block-end: calc(var(--hcv-table-space) * 6); }
  ${table}:not(:has(> colgroup)) [${columnMark}] {
    min-inline-size: calc(var(--hcv-table-width-unit) * var(--hcv-table-column-min));
    max-inline-size: calc(var(--hcv-table-width-unit) * var(--hcv-table-column-max));
  }
  ${table} [${columnMark}="sm"] { --hcv-table-column-min: 4; --hcv-table-column-max: 6; }
  ${table} [${columnMark}="md"] { --hcv-table-column-min: 6; --hcv-table-column-max: 8; }
  ${table} [${columnMark}="lg"] { --hcv-table-column-min: 8; --hcv-table-column-max: 12; }
  ${table} [${columnMark}="xl"] { --hcv-table-column-min: 14; --hcv-table-column-max: 18; }
  ${table} td[data-hcv-table-number] {
    min-inline-size: calc(3ch + (var(--hcv-table-space) * 6));
    white-space: nowrap;
  }
  ${table} :not(pre) > code {
    background: color-mix(in srgb, color-mix(in srgb, var(--hcv-table-text) 9%, transparent) 60%, var(--hcv-table-text) 6%);
    border-radius: 6px;
    padding: 1px 6px;
    box-decoration-break: clone;
    font-family: ui-monospace, "SFMono-Regular", "SF Mono", menlo, consolas, "Liberation Mono", monospace;
    font-size: .92em;
    overflow-wrap: anywhere;
    word-break: break-word;
  }
  ${scroll}[data-hcv-table-overflow] > [${tableMark}] {
    mask-image: linear-gradient(to right,
      transparent var(--hcv-table-left),
      black calc(var(--hcv-table-left) + var(--hcv-table-fade-left)) calc(var(--hcv-table-right) - var(--hcv-table-fade-right)),
      transparent var(--hcv-table-right));
  }
  ${toolbar2} {
    position: sticky;
    inset-inline-start: 0;
    z-index: 12;
    block-size: 0;
    inline-size: 100%;
    pointer-events: none;
  }
  ${toolbar2} > div {
    position: absolute;
    inset-block-start: 0;
    inset-inline-end: 0;
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 2px;
    border-radius: 100vw;
    background: var(--hcv-chat);
    color: color-mix(in srgb, var(--hcv-table-text) 55%, transparent);
    opacity: 0;
    pointer-events: none;
    user-select: none;
  }
  ${scroll}:is(:hover, :focus-within) > [${toolbarMark}] > div { opacity: 1; pointer-events: auto; }
  ${action} {
    box-sizing: border-box;
    display: grid;
    place-items: center;
    flex: none;
    inline-size: 36px;
    block-size: 36px;
    padding: 0;
    border: 0;
    border-radius: 100vw;
    background: transparent;
    color: inherit;
    cursor: pointer;
    -webkit-app-region: no-drag;
  }
  ${action}:hover { background: color-mix(in srgb, var(--hcv-table-text) 9%, transparent); color: var(--hcv-table-text); }
  ${action}::before {
    content: "";
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: var(--hcv-table-icon) center / contain no-repeat;
  }
  ${action}[data-hcv-table-action="copy"] { --hcv-table-icon: ${codexMask("tableCopy")}; }
  ${action}[data-hcv-table-action="copy"][data-copied] { --hcv-table-icon: ${codexMask("check")}; }
  ${action}[data-hcv-table-action="expand"] { --hcv-table-icon: ${codexMask("tableExpand")}; }
  ${action}[data-hcv-table-action="close"] { --hcv-table-icon: ${codexMask("tableClose")}; }
  :is(${action}, ${scroll}, ${dialog2} [role="region"]):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${tip2} {
    position: fixed;
    z-index: 9999;
    max-inline-size: calc(100vw - 24px);
    padding: ${codexReference.tooltip.padding};
    border: 1px solid var(--hcv-table-dialog-border);
    border-radius: ${codexReference.tooltip.radius};
    background: var(--hcv-table-preview);
    font: 400 13px/18px ${codexReference.font};
    transform: translate(-50%, -100%);
    pointer-events: none;
  }
  ${dialog2} {
    position: fixed;
    inset: 0;
    box-sizing: border-box;
    inline-size: 100%;
    block-size: 100dvh;
    max-inline-size: none;
    max-block-size: none;
    margin: 0;
    padding: 0;
    border: 0;
    background: transparent;
    overflow: hidden;
  }
  ${dialog2}::backdrop { background: rgb(0 0 0 / .9); }
  ${dialog2} [data-hcv-table-stage] {
    display: grid;
    grid-template: minmax(0, 1fr) / minmax(0, 1fr);
    place-items: center;
    box-sizing: border-box;
    block-size: 100%;
    min-inline-size: 0;
    padding: 96px 32px 32px;
  }
  ${dialog2} [data-hcv-table-panel] {
    box-sizing: border-box;
    display: flex;
    min-block-size: 0;
    max-inline-size: 80%;
    max-block-size: 100%;
    padding: 32px;
    border: 1px solid var(--hcv-table-dialog-border);
    border-radius: 16px;
    background: var(--hcv-table-preview);
    box-shadow: 0 16px 32px -8px #00000030;
    overflow: hidden;
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${dialog2} [data-hcv-table-panel] { border-radius: 20px; corner-shape: superellipse(1.5); }
  }
  ${dialog2} [role="region"] { min-block-size: 0; min-inline-size: 0; overflow: auto; scrollbar-width: thin; }
  ${dialog2} [data-hcv-table-content] { inline-size: fit-content; min-inline-size: 100%; padding-inline-end: 8px; padding-block-end: 8px; }
  ${dialog2} [${tableMark}] :is(a, button) { cursor: pointer; }
  ${dialog2} [data-hcv-table-action="close"] {
    position: absolute;
    inset-block-start: 48px;
    inset-inline-end: 12px;
    inline-size: 40px;
    block-size: 40px;
    color: var(--hcv-table-text);
    background: light-dark(#f3f3f3, #282828);
    box-shadow: 0 4px 6px -1px #0000001a, 0 0 0 1px #0000000d;
  }
  ${dialog2} [data-hcv-table-action="close"]::before { inline-size: 20px; block-size: 20px; }
  ${dialog2} [data-hcv-table-action="close"]:hover { background: var(--hcv-selected); }
  @media (max-width: 639px) {
    ${dialog2} [data-hcv-table-stage] { padding-inline: 16px; }
    ${dialog2} [data-hcv-table-panel] { max-inline-size: 100%; padding-inline: 0; }
    ${dialog2} [data-hcv-table-content] { padding-inline: 16px; }
  }
  @media (max-height: 420px) {
    ${dialog2} [data-hcv-table-stage] { padding-block: 56px 16px; }
    ${dialog2} [data-hcv-table-panel] { padding-block: 16px; }
    ${dialog2} [data-hcv-table-action="close"] { inset-block-start: 12px; }
  }
  @media (pointer: coarse), (hover: none) {
    ${scroll} { padding-block-start: 44px; }
    ${toolbar2} > div { inset-block-start: -44px; opacity: 1; pointer-events: auto; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${action} { transition: background-color 150ms, color 150ms, scale 150ms; }
    ${dialog2} [data-hcv-table-action="close"]:active { scale: .95; }
  }
  @media (forced-colors: active) {
    ${action}::before { background: ButtonText; forced-color-adjust: none; }
    ${dialog2} [data-hcv-table-panel] { border-color: ButtonText; }
    ${scroll}[data-hcv-table-overflow] > [${tableMark}] { mask-image: none; }
  }
  `;
}
function registerChatTables(ctx, active2) {
  const root = document.documentElement;
  const states = /* @__PURE__ */ new Map();
  const pending = /* @__PURE__ */ new Set();
  let frame = 0;
  let preview3;
  let tipTimer;
  let tipButton;
  const style = make2("style", "data-hcv-chat-tables-style");
  style.textContent = tableCss(active2);
  mountStyle(ctx, style, { surface: ".aui-md-table, [data-hcv-subagent-table], [data-hcv-table-dialog]", retainAcrossChatTabs: true });
  const tip2 = make2("div", "data-hcv-table-tip");
  tip2.hidden = true;
  tip2.setAttribute("aria-hidden", "true");
  document.body.append(tip2);
  function hideTip() {
    clearTimeout(tipTimer);
    tipButton = null;
    tip2.hidden = true;
  }
  function showTip(element7) {
    hideTip();
    tipButton = element7;
    tipTimer = setTimeout(() => {
      if (!element7.isConnected || tipButton !== element7) return;
      tip2.textContent = element7.getAttribute("aria-label");
      tip2.hidden = false;
      const anchor = element7.getBoundingClientRect();
      const half = tip2.offsetWidth / 2;
      tip2.style.left = Math.min(innerWidth - half - 6, Math.max(half + 6, anchor.x + anchor.width / 2)) + "px";
      tip2.style.top = anchor.top - 3 + "px";
    }, 250);
  }
  function refreshPreview() {
    const { state, content } = preview3;
    const clone = copyOf(state.table);
    const before = [...content.querySelectorAll(interactive)];
    const focusIndex = before.indexOf(document.activeElement);
    const nodes = [...clone.querySelectorAll(interactive)];
    const originals = state.table.querySelectorAll(interactive);
    preview3.actions = new Map(nodes.map((node3, i) => [node3, originals[i]]));
    content.replaceChildren(clone);
    nodes[focusIndex]?.focus({ preventScroll: true });
  }
  function closePreview(restoreFocus = true) {
    if (!preview3) return;
    const { modal, state } = preview3;
    preview3 = null;
    state.expand.setAttribute("aria-expanded", "false");
    modal.close();
    modal.remove();
    if (restoreFocus && root.matches(active2) && state.expand.isConnected) state.expand.focus({ preventScroll: true });
  }
  function openPreview(state) {
    if (preview3) closePreview();
    hideTip();
    const copy7 = strings();
    const modal = make2("dialog", dialogMark);
    const stage = make2("div", "data-hcv-table-stage");
    const panel2 = make2("div", "data-hcv-table-panel");
    const region = document.createElement("div");
    const content = make2("div", "data-hcv-table-content");
    const close2 = button("close", copy7.close);
    close2.autofocus = true;
    modal.setAttribute("aria-label", copy7.preview);
    modal.setAttribute("role", "dialog");
    region.setAttribute("role", "region");
    region.setAttribute("aria-label", copy7.scroll);
    region.tabIndex = 0;
    region.append(content);
    panel2.append(region);
    stage.append(panel2);
    modal.append(stage, close2);
    document.body.append(modal);
    preview3 = { modal, state, content, region, close: close2 };
    refreshPreview();
    state.expand.setAttribute("aria-expanded", "true");
    close2.addEventListener("click", () => closePreview());
    modal.addEventListener("keydown", (event) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      closePreview();
    });
    modal.addEventListener("cancel", (event) => {
      event.preventDefault();
      closePreview();
    });
    modal.addEventListener("pointerdown", (event) => {
      if (event.button !== 0 || event.target !== stage) return;
      event.preventDefault();
      closePreview();
    });
    content.addEventListener("click", (event) => {
      const origin = preview3?.actions.get(event.target.closest(interactive));
      if (!origin?.isConnected) return;
      event.preventDefault();
      closePreview(false);
      origin.click();
    });
    modal.showModal();
  }
  function measureOverflow(state) {
    const { wrapper, table } = state;
    const width = wrapper.clientWidth;
    const wide = width > 0 && wrapper.scrollWidth > width + 1;
    if (!wide) return { state, wide };
    const left = Math.max(0, wrapper.getBoundingClientRect().left - table.getBoundingClientRect().left);
    return { state, wide, width, left, tableWidth: table.offsetWidth };
  }
  function applyOverflow({ state, wide, width, left, tableWidth }) {
    const { wrapper } = state;
    if (wide !== wrapper.hasAttribute("data-hcv-table-overflow")) {
      wrapper.toggleAttribute("data-hcv-table-overflow", wide);
      for (const [name, value] of Object.entries(wide ? {
        role: "region",
        tabindex: "0",
        "aria-label": strings().scroll
      } : state.nativeAttributes)) {
        if (value === null) wrapper.removeAttribute(name);
        else wrapper.setAttribute(name, value);
      }
    }
    if (wide && wrapper.getAttribute("aria-label") !== strings().scroll) {
      wrapper.setAttribute("aria-label", strings().scroll);
    }
    if (!wide) return;
    const right = left + width;
    const fade = Math.min(96, width / 3);
    for (const [name, size] of [
      ["left", left],
      ["right", right],
      ["fade-left", left > 2 ? fade : 0],
      ["fade-right", right < tableWidth - 2 ? fade : 0]
    ]) {
      const property = "--hcv-table-" + name;
      const value = size + "px";
      if (wrapper.style.getPropertyValue(property) !== value) wrapper.style.setProperty(property, value);
    }
  }
  function updateOverflow(statesToMeasure) {
    const measured = [];
    for (const state of statesToMeasure) {
      if (state.wrapper.checkVisibility({ contentVisibilityAuto: true })) {
        measured.push(measureOverflow(state));
      }
    }
    measured.forEach(applyOverflow);
  }
  const resize = new ResizeObserver((entries) => {
    const affected = /* @__PURE__ */ new Set();
    for (const { target } of entries) {
      const state = states.get(target.matches("table") ? target : target.querySelector(":scope > table"));
      if (state) affected.add(state);
    }
    updateOverflow(affected);
  });
  function attach(table) {
    const wrapper = table.parentElement;
    const toolbar2 = make2("div", toolbarMark);
    const bar = document.createElement("div");
    const copy7 = button("copy", strings().copy);
    const expand = button("expand", strings().expand);
    const listeners = new AbortController();
    const options = { signal: listeners.signal };
    const nativeAttributes = Object.fromEntries(["role", "tabindex", "aria-label"].map((name) => [name, wrapper.getAttribute(name)]));
    const state = { table, wrapper, toolbar: toolbar2, copy: copy7, expand, listeners, nativeAttributes };
    expand.setAttribute("aria-haspopup", "dialog");
    expand.setAttribute("aria-expanded", "false");
    bar.append(copy7, expand);
    toolbar2.append(bar);
    wrapper.prepend(toolbar2);
    wrapper.setAttribute(wrapMark, "");
    table.setAttribute(tableMark, "");
    states.set(table, state);
    resize.observe(table);
    resize.observe(wrapper);
    const originalOverlay = wrapper.getAttribute("data-overlay-surface");
    state.restoreOverlay = () => {
      if (originalOverlay === null) wrapper.removeAttribute("data-overlay-surface");
      else wrapper.setAttribute("data-overlay-surface", originalOverlay);
    };
    wrapper.addEventListener("focus", (event) => {
      if (event.target === wrapper || toolbar2.contains(event.target)) wrapper.setAttribute("data-overlay-surface", "");
    }, { ...options, capture: true });
    wrapper.addEventListener("blur", () => queueMicrotask(() => {
      if (document.activeElement !== wrapper && !toolbar2.contains(document.activeElement)) state.restoreOverlay();
    }), { ...options, capture: true });
    for (const control4 of [copy7, expand]) {
      control4.addEventListener("pointerenter", () => showTip(control4), options);
      control4.addEventListener("focus", () => {
        if (control4.matches(":focus-visible")) showTip(control4);
      }, options);
      control4.addEventListener("pointerleave", hideTip, options);
      control4.addEventListener("blur", hideTip, options);
    }
    copy7.addEventListener("click", async () => {
      if (state.copying || copy7.hasAttribute("data-copied")) return;
      const clone = copyOf(table);
      const source = markdownSource(table) || renderedMarkdown(clone);
      if (!source) return;
      state.copying = true;
      try {
        if (!writeRichCopy(source, clipboardHtml(clone)) && !await ctx.os.writeClipboard(source)) {
          throw new Error("Clipboard unavailable");
        }
        if (!copy7.isConnected) return;
        copy7.setAttribute("data-copied", "");
        copy7.setAttribute("aria-label", strings().copied);
        if (tipButton === copy7 && !tip2.hidden) tip2.textContent = strings().copied;
        state.copyTimer = setTimeout(() => {
          copy7.removeAttribute("data-copied");
          copy7.setAttribute("aria-label", strings().copy);
          if (tipButton === copy7 && !tip2.hidden) tip2.textContent = strings().copy;
        }, 1500);
      } catch {
        if (copy7.isConnected) host14.notify({ kind: "error", message: ctx.i18n.t("copyMessageError") });
      } finally {
        state.copying = false;
      }
    }, options);
    expand.addEventListener("click", () => openPreview(state), options);
    wrapper.addEventListener("scroll", () => {
      applyOverflow(measureOverflow(state));
      hideTip();
    }, options);
    wrapper.addEventListener("keydown", (event) => {
      if (!wrapper.hasAttribute("data-hcv-table-overflow") || event.defaultPrevented || event.ctrlKey || event.metaKey || event.shiftKey || event.key !== "ArrowLeft" && event.key !== "ArrowRight" || event.target !== wrapper && !toolbar2.contains(event.target)) return;
      event.preventDefault();
      wrapper.scrollBy({ left: (event.key === "ArrowLeft" ? -1 : 1) * (event.altKey ? wrapper.clientWidth : 40) });
    }, options);
    return state;
  }
  function detach(state) {
    const { table, wrapper, toolbar: toolbar2, nativeAttributes } = state;
    if (preview3?.state === state) closePreview(false);
    if (toolbar2.contains(tipButton)) hideTip();
    state.listeners.abort();
    clearTimeout(state.copyTimer);
    resize.unobserve(table);
    resize.unobserve(wrapper);
    toolbar2.remove();
    state.restoreOverlay();
    table.removeAttribute(tableMark);
    wrapper.removeAttribute(wrapMark);
    if (wrapper.hasAttribute("data-hcv-table-overflow")) {
      wrapper.removeAttribute("data-hcv-table-overflow");
      for (const [name, value] of Object.entries(nativeAttributes)) {
        if (value === null) wrapper.removeAttribute(name);
        else wrapper.setAttribute(name, value);
      }
    }
    for (const name of ["left", "right", "fade-left", "fade-right"]) wrapper.style.removeProperty("--hcv-table-" + name);
    for (const cell of table.querySelectorAll(`[${columnMark}]`)) {
      cell.removeAttribute(columnMark);
      cell.removeAttribute("data-hcv-table-number");
    }
    states.delete(table);
  }
  function flush() {
    frame = 0;
    const enabled = root.matches(active2);
    for (const state of states.values()) {
      if (!enabled || !state.table.isConnected || state.table.parentElement !== state.wrapper) detach(state);
    }
    if (enabled) {
      const measured = [];
      let refresh = false;
      for (const table of pending) {
        if (!table.isConnected || !table.matches(nativeTable)) continue;
        const state = states.get(table) || attach(table);
        markColumns(table);
        state.copy.setAttribute("aria-label", state.copy.hasAttribute("data-copied") ? strings().copied : strings().copy);
        state.expand.setAttribute("aria-label", strings().expand);
        measured.push(state);
        refresh ||= preview3?.state === state;
      }
      updateOverflow(measured);
      if (refresh) refreshPreview();
    }
    pending.clear();
  }
  function queue() {
    if (!frame) frame = requestAnimationFrame(flush);
  }
  const observer = new MutationObserver((records) => {
    if (!root.matches(active2)) return;
    let removed = false;
    for (const { target, addedNodes, removedNodes } of records) {
      const element7 = target instanceof Element ? target : target.parentElement;
      if (element7?.closest(`[${toolbarMark}], [${dialogMark}], [data-hcv-table-tip]`)) continue;
      const table = element7?.closest("table");
      if (table?.matches(nativeTable)) pending.add(table);
      for (const node3 of addedNodes) {
        if (!(node3 instanceof Element)) continue;
        if (node3.matches(nativeTable)) pending.add(node3);
        else for (const child of node3.querySelectorAll(nativeTable)) pending.add(child);
      }
      for (const node3 of removedNodes) {
        if (node3 instanceof Element && (node3.matches(`[${tableMark}], [${wrapMark}]`) || node3.querySelector(`[${tableMark}], [${wrapMark}]`))) removed = true;
      }
    }
    if (pending.size || removed && states.size) queue();
  });
  observer.observe(document.body, { childList: true, characterData: true, subtree: true });
  ctx.addEventListener(document, "contentvisibilityautostatechange", (event) => {
    if (event.skipped || !root.matches(active2)) return;
    for (const table of event.target.querySelectorAll(`[${tableMark}]`)) pending.add(table);
    if (pending.size) queue();
  }, true);
  function collect() {
    if (root.matches(active2)) for (const table of document.querySelectorAll(nativeTable)) pending.add(table);
    queue();
  }
  function localize() {
    const copy7 = strings();
    for (const state of states.values()) {
      state.copy.setAttribute("aria-label", state.copy.hasAttribute("data-copied") ? copy7.copied : copy7.copy);
      state.expand.setAttribute("aria-label", copy7.expand);
      if (state.wrapper.hasAttribute("data-hcv-table-overflow")) state.wrapper.setAttribute("aria-label", copy7.scroll);
    }
    if (preview3) {
      for (const [node3, label3] of [[preview3.modal, copy7.preview], [preview3.region, copy7.scroll], [preview3.close, copy7.close]]) {
        node3.setAttribute("aria-label", label3);
      }
    }
    if (tipButton && !tip2.hidden) tip2.textContent = tipButton.getAttribute("aria-label");
  }
  const theme2 = new MutationObserver((records) => {
    if (records.some((record) => record.attributeName === "data-hermes-theme")) collect();
    if (records.some((record) => record.attributeName === "lang")) localize();
  });
  theme2.observe(root, { attributes: true, attributeFilter: ["lang", "data-hermes-theme"] });
  collect();
  window.addEventListener("scroll", hideTip, true);
  window.addEventListener("resize", hideTip);
  ctx.onDispose(() => {
    observer.disconnect();
    theme2.disconnect();
    resize.disconnect();
    cancelAnimationFrame(frame);
    closePreview(false);
    hideTip();
    window.removeEventListener("scroll", hideTip, true);
    window.removeEventListener("resize", hideTip);
    for (const state of states.values()) detach(state);
    tip2.remove();
    style.remove();
  });
}

// source/review-proposals.js
import { host as host15 } from "@hermes/plugin-sdk";

// source/review-proposal-data.js
var idPattern = "[0-9a-f]{8}";
function pendingProposals(kind, output) {
  if (kind !== "skills" && kind !== "memory") return null;
  const header2 = output.match(new RegExp(`^Pending ${kind} writes \\((\\d+)\\):\\n`));
  if (!header2) return null;
  const footer = `

Apply: /${kind} approve <id>   Reject: /${kind} reject <id>` + (kind === "skills" ? "\nReview full diff: /skills diff <id>" : "");
  if (!output.endsWith(footer)) return null;
  const body2 = output.slice(header2[0].length, -footer.length);
  const starts = [...body2.matchAll(new RegExp(`^ {2}(${idPattern})( \\[auto\\])? {2}`, "gm"))];
  if (!starts.length || starts[0].index !== 0 || starts.length !== Number(header2[1])) return null;
  const items2 = starts.map((match, index) => ({
    id: match[1],
    kind,
    auto: Boolean(match[2]),
    gist: body2.slice(match.index + match[0].length, starts[index + 1]?.index).trimEnd()
  }));
  return new Set(items2.map((item) => item.id)).size === items2.length ? items2 : null;
}
function skillProposal(output) {
  const prefix = output.match(new RegExp(`^# Pending skill write (${idPattern}): ([^\\n]+)\\n\\n`));
  if (!prefix) return null;
  const content = output.slice(prefix[0].length);
  if (!content.trim()) return null;
  return { id: prefix[1], kind: "skills", gist: prefix[2], content };
}
function skillSubject(gist) {
  const match = gist.match(/^(create|rewrite|patch|delete) '([^'\n]+)'/);
  if (match) return { operation: match[1], name: match[2] };
  const file = gist.match(/^(write|remove) .+ (?:in|from) '([^'\n]+)'$/);
  return file ? { operation: file[1], name: file[2] } : { operation: "change", name: "" };
}
function pairedSkillLines(content) {
  const lines = content.split("\n");
  if (!lines[0]?.startsWith("--- ") || !lines[1]?.startsWith("+++ ")) return null;
  if (!/^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@/.test(lines[2] || "")) return null;
  const change = lines.slice(3);
  if (change.some((line) => line.startsWith("@@") || line.startsWith("--- ") || line.startsWith("+++ "))) return null;
  const before = change.filter((line) => line.startsWith("-")).map((line) => line.slice(1));
  const after = change.filter((line) => line.startsWith("+")).map((line) => line.slice(1));
  if (before.length !== 1 || after.length !== 1) return null;
  if (change.indexOf("+" + after[0]) !== change.indexOf("-" + before[0]) + 1) return null;
  return { before: before[0], after: after[0] };
}
function memoryProposal(record, id2) {
  if (record?.id !== id2 || record.subsystem !== "memory") return null;
  const payload = record.payload;
  if (!payload || !["user", "memory"].includes(payload.target) || record.action !== payload.action) return null;
  const operations = payload.action === "batch" ? payload.operations : [payload];
  if (!Array.isArray(operations) || !operations.length) return null;
  const changes2 = [];
  for (const op of operations) {
    const { action, old_text: old, matched_entry: entry } = op || {};
    const content = op?.content ?? op?.new_text;
    if (action === "add" && typeof content === "string" && content.trim()) {
      changes2.push({ action, content });
      continue;
    }
    if (typeof entry !== "string" || !entry.trim()) return null;
    if (action === "remove") changes2.push({ action, entry });
    else if (action === "replace" && typeof content === "string") changes2.push({ action, entry, content });
    else if (action === "patch" && typeof old === "string" && old.trim() && typeof content === "string") {
      changes2.push({ action, entry, old, content });
    } else return null;
  }
  return { target: payload.target, changes: changes2 };
}

// source/review-proposals.js
var surface4 = '[data-chat-surface][data-composer-target="main"]:not([data-hud-shell] *)';
var nativeRow = '[data-slot="aui_system-message-root"][data-role="system"]';
var stack = "[data-hcv-proposals]";
var enhanced2 = "[data-hcv-review-notice]";
var hidden2 = "[hidden], [data-pane-hidden]";
var copy4 = {
  ru: {
    skills: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u043F\u043E \u0441\u043A\u0438\u043B\u043B\u0430\u043C",
    memory: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0434\u043B\u044F \u043F\u0430\u043C\u044F\u0442\u0438",
    auto: "\u0418\u0437 \u0430\u0432\u0442\u043E\u0440\u0430\u0437\u0431\u043E\u0440\u0430",
    create: "\u0421\u043E\u0437\u0434\u0430\u0442\u044C \u0441\u043A\u0438\u043B\u043B",
    rewrite: "\u041F\u0435\u0440\u0435\u043F\u0438\u0441\u0430\u0442\u044C \u0441\u043A\u0438\u043B\u043B",
    patch: "\u041E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043A\u0438\u043B\u043B",
    delete: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0441\u043A\u0438\u043B\u043B",
    write: "\u0417\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0444\u0430\u0439\u043B \u0441\u043A\u0438\u043B\u043B\u0430",
    remove: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0444\u0430\u0439\u043B \u0441\u043A\u0438\u043B\u043B\u0430",
    change: "\u0418\u0437\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u043A\u0438\u043B\u043B",
    remember: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u0432 \u043F\u0430\u043C\u044F\u0442\u044C",
    profile: "\u041F\u0440\u043E\u0444\u0438\u043B\u044C \u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044F",
    notes: "\u041F\u0430\u043C\u044F\u0442\u044C \u0413\u0435\u0440\u043C\u0435\u0441\u0430",
    future: "\u0411\u0443\u0434\u0435\u0442 \u0443\u0447\u0438\u0442\u044B\u0432\u0430\u0442\u044C\u0441\u044F \u0432 \u0431\u0443\u0434\u0443\u0449\u0438\u0445 \u0447\u0430\u0442\u0430\u0445 \u044D\u0442\u043E\u0433\u043E \u043F\u0440\u043E\u0444\u0438\u043B\u044F.",
    before: "\u0411\u044B\u043B\u043E",
    after: "\u0421\u0442\u0430\u043D\u0435\u0442",
    entry: "\u0422\u0435\u043A\u0443\u0449\u0430\u044F \u0437\u0430\u043F\u0438\u0441\u044C",
    fragment: "\u0417\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442",
    addNote: "\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u043C\u0435\u0442\u043A\u0430",
    removeNote: "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0437\u0430\u043C\u0435\u0442\u043A\u0443",
    skillText: "\u041F\u0440\u0435\u0434\u043B\u0430\u0433\u0430\u0435\u043C\u0430\u044F \u043F\u0440\u0430\u0432\u043A\u0430",
    inspect: "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043F\u0440\u0430\u0432\u043A\u0443",
    hide: "\u0421\u0432\u0435\u0440\u043D\u0443\u0442\u044C \u043F\u0440\u0430\u0432\u043A\u0443",
    load: "\u041E\u0442\u043A\u0440\u044B\u0432\u0430\u044E \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435\u2026",
    inspectNote: "\u041E\u0442\u043A\u0440\u044B\u0442\u044C \u0437\u0430\u043C\u0435\u0442\u043A\u0443",
    accept: "\u041F\u0440\u0438\u043D\u044F\u0442\u044C",
    reject: "\u041E\u0442\u043A\u043B\u043E\u043D\u0438\u0442\u044C",
    saved: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043F\u0440\u0438\u043D\u044F\u0442\u043E",
    rejected: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u043E",
    unavailable: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u043F\u043E\u043B\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442. \u041C\u043E\u0436\u043D\u043E \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043C\u0430\u043D\u0434\u043E\u0439",
    details: "\u0414\u0430\u043D\u043D\u044B\u0435 \u0413\u0435\u0440\u043C\u0435\u0441\u0430",
    changed: "\u041F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0438\u0437\u043C\u0435\u043D\u0438\u043B\u043E\u0441\u044C. \u041F\u0440\u043E\u0432\u0435\u0440\u044C \u0435\u0433\u043E \u043F\u0435\u0440\u0435\u0434 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u0438\u0435\u043C.",
    unconfirmed: "\u0420\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442 \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D. \u041E\u0431\u043D\u043E\u0432\u0438 \u0441\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043C\u0430\u043D\u0434\u043E\u0439"
  },
  en: {
    skills: "Skill proposals",
    memory: "Memory proposals",
    auto: "From background review",
    create: "Create skill",
    rewrite: "Rewrite skill",
    patch: "Update skill",
    delete: "Delete skill",
    write: "Write skill file",
    remove: "Remove skill file",
    change: "Change skill",
    remember: "Save to memory",
    profile: "User profile",
    notes: "Hermes memory",
    future: "This will be used in future chats in this profile.",
    before: "Before",
    after: "After",
    entry: "Current entry",
    fragment: "Replace passage",
    addNote: "New note",
    removeNote: "Remove note",
    skillText: "Proposed change",
    inspect: "View proposed change",
    hide: "Hide change",
    load: "Opening proposal\u2026",
    inspectNote: "Open note",
    accept: "Approve",
    reject: "Reject",
    saved: "Proposal approved",
    rejected: "Proposal rejected",
    unavailable: "Could not open the full proposal. Refresh the list with",
    details: "Hermes details",
    changed: "The proposal changed. Review it before approving.",
    unconfirmed: "The result is unconfirmed. Refresh the list with"
  }
};
function element5(tag, part, text) {
  const node3 = document.createElement(tag);
  if (part) node3.dataset.hcvProposalPart = part;
  if (text !== void 0) node3.textContent = text;
  return node3;
}
function currentScope(row5) {
  if (!row5.isConnected || !row5.closest(surface4) || row5.closest(hidden2)) return null;
  const session = host15.state.activeSessionId.get();
  const profile2 = host15.state.profile.get() || "default";
  const connection = host15.state.connectionId.get();
  const focused = host15.state.focusedSessionId.get();
  const owner = host15.state.focusedSessionOwner?.get();
  const socket = host15.getGateway();
  if (!session || !socket || focused && focused !== session) return null;
  if (owner && (owner.profile !== profile2 || connection && owner.connectionId !== connection)) return null;
  return { session, profile: profile2, connection: owner?.connectionId ?? connection, socket };
}
function sameScope(a, b) {
  return Boolean(a && b && a.session === b.session && a.profile === b.profile && a.connection === b.connection && a.socket === b.socket);
}
function normalize(text) {
  return text.replaceAll("\r\n", "\n").trim();
}
async function slash(scope4, kind, operation, id2) {
  const command2 = [kind, operation, id2].filter(Boolean).join(" ");
  const response3 = await scope4.socket.request("slash.exec", { session_id: scope4.session, command: command2 }, 12e3);
  if (response3?.warning || typeof response3?.output !== "string") throw new Error("No confirmed command output");
  return response3.output.replaceAll("\r\n", "\n");
}
async function loadMemory(scope4, id2) {
  if (scope4.connection !== "local" || !/^[\w-]+$/.test(scope4.profile)) return null;
  const desktop = window.hermesDesktop;
  const info = await desktop?.getVersion?.();
  const home = info?.hermesHome;
  if (!home || !desktop?.readFileText) return null;
  const path = home.replace(/[\\/]+$/, "") + (scope4.profile === "default" ? "" : "/profiles/" + scope4.profile) + "/pending/memory/" + id2 + ".json";
  const file = await desktop.readFileText(path);
  const pathKey2 = (value) => {
    const normalized2 = String(value).replaceAll("\\", "/");
    return info.platform === "win32" ? normalized2.toLowerCase() : normalized2;
  };
  if (file?.truncated || file?.binary || typeof file?.text !== "string" || pathKey2(file.path) !== pathKey2(path)) return null;
  const data = memoryProposal(JSON.parse(file.text), id2);
  return data && { data, signature: file.text };
}
async function loadPreview(scope4, item) {
  if (item.kind === "memory") return loadMemory(scope4, item.id);
  const signature = await slash(scope4, "skills", "diff", item.id);
  const data = skillProposal(signature);
  if (data?.id !== item.id || /^\s*\((?:patch (?:would fail|['"])|[^)]* on ')/.test(data.content)) return null;
  return { signature, data };
}
function block(label3, text, part = "excerpt") {
  const section2 = element5("div", part);
  section2.append(element5("div", "label", label3), element5("div", "text", text));
  return section2;
}
function changedPair(before, after, t) {
  const pair2 = element5("div", "pair");
  pair2.append(block(t.before, before, "before"), block(t.after, after, "after"));
  return pair2;
}
function showPreview(body2, item, data, t) {
  const content = document.createDocumentFragment();
  if (item.kind === "skills") {
    const pair2 = pairedSkillLines(data.content);
    content.append(pair2 ? changedPair(pair2.before, pair2.after, t) : block(t.skillText, data.content, "full"));
  } else {
    for (const op of data.changes) {
      if (op.action === "add") content.append(block(t.addNote, op.content));
      if (op.action === "remove") content.append(block(t.removeNote, op.entry, "before"));
      if (op.action === "replace") content.append(changedPair(op.entry, op.content, t));
      if (op.action === "patch") {
        content.append(block(t.entry, op.entry), element5("div", "label", t.fragment), changedPair(op.old, op.content, t));
      }
    }
    if (data.changes.some((op) => op.action !== "remove")) content.append(element5("p", "context", t.future));
  }
  body2.replaceChildren(content);
}
function button2(text, part, handler) {
  const control4 = element5("button", part, text);
  control4.type = "button";
  control4.addEventListener("click", (event) => {
    if (event.isTrusted) void handler();
  });
  return control4;
}
function card(item, t, bound, isCurrent, completed, onComplete) {
  const skill = item.kind === "skills";
  const subject = skill ? skillSubject(item.gist) : null;
  const headingText = skill ? t[subject.operation] : t.remember;
  const article = element5("section", "card");
  article.setAttribute("aria-label", headingText);
  article.addEventListener("focus", () => article.setAttribute("data-overlay-surface", ""), true);
  article.addEventListener("blur", () => queueMicrotask(() => {
    if (!article.contains(document.activeElement)) article.removeAttribute("data-overlay-surface");
  }), true);
  const header2 = element5("div", "header");
  const icon8 = element5("span", skill ? "skill-icon" : "memory-icon");
  icon8.setAttribute("aria-hidden", "true");
  const heading = element5("div", "heading");
  const title = element5("h3", "title", headingText);
  const info = element5("div", "subtitle");
  heading.append(title, info);
  header2.append(icon8, heading);
  const body2 = element5("div", "body");
  const footer = element5("div", "actions");
  const status2 = element5("span", "status");
  status2.setAttribute("role", "status");
  status2.tabIndex = -1;
  const inspect = button2(t.inspect, "inspect", open);
  inspect.setAttribute("aria-expanded", "false");
  const reject = button2(t.reject, "reject", () => decide("reject"));
  const accept = button2(t.accept, "accept", () => decide("approve"));
  footer.append(status2, inspect, reject, accept);
  article.append(header2, body2, footer);
  let preview3 = item.content ? { data: item, signature: item.original } : null;
  let shown = Boolean(preview3);
  let incomplete = false;
  let busy = false;
  let finished2 = false;
  function update() {
    const target = preview3?.data?.target ?? (item.gist.includes("user profile") ? "user" : "memory");
    info.textContent = [skill ? subject.name : t[target === "user" ? "profile" : "notes"], item.auto ? t.auto : ""].filter(Boolean).join(" \xB7 ");
    info.hidden = !info.textContent;
    body2.hidden = !(preview3 && shown) && !incomplete;
    inspect.hidden = finished2 || !skill && (Boolean(preview3) || busy);
    inspect.disabled = !bound || busy;
    inspect.textContent = skill ? shown ? t.hide : t.inspect : t.inspectNote;
    inspect.setAttribute("aria-expanded", String(shown));
    reject.hidden = !bound || finished2;
    accept.hidden = !bound || finished2 || !preview3 || !shown;
    accept.disabled = reject.disabled = busy;
  }
  function describe() {
    incomplete = false;
    shown = true;
    showPreview(body2, item, preview3.data, t);
    update();
  }
  function close2(message, focus) {
    finished2 = true;
    status2.textContent = message;
    update();
    if (focus) status2.focus({ preventScroll: true });
  }
  function needsList(message) {
    return message + " /" + item.kind + " pending";
  }
  function unavailable() {
    preview3 = null;
    shown = false;
    incomplete = true;
    const details = element5("details", "details");
    details.append(element5("summary", "label", t.details), element5("div", "text", item.gist));
    body2.replaceChildren(details);
    status2.textContent = needsList(t.unavailable);
  }
  async function open() {
    if (busy || finished2 || !isCurrent()) return;
    if (preview3) {
      shown = !shown;
      update();
      return;
    }
    busy = true;
    status2.textContent = t.load;
    update();
    try {
      const result = await loadPreview(bound, item);
      if (!isCurrent()) return;
      if (!result) {
        unavailable();
        return;
      }
      preview3 = result;
      status2.textContent = "";
      describe();
    } catch {
      if (isCurrent()) unavailable();
    } finally {
      busy = false;
      update();
    }
  }
  async function decide(action) {
    if (busy || finished2 || !isCurrent() || action === "approve" && (!preview3 || !shown)) return;
    busy = true;
    status2.textContent = "";
    update();
    let attempted = false;
    try {
      if (action === "approve") {
        const fresh = await loadPreview(bound, item);
        if (!isCurrent()) return;
        if (!fresh) {
          unavailable();
          return;
        }
        if (fresh.signature !== preview3.signature) {
          preview3 = fresh;
          status2.textContent = t.changed;
          describe();
          return;
        }
      } else {
        const queue = pendingProposals(item.kind, normalize(await slash(bound, item.kind, "pending")));
        if (!isCurrent()) return;
        if (!queue?.some((proposal) => proposal.id === item.id && proposal.gist === item.gist)) {
          status2.textContent = needsList(t.unavailable);
          return;
        }
      }
      attempted = true;
      const output = normalize(await slash(bound, item.kind, action, item.id));
      const success = action === "approve" ? output.split("\n", 1)[0] === "Approved 1 " + item.kind + " write(s)." : output === "Rejected pending " + item.kind + " write '" + item.id + "'.";
      if (success) onComplete(action);
      if (!isCurrent()) return;
      if (success) close2(action === "approve" ? t.saved : t.rejected, true);
      else close2(needsList(t.unconfirmed), true);
    } catch {
      if (!isCurrent()) return;
      if (attempted) close2(needsList(t.unconfirmed), true);
      else status2.textContent = needsList(t.unavailable);
    } finally {
      busy = false;
      update();
    }
  }
  if (preview3) describe();
  if (completed) close2(completed === "approve" ? t.saved : t.rejected, false);
  else if (bound && !skill) queueMicrotask(() => {
    void open();
  });
  else if (!bound && !preview3) unavailable();
  update();
  return article;
}
function styles3(active2) {
  const s = active2 + " " + stack;
  const row5 = active2 + " " + enhanced2;
  const part = (name) => s + ' [data-hcv-proposal-part="' + name + '"]';
  return `
    ${row5} {
      inline-size: min(100%, 48rem); max-inline-size: 100%; padding: 6px 0 10px; text-align: start;
    }
    ${row5} > :not(${stack}) { display: none; }
    ${s} {
      display: grid; gap: 10px; inline-size: 100%; min-inline-size: 0;
      color: var(--hcv-text); font: 14px/1.5 ${codexReference.font};
    }
    ${part("card")} {
      container-type: inline-size; min-inline-size: 0; border-radius: 14px;
      background: light-dark(#f7f7f7, #222222); border: 1px solid var(--hcv-stroke);
    }
    ${part("header")} { display: flex; align-items: center; gap: 12px; padding: 14px 16px 10px; }
    ${part("heading")} { min-inline-size: 0; }
    ${part("title")} { margin: 0; color: var(--hcv-text); font-size: 14px; font-weight: 600; }
    ${part("subtitle")}, ${part("context")}, ${part("status")} {
      color: var(--hcv-muted); font-size: 12px; line-height: 1.5; overflow-wrap: anywhere;
    }
    ${part("subtitle")} { margin-block-start: 2px; }
    ${part("skill-icon")}, ${part("memory-icon")} {
      flex: 0 0 40px; block-size: 40px; display: grid; place-items: center; border-radius: 8px;
      color: var(--hcv-text); background: light-dark(#ededed, #181818);
    }
    ${part("skill-icon")}::before, ${part("memory-icon")}::before {
      content: ""; inline-size: 18px; block-size: 18px; background: currentColor;
    }
    ${part("skill-icon")}::before { mask: ${codexMask("chatSkill")} center / contain no-repeat; }
    ${part("memory-icon")}::before { mask: ${codexMask("memory")} center / contain no-repeat; }
    ${part("body")} {
      display: grid; gap: 8px; min-inline-size: 0; padding: 2px 16px 10px;
      overflow-wrap: anywhere;
    }
    ${part("pair")} { display: grid; gap: 8px; }
    ${part("before")}, ${part("after")}, ${part("excerpt")}, ${part("full")} {
      min-inline-size: 0; padding: 8px 12px; border-radius: 8px; border: 1px solid var(--hcv-stroke);
      background: light-dark(#ffffff, #1c1c1c);
    }
    ${part("before")} { border-inline-start: 2px solid light-dark(#ac2d35, #e37479); }
    ${part("after")} { border-inline-start: 2px solid light-dark(#257445, #6acf8b); }
    ${part("label")} { color: var(--hcv-muted); font-size: 12px; font-weight: 500; margin-block-end: 3px; }
    ${part("text")} { color: var(--hcv-text); white-space: pre-wrap; overflow-wrap: anywhere; }
    ${part("full")} { max-block-size: 340px; overflow: auto; overscroll-behavior: contain; }
    ${part("context")} { margin: 0; }
    ${part("actions")} {
      display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-end;
      gap: 8px; padding: 2px 16px 14px;
    }
    ${part("status")} { margin-inline-end: auto; }
    ${part("status")}:empty { display: none; }
    ${s} button {
      min-block-size: 32px; max-inline-size: 100%; padding: 4px 12px; border: 1px solid var(--hcv-stroke);
      border-radius: 8px; color: var(--hcv-text); background: transparent; font: 500 13px/1.4 ${codexReference.font};
      cursor: pointer; white-space: normal;
    }
    ${s} button:is(:hover, :focus-visible) { background: var(--hcv-hover); }
    ${s} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 2px; }
    ${s} button:disabled { cursor: default; opacity: .55; }
    ${s} button[data-hcv-proposal-part="accept"] {
      border-color: transparent; background: var(--hcv-action); color: var(--hcv-ink);
    }
    ${s} button[data-hcv-proposal-part="accept"]:hover:not(:disabled) { opacity: .86; }
    ${s} [hidden] { display: none; }
    @container (max-width: 332px) {
      ${part("actions")} { align-items: stretch; flex-direction: column; }
      ${part("status")} { margin: 0; }
    }
  `;
}
function readRow(row5) {
  const label3 = row5.firstElementChild;
  if (!label3?.classList.contains("font-mono")) return null;
  const kind = label3.textContent.trim().slice(1);
  if (label3.textContent.trim() !== "/" + kind || !["skills", "memory"].includes(kind)) return null;
  const output = normalize(row5.querySelector(":scope > .whitespace-pre-wrap")?.textContent ?? "");
  const queue = pendingProposals(kind, output);
  if (queue) return { kind, output, items: queue };
  const detail = kind === "skills" ? skillProposal(output) : null;
  return detail && { kind, output, items: [{ ...detail, original: output }] };
}
function registerReviewProposals(ctx, active2) {
  const root = document.documentElement;
  mountCSS(ctx, "data-hcv-proposals-style", styles3(active2), chatStyles);
  const rows = /* @__PURE__ */ new Map();
  const pending = /* @__PURE__ */ new Set();
  const decisions = /* @__PURE__ */ new Map();
  let frame = 0;
  const enabled = () => root.matches(active2);
  const locale = () => root.lang.toLowerCase().startsWith("ru") ? "ru" : "en";
  function clear(row5) {
    rows.get(row5)?.panel.remove();
    rows.delete(row5);
    row5.removeAttribute("data-hcv-review-notice");
  }
  function render(row5) {
    if (!row5.isConnected || !row5.closest(surface4)) return clear(row5);
    const notice2 = readRow(row5);
    if (!notice2) return clear(row5);
    const lang = locale();
    const scope4 = currentScope(row5);
    const last = rows.get(row5);
    if (last?.output === notice2.output && lang === last.lang && last.panel.isConnected && (!last.scope && !scope4 || sameScope(last.scope, scope4))) return;
    clear(row5);
    const panel2 = element5("div");
    panel2.dataset.hcvProposals = notice2.kind;
    panel2.setAttribute("role", "group");
    panel2.setAttribute("aria-label", copy4[lang][notice2.kind]);
    for (const item of notice2.items) {
      const key = scope4 && JSON.stringify([scope4.connection, scope4.profile, item.kind, item.id]);
      panel2.append(card(
        item,
        copy4[lang],
        scope4,
        () => enabled() && panel2.isConnected && sameScope(scope4, currentScope(row5)),
        key && decisions.get(key),
        (action) => {
          if (!key) return;
          decisions.set(key, action);
          if (decisions.size > 256) decisions.delete(decisions.keys().next().value);
        }
      ));
    }
    row5.append(panel2);
    row5.dataset.hcvReviewNotice = "";
    rows.set(row5, { panel: panel2, output: notice2.output, lang, scope: scope4 });
  }
  function flush() {
    frame = 0;
    for (const row5 of rows.keys()) if (!row5.isConnected) clear(row5);
    for (const row5 of pending) render(row5);
    pending.clear();
  }
  function collect(node3) {
    const el2 = node3 instanceof Element ? node3 : node3.parentElement;
    if (!el2 || el2.closest(stack)) return;
    const row5 = el2.closest(nativeRow);
    if (row5?.closest(surface4)) pending.add(row5);
    for (const entry of el2.querySelectorAll(nativeRow)) if (entry.closest(surface4)) pending.add(entry);
  }
  function schedule() {
    if (!frame) frame = requestAnimationFrame(flush);
  }
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      if (record.type === "characterData") collect(record.target);
      else for (const node3 of record.addedNodes) collect(node3);
    }
    if (pending.size || rows.size) schedule();
  });
  function sync() {
    observer.disconnect();
    cancelAnimationFrame(frame);
    frame = 0;
    pending.clear();
    if (enabled()) {
      collect(document.body);
      schedule();
      observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    } else for (const row5 of rows.keys()) clear(row5);
  }
  const theme2 = new MutationObserver(sync);
  theme2.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  const unsubscribe = [
    host15.state.activeSessionId,
    host15.state.focusedSessionId,
    host15.state.focusedSessionOwner,
    host15.state.connectionId,
    host15.state.profile,
    host15.state.gateway
  ].filter(Boolean).map((atom7) => atom7.listen(sync));
  sync();
  ctx.onDispose(() => {
    observer.disconnect();
    theme2.disconnect();
    cancelAnimationFrame(frame);
    for (const stop of unsubscribe) stop();
    for (const row5 of rows.keys()) clear(row5);
    pending.clear();
    decisions.clear();
  });
}

// source/draft-setup.js
import { host as host16 } from "@hermes/plugin-sdk";
var primary3 = '[data-chat-surface][data-composer-target="main"]:not([data-hud-shell] *, [inert] *)';
var formSelector = 'form[data-slot="composer-root"]:not([data-popped-out])';
var sidebarSelector = '[data-slot="sidebar"][data-tour="sessions-sidebar"]';
var nativeDevice = '[data-slot="statusbar"] [data-slot="connection-switcher"] button[aria-haspopup="menu"]';
var toolbar = "[data-hcv-draft-bar]";
var settingsRoute = "/settings?tab=connections";
var menuWidths = { projects: 260, device: 280, git: 260 };
var toolbarInset = 13 + 5;
var copy5 = {
  ru: {
    bar: "\u041F\u0430\u0440\u0430\u043C\u0435\u0442\u0440\u044B \u043D\u043E\u0432\u043E\u0433\u043E \u0447\u0430\u0442\u0430",
    projects: "\u0412\u044B\u0431\u0440\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442",
    search: "\u041F\u043E\u0438\u0441\u043A \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432",
    create: "\u041D\u043E\u0432\u044B\u0439 \u043F\u0440\u043E\u0435\u043A\u0442",
    none: "\u0420\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0431\u0435\u0437 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    noProject: "\u0411\u0435\u0437 \u043F\u0440\u043E\u0435\u043A\u0442\u0430",
    loading: "\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430\u2026",
    empty: "\u041F\u0440\u043E\u0435\u043A\u0442\u044B \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u044B",
    projectError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442\u044B",
    actionsError: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0435 \u043F\u043E\u043A\u0430 \u043D\u0435\u0434\u043E\u0441\u0442\u0443\u043F\u043D\u043E. \u041E\u0442\u043A\u0440\u043E\u0439\u0442\u0435 \u043F\u0430\u043D\u0435\u043B\u044C \u0441\u0435\u0430\u043D\u0441\u043E\u0432.",
    device: "\u042D\u0442\u043E\u0442 \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440",
    location: "\u0420\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0432",
    manage: "\u0423\u043F\u0440\u0430\u0432\u043B\u044F\u0442\u044C \u0448\u043B\u044E\u0437\u0430\u043C\u0438\u2026",
    configure: "\u041D\u0430\u0441\u0442\u0440\u043E\u0438\u0442\u044C \u043B\u043E\u043A\u0430\u043B\u044C\u043D\u0443\u044E \u0441\u0440\u0435\u0434\u0443",
    worktree: "\u041D\u043E\u0432\u043E\u0435 \u0440\u0430\u0431\u043E\u0447\u0435\u0435 \u0434\u0435\u0440\u0435\u0432\u043E",
    nativeWorktree: "\u041D\u043E\u0432\u044B\u0439 worktree",
    branchError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0442\u043A\u0440\u044B\u0442\u044C \u0432\u0435\u0442\u043A\u0438",
    switchError: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u043F\u0435\u0440\u0435\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u0432\u0435\u0442\u043A\u0443",
    branch: "\u0412\u0435\u0442\u043A\u0430",
    noBranch: "\u041D\u0435\u0442 \u0432\u0435\u0442\u043A\u0438",
    environment: "\u0421\u0440\u0435\u0434\u0430",
    noEnvironment: "\u041D\u0435\u0442 \u043E\u043A\u0440\u0443\u0436\u0435\u043D\u0438\u044F"
  },
  en: {
    bar: "New chat setup",
    projects: "Choose a project",
    search: "Search projects",
    create: "New project",
    none: "Work without a project",
    noProject: "No project",
    loading: "Loading\u2026",
    empty: "No matching projects",
    projectError: "Could not load projects",
    actionsError: "This action is unavailable. Open the sessions sidebar.",
    device: "This computer",
    location: "Work in",
    manage: "Manage gateways\u2026",
    configure: "Configure local environment",
    worktree: "New worktree",
    nativeWorktree: "New worktree",
    branchError: "Could not load branches",
    switchError: "Could not switch branches",
    branch: "Branch",
    noBranch: "No branch",
    environment: "Environment",
    noEnvironment: "No environment"
  }
};
var labels11 = () => copy5[document.documentElement.lang.toLowerCase().startsWith("ru") ? "ru" : "en"];
function node2(tag, attrs = {}, text = "") {
  const element7 = document.createElement(tag);
  for (const [name, value] of Object.entries(attrs)) element7.setAttribute(name, value);
  if (text) element7.textContent = text;
  return element7;
}
function icon7(glyph3) {
  const element7 = node2("span", { "data-hcv-draft-icon": glyph3, "aria-hidden": "true" });
  Object.assign(element7.style, codexIconStyle(glyph3));
  return element7;
}
function button3(glyph3, name, action) {
  const element7 = node2("button", { type: "button", "data-hcv-draft-button": "" });
  const label3 = node2("span", { "data-hcv-draft-label": "" }, name);
  element7.append(icon7(glyph3), label3);
  if (action) element7.addEventListener("click", action);
  return { element: element7, label: label3, glyph: (name2) => element7.firstElementChild.replaceWith(icon7(name2)) };
}
function panel(kind) {
  return node2("div", { popover: "auto", "data-hcv-draft-menu": kind });
}
function position(popup, anchor, end = false) {
  const target = popup.closest("[data-radix-popper-content-wrapper]") || popup;
  const rect = anchor.getBoundingClientRect();
  const kind = popup.dataset.hcvDraftMenu || popup.dataset.hcvDraftNativeMenu;
  const width = Math.min(menuWidths[kind], window.innerWidth - 16);
  const top = rect.top - (kind === "git" ? 5 : 4);
  const left = Math.max(8, Math.min(end ? rect.right - width : rect.left, window.innerWidth - width - 8));
  target.style.setProperty("--hcv-draft-left", left + "px");
  target.style.setProperty("--hcv-draft-bottom", window.innerHeight - top + "px");
  target.style.setProperty("--hcv-draft-max-height", Math.max(80, top - 8) + "px");
}
function startNativeMenu(source, anchor, decorate) {
  if (!source || source.disabled) return null;
  const cleanup = () => {
    if (!menu) return;
    const wrapper = menu.closest("[data-radix-popper-content-wrapper]");
    menu.removeAttribute("data-hcv-draft-native-menu");
    title?.remove();
    for (const item of menu.querySelectorAll("[data-hcv-device-label]")) item.removeAttribute("data-hcv-device-label");
    for (const property of ["--hcv-draft-left", "--hcv-draft-bottom", "--hcv-draft-max-height"]) {
      wrapper?.style.removeProperty(property);
    }
  };
  let menu;
  let title;
  let frames = 0;
  let frame = 0;
  let stopped = false;
  const observer = new MutationObserver(queue);
  const dispose = (close2 = false) => {
    if (stopped) return;
    stopped = true;
    observer.disconnect();
    window.removeEventListener("resize", queue);
    cancelAnimationFrame(frame);
    cleanup();
    anchor.removeAttribute("data-hcv-native-open");
    anchor.setAttribute("aria-expanded", "false");
    if (close2 && menu?.dataset.state === "open") {
      menu.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true }));
    }
  };
  function update() {
    frame = 0;
    if (!anchor.isConnected || !source.isConnected) return dispose(true);
    if (menu && (!menu.isConnected || menu.dataset.state !== "open")) {
      if (document.activeElement === source) anchor.focus({ preventScroll: true });
      return dispose();
    }
    if (!menu) {
      const id2 = source.getAttribute("aria-controls");
      menu = id2 && document.getElementById(id2);
      if (!menu) {
        if (frames++ < 8) queue();
        else dispose();
        return;
      }
      menu.setAttribute("data-hcv-draft-native-menu", "device");
      title = node2("div", { "data-hcv-draft-menu-heading": "" }, labels11().location);
      menu.prepend(title);
      decorate?.(menu);
    }
    position(menu, anchor);
  }
  function queue() {
    if (!frame && !stopped) frame = requestAnimationFrame(update);
  }
  anchor.setAttribute("data-hcv-native-open", "");
  anchor.setAttribute("aria-expanded", "true");
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["data-state"] });
  window.addEventListener("resize", queue);
  source.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true, cancelable: true }));
  queue();
  return dispose;
}
function normalized(path) {
  const clean = (path || "").replaceAll("\\", "/").replace(/\/+$/, "");
  return /^[A-Z]:/i.test(clean) ? clean.toLowerCase() : clean;
}
function newDraftBar(form, current, localEnvironment) {
  const strip2 = node2("div", { "data-hcv-draft-bar": "", role: "group", "aria-label": labels11().bar });
  const projectMenu2 = panel("projects");
  const localMenu = panel("device");
  const gearMenu = panel("git");
  let connection;
  let dataScope;
  let worktreeCwd;
  let worktree = { label: "", branch: "" };
  let bridge;
  let disposed = false;
  const scope4 = () => JSON.stringify([host16.state.connectionId.get(), host16.state.profile.get()]);
  const activeHere = (key) => !disposed && current() && key === scope4();
  const canRequest = () => host16.state.gateway.get() === "open";
  const request = (method, params) => host16.request(method, { ...params, profile: host16.state.profile.get() }, 5e3);
  const error = () => host16.notify({ kind: "error", message: labels11().actionsError });
  const projects2 = button3("folder", labels11().noProject);
  const device = button3("laptop", labels11().device);
  const gear = button3("settings", "");
  const search = node2("input", { type: "search", "data-hcv-draft-search": "" });
  const results = node2("div", { "data-hcv-draft-projects": "" });
  const create = button3("plus", labels11().create, () => void createProject());
  const noProject = button3("close", labels11().none, () => void selectProject(null));
  const projectFooter = node2("div", { "data-hcv-draft-menu-footer": "" });
  projectFooter.append(create.element, noProject.element);
  const searchRow = node2("label", { "data-hcv-draft-search-row": "" });
  const separator = () => node2("div", { "data-hcv-draft-menu-separator": "", role: "separator" });
  searchRow.append(icon7("activitySearch"), search);
  projectMenu2.append(searchRow, separator(), results, separator(), projectFooter);
  function bind(opener, popup, end = false) {
    opener.popoverTargetElement = popup;
    opener.setAttribute("aria-haspopup", "dialog");
    popup.setAttribute("role", "dialog");
    popup.addEventListener("beforetoggle", (event) => {
      if (event.newState === "open") position(popup, opener, end);
    });
    popup.addEventListener("toggle", (event) => {
      opener.setAttribute("aria-expanded", String(event.newState === "open"));
    });
    popup.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || event.isComposing || event.defaultPrevented) return;
      event.preventDefault();
      event.stopPropagation();
      popup.hidePopover();
      opener.focus({ preventScroll: true });
    });
    opener.setAttribute("aria-expanded", "false");
  }
  bind(projects2.element, projectMenu2);
  bind(gear.element, gearMenu, true);
  bind(device.element, localMenu);
  device.element.addEventListener("click", (event) => {
    const source = document.querySelector(nativeDevice);
    if (!source) {
      device.element.setAttribute("aria-haspopup", "dialog");
      return;
    }
    event.preventDefault();
    bridge?.(true);
    device.element.setAttribute("aria-haspopup", "menu");
    bridge = startNativeMenu(source, device.element, (menu) => {
      for (const glyph3 of menu.querySelectorAll('[data-slot="connection-glyph"][data-connection-kind="local"]')) {
        const title = glyph3.nextElementSibling;
        title?.setAttribute("data-hcv-device-label", labels11().device);
      }
    });
  });
  const manage = button3("settings", labels11().manage, () => {
    localMenu.hidePopover();
    host16.navigate(settingsRoute);
  });
  const localHeading = node2("div", { "data-hcv-draft-menu-heading": "" });
  const selectedLocal = button3("laptop", labels11().device, () => localMenu.hidePopover());
  selectedLocal.element.append(icon7("check"));
  localMenu.append(localHeading, selectedLocal.element, manage.element);
  const gitHeading = node2("div", { "data-hcv-draft-menu-heading": "" });
  const localGit = () => host16.state.connectionId.get() === "local" && worktree.branch && window.hermesDesktop?.git;
  const worktreeTrigger = () => {
    const label3 = CSS.escape(labels11().nativeWorktree);
    const cwd = normalized(host16.state.cwd.get());
    return [...document.querySelectorAll(sidebarSelector + ' button[aria-label="' + label3 + '"]:has(> .codicon-git-branch)')].find((button5) => {
      const target = nativeWorktreeTarget(button5);
      return cwd && target && normalized(target.path) === cwd && (!target.connectionId || target.connectionId === host16.state.connectionId.get() && (target.profile || "default") === host16.state.profile.get());
    });
  };
  const newWorktree = button3("worktree", labels11().worktree, async () => {
    if (!localGit()) return;
    const key = scope4();
    const cwd = host16.state.cwd.get();
    const ready = () => activeHere(key) && cwd === host16.state.cwd.get();
    gearMenu.hidePopover();
    const trigger = worktreeTrigger();
    if (trigger) return trigger.click();
    if (!worktree.projectId) return error();
    const sidebar2 = await sidebarFor(sidebarSelector, key);
    if (!sidebar2 || !ready()) return;
    sidebar2.querySelector("[data-hcv-show-projects]")?.click();
    sidebar2.querySelector('[data-sessions-mode="project"] button[class~="group/back"]')?.click();
    const projectRow2 = sidebarSelector + ' [data-sessions-project="' + CSS.escape(worktree.projectId) + '"] [data-hcv-native-project-action][data-slot="row-button"]';
    const projectButton = await sidebarFor(projectRow2, key);
    if (!ready()) return;
    if (!projectButton) return error();
    const opened = await new Promise((resolve) => {
      const done = (result) => {
        observer.disconnect();
        clearTimeout(timeout);
        resolve(result);
      };
      const open = () => {
        if (!ready()) return done(false);
        const action = worktreeTrigger();
        if (!action) return;
        done(true);
        action.click();
      };
      const observer = new MutationObserver(open);
      const timeout = setTimeout(() => done(false), 1e3);
      observer.observe(sidebar2, { childList: true, subtree: true, attributes: true, attributeFilter: ["data-sessions-mode"] });
      projectButton.click();
      open();
    });
    if (!opened && ready()) error();
  });
  newWorktree.element.append(node2("span", { "data-hcv-draft-detail": "" }), icon7("right"));
  const branch = button3("branch", labels11().branch, () => void chooseBranch());
  const branchValue = node2("span", { "data-hcv-draft-detail": "" });
  branch.element.append(branchValue, icon7("right"));
  const environment = button3("settings", labels11().environment, () => {
    const cwd = host16.state.cwd.get();
    gearMenu.hidePopover();
    void localEnvironment?.open({ cwd, projectName: worktree.label, trigger: gear.element });
  });
  environment.element.disabled = true;
  const envValue = node2("span", { "data-hcv-draft-detail": "" });
  environment.element.append(envValue, icon7("right"));
  const gitOptions = node2("div", { "data-hcv-draft-branches": "" });
  const gitSetup = node2("div", { "data-hcv-draft-git-setup": "" });
  let branchRequest;
  gitSetup.append(newWorktree.element, branch.element, environment.element);
  gearMenu.append(gitHeading, gitSetup, gitOptions);
  gearMenu.addEventListener("beforetoggle", (event) => {
    if (event.newState !== "open") return;
    branchRequest = null;
    branch.element.removeAttribute("aria-busy");
    newWorktree.element.disabled = !localGit() || !(worktreeTrigger() || worktree.projectId);
    branch.element.disabled = !localGit();
    const cwd = host16.state.cwd.get();
    const key = scope4();
    environment.element.disabled = !localEnvironment || host16.state.connectionId.get() !== "local" || !cwd;
    envValue.textContent = labels11().noEnvironment;
    if (!environment.element.disabled) void localEnvironment.name(cwd).then((name) => {
      if (activeHere(key) && cwd === host16.state.cwd.get() && gearMenu.matches(":popover-open")) {
        envValue.textContent = name || labels11().noEnvironment;
      }
    });
    branchValue.textContent = worktree.branch || labels11().noBranch;
    gitHeading.textContent = labels11().configure;
    gitSetup.hidden = false;
    gitOptions.replaceChildren();
  });
  async function chooseBranch() {
    const git = localGit();
    const cwd = host16.state.cwd.get();
    const key = scope4();
    if (!git || !cwd || branchRequest) return;
    const pending = git.branchList(cwd).catch(() => null);
    branchRequest = pending;
    branch.element.setAttribute("aria-busy", "true");
    branchValue.textContent = labels11().loading;
    const ready = () => activeHere(key) && cwd === host16.state.cwd.get() && gearMenu.matches(":popover-open");
    const branches = await pending;
    if (branchRequest !== pending) return;
    branchRequest = null;
    branch.element.removeAttribute("aria-busy");
    branchValue.textContent = worktree.branch || labels11().noBranch;
    if (!ready()) return;
    gitSetup.hidden = true;
    gitHeading.textContent = labels11().branch;
    const localBranches = branches?.filter((row5) => !row5.isRemote && row5.name) || [];
    if (!localBranches.length) {
      gitOptions.replaceChildren(node2("p", { role: "status" }, labels11().branchError));
      return;
    }
    gitOptions.replaceChildren(...localBranches.map(({ name }) => {
      const row5 = button3("branch", name, async () => {
        if (!ready()) return;
        gearMenu.hidePopover();
        if (name === worktree.branch) return;
        try {
          const result = await git.branchSwitch(cwd, name);
          if (activeHere(key) && cwd === host16.state.cwd.get()) {
            worktree.branch = result.branch;
            localize();
            void refresh();
          }
        } catch {
          host16.notify({ kind: "error", message: labels11().switchError });
        }
      }).element;
      if (name === worktree.branch) {
        row5.setAttribute("aria-current", "true");
        row5.append(icon7("check"));
      }
      return row5;
    }));
    gitOptions.querySelector('[aria-current="true"], button')?.focus({ preventScroll: true });
  }
  let catalog;
  let catalogRequest;
  function renderProjects() {
    const text = search.value.trim().toLowerCase();
    const cwd = normalized(host16.state.cwd.get());
    const list = catalog?.filter(({ label: label3, path }) => (label3 + " " + path).toLowerCase().includes(text)) || [];
    const focusedPath = results.contains(document.activeElement) ? document.activeElement.title : null;
    if (!list.length) {
      const message = catalog ? labels11().empty : catalog === null || !canRequest() ? labels11().projectError : labels11().loading;
      results.replaceChildren(node2("p", { role: "status" }, message));
      if (focusedPath) search.focus({ preventScroll: true });
      return;
    }
    results.replaceChildren(...list.map(({ label: label3, path }) => {
      const row5 = button3("folder", label3, () => void selectProject(path)).element;
      row5.title = path;
      if (cwd && (cwd === normalized(path) || cwd.startsWith(normalized(path) + "/"))) {
        row5.setAttribute("aria-current", "true");
        row5.append(icon7("check"));
      }
      return row5;
    }));
    if (focusedPath) {
      const target = Array.from(results.children).find((item) => item.title === focusedPath) || search;
      target.focus({ preventScroll: true });
    }
  }
  function loadCatalog(key) {
    if (catalogRequest || !canRequest()) return;
    const pending = request("projects.tree", { preview_limit: 1 }).then(
      (reply) => (reply.projects || []).filter((row5) => !row5.isNoProject && row5.label).map((row5) => ({ label: row5.label, path: row5.path || row5.repos?.find((repo) => repo.path)?.path })).filter((row5) => typeof row5.path === "string" && row5.path.trim())
    ).catch(() => catalog ?? null);
    catalogRequest = pending;
    void pending.then((next) => {
      if (catalogRequest !== pending) return;
      catalogRequest = null;
      if (!activeHere(key) || JSON.stringify(next) === JSON.stringify(catalog)) return;
      catalog = next;
      if (projectMenu2.matches(":popover-open")) renderProjects();
    });
  }
  projectMenu2.addEventListener("beforetoggle", (event) => {
    if (event.newState !== "open") return;
    results.style.blockSize = catalog === void 0 && canRequest() ? "84px" : "";
    search.value = "";
    renderProjects();
    loadCatalog(scope4());
  });
  projectMenu2.addEventListener("toggle", (event) => {
    if (event.newState !== "open") return;
    results.style.blockSize = results.getBoundingClientRect().height + "px";
    search.focus({ preventScroll: true });
  });
  search.addEventListener("input", renderProjects);
  projectMenu2.addEventListener("keydown", (event) => {
    if (!["ArrowUp", "ArrowDown"].includes(event.key)) return;
    const options = [...results.querySelectorAll("button")];
    if (!options.length) return;
    event.preventDefault();
    const index = options.indexOf(document.activeElement);
    const target = index < 0 ? event.key === "ArrowDown" ? 0 : options.length - 1 : index + (event.key === "ArrowDown" ? 1 : -1);
    if (target < 0) search.focus();
    else options[Math.min(target, options.length - 1)].focus();
  });
  async function sidebarFor(selector, key) {
    let found = document.querySelector(selector);
    if (found) return found;
    host16.revealPane("sessions");
    for (let i = 0; i < 10 && activeHere(key); i++) {
      await new Promise(requestAnimationFrame);
      found = document.querySelector(selector);
      if (found) return found;
    }
    return null;
  }
  async function selectProject(path) {
    const key = scope4();
    projectMenu2.hidePopover();
    if (normalized(path) === normalized(host16.state.cwd.get())) return;
    const draft = await host16.composer.getDraft(null).catch(() => null);
    const sidebar2 = await sidebarFor(sidebarSelector, key);
    const openDraft = nativeDraftWorkspaceAction(sidebar2);
    if (!activeHere(key)) return;
    if (!openDraft) return error();
    openDraft(path);
    if (draft) {
      await new Promise(requestAnimationFrame);
      await new Promise(requestAnimationFrame);
      const next = await host16.composer.getDraft(null).catch(() => null);
      if (!next && !host16.state.focusedStoredSessionId.get() && !host16.state.busy.get() && key === scope4()) {
        await host16.composer.setDraft(null, draft).catch(() => {
        });
      }
    }
  }
  async function createProject() {
    const key = scope4();
    projectMenu2.hidePopover();
    const sidebar2 = await sidebarFor(sidebarSelector, key);
    if (!sidebar2 || !activeHere(key)) return;
    sidebar2.querySelector("[data-hcv-show-projects]")?.click();
    sidebar2.querySelector('[data-sessions-mode="project"] button[class~="group/back"]')?.click();
    const create2 = await sidebarFor(sidebarSelector + " [data-hcv-projects-actions] button:has(> .codicon-add)", key);
    if (activeHere(key)) {
      if (create2) create2.click();
      else error();
    }
  }
  function localize() {
    const t = labels11();
    strip2.setAttribute("aria-label", t.bar);
    projects2.element.setAttribute("aria-label", t.projects);
    projectMenu2.setAttribute("aria-label", t.projects);
    device.element.setAttribute("aria-label", t.location);
    localMenu.setAttribute("aria-label", t.location);
    gear.element.setAttribute("aria-label", t.configure);
    gear.element.title = t.configure;
    gearMenu.setAttribute("aria-label", t.configure);
    search.setAttribute("aria-label", t.search);
    search.placeholder = t.search;
    localHeading.textContent = t.location;
    gitHeading.textContent = t.configure;
    create.label.textContent = t.create;
    noProject.label.textContent = t.none;
    selectedLocal.label.textContent = t.device;
    manage.label.textContent = t.manage;
    newWorktree.label.textContent = t.worktree;
    branch.label.textContent = t.branch;
    branchValue.textContent = worktree.branch || t.noBranch;
    environment.label.textContent = t.environment;
    envValue.textContent = t.noEnvironment;
    projects2.label.textContent = worktree.label || t.noProject;
    device.label.textContent = connection?.kind === "local" || !connection ? t.device : connection.label;
  }
  let refreshId = 0;
  async function refresh() {
    const key = scope4();
    const id2 = ++refreshId;
    const cwd = host16.state.cwd.get();
    const folderLabel = cwd.split(/[/\\]/).filter(Boolean).at(-1) || "";
    if (cwd !== worktreeCwd || key !== dataScope) {
      worktreeCwd = cwd;
      const knownProject = key === dataScope && catalog?.find((row5) => normalized(row5.path) === normalized(cwd));
      worktree = { label: knownProject?.label || folderLabel, branch: "" };
    }
    if (key !== dataScope) {
      dataScope = key;
      catalog = void 0;
      catalogRequest = null;
      const active3 = host16.state.connectionId.get();
      connection = active3 && active3 !== "local" ? { kind: "remote", label: "\u2026" } : null;
      for (const menu of [projectMenu2, localMenu, gearMenu]) menu.hidePopover();
    }
    if (catalog === void 0) loadCatalog(key);
    localize();
    const active2 = host16.state.connectionId.get();
    const [devices, info] = await Promise.all([
      host16.connections().catch(() => []),
      cwd && canRequest() ? request("projects.for_cwd", { cwd }).catch(() => null) : null
    ]);
    if (!activeHere(key) || id2 !== refreshId) return;
    connection = devices.find((row5) => row5.id === active2) || connection;
    worktree = {
      label: info?.project?.name || folderLabel,
      branch: info?.branch || "",
      projectId: info?.project?.id
    };
    device.glyph(connection?.kind === "local" || !connection ? "laptop" : "cloud");
    localize();
  }
  strip2.append(projects2.element, projectMenu2, device.element, localMenu, gear.element, gearMenu);
  const statusDrawer = form.parentElement?.querySelector(":scope > .status-drawer");
  if (statusDrawer) statusDrawer.before(strip2);
  else form.before(strip2);
  const unbind = [host16.state.connectionId, host16.state.profile, host16.state.gateway, host16.state.cwd].map((store) => store.listen(refresh));
  const resize = () => {
    for (const [popup, control4, end] of [[projectMenu2, projects2, false], [localMenu, device, false], [gearMenu, gear, true]]) {
      if (popup.matches(":popover-open")) position(popup, control4.element, end);
    }
  };
  window.addEventListener("resize", resize);
  window.addEventListener("focus", refresh);
  void refresh();
  return {
    localize,
    dispose() {
      disposed = true;
      for (const off of unbind) off();
      window.removeEventListener("resize", resize);
      window.removeEventListener("focus", refresh);
      bridge?.(true);
      strip2.remove();
    }
  };
}
function styles4(active2) {
  const draft = active2 + " " + toolbar;
  const menu = active2 + " [data-hcv-draft-menu]";
  const projectMenu2 = menu + '[data-hcv-draft-menu="projects"]';
  const projectSearch = projectMenu2 + " [data-hcv-draft-search]";
  const native2 = active2 + " [data-hcv-draft-native-menu]";
  const popper = active2 + " [data-radix-popper-content-wrapper]:has(> [data-hcv-draft-native-menu])";
  const control4 = "[data-hcv-draft-button]";
  const label3 = "[data-hcv-draft-label]";
  const glyph3 = "[data-hcv-draft-icon]";
  return [
    "@media (forced-colors: none) {",
    draft + " { position: relative; z-index: 1; display: flex; align-items: center; min-inline-size: 0; min-block-size: 40px; margin: 0 " + toolbarInset + "px -4px; padding: 6px 8px; border-radius: 20px 20px 0 0; background: var(--hcv-hover); color: var(--hcv-text); font: 12px/18px var(--hcv-ui-font); }",
    draft + " + " + formSelector + ", " + draft + " + .status-drawer + " + formSelector + " { z-index: 2; }",
    draft + " " + control4 + " { display: flex; min-inline-size: 0; min-block-size: 28px; align-items: center; gap: 6px; padding: 0 8px; border-radius: 999px; text-align: start; cursor: pointer; -webkit-app-region: no-drag; }",
    draft + " > " + control4 + ":last-of-type { flex: none; justify-content: center; margin-inline-start: auto; inline-size: 28px; padding: 0; color: var(--hcv-muted); }",
    draft + " " + label3 + " { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }",
    draft + " " + label3 + ":empty { display: none; }",
    draft + " " + glyph3 + " { display: inline-block; flex: none; inline-size: 16px; block-size: 16px; }",
    draft + " > " + control4 + ':is(:hover, [aria-expanded="true"]) { background: var(--hcv-composer); }',
    draft + " > " + control4 + ":focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }",
    menu + ", " + native2 + " { box-sizing: border-box; min-inline-size: 0; max-block-size: var(--hcv-draft-max-height, 60vh); overflow: auto; overscroll-behavior: contain; padding: 4px; border: 1px solid transparent; border-radius: 16px; background: var(--hcv-menu); box-shadow: 0 0 0 .5px var(--hcv-hairline), 0 8px 16px -4px #0000001f; color: var(--hcv-text); font: 13px/20px var(--hcv-ui-font); }",
    ...Object.entries(menuWidths).map(([kind, width]) => menu + '[data-hcv-draft-menu="' + kind + '"]' + (kind === "device" ? ", " + native2 : "") + " { inline-size: min(" + width + "px, calc(100vw - 16px)); }"),
    menu + '[data-hcv-draft-menu="git"] { padding: 8px; }',
    menu + ", " + popper + " { position: fixed !important; inset: auto auto var(--hcv-draft-bottom, 40px) var(--hcv-draft-left, 8px) !important; transform: none !important; margin: 0; }",
    menu + " " + control4 + ", " + native2 + ' [role^="menuitem"] { inline-size: 100%; justify-content: flex-start; border-radius: 11px; min-block-size: 28px; }',
    menu + " " + control4 + ":disabled { color: var(--hcv-muted); opacity: .55; cursor: default; background: transparent; }",
    menu + " " + control4 + " > " + glyph3 + '[data-hcv-draft-icon="check"] { margin-inline-start: auto; }',
    active2 + " [data-hcv-draft-menu-heading] { min-block-size: 28px; display: flex; align-items: center; padding-inline: 8px; color: var(--hcv-muted); }",
    draft + " [data-hcv-draft-detail] { margin-inline-start: auto; color: var(--hcv-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }",
    // Codex Desktop: ZZgR menu input and bqtn separator used by Rvqv.
    projectMenu2 + " { max-block-size: min(350px, var(--hcv-draft-max-height, 60vh)); border: 0; border-radius: var(--hcv-dropdown-radius); background: var(--hcv-dropdown-background); color: var(--hcv-dropdown-text); font: 430 13px/calc(1.25 / .875) var(--hcv-ui-font); box-shadow: var(--hcv-dropdown-shadow); }",
    projectMenu2 + " [data-hcv-draft-search-row] { display: flex; align-items: center; gap: 6px; padding: 5px 8px; color: var(--hcv-dropdown-muted); }",
    projectSearch + " { flex: 1; min-inline-size: 0; appearance: none; padding: 0; border: 0; background: transparent; color: var(--hcv-dropdown-text); font: inherit; outline: none; box-shadow: none; }",
    projectSearch + "::placeholder { color: var(--hcv-dropdown-muted); opacity: 1; }",
    projectSearch + "::-webkit-search-cancel-button { appearance: none; }",
    projectMenu2 + " [data-hcv-draft-menu-separator] { block-size: 1px; margin: 4px 8px; background: var(--hcv-dropdown-outline); }",
    projectMenu2 + " " + control4 + " { min-block-size: 0; padding: 5px 8px; border-radius: var(--hcv-dropdown-row-radius); font: inherit; }",
    projectMenu2 + " " + control4 + ':is(:hover, :focus, [aria-current="true"]):not(:disabled) { background-color: var(--hcv-dropdown-hover); color: var(--hcv-dropdown-text); }',
    "@supports (corner-shape: superellipse(1.5)) {",
    projectMenu2 + ", " + projectMenu2 + " " + control4 + " { corner-shape: superellipse(1.5); }",
    "}",
    projectMenu2 + " [data-hcv-draft-projects] { max-block-size: min(40vh, 230px); overflow-y: auto; overscroll-behavior: contain; }",
    projectMenu2 + " [data-hcv-draft-projects] p { margin: 0; padding: 8px; color: var(--hcv-dropdown-muted); }",
    draft + " [data-hcv-draft-branches] p { margin: 0; padding: 7px; color: var(--hcv-muted); }",
    native2 + ' [role^="menuitem"] { padding: 0 8px; }',
    native2 + ' [role^="menuitem"] > span:first-child { gap: 6px; }',
    native2 + ' [data-slot="dropdown-menu-separator"] { margin-inline: 8px; }',
    native2 + ' [data-slot="connection-glyph"] { flex: none; width: 16px; height: 16px; background: currentColor; mask: ' + codexMask("cloud") + " center / contain no-repeat; }",
    native2 + ' [data-connection-kind="local"] { mask-image: ' + codexMask("laptop") + "; }",
    native2 + ' [data-slot="connection-glyph"] > svg { display: none; }',
    native2 + ' [role^="menuitem"] :is(.codicon-settings-gear, .codicon-check) { flex: none; width: 16px; height: 16px; background: currentColor; }',
    native2 + " .codicon-settings-gear { mask: " + codexMask("settings") + " center / contain no-repeat; }",
    native2 + " .codicon-check { mask: " + codexMask("check") + " center / contain no-repeat; }",
    native2 + ' [role^="menuitem"] :is(.codicon-settings-gear, .codicon-check)::before { content: none; }',
    native2 + " [data-hcv-device-label] { font-size: 0; }",
    native2 + " [data-hcv-device-label]::after { content: attr(data-hcv-device-label); font-size: 13px; }",
    "}"
  ].join("\n");
}
function registerDraftSetup(ctx, active2, localEnvironment) {
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const sheet = node2("style", { "data-hcv-draft-setup-style": "" });
  sheet.textContent = styles4(active2);
  mountStyle(ctx, sheet, chatStyles);
  let form;
  let bar;
  let frame = 0;
  const target = () => {
    if (!contrast.matches || !root.matches(active2) || host16.state.focusedStoredSessionId.get() || host16.state.activeSessionId.get() || host16.state.busy.get()) return null;
    const chat3 = document.querySelector(primary3);
    const transcript4 = chat3?.querySelector('[data-slot="aui_thread-content"]');
    if (!transcript4 || transcript4.querySelector('[data-slot="aui_message-group"]')) return null;
    return chat3.querySelector(formSelector);
  };
  const update = () => {
    frame = 0;
    const next = target();
    if (next === form) return;
    bar?.dispose();
    form = next;
    bar = form ? newDraftBar(form, () => target() === form, localEnvironment) : null;
  };
  const queue = () => {
    if (!frame) frame = requestAnimationFrame(update);
  };
  const observer = new MutationObserver((records) => {
    const selector = [primary3, formSelector, '[data-slot="aui_thread-content"]', '[data-slot="aui_message-group"]'].join(", ");
    if (records.some(({ target: target2, addedNodes, removedNodes }) => target2 === root || [...addedNodes, ...removedNodes].some((node3) => node3 instanceof Element && (node3.matches(selector) || node3.querySelector(selector))))) queue();
  });
  observer.observe(root, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-hermes-theme", "data-hermes-codex-visual", "data-popped-out"]
  });
  contrast.addEventListener("change", queue);
  const off = [host16.state.focusedStoredSessionId, host16.state.activeSessionId, host16.state.busy].map((store) => store.subscribe(queue));
  ctx.i18n.onLocaleChange(() => bar?.localize());
  ctx.onDispose(() => {
    observer.disconnect();
    contrast.removeEventListener("change", queue);
    for (const unsubscribe of off) unsubscribe();
    cancelAnimationFrame(frame);
    bar?.dispose();
    sheet.remove();
  });
  queue();
}

// source/interface.js
import { host as host17 } from "@hermes/plugin-sdk";

// source/command-palette.js
var commandRoot = '[data-slot="command"]';
var paletteDialog = '[role="dialog"][data-state]:not([data-slot])';
var paletteRoot = `${commandRoot}[cmdk-root]`;
var icons2 = {
  plus: "newChat",
  "app-window": "activityBrowser",
  settings: "settings",
  tool: "skills",
  "message-circle": "chatTab",
  package: "artifacts",
  clock: "schedule",
  users: "team",
  cpu: "system",
  "chart-dots-3": "graph",
  folder: "folder",
  "chevron-right": "right",
  check: "check"
};
function commandPaletteStyles(active2) {
  const dialog2 = `${active2} ${paletteDialog}:has(> ${paletteRoot})`;
  const root = `${active2} ${paletteDialog} > ${paletteRoot}`;
  const search = `${root} > [data-slot="command-input-wrapper"]`;
  const list = `${root} > [data-slot="command-list"]`;
  const item = `${list} [data-slot="command-item"]`;
  const enabled = `${item}:not([aria-disabled="true"], [data-disabled="true"])`;
  const heading = `${list} [cmdk-group-heading]`;
  return `
  /* Codex global search (757723.3067c948bc.js, 20dca5934f5d.css).
     Keep the surface opaque so moving the highlight never samples the chat. */
  ${dialog2} {
    --hcv-palette-top: max(calc(var(--titlebar-height, 34px) + 6px), calc((100dvh - 504px) / 2));
    inset-block-start: var(--hcv-palette-top);
    display: flex;
    inline-size: min(768px, 92vw);
    max-block-size: calc(100dvh - var(--hcv-palette-top) - 16px);
    border: 1px solid var(--hcv-dropdown-outline);
    border-radius: 16px;
    background: var(--hcv-dropdown-background);
    box-shadow: 0 16px 32px -8px #00000030;
    color: var(--hcv-dropdown-text);
    outline: none;
    transform-origin: top center;
    animation: none;
  }
  ${dialog2}[data-state="closed"] { pointer-events: none; }
  ${root} {
    min-block-size: 0;
    block-size: auto;
    padding: 4px;
    border-radius: inherit;
    background: transparent;
    color: inherit;
    font: 430 14px/20px var(--hcv-ui-font);
  }
  ${search} {
    flex: none;
    block-size: 44px;
    padding-inline: 10px;
    border-block-end: 1px solid var(--hcv-dropdown-outline);
    color: var(--hcv-muted);
  }
  ${search} > input {
    min-inline-size: 0;
    block-size: 100%;
    padding: 0;
    color: var(--hcv-dropdown-text);
    font: inherit;
  }
  ${search} > input::placeholder { color: var(--hcv-muted); opacity: 1; }
  ${search} > svg {
    inline-size: 16px;
    block-size: 16px;
    color: inherit;
  }
  ${codexIconRules(`${search} > svg.tabler-icon-search`, "search")}
  ${root} > button:first-of-type {
    flex: none;
    border-radius: 8px;
    border-color: var(--hcv-dropdown-outline);
    transition: none;
  }
  ${list} {
    min-block-size: 0;
    max-block-size: min(440px, calc(90dvh - 64px));
    contain: layout paint;
    overscroll-behavior: contain;
    scrollbar-width: none;
    scroll-padding-block: 4px;
  }
  ${list} [data-slot="command-group"] { padding: 4px 0 0; }
  ${heading} {
    padding: 4px 10px 2px;
    color: var(--hcv-muted);
    font: 500 12px/18px var(--hcv-ui-font);
    text-transform: none;
    letter-spacing: normal;
  }
  ${item} {
    content-visibility: auto;
    contain-intrinsic-block-size: auto 36px;
    gap: 8px;
    min-block-size: 36px;
    padding: 8px 10px;
    border-radius: 10px;
    color: inherit;
    font: inherit;
    transition: none;
  }
  ${enabled} { cursor: pointer; opacity: .75; }
  ${enabled}:is([data-selected="true"], :focus-visible, :active) {
    background-color: var(--hcv-dropdown-hover);
    color: inherit;
    opacity: 1;
  }
  @media (hover: hover) and (pointer: fine) {
    ${enabled}:hover { opacity: 1; }
    ${enabled}:hover:not([data-selected="true"], :active, :focus-visible) {
      background-color: color-mix(in srgb, var(--hcv-dropdown-hover) 25%, transparent);
    }
  }
  ${item} > :is([data-slot="kbd-group"], [data-slot="command-shortcut"], kbd) { display: none; }
  ${item} > svg {
    inline-size: 16px;
    block-size: 16px;
    flex: none;
  }
  ${item} > svg:is(.tabler-icon-chevron-right, .tabler-icon-check):not(:first-child) { margin-inline-start: auto; }
  ${Object.entries(icons2).map(([native2, glyph3]) => codexIconRules(`${item} > svg.tabler-icon-${native2}`, glyph3)).join("")}
  @supports (corner-shape: superellipse(1.5)) {
    ${dialog2} { border-radius: 20px; corner-shape: superellipse(1.5); }
    ${item} { border-radius: 12.5px; corner-shape: superellipse(1.5); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${dialog2}[data-state="open"] { animation: hcv-palette-in 150ms var(--hcv-enter) both; }
    ${dialog2}[data-state="closed"] { animation: hcv-palette-out 150ms var(--hcv-enter) both; }
  }
  @keyframes hcv-palette-in {
    from { opacity: 0; scale: .98; }
    to { opacity: 1; scale: 1; }
  }
  @keyframes hcv-palette-out {
    from { opacity: 1; scale: 1; }
    to { opacity: 0; scale: .98; }
  }
  `;
}

// source/interface.js
var menus = ':is([data-slot="dropdown-menu-content"], [data-slot="dropdown-menu-sub-content"], [data-slot="context-menu-content"], [data-slot="context-menu-sub-content"], [data-slot="select-content"]):not([data-hcv-window-menu-content])';
var modelCatalog = '[data-slot="dropdown-menu-content"]:has(> [data-slot="dropdown-menu-search"]):has(> [data-slot="dropdown-menu-item"] > .codicon-settings-gear)';
var modelRow = '[data-slot="dropdown-menu-sub-trigger"]';
var modelMeta = `${modelRow} > span > span.uppercase.tracking-wide, ${modelRow} > [data-slot="badge"].uppercase.tracking-wide`;
var sidebarMenu = "[data-hcv-sidebar-menu]";
var effortBadge = "data-hcv-model-effort";
var effortLabels = /* @__PURE__ */ new Set(["Off", "Min", "Low", "Med", "High", "XHigh", "Max", "Ultra"]);
var items = ':is([data-slot^="dropdown-menu-"][role^="menuitem"], [data-slot^="context-menu-"][role^="menuitem"], [data-slot="select-item"])';
var menuRows = `${menus} ${items}`;
var popover2 = '[data-slot="popover-content"]';
var tip = '[data-slot="tooltip-content"]';
var button4 = ':is(button, [role="button"], [data-slot="button"])';
var quietIcon = '[data-variant="ghost"][data-size^="icon"]';
var dialog = '[data-slot="dialog-content"]';
var dialogOverlay = '[data-slot="dialog-overlay"]';
var notification = '[data-slot="card-stack-surface"] > div > [data-slot="alert"][aria-live]';
var notificationStack = `[data-slot="card-stack"]:has(> [data-slot="card-stack-front"] > ${notification})`;
var overlays = "[data-overlay-surface]";
var selectTriggers = ':is([data-slot="select-trigger"], [data-slot="searchable-select-trigger"], [data-slot="compact-select-trigger"])';
var fields = `:is([data-slot="input"]:not([type="file"], [type="checkbox"], [type="range"], [type="color"]), ${selectTriggers}, [data-slot="textarea"])`;
var checks = ':is([data-slot="checkbox"], [data-slot="checkbox-mark"])';
var checkIcon = ":is(.codicon-check, svg.tabler-icon-check)";
var commandItems = '[data-slot="command-item"]';
var commandMenuSearch = `${popover2} [data-slot="command-input-wrapper"]:has(> [data-slot="command-input"]):not(:has(> svg))`;
var menuSearch = `:is([data-slot="dropdown-menu-search"], ${commandMenuSearch})`;
var menuButtons = ":is([data-hcv-draft-menu], [data-hcv-recents-menu], [data-hcv-queue-menu], [data-hcv-message-menu]) button";
var enabledItem = `${menuRows}:not([data-disabled], [aria-disabled="true"])`;
var highlightedItem = `${enabledItem}:is(:focus, [data-highlighted], [data-kb-active], [data-state="open"])`;
var toggle = '[data-slot="switch"][role="switch"]';
var thumb = '[data-slot="switch-thumb"]';
var pageTabs = '[data-tour="page-tabs"]';
var pageShell = "section.h-full.min-w-0.overflow-hidden:not([data-chat-surface])";
var settingsViews = /* @__PURE__ */ new Map([
  ["providers", ["pview", "accounts"]],
  ["keys", ["kview", "tools"]],
  ["billing", ["bview", "overview"]]
]);
var menuGlyphs = {
  "archive": "archive",
  "check": "check",
  "check-all": "markRead",
  "chevron-down": "down",
  "chevron-right": "right",
  "close": "close",
  "copy": "copy",
  "edit": "edit",
  "folder": "folder",
  "folder-library": "folder",
  "folder-opened": "folderOpen",
  "new-folder": "folderPlus",
  "pin": "pin",
  "pinned": "pin",
  "pinned-dirty": "pin",
  "refresh": "refresh",
  "symbol-color": "palette",
  "target": "target",
  "trash": "trash",
  "clock": "schedule",
  "root-folder": "folder",
  "account": "person",
  "pulse": "system",
  "list-filter": "filter",
  "add": "plus",
  "kebab-vertical": "more",
  "ellipsis": "more",
  "settings-gear": "settings"
};
function screenFromRoute() {
  const name = window.location.hash.match(/^#\/(settings|command-center|session-import|capabilities|messaging|artifacts|cron|agents|profiles|starmap|webhooks)(?:[/?#]|$)/)?.[1];
  return name || "";
}
function watchModelEffortBadges(ctx) {
  const refresh = () => {
    observer.disconnect();
    observer.observe(document.body, { childList: true });
    for (const menu of document.querySelectorAll(modelCatalog)) {
      for (const badge of menu.querySelectorAll(modelMeta)) {
        const levels = badge.textContent.trim().split("\u2192");
        badge.toggleAttribute(effortBadge, levels.every((level) => effortLabels.has(level)));
      }
      observer.observe(menu, { childList: true, subtree: true, characterData: true });
    }
  };
  const observer = new MutationObserver((records) => {
    if (records.some((record) => record.target !== document.body || movedElementMatches(record, '[data-slot="dropdown-menu-content"]'))) refresh();
  });
  refresh();
  ctx.onDispose(() => {
    observer.disconnect();
    for (const badge of document.querySelectorAll(`[${effortBadge}]`)) badge.removeAttribute(effortBadge);
  });
}
function catalogGroupHover(ctx) {
  const marker4 = "data-catalog-hover-group";
  const selector = "[" + marker4 + "]";
  const disabled = /* @__PURE__ */ new Map();
  let watching = false;
  function disable(node3) {
    const groups2 = node3.matches(selector) ? [node3] : node3.querySelectorAll(selector);
    for (const group2 of groups2) {
      disabled.set(group2, group2.getAttribute(marker4));
      group2.removeAttribute(marker4);
    }
  }
  function restore(group2, value) {
    group2.setAttribute(marker4, value);
    disabled.delete(group2);
  }
  const mounts = new MutationObserver((records) => {
    for (const [group2, value] of disabled) {
      if (!group2.isConnected) restore(group2, value);
    }
    for (const { addedNodes } of records) {
      for (const node3 of addedNodes) {
        if (node3 instanceof Element && node3.isConnected) disable(node3);
      }
    }
  });
  function sync(enabled) {
    if (enabled === watching) return;
    watching = enabled;
    mounts.disconnect();
    if (enabled) {
      disable(document.body);
      mounts.observe(document.body, { subtree: true, childList: true });
    } else {
      for (const [group2, value] of disabled) restore(group2, value);
    }
  }
  ctx.onDispose(() => sync(false));
  return sync;
}
function registerInterface(ctx, active2) {
  watchModelEffortBadges(ctx);
  const suppressCatalogHover = catalogGroupHover(ctx);
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const setScreen = () => {
    const screen = screenFromRoute();
    const enabled = root.matches(active2);
    suppressCatalogHover(enabled && contrast.matches && screen === "capabilities");
    if (!enabled || !screen) root.removeAttribute("data-hcv-screen");
    else if (root.dataset.hcvScreen !== screen) root.dataset.hcvScreen = screen;
    if (root.dataset.hcvScreen === "settings") {
      const params = new URLSearchParams(location.hash.split("?")[1]);
      const tab = params.get("tab") || "config:model";
      const view = settingsViews.get(tab);
      root.dataset.hcvSettingsTab = tab;
      root.dataset.hcvSettingsPage = view ? params.get(view[0]) || view[1] : params.get("page") || "";
    } else {
      root.removeAttribute("data-hcv-settings-tab");
      root.removeAttribute("data-hcv-settings-page");
    }
  };
  const observer = new MutationObserver(setScreen);
  observer.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "data-hermes-codex-visual"] });
  ctx.addEventListener(window, "hashchange", setScreen);
  ctx.addEventListener(window, "popstate", setScreen);
  ctx.addEventListener(contrast, "change", setScreen);
  if (window.navigation) ctx.addEventListener(window.navigation, "currententrychange", setScreen);
  ctx.onDispose(() => {
    observer.disconnect();
    root.removeAttribute("data-hcv-screen");
    root.removeAttribute("data-hcv-settings-tab");
    root.removeAttribute("data-hcv-settings-page");
  });
  setScreen();
  const rescan = "[data-catalog-actions] button[aria-label]:has(> svg.tabler-icon-refresh)";
  ctx.addEventListener(document, "click", (event) => {
    if (!root.matches(active2) || screenFromRoute() !== "capabilities" || event.defaultPrevented) return;
    const control4 = event.target.closest?.(rescan);
    if (!control4 || control4.matches(':disabled, [aria-disabled="true"]')) return;
    const russian = root.lang.toLowerCase().startsWith("ru");
    host17.notify({
      id: "hermes-codex-visual:plugins-rescan",
      kind: "info",
      message: russian ? "\u0417\u0430\u043F\u0443\u0449\u0435\u043D\u043E \u0441\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u043B\u0430\u0433\u0438\u043D\u043E\u0432" : "Plugin scan started"
    });
  });
  const pages = `${active2}:is([data-hcv-screen="capabilities"],[data-hcv-screen="messaging"],[data-hcv-screen="artifacts"]) ${pageShell}`;
  const animatedPages = `${active2}:is([data-hcv-screen="messaging"],[data-hcv-screen="artifacts"]) ${pageShell}`;
  const capabilities = `${active2}[data-hcv-screen="capabilities"] ${pageShell}`;
  const shown = `${active2} ${overlays}`;
  const sessions = `${active2}[data-hcv-screen="command-center"] ${overlays} main`;
  const pageSearch = "div:has(> svg.tabler-icon-search + input[placeholder])";
  const capabilitySearch = `${capabilities} div:has(> svg.tabler-icon-search):has(> input[placeholder])`;
  const catalogCard = `${capabilities} [data-catalog-card]`;
  const mutedArtwork = ':is([data-entry-id="desktop:kanban"], [data-entry-id="desktop:hermes-bots"], [data-entry-id$=":desktop:kanban"], [data-entry-id$=":desktop:hermes-bots"])';
  const plainCatalogCard = `${catalogCard}:is(:not([data-catalog-editorial-art]), ${mutedArtwork})`;
  const catalogFilters = `${capabilities} [data-catalog-filters]`;
  const filterMode = `${catalogFilters} .catalog-filter-row > .inline-grid:has(> button[aria-pressed])`;
  const filterPopup = `${active2}[data-hcv-screen="capabilities"] ${popover2}:has(> [data-catalog-expanded-filters], > .flex.flex-wrap > button[aria-pressed])`;
  const filterChips = `:is(${catalogFilters} .catalog-filter-chips > button, ${filterPopup} button[aria-pressed])`;
  const filterTrigger = `${catalogFilters} .catalog-filter-trigger > button`;
  const catalogActions = `${capabilities} [data-catalog-actions] button[data-slot="button"]`;
  const catalogControls = `:is(${filterMode} > button, ${filterChips}, ${filterTrigger}, ${catalogActions})`;
  const tabs = `${active2} [data-zone-tabstrip] [role="tab"][data-tree-tab]:has(> .pane-tab-content):not([data-vertical])`;
  const mainTabs = tabs.replace("[data-zone-tabstrip]", '[data-zone-tabstrip="grp-main"]');
  const projectRow2 = `${active2} [data-sessions-project]:not([data-sessions-mode]) > :first-child`;
  const paneAdd = `${active2} [data-zone-tabstrip] button:has(> .codicon-add)`;
  const card2 = `${active2} [data-hcv-context-card]`;
  const catalogDetail = `${active2}[data-hcv-screen="capabilities"] [data-slot="dialog-content"]:has([data-catalog-detail])`;
  const nav = `${shown} [data-tour="overlay-nav"]`;
  const notice2 = `${active2} ${notification}`;
  const noticeDetails = `${notice2} details > summary`;
  const popupButtons = `${active2} :is(
    ${dialog} [data-slot="dialog-close-button"],
    ${dialog} :is([data-slot="dialog-footer"], footer) button[data-slot="button"],
    ${popover2} button[data-slot="button"],
    ${notification} button[data-slot="button"]
  )`;
  const quietPopupButtons = `${popupButtons}:is([data-variant="ghost"], [data-variant="outline"], [data-variant="secondary"], [data-slot="dialog-close-button"])`;
  const switchThumb = codexReference.switch.height - codexReference.switch.offset * 2;
  const switchTravel = codexReference.switch.width - codexReference.switch.height;
  const sheet = document.createElement("style");
  sheet.dataset.hcvInterface = "";
  sheet.textContent = `
@media (forced-colors: none) {
  ${active2} {
    --hcv-unit: ${codexReference.spacing}px;
    --hcv-ui-font: ${codexReference.font};
    --hcv-enter: ${codexReference.enter};
    --hcv-exit: ${codexReference.exit};
    --hcv-ease: ${codexReference.hover};
    --hcv-move: ${codexReference.move};
    --hcv-enter-time: ${codexReference.enterTime};
    --hcv-exit-time: ${codexReference.exitTime};
    --hcv-menu-start-scale: ${codexReference.menuStartScale};
    /* Codex Desktop menu/form/action radii. See 0fff881d427a.css and e77f816560c6.css. */
    --hcv-menu-radius: calc(5 * var(--hcv-unit));
    --hcv-dialog-radius: calc(6 * var(--hcv-unit));
    --hcv-popup-button-radius: 10px;
    /* Desktop AppMenu (Lhpx.MX) and surface tokens in 9ec44337a842.css. */
    --hcv-dropdown-radius: 16px;
    --hcv-dropdown-row-radius: 12px;
    --hcv-dropdown-background: light-dark(#fff, #2d2d2d);
    --hcv-dropdown-text: light-dark(#1a1c1f, #dfdfdf);
    --hcv-dropdown-muted: light-dark(rgb(26 28 31 / .495), rgb(255 255 255 / .498));
    --hcv-dropdown-outline: light-dark(rgb(26 28 31 / .078), rgb(255 255 255 / .084));
    --hcv-dropdown-ring: 0 0 0 .5px var(--hcv-dropdown-outline);
    --hcv-dropdown-shadow: var(--hcv-dropdown-ring), 0 8px 16px -4px #0000001f;
    --hcv-popover-shadow: var(--hcv-dropdown-ring), 0 4px 8px -2px #0000001a;
    --hcv-dropdown-hover: light-dark(rgb(26 28 31 / .0535), rgb(255 255 255 / .078));
    --hcv-hover-menu: color-mix(in srgb, var(--hcv-text) 8%, transparent);
    --hcv-hairline: color-mix(in srgb, var(--hcv-text) 11%, transparent);
    --hcv-form-surface: color-mix(in srgb, var(--hcv-text) 4%, var(--hcv-chat));
    --hcv-menu-shadow: 0 12px 32px rgba(0,0,0,.15), 0 2px 6px rgba(0,0,0,.09);
  }
  ${active2}[data-hermes-mode="dark"] {
    --hcv-hover-menu: color-mix(in srgb, var(--hcv-text) 12%, transparent);
    --hcv-menu-shadow: 0 12px 32px rgba(0,0,0,.28), 0 2px 6px rgba(0,0,0,.19);
  }
  ${active2}[data-hermes-glass] {
    --translucency-glass-keep: 100% !important;
  }

  @supports (corner-shape: superellipse(1.5)) {
    ${active2} { --hcv-dropdown-radius: 20px; --hcv-dropdown-row-radius: 15px; }
  }
  /* A button label can carry its own underline independently of the button. */
  ${active2} :is(${button4}, ${button4} :where(.underline, [class*=':underline'])) {
    text-decoration-line: none;
  }
  ${active2} :where(${quietIcon}) { border-radius: ${codexReference.quietControl.radius}; }
  ${active2} ${tip} {
    max-inline-size: min(300px, calc(100vw - 24px), var(--radix-tooltip-content-available-width, 300px));
    padding: ${codexReference.compactTooltip.padding};
    border: 0;
    border-radius: ${codexReference.compactTooltip.radius};
    background: var(--hcv-menu);
    color: var(--hcv-text);
    box-shadow: ${codexReference.compactTooltip.shadow};
    font: 400 13px/18px var(--hcv-ui-font);
    letter-spacing: -.15px;
    transform-origin: var(--radix-tooltip-content-transform-origin);
    animation: none;
  }
  ${active2} ${tip} :is([data-slot="tooltip-arrow"], span:has(> [data-slot="tooltip-arrow"])) { display: none; }
  ${active2} ${notificationStack} :is([data-slot="card-stack-surface"], [data-slot="card-stack-edge"]) {
    border-color: var(--hcv-hairline);
    border-radius: var(--hcv-menu-radius);
    background-color: var(--hcv-menu);
    box-shadow: var(--hcv-menu-shadow);
  }
  ${notice2} {
    column-gap: 10px;
    font-family: var(--hcv-ui-font);
  }
  ${notice2} [data-slot="alert-title"] {
    font-size: 14px;
    font-weight: 600;
    line-height: 1.4;
    letter-spacing: -.01em;
  }
  ${notice2} [data-slot="alert-description"] {
    color: var(--hcv-muted);
    font-size: 13px;
    line-height: 1.5;
  }
  ${notice2} [data-slot="alert-description"] > p:first-child { line-height: inherit; }
  ${noticeDetails} {
    inline-size: fit-content;
    margin-inline-start: -6px;
    padding: 2px 6px;
    border-radius: 7px;
    cursor: pointer;
  }
  ${notice2} details > div { border-radius: var(--hcv-popup-button-radius); }
  ${popupButtons} {
    border-radius: var(--hcv-popup-button-radius);
    font-family: var(--hcv-ui-font);
    transition: none;
  }
  /* Native checkbox and checkbox-mark need different selectors: the mark
     renders a child icon only when selected and is itself decorative. */
  ${active2} ${checks} {
    inline-size: 16px;
    block-size: 16px;
    flex: 0 0 16px;
    border: 1px solid color-mix(in srgb, var(--hcv-text) 28%, transparent);
    border-radius: 4px;
  }
  ${active2} ${checks}:is([data-state="checked"], [data-state="indeterminate"], :has(> ${checkIcon})) {
    border-color: transparent;
    background-color: var(--hcv-action);
    color: var(--hcv-ink);
  }
  ${codexIconRules(`${active2} ${checks} ${checkIcon}`, "check")}
  ${active2} ${fields} {
    border-radius: 8px;
    min-inline-size: 0;
    font-family: var(--hcv-ui-font);
  }
  ${codexIconRules(`${active2} ${selectTriggers} > .codicon-chevron-down`, "down")}
  ${codexIconRules(`${active2} ${selectTriggers} > .codicon-chevron-up`, "down")}
  ${active2} ${selectTriggers} > .codicon-chevron-up { rotate: 180deg; }
  ${active2} ${toggle} {
    box-sizing: border-box;
    inline-size: ${codexReference.switch.width}px;
    min-inline-size: ${codexReference.switch.width}px;
    block-size: ${codexReference.switch.height}px;
    padding-inline: ${codexReference.switch.offset - 1}px;
    justify-content: flex-start;
    border: 1px solid var(--hcv-stroke);
    border-radius: 999px;
    background-color: var(--hcv-selected);
    box-shadow: none;
  }
  ${active2} ${toggle}[data-state="checked"] { background-color: var(--hcv-action); border-color: transparent; }
  ${active2} ${toggle} > ${thumb} {
    inline-size: ${switchThumb}px;
    block-size: ${switchThumb}px;
    translate: 0 0;
    transform: none;
    background-color: var(--hcv-text);
  }
  ${active2} ${toggle}[data-state="checked"] > ${thumb} {
    translate: ${switchTravel}px 0;
    background-color: var(--hcv-ink);
  }
  ${active2} ${toggle}[data-state="checked"]:dir(rtl) > ${thumb} { translate: -${switchTravel}px 0; }
  ${active2} ${toggle}:is(:disabled, [aria-disabled="true"]) { opacity: .5; }

  /* Compact controls: the hover target includes the whole row, with a
     stable trailing slot so titles don't jump when the actions appear. */
  ${tabs} {
    box-sizing: border-box;
    block-size: 32px;
    min-block-size: 32px;
    max-block-size: 32px;
    align-self: center;
    margin-inline: 2px;
    padding-inline: 4px;
    border: 0;
    border-radius: 8px;
    box-shadow: none;
    background: transparent;
    color: var(--hcv-muted);
  }
  ${tabs}[data-closeable] { --pane-tab-close-width: 22px; padding-inline-end: var(--pane-tab-close-width); }
  ${mainTabs} {
    block-size: 28px;
    min-block-size: 28px;
    max-block-size: 28px;
    padding-inline: 8px;
  }
  ${mainTabs}[data-closeable] { padding-inline-end: calc(var(--pane-tab-close-width) + 4px); }
  ${tabs}[data-closeable]:hover > .pane-tab-content { mask-image: none; }
  ${tabs}[data-active="true"], ${tabs}[data-selected] { color: var(--hcv-text); background: var(--hcv-selected); }
  ${tabs} .pane-tab-content span { text-transform: none; letter-spacing: normal; }
  ${tabs} .pane-tab-content .truncate {
    font: 500 13px/18px var(--hcv-ui-font);
    letter-spacing: 0;
    text-transform: none;
    text-overflow: ellipsis;
    unicode-bidi: plaintext;
  }
  ${tabs} .pane-tab-content > span:first-child { margin-inline: 4px 0; }
  ${codexIconRules(`${tabs} .pane-tab-content .codicon-folder`, "folder")}
  ${codexIconRules(`${paneAdd} > .codicon-add`, "plus")}
  ${paneAdd} {
    inline-size: 26px;
    block-size: 26px;
    margin-inline: 2px;
    border-radius: 7px;
  }
  ${active2} [data-titlebar-cluster] button[data-size="icon-titlebar"] { border-radius: 8px; }
  ${codexIconRules(`${active2} [data-titlebar-cluster] .codicon-settings-gear`, "settings")}
  ${codexIconRules(`${active2} [data-titlebar-cluster] .codicon-comment-discussion`, "hud")}
  ${codexIconRules(`${active2} [data-titlebar-cluster] .codicon-arrow-swap`, "swap")}
  ${codexIconRules(`${active2} [data-titlebar-cluster] .codicon-layout`, "layout")}
  ${projectRow2} {
    min-block-size: ${codexReference.sidebar.rowHeight}px;
    border-radius: ${codexReference.sidebar.rowRadius}px;
    padding-inline: 2px 4px;
    color: var(--hcv-text);
    cursor: default;
  }
  ${projectRow2}:has([data-state="open"][aria-haspopup="menu"]) { background: var(--hcv-selected); }
  ${projectRow2} [data-slot="row-button"] > span { text-decoration: none; }
  ${projectRow2} [data-row-actions] button:focus-visible,
  ${projectRow2}[data-hcv-preview-open] [data-row-actions] button,
  ${projectRow2}:has([data-state="open"][aria-haspopup="menu"]) [data-row-actions] button { opacity: 1; }
  ${projectRow2} [data-row-actions] button > .codicon { font-size: 14px !important; }
  ${codexIconRules(`${projectRow2} [data-row-actions] .codicon-kebab-vertical`, "more")}
  ${codexIconRules(`${projectRow2} [data-row-actions] .codicon-add`, "newChat")}
  ${codexIconRules(`${active2} [data-tour="sessions-sidebar"] [data-row-actions] .codicon-kebab-vertical`, "more")}
  ${codexIconRules(`${active2} [data-tour="sessions-sidebar"] .codicon-list-filter`, "filter")}

  ${active2} :is(${fields}, ${toggle}, [data-slot="checkbox"], [data-hcv-context-card] button, ${dialog} button):focus-visible,
  ${popupButtons}:focus-visible,
  ${noticeDetails}:focus-visible,
  ${shown} :is(button, a, input, textarea, select):focus-visible,
  ${projectRow2} :is(button, a):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  :is(${pages}, ${shown}) ${pageSearch} > input:focus-visible { outline: none; }

  /* Codex Desktop bf55123332b3.css: menu item focus is a fill, with
     native outline behavior in forced colors. */
  ${active2} ${menuButtons}:focus-visible:not(:disabled, [aria-disabled="true"]) {
    background-color: var(--hcv-dropdown-hover);
    color: var(--hcv-text);
  }
  ${active2} ${menuButtons}:focus {
    outline: none;
    box-shadow: none;
  }

  @media (hover: hover) and (pointer: fine) {
    ${active2} :where(${quietIcon}):hover:not(:disabled, [aria-disabled="true"], [aria-pressed="true"], [data-state="open"]) {
      background-color: var(--hcv-dropdown-hover);
      color: var(--hcv-text);
    }
    ${active2} ${menuButtons}:hover:not(:disabled, [aria-disabled="true"]) {
      background-color: var(--hcv-dropdown-hover);
    }
    ${noticeDetails}:hover,
    ${quietPopupButtons}:hover:not(:disabled, [aria-disabled="true"]) {
      background-color: var(--hcv-hover-menu);
      color: var(--hcv-text);
    }
    ${active2} ${toggle}[data-state="unchecked"]:not(:disabled, [aria-disabled="true"]):hover {
      background-color: color-mix(in srgb, var(--hcv-selected) 88%, var(--hcv-text));
    }
    ${tabs}:not([data-active="true"], [data-selected]):hover { background-color: var(--hcv-hover); }
    ${projectRow2}:hover { background-color: var(--hcv-sidebar-highlight); }
    ${paneAdd}:hover { background-color: var(--hcv-hover); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${active2} ${tip}:is([data-state="delayed-open"], [data-state="instant-open"]) {
      animation: hcv-menu-in ${codexReference.tooltip.duration} var(--hcv-enter) both;
    }
    ${active2} ${tip}[data-state="closed"] { animation: hcv-tip-out ${codexReference.tooltip.duration} var(--hcv-enter) both; }
    ${active2} ${toggle} {
      transition: background-color ${codexReference.switch.trackTime} linear ${codexReference.switch.trackDelay},
        border-color var(--hcv-enter-time) var(--hcv-ease);
    }
    ${active2} ${toggle} > ${thumb} {
      transition: translate ${codexReference.switch.thumbTime} var(--hcv-move),
        background-color var(--hcv-enter-time) var(--hcv-ease);
    }
    ${popupButtons}, ${noticeDetails} {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease),
        color var(--hcv-enter-time) var(--hcv-ease);
    }
    ${tabs}, ${paneAdd}, ${card2} button, ${projectRow2}, ${projectRow2} button {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease),
        color var(--hcv-enter-time) var(--hcv-ease),
        border-color var(--hcv-enter-time) var(--hcv-ease);
    }
  }
  @media (any-hover: none) {
    ${projectRow2} [data-row-actions] button { opacity: 1; }
  }
  @keyframes hcv-menu-in {
    from { opacity: 0; transform: scale(var(--hcv-menu-start-scale)); }
    to { opacity: 1; transform: scale(1); }
  }
  @keyframes hcv-menu-out {
    from { opacity: 1; transform: scale(1); }
    to { opacity: 0; transform: scale(var(--hcv-menu-start-scale)); }
  }
  @keyframes hcv-tip-out {
    from { opacity: 1; transform: scale(1); }
    to { opacity: 0; transform: scale(${codexReference.tooltip.exitScale}); }
  }
  @keyframes hcv-surface-in {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  @keyframes hcv-surface-out {
    from { opacity: 1; }
    to { opacity: 0; }
  }
}
`;
  mountStyle(ctx, sheet);
  mountCSS(ctx, "data-hcv-interface-popups", `
${active2} ${modelCatalog} [${effortBadge}] { display: none; }
${active2} ${modelCatalog} :is([data-slot="dropdown-menu-item"][class~="group/label"], [data-slot="dropdown-menu-label"]) {
  text-transform: lowercase;
  letter-spacing: normal;
}
@media (forced-colors: none) {
  /* The menu combobox input and separator are separate in Codex ZZgR/bqtn. */
  ${active2} ${menuSearch} {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 5px 8px;
    border: 0;
    background: transparent;
    box-shadow: none;
  }
  ${active2} ${menuSearch}::before {
    content: "";
    flex: none;
    inline-size: 16px;
    block-size: 16px;
    background: var(--hcv-dropdown-muted);
    mask: ${codexMask("activitySearch")} center / contain no-repeat;
    pointer-events: none;
  }
  ${active2} ${menuSearch} > input {
    flex: 1;
    min-inline-size: 0;
    block-size: auto;
    padding: 0;
    border: 0;
    background: transparent;
    color: var(--hcv-dropdown-text);
    font: 430 13px/calc(1.25 / .875) var(--hcv-ui-font);
    outline: none;
    box-shadow: none;
  }
  ${active2} ${menuSearch} > input::placeholder { color: var(--hcv-dropdown-muted); opacity: 1; }
  ${active2} ${commandMenuSearch} {
    position: relative;
    margin-block-end: 0;
    padding-block-end: 14px;
  }
  ${active2} ${commandMenuSearch}::after {
    content: "";
    position: absolute;
    inset: auto 8px 4px;
    block-size: 1px;
    background: var(--hcv-dropdown-outline);
    pointer-events: none;
  }
  ${active2} [data-slot="dropdown-menu-search"] + [data-slot="dropdown-menu-separator"] {
    block-size: 1px;
    margin: 4px 8px;
    background: var(--hcv-dropdown-outline);
  }

  /* Native Radix menus retain focus, arrow keys, radio semantics and placement. */
  ${active2} :is(${menus}, ${popover2}) {
    border: 0;
    border-radius: var(--hcv-dropdown-radius);
    background-color: var(--hcv-dropdown-background);
    color: var(--hcv-dropdown-text);
    box-shadow: var(--hcv-dropdown-shadow);
    backdrop-filter: none;
    font-family: var(--hcv-ui-font);
    --tw-enter-blur: 0px;
    --tw-exit-blur: 0px;
    animation: none;
  }
  ${active2} :is([data-slot="context-menu-content"], [data-slot="context-menu-sub-content"], ${popover2}) {
    box-shadow: var(--hcv-popover-shadow);
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${active2} :is(${menus}, ${popover2}), ${active2} ${menuRows} { corner-shape: superellipse(1.5); }
  }
  ${active2} :is(${dialog}, ${dialogOverlay}) { animation: none; }
  /* A dialog on a route overlay already has a blurred layer behind it.
     Use Codex's solid scrim here to avoid sampling that layer a second time. */
  ${active2}:has(${overlays}) ${dialogOverlay} {
    backdrop-filter: none;
    background-color: light-dark(#0000004d, #00000080);
  }
  ${active2}:has(${overlays}) ${dialog} { background-color: var(--hcv-menu); }
  ${active2} ${dialog} {
    background-color: var(--hcv-menu);
    backdrop-filter: none;
    border: 1px solid var(--hcv-hairline);
    border-radius: var(--hcv-dialog-radius);
    box-shadow: var(--hcv-menu-shadow);
    font-family: var(--hcv-ui-font);
  }
  ${active2} ${dialog} [data-slot="dialog-title"] {
    font-weight: 600;
    line-height: 1.35;
    letter-spacing: -.012em;
  }
  ${active2} ${dialog} [data-slot="dialog-description"] {
    font-size: 13px;
    line-height: 1.5;
  }
  ${active2} :is(${dialog}, ${dialogOverlay})[data-state="closed"] { pointer-events: none; }
  ${active2} ${menus} { padding: 4px; font-size: 13px; line-height: calc(1.25 / .875); }
  ${active2} [data-slot="dropdown-menu-content"]${sidebarMenu} {
    inline-size: max-content;
    min-inline-size: min(160px, var(--radix-dropdown-menu-content-available-width, 100vw));
    max-inline-size: min(calc(100vw - 16px), var(--radix-dropdown-menu-content-available-width, 100vw));
  }
  ${active2} [data-hcv-sidebar-menu] { translate: var(--hcv-sidebar-menu-shift, 0px) 0; }
  ${active2} ${menuRows} {
    position: relative;
    min-block-size: 28px;
    border-radius: var(--hcv-dropdown-row-radius);
    gap: 6px;
    padding-block: 4px;
    padding-inline: 8px;
    font-size: 13px;
    font-weight: 430;
    line-height: calc(1.25 / .875);
  }
  ${active2} ${menuRows}:not([data-variant="destructive"]) { color: var(--hcv-dropdown-text); }
  ${active2} ${highlightedItem} {
    background-color: var(--hcv-dropdown-hover);
  }
  ${active2} ${menus} :is([data-slot="dropdown-menu-separator"], [data-slot="context-menu-separator"], [data-slot="select-separator"]) {
    margin: 4px 8px;
    background: var(--hcv-dropdown-outline);
  }
  ${Object.entries(menuGlyphs).map(([native2, name]) => codexIconRules(`${active2} ${items} .codicon-${native2}`, name)).join("")}
  ${codexIconRules(`${active2} ${items} ${checkIcon}`, "check")}
  ${active2} ${commandItems} { border-radius: 8px; }
  ${active2} ${commandItems}:is(:focus, [data-selected="true"]):not([data-disabled="true"], [aria-disabled="true"]) {
    background-color: var(--hcv-dropdown-hover);
    color: var(--hcv-text);
  }
  ${codexIconRules(`${active2} ${commandItems} ${checkIcon}`, "check")}

  ${active2} :is(${items}, ${commandItems}):focus {
    outline: none;
    box-shadow: none;
  }
  @media (hover: hover) and (pointer: fine) {
    ${active2} ${enabledItem}:hover { background-color: var(--hcv-dropdown-hover); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${active2} ${dialog}[data-state="open"] { animation: hcv-menu-in var(--hcv-enter-time) var(--hcv-enter) both; }
    ${active2} ${dialog}[data-state="closed"] { animation: hcv-menu-out var(--hcv-exit-time) var(--hcv-exit) both; }
    ${active2} ${dialogOverlay}[data-state="open"] { animation: hcv-surface-in var(--hcv-enter-time) var(--hcv-enter) both; }
    ${active2} ${dialogOverlay}[data-state="closed"] { animation: hcv-surface-out var(--hcv-exit-time) var(--hcv-exit) both; }
    ${active2} :is(${menus}, ${popover2}) {
      transform-origin: var(--hcv-sidebar-menu-origin, var(--radix-dropdown-menu-content-transform-origin,
        var(--radix-context-menu-content-transform-origin,
        var(--radix-popover-content-transform-origin,
        var(--radix-select-content-transform-origin, center top)))));
    }
    ${active2} :is(${menus}, ${popover2})[data-state="open"] {
      animation: hcv-menu-in var(--hcv-enter-time) var(--hcv-enter) both;
    }
    ${active2} :is(${menus}, ${popover2})[data-state="closed"] {
      animation: hcv-menu-out var(--hcv-exit-time) var(--hcv-exit) both;
      pointer-events: none;
    }
  }
  ${commandPaletteStyles(active2)}
}
`, { surface: `:is(${menus}, ${popover2}, ${dialog}, ${dialogOverlay}, ${items}, ${commandRoot})` });
  mountCSS(ctx, "data-hcv-interface-pages", `
@media (forced-colors: none) {
  /* Shells share spacing but keep their own controls, labels and content. */
  ${pages}, ${shown} {
    font-family: var(--hcv-ui-font);
    --conversation-text-font-size: 14px;
    --conversation-caption-font-size: 12px;
    --conversation-caption-line-height: 18px;
  }
  ${pages} [data-tour="artifact-card"] {
    border: 1px solid var(--hcv-hairline);
    border-radius: 12px;
    background: var(--hcv-form-surface);
  }
  ${pages} ${pageTabs} button {
    min-block-size: 30px;
    padding-inline: 12px;
    border-radius: 8px;
    font-size: 13px;
    line-height: 18px;
  }
  ${pages} ${pageTabs} button:is([aria-current], [aria-selected="true"], [data-active="true"]) {
    color: var(--hcv-text);
    background: var(--hcv-selected);
  }
  :is(${pages}, ${shown}) ${pageSearch} {
    min-block-size: 32px;
    gap: 8px;
    padding: 0 10px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 8px;
    opacity: 1;
    background-color: var(--hcv-form-surface);
  }
  :is(${pages}, ${shown}) ${pageSearch}:focus-within { border-color: var(--hcv-focus); }
  :is(${pages}, ${shown}) ${pageSearch} > input {
    height: auto;
    min-block-size: 30px;
    font-size: 13px;
    line-height: 18px;
  }
  ${codexIconRules(`:is(${pages}, ${shown}) ${pageSearch} > svg.tabler-icon-search`, "search")}
  @media (hover: hover) and (pointer: fine) {
    ${pages} [data-tour="artifact-card"]:hover {
      border-color: var(--hcv-stroke);
      background: var(--hcv-hover);
    }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${animatedPages}, ${shown} > div > [data-glass-raised] {
      animation: hcv-surface-in var(--hcv-enter-time) var(--hcv-enter);
    }
    :is(${pages}, ${shown}) ${pageSearch}, ${nav} button,
    ${sessions} > div > div > ul > li, ${pages} :is([data-tour="artifact-card"], ${pageTabs} button) {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease),
        color var(--hcv-enter-time) var(--hcv-ease), border-color var(--hcv-enter-time) var(--hcv-ease);
    }
  }
}
`, { screens: ["capabilities", "messaging", "artifacts"], surface: overlays });
  mountCSS(ctx, "data-hcv-interface-catalog", `
@media (forced-colors: none) {
  /* Codex's catalog cards use a border and a quiet fill on hover.
     The Hermes featured carousel and artwork keep their native layout. */
  ${catalogCard} {
    border-radius: 16px;
    box-shadow: none;
    filter: none;
    opacity: 1;
    transition: background-color 100ms var(--hcv-ease), border-color 100ms var(--hcv-ease);
  }
  ${plainCatalogCard} {
    border-color: var(--hcv-dropdown-outline);
    background: var(--hcv-chat);
  }
  ${plainCatalogCard}[data-catalog-variant="hero"] {
    border-radius: 12px;
    background: var(--hcv-form-surface);
  }
  ${catalogCard}::after { content: none; }
  ${catalogCard}${mutedArtwork}::before { content: none; }
  ${catalogCard}${mutedArtwork} > .catalog-card-image { display: none; }
  ${catalogCard}${mutedArtwork} .catalog-card-description {
    color: var(--ui-text-secondary);
  }
  ${catalogCard}:not([data-catalog-variant="hero"]) .catalog-card-title {
    font-size: 14px;
    line-height: 20px;
    font-weight: 600;
  }
  ${catalogCard} .catalog-card-description { font-size: 13px; line-height: 18px; }
  ${catalogCard} button[aria-haspopup="dialog"]:focus-visible::after {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -3px;
  }
  ${capabilities} .catalog-section-heading h2 {
    color: var(--hcv-text);
    font-size: 18px;
    line-height: 24px;
    font-weight: 500;
    letter-spacing: normal;
  }
  ${capabilities} .catalog-section-heading p { font-size: 13px; line-height: 18px; }
  ${catalogDetail} {
    background: var(--hcv-chat);
    color: var(--hcv-text);
    box-shadow: var(--hcv-menu-shadow);
    font-family: var(--hcv-ui-font);
    --conversation-caption-font-size: 13px;
    --conversation-caption-line-height: 20px;
  }
  ${catalogDetail} [data-slot="dialog-title"] {
    font-size: 21px;
    line-height: 28px;
    font-weight: 600;
  }
  ${catalogDetail} button.row-hover {
    border-radius: 8px;
    border: 1px solid var(--hcv-hairline);
  }
  ${capabilities} ${pageTabs} button {
    min-block-size: 26px;
    block-size: 26px;
    padding-inline: 8px;
    border-radius: 7px;
  }
  ${capabilities} ${pageTabs} button[data-active] > span { text-decoration-line: none; }
  ${capabilities} ${pageTabs} button[data-active="true"] { background-color: var(--hcv-dropdown-hover); }
  /* okCa (739301.37a39f26d6.js), used by the Skills and Plugins catalogs.
     The native scope badge may sit between the search icon and input. */
  ${capabilitySearch} {
    block-size: auto;
    min-block-size: 32px;
    gap: 8px;
    padding: 0 10px;
    border: 1px solid var(--hcv-dropdown-outline);
    border-radius: 999px;
    background-color: transparent;
    box-shadow: none;
    opacity: 1;
  }
  ${capabilitySearch}:focus-within { border-color: var(--hcv-focus); }
  ${capabilitySearch} > input {
    block-size: auto;
    min-block-size: 30px;
    font-size: 14px;
    line-height: 18px;
  }
  ${capabilitySearch} > input:focus-visible { outline: none; }
  ${capabilitySearch} > svg.tabler-icon-search {
    inline-size: 16px;
    block-size: 16px;
    color: var(--hcv-muted);
  }
  ${codexIconRules(`${capabilitySearch} > svg.tabler-icon-search`, "search")}
  ${capabilities} [data-catalog-actions] { gap: 6px; }
  ${catalogFilters} .catalog-filter-row,
  ${catalogFilters} .catalog-filter-chips { gap: 8px; }
  ${filterMode} {
    padding: 2px;
    gap: 2px;
    border-radius: 999px;
    background: var(--hcv-hover);
  }
  ${catalogControls} {
    border-color: transparent;
    background-color: transparent;
    color: var(--hcv-muted);
    box-shadow: none;
    text-decoration: none;
  }
  ${filterMode} > button,
  ${filterChips} {
    min-block-size: 24px;
    padding-inline: 8px;
    border-radius: 999px;
    font-size: 13px;
    line-height: 18px;
  }
  ${catalogControls}:is([aria-pressed="true"], [data-state="open"]) {
    background-color: var(--hcv-dropdown-hover);
    color: var(--hcv-text);
  }
  ${catalogControls}:focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${catalogFilters} .catalog-filter-trigger > span {
    font-size: 13px;
    letter-spacing: normal;
    text-transform: none;
  }
  ${filterTrigger}, ${catalogActions} {
    min-block-size: 26px;
    border-radius: ${codexReference.quietControl.radius};
  }
  ${catalogActions}:not([data-size^="icon"]) { padding-inline: 8px; }
  ${catalogControls}:active:not(:disabled) {
    background-color: var(--hcv-hover-menu);
    color: var(--hcv-text);
  }
  ${codexIconRules(`${filterTrigger} > svg.tabler-icon-filter-2`, "filter")}
  ${codexIconRules(`${capabilities} ${rescan} > svg.tabler-icon-refresh`, "refresh")}
  @media (hover: hover) and (pointer: fine) {
    ${capabilities} ${pageTabs} button[data-active="false"]:hover { background-color: var(--hcv-dropdown-hover); }
    ${capabilitySearch}:hover:not(:focus-within) { border-color: var(--hcv-stroke); }
    ${catalogControls}:hover:not(:disabled, [aria-pressed="true"], [data-state="open"]) {
      background-color: var(--hcv-dropdown-hover);
      color: var(--hcv-text);
    }
    ${plainCatalogCard}:not([data-catalog-variant="hero"]):hover {
      background-color: var(--hcv-dropdown-hover);
    }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${catalogCard}, ${capabilitySearch}, ${catalogControls} {
      transition: background-color 150ms ease, border-color 150ms ease, color 150ms ease;
    }
  }
  @media (prefers-reduced-motion: reduce) {
    ${catalogCard}, ${capabilitySearch}, ${catalogControls} {
      transition: none;
    }
  }
}
`, { screens: ["capabilities"] });
  mountCSS(ctx, "data-hcv-interface-overlays", `
@media (forced-colors: none) {
  ${shown} {
    padding: clamp(10px, 2.4vw, 32px);
    background-color: rgb(0 0 0 / .24);
    backdrop-filter: none;
  }
  ${shown} > div > [data-glass-raised] {
    border: 1px solid var(--hcv-hairline);
    border-radius: var(--hcv-dialog-radius);
    background-color: var(--hcv-chat);
    backdrop-filter: none;
    box-shadow: var(--hcv-menu-shadow);
  }
  ${shown} main {
    padding-block-start: 24px;
    padding-block-end: 12px;
  }
  ${nav} { padding: 12px 8px; background: var(--hcv-sidebar); }
  ${nav} button.row-hover {
    height: auto;
    min-height: 30px;
    border: 0;
    border-radius: 8px;
    font-size: 13px;
    gap: 8px;
  }
  ${nav} button.row-hover[aria-current="page"] { background: var(--hcv-selected); color: var(--hcv-text); }
  ${nav} button.row-hover > svg { width: 16px; height: 16px; }
  ${shown} button[data-size="icon-titlebar"] { border-radius: 8px; }
  ${codexIconRules(`${shown} button[data-size="icon-titlebar"] .codicon-close`, "close")}
  ${codexIconRules(`${nav} button[data-tour="nav-sessions"] > svg`, "messages")}
  ${codexIconRules(`${nav} button[data-tour="nav-system"] > svg`, "system")}
  ${codexIconRules(`${nav} button[data-tour="nav-usage"] > svg`, "usage")}
  ${codexIconRules(`${nav} button[data-tour="nav-maintenance"] > svg`, "wrench")}

  ${sessions} > header h2 { font-size: 22px; font-weight: 600; line-height: 28px; }
  ${sessions} > header p { margin-block-start: 4px; }
  ${sessions} > header:has(input) > :last-child { flex: 0 1 min(45%, 320px); }
  ${sessions} > header:has(input) > :last-child > div { inline-size: 100%; }
  ${sessions} > div > div > ul > li {
    margin-block: 2px;
    padding: 0 8px 0 0;
    border-radius: 10px;
  }
  ${sessions} > div > div > ul > li > button:first-child {
    min-block-size: 48px;
    padding: 8px 12px;
    border-radius: 10px;
  }
  ${sessions} > div > div > ul > li > button:first-child > div:first-child { font-size: 14px; }
  ${sessions} > div > div > ul > li:focus-within { background: var(--hcv-hover); }

  @media (hover: hover) and (pointer: fine) {
    ${nav} button.row-hover:not([aria-current="page"]):hover,
    ${sessions} > div > div > ul > li:hover { background-color: var(--hcv-hover); }
  }
  @media (max-width: 760px) {
    ${shown} { padding: 16px 8px 8px; }
    ${shown} main { padding-block-start: 8px; }
    ${shown} [data-glass-raised] > div > .grid:has(> [data-tour="overlay-nav"]) {
      grid-template-columns: minmax(0, 1fr);
      grid-template-rows: auto minmax(0, 1fr);
    }
    ${nav} { display: none; }
    ${nav} + div { display: flex; }
    ${sessions} > header:has(input) > :last-child { flex: 1 1 100%; }
    ${sessions} > header:has(input) > :last-child > div { max-inline-size: none; }
  }
}
`, { surface: overlays });
}

// source/desktop-pages.js
function registerDesktopPages(ctx, active2) {
  const page = "section.h-full.min-w-0.overflow-hidden:not([data-chat-surface])";
  const artifacts = `${active2}[data-hcv-screen="artifacts"] ${page}`;
  const messages = `${active2}[data-hcv-screen="messaging"] ${page}`;
  const scheduled = `${active2}[data-hcv-screen="cron"] [data-overlay-surface]`;
  const searches = `:is(${artifacts}, ${messages}, ${scheduled}) div:has(> svg.tabler-icon-search + input[placeholder])`;
  const artifactRows = `${artifacts} tbody > tr`;
  const artifactAction = `${artifactRows} > td > :is(a[href], button[data-slot="row-button"])`;
  const platform = `${messages} aside li > button.row-hover`;
  const task = `${scheduled} [data-panel-row]`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvDesktopPages = "";
  sheet.textContent = `
    @media (forced-colors: none) {
      /* okCa toolbar-compact in 739301.37a39f26d6.js. */
      ${searches} {
        min-block-size: 32px;
        border-color: var(--hcv-dropdown-outline);
        border-radius: 9999px;
        background: transparent;
        padding-inline: 12px;
      }
      ${searches} > input {
        min-inline-size: 0;
        min-block-size: 28px;
        font-size: 14px;
        line-height: 20px;
      }
      ${searches}:focus-within { border-color: var(--hcv-focus); }
      ${searches} > svg.tabler-icon-search {
        color: var(--hcv-muted);
        inline-size: 16px;
        block-size: 16px;
        flex: none;
      }

      /* The Codex resource list supplies surface, icon tile and type.
         Hermes keeps its columns, pagination and individual cell actions. */
      ${artifacts} div:has(> table) {
        border-radius: 12px;
        border-color: var(--hcv-hairline);
        background: var(--hcv-chat);
      }
      ${artifacts} thead { background: var(--hcv-chat); border-color: var(--hcv-hairline); }
      ${artifacts} table th {
        padding: 8px 12px;
        background: transparent;
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 0;
        text-transform: none;
      }
      ${artifacts} div.sticky:has(+ div > table) { background: var(--hcv-chat); }
      ${artifactRows} { height: 48px; }
      ${artifactRows} + tr { border-top: 1px solid var(--hcv-hairline); }
      ${artifactAction} {
        min-block-size: 47px;
        padding: 4px 12px;
        color: var(--hcv-text);
        text-decoration: none;
      }
      ${artifactAction}:hover { text-decoration: none; }
      ${artifactRows} > td:first-child > :is(a, button) > span:first-child {
        align-self: center;
        margin-block-start: 0;
        inline-size: 32px;
        block-size: 32px;
        border: 0;
        border-radius: 0;
        background: transparent;
        box-shadow: none;
        color: var(--hcv-muted);
      }
      ${codexIconRules(`${artifactRows} td:first-child .tabler-icon-file-text`, "artifacts")}
      ${codexIconRules(`${artifactRows} td:first-child .tabler-icon-link`, "link")}
      ${artifactRows} td:first-child :is(.tabler-icon-file-text, .tabler-icon-link) {
        inline-size: 16px;
        block-size: 16px;
      }
      ${artifacts} [data-tour="page-tabs"] button { border-radius: 9999px; }

      ${messages} aside { padding: 8px 10px; }
      ${platform}, ${task} {
        min-block-size: 36px;
        border-radius: 10px;
        font-size: 14px;
        line-height: 20px;
      }
      ${platform} { padding-inline: 10px; }
      ${task} > button:first-child { padding-inline: 10px; }
      ${task} > button:first-child > span:last-child { font-weight: 430; }
      ${scheduled} header > div > h2 {
        font-size: 20px;
        line-height: 26px;
        letter-spacing: -.01em;
      }
      ${codexIconRules(`${scheduled} .codicon-watch`, "schedule")}
      ${codexIconRules(`${scheduled} .codicon-kebab-vertical`, "more")}
      ${codexIconRules(`${scheduled} .codicon-add`, "plus")}

      ${artifactRows}:focus-within { background: var(--hcv-hover); }
      :is(${artifactAction}, ${platform}, ${task} > button:first-child):focus-visible {
        outline: 2px solid var(--hcv-focus);
        outline-offset: -2px;
        box-shadow: none;
      }
      @media (hover: hover) and (pointer: fine) {
        ${artifactRows}:hover { background: var(--hcv-hover); }
      }
      @media (prefers-reduced-motion: no-preference) {
        :is(${artifactRows}, ${platform}, ${task}) {
          transition: background-color 150ms var(--hcv-enter), color 150ms var(--hcv-enter);
        }
        ${searches} { transition: border-color 150ms var(--hcv-enter); }
      }
      @media (prefers-reduced-motion: reduce) {
        :is(${artifactRows}, ${artifactAction}, ${platform}, ${task}, ${searches}) { transition: none; }
      }
    }
  `;
  mountStyle(ctx, sheet, { screens: ["messaging", "artifacts", "cron"] });
}

// source/desktop-corners.js
function registerDesktopCorners(ctx, active2) {
  const messaging = `${active2}[data-hcv-screen="messaging"] main`;
  const scheduled = `${active2}[data-hcv-screen="cron"] [data-overlay-surface]`;
  const capabilities = `${active2}[data-hcv-screen="capabilities"]`;
  const setupCard = `${messaging} :is([data-testid^="relay-link-"], section > .mt-3 > div.rounded-xl.border[class~="bg-(--ui-surface-secondary,transparent)"])`;
  const featuredControls = `${capabilities} :is(.catalog-featured-controls > button[data-size="icon-xs"], .catalog-hero-action button[data-size="xs"])`;
  const kanbanCard = `${active2} div[draggable].rounded-md.border-l-2[style*="--kanban-tone:"]`;
  const sessionArc = `${active2} [data-tour="sessions-sidebar"] .row-hover > .arc-border.arc-row`;
  const tour = `${active2} .driver-popover`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvDesktopCorners = "";
  sheet.textContent = `
    @media (forced-colors: none) {
      /* Settings card and control geometry adapted to Hermes's QR setup. */
      ${setupCard} {
        border-radius: 12px;
        border-color: var(--hcv-hairline);
      }
      ${setupCard} button[data-size="sm"],
      ${scheduled} header:has(h3) button[data-slot="button"][data-size="sm"],
      ${featuredControls} {
        border-radius: ${codexReference.quietControl.radius};
      }
      ${scheduled} section > pre.rounded[class~="bg-foreground/5"] {
        border-radius: 10px;
      }

      /* The working session arc has zero standoff. Follow the painted row. */
      ${sessionArc} { border-radius: inherit; }

      /* The board's left status border is 2px while its other sides are 1px. */
      ${kanbanCard} { border-radius: 10px; }
      ${kanbanCard} > .kanban-arc { inset: -1px -1px -1px -2px; }

      ${tour} { border-radius: var(--hcv-dropdown-radius); }
      ${tour} .driver-popover-footer-btn { border-radius: ${codexReference.quietControl.radius}; }
    }
  `;
  mountStyle(ctx, sheet, {
    screens: ["messaging", "cron", "capabilities", "kanban"],
    surface: '.arc-border, .driver-popover, div[draggable][style*="--kanban-tone:"]'
  });
}

// source/settings-layout.js
var settingsRowHost = '[class~="@container"]';
var body = ".grid.gap-3.py-3";
var hostBody = `${settingsRowHost} > ${body}`;
var row3 = `${settingsRowHost}:has(> ${body})`;
var wrapped = ':is([id^="setting-field-"], [id^="aux-task-"], [id^="archived-session-"]):not([class~="@container"])';
var member = `:is(${settingsRowHost}, ${wrapped})`;
function settingsLayoutRules(screen, main) {
  const grid = `${main} ${hostBody}`;
  const copy7 = `${grid} > div:first-child`;
  const trailing = `${grid} > div:nth-child(2)`;
  const group2 = `${main} :where(div, section):where(:not(${member}):has(> ${hostBody}, > ${wrapped} > ${hostBody}):not(:has(> :not(${member}))))`;
  const delegation = `${main} [id="setting-field-delegation.model"]`;
  const delegationRows = `${delegation} .grid.gap-1:has(> ${hostBody})`;
  const moa = `${screen}[data-hcv-settings-tab="config:model"][data-hcv-settings-page="moa"] [data-overlay-surface] main`;
  const addReference = 'button[data-slot="button"][data-variant="textStrong"]';
  const moaRows = `${moa} .grid.gap-1:has(> ${settingsRowHost} + ${addReference} + ${hostBody})`;
  const loose = `${main} :where(${row3}:not(${group2} > *, ${group2} > ${wrapped} > *, ${delegation} *, ${moaRows} > *))`;
  const looseRun = `${main} .grid.gap-1:has(> ${settingsRowHost} + ${hostBody}):not(:where(${group2}, ${delegationRows}, ${moaRows}))`;
  const attachmentSize = '[id="setting-field-chat.attachment-size"]';
  const imageMode = '[id="setting-field-agent.image_input_mode"]:only-child';
  const attachmentTail = `${main} ${attachmentSize} + .grid:has(> ${imageMode} > ${hostBody})`;
  const attachmentHead = `${main} ${attachmentSize}:has(+ .grid > ${imageMode} > ${hostBody})`;
  const divider = "1px solid var(--hcv-settings-group-stroke)";
  const profile2 = `${main} .grid.gap-2:has(> .flex.flex-wrap[class~="gap-1.5"] > button.rounded-full.border[type="button"])`;
  const auxIntro = `${screen}[data-hcv-settings-page="auxiliary"] [data-overlay-surface] main section:has(> .grid > [id^="aux-task-"])`;
  const actionRail = `${main} [id^="aux-task-"] ${hostBody} > div:nth-child(2) > .flex`;
  const modelList = `${main} :is([id^="aux-task-"], [id="setting-field-delegation.model"]) ${hostBody}`;
  const presetBar = `${moa} .flex.flex-wrap:has(> label > [role="switch"]):has(> [data-slot="select-trigger"])`;
  const modelEditor = `${moaRows} > ${settingsRowHost} > ${body} > div:first-child > .mt-2.flex`;
  const modelTitle = `:is(${modelList}, ${moaRows} > ${hostBody}) > div:first-child > div:first-child > span.flex`;
  const fontRow = `${main} :is([id="setting-field-appearance.chat-font"], [id="setting-field-appearance.terminal-font"]) ${hostBody}`;
  const routeModes = `${main} [role="radiogroup"]:has(> [data-mode] > button[role="radio"])`;
  return `
  /* Codex AWNZ.ic / ZEx5: a flat list of rows within one frame. A deep-link
     wrapper is a member of that list, never another card inside it. */
  ${group2}, ${loose}, ${moaRows} {
    min-inline-size: 0;
    padding-inline: var(--hcv-settings-inset);
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-card-radius);
    background-color: var(--hcv-settings-group);
  }
  ${group2}, ${looseRun}, ${delegationRows}, ${moaRows} { gap: 0; }
  /* Separate independent cards while preserving intentionally joined rows. */
  :is(${group2}) + :is(${group2}),
  :is(${group2}) + :is(${loose}),
  :is(${loose}):not(:is(${attachmentHead})) + :is(${group2}) {
    margin-block-start: var(--hcv-settings-block-gap);
  }
  ${group2} > ${member} { min-inline-size: 0; border-radius: 0; }
  ${group2} > ${member} + ${member},
  ${delegationRows} > ${settingsRowHost} + ${settingsRowHost},
  ${moaRows} > ${settingsRowHost} + ${settingsRowHost} { border-block-start: ${divider}; }
  ${loose} + ${settingsRowHost} {
    border-start-start-radius: 0;
    border-start-end-radius: 0;
    border-block-start-color: var(--hcv-settings-group-stroke);
  }
  ${loose}:has(+ ${settingsRowHost} > ${body}) {
    border-end-start-radius: 0;
    border-end-end-radius: 0;
    border-block-end-width: 0;
  }
  ${attachmentHead} {
    border-block-end: 0;
    border-end-start-radius: 0;
    border-end-end-radius: 0;
  }
  ${attachmentTail} {
    border-block-start: 0;
    border-start-start-radius: 0;
    border-start-end-radius: 0;
  }
  ${attachmentTail} > ${imageMode} { border-block-start: ${divider}; }

  ${grid} {
    grid-template-columns: minmax(0, 1fr);
    gap: 8px var(--hcv-settings-row-gap);
    padding-block: var(--hcv-settings-row-pad);
  }
  ${copy7} > div:first-child { font-size: 13px; font-weight: 500; line-height: calc(1.25 / .875); }
  ${copy7} > div:first-child > span { min-inline-size: 0; overflow-wrap: anywhere; }
  ${copy7} > .mt-1 { margin-block-start: 2px; overflow-wrap: anywhere; }
  ${trailing} { min-inline-size: 0; gap: 8px; }
  ${trailing} > :is(div, button, input) { max-inline-size: 100%; }
  ${grid}:has(> div:nth-child(2) > [role="switch"]:only-child) {
    grid-template-columns: minmax(0, 1fr) max-content;
    align-items: center;
  }
  ${grid}:has(> div:nth-child(2) > [role="switch"]:only-child) > div:nth-child(2) {
    justify-self: end;
  }
  @container (min-width: 480px) {
    ${grid}:has(> div + div) {
      grid-template-columns: minmax(0, 1fr) fit-content(54%);
      align-items: center;
    }
    ${grid}[class~="@2xl:items-start"] { align-items: start; }
    ${trailing} { justify-self: end; justify-content: flex-end; }
  }
  @container (width < 480px) {
    ${copy7} > div:first-child { flex-wrap: wrap; gap: 4px 8px; }
    ${trailing} { justify-self: start; justify-content: flex-start; }
  }

  /* Hermes-only controls mapped to stacked rows and compact actions. */
  ${delegationRows} > div.pb-3:empty { display: none; }
  ${delegationRows} > div.pb-3:not(:empty) { padding-block: 4px 12px; }
  ${routeModes} {
    gap: 0;
    padding-inline: var(--hcv-settings-inset);
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-card-radius);
    background: var(--hcv-settings-group);
  }
  ${routeModes} > [data-mode] { border: 0; border-radius: 0; background: transparent; }
  ${routeModes} > [data-mode] + [data-mode] { border-block-start: ${divider}; }
  ${routeModes} > [data-mode] > button[role="radio"] { padding: 10px 0; }
  ${routeModes} > [data-blocked="true"] { background: color-mix(in srgb, #f59e0b 8%, transparent); }
  @media (hover: hover) and (pointer: fine) {
    ${routeModes} > [data-mode]:has(> button[role="radio"]:hover:not(:disabled)) { background: var(--hcv-settings-button); }
  }
  @container hcv-settings-main (min-width: 540px) {
    ${auxIntro} {
      display: grid;
      grid-template-columns: minmax(0, 1fr) max-content;
      align-items: center;
      gap: 12px 16px;
    }
    ${auxIntro} > * { grid-column: 1 / -1; }
    ${auxIntro} > div:first-child { grid-area: 1 / 2; margin: 0; }
    ${auxIntro} > p:nth-child(2) { grid-area: 1 / 1; margin: 0; }
  }
  ${modelTitle} { flex-wrap: wrap; gap: 2px 8px; }
  ${modelTitle} > [data-slot="badge"] {
    padding: 0;
    border: 0;
    background: transparent;
    color: var(--hcv-muted);
    font: 400 12px/16px var(--hcv-ui-font);
    white-space: normal;
    text-align: start;
  }
  ${actionRail} { flex-wrap: wrap; flex-shrink: 1; justify-content: inherit; gap: 4px 8px; }
  ${modelList} > div:first-child > .mt-2.grid { margin-block-start: 8px; padding-block-start: 0; }
  ${presetBar} > [data-slot="select-trigger"] {
    inline-size: auto;
    min-inline-size: min(136px, 100%);
  }
  ${presetBar} > label:has(> [role="switch"]) {
    min-block-size: 28px;
    padding: 2px 8px;
    border-radius: 8px;
  }
  ${moaRows} > ${addReference} {
    justify-self: end;
    margin-block: 8px;
  }
  ${moaRows} > ${settingsRowHost}:has(+ ${addReference}) { border-block-end: ${divider}; }
  ${moaRows} > ${addReference} + ${settingsRowHost} { border-block-start: ${divider}; }
  ${modelEditor} { margin-block-start: 6px; padding-block-start: 0; gap: 6px 8px; }
  ${modelEditor} > :is(button, div) { max-inline-size: 100%; min-inline-size: 0; }
  ${modelEditor} > :is([data-slot$="select-trigger"], div:has(> [data-slot="input"])) {
    inline-size: auto;
    flex: 1 1 160px;
  }
  ${moaRows} > ${hostBody}:has(> div:nth-child(2)) { align-items: start; }
  ${moaRows} > ${hostBody} > div:nth-child(2) { padding-block-start: 1px; }
  ${fontRow} > div > .space-y-2 { margin-block-start: 8px; }
  ${fontRow} > div > .space-y-2 > div:first-child { flex-wrap: wrap; gap: 8px; }
  ${fontRow} > div > .space-y-2 > div:first-child > div { min-inline-size: min(200px, 100%); }
  ${fontRow} > div > .space-y-2 > .overflow-hidden {
    padding: 6px 0 0;
    overflow-wrap: anywhere;
  }
  ${profile2} { gap: 4px; margin-block-end: 16px; }
  ${profile2} > .flex { gap: 6px; }
  ${profile2} > .flex > button {
    padding: 3px 8px;
    max-inline-size: 100%;
    min-block-size: 24px;
    border-radius: 8px;
    line-height: 16px;
    overflow-wrap: anywhere;
  }
  `;
}

// source/settings.js
var groups = {
  "config:model": "model",
  "config:chat": "messages",
  "config:appearance": "palette",
  "config:workspace": "desktop",
  "config:safety": "lock",
  "config:browser": "web",
  "config:memory": "memory",
  "config:voice": "mic",
  "config:advanced": "wrench",
  vault: "shield",
  notifications: "bell",
  billing: "usage",
  providers: "bolt",
  gateway: "globe",
  connections: "globe",
  "web-access": "web",
  keybinds: "keyboard",
  keys: "keys",
  sessions: "archive",
  plugins: "plugins",
  about: "info"
};
var nativeIcons = {
  archive: "archive",
  bell: "bell",
  box: "model",
  brain: "memory",
  "chart-bar": "usage",
  "circle-letter-a": "artifacts",
  cpu: "model",
  download: "download",
  "file-image": "artifacts",
  "file-text": "artifacts",
  "git-fork": "bots",
  "folder-open": "folderOpen",
  globe: "globe",
  keyboard: "keyboard",
  key: "keys",
  "key-round": "keys",
  lock: "lock",
  "message-circle": "messages",
  microphone: "mic",
  mic: "mic",
  monitor: "desktop",
  "device-desktop": "desktop",
  network: "globe",
  palette: "palette",
  paw: "paw",
  photo: "image",
  "settings-2": "sliders",
  "adjustments-horizontal": "sliders",
  "shield-lock": "shield",
  terminal: "terminal",
  "terminal-2": "terminal",
  tool: "wrench",
  trash: "trash",
  "trash-2": "trash",
  users: "team",
  "volume-2": "audio",
  wrench: "wrench",
  bolt: "bolt",
  zap: "bolt",
  "info-circle": "info"
};
function registerSettingsStyle(ctx, active2) {
  const screen = `${active2}[data-hcv-screen="settings"]`;
  const settings = `${screen} [data-overlay-surface]`;
  const rail = `${settings} [data-tour="overlay-nav"]`;
  const searchButton = "button[data-glass-opaque]";
  const searchIcon = "svg.tabler-icon-search";
  const search = `${settings} ${searchButton}:has(> ${searchIcon})`;
  const searchPosition = `${settings} > div > div:has(> ${searchButton} > ${searchIcon})`;
  const compact = `${rail} + div button[aria-haspopup="menu"]`;
  const settingsMenu = `${active2}[data-hcv-screen="settings"] [data-slot="dropdown-menu-content"] [role="menuitem"]`;
  const main = `${settings} main`;
  const panels = `${screen} :is([data-slot="dialog-content"], [data-slot="popover-content"], [data-slot="select-content"], [data-slot="dropdown-menu-content"])`;
  const selectPanel = `${screen} [data-slot="select-content"]`;
  const system = `${active2}[data-hcv-screen="command-center"] [data-overlay-surface] main`;
  const preferences = `:is(${main}, ${system})`;
  const crumbWrap = `${main} > div:has(> nav > [aria-current="page"])`;
  const directCrumbs = `${main} > nav:has(> [aria-current="page"])`;
  const crumbs = `:is(${directCrumbs}, ${crumbWrap} > nav)`;
  const triggers = ':is([data-slot="select-trigger"], [data-slot="searchable-select-trigger"], [data-slot="compact-select-trigger"])';
  const control4 = `:is(${triggers}, [data-slot="input"]:not([type="file"], [type="checkbox"], [type="range"], [type="color"]), [data-slot="textarea"], [data-slot="combobox-input"])`;
  const surfaces = `:is(${main}, ${panels})`;
  const sectionTitle = `${main} .flex.items-center.gap-2.pt-2:has(> svg.size-4)`;
  const segmented = `${main} .inline-grid.grid-flow-col:has(> button[aria-pressed])`;
  const searchField = `${main} div.inline-flex:has(> ${searchIcon} ~ input[placeholder])`;
  const mainButtons = `${surfaces} :is(button, a[data-slot="button"])[data-variant][data-size]:not([data-size="inline"], [role="switch"])`;
  const compactButton = `${mainButtons}:is([data-size="sm"], [data-size="default"])`;
  const quietButton = `${mainButtons}:is([data-variant="ghost"], [data-variant="text"])`;
  const modes = `${main} [id="setting-field-gateway.connection-mode"] > .grid`;
  const mode = `${modes} > button`;
  const selectable = `${main} button.rounded-lg.border.transition-colors.text-left:not([data-slot], [id="setting-field-gateway.connection-mode"] *)`;
  const action = `${preferences} button[data-slot="button"]:is([data-variant="text"], [data-variant="textStrong"]):not([data-size="inline"])`;
  const inlineAction = `${preferences} button[data-size="inline"]:is([data-variant="text"], [data-variant="textStrong"])`;
  const link2 = `:is(${preferences}, ${active2}[data-hcv-screen="settings"] [data-slot="dialog-content"]) a[href]:not([role="button"], [data-slot="button"])`;
  const operationRow = '.flex.items-center.justify-between.gap-3.py-2:has(> div.min-w-0 + button[data-variant="textStrong"])';
  const operation = `${system} section > ${operationRow}`;
  const toggle2 = `${surfaces} [data-slot="switch"][role="switch"]`;
  const focusable2 = `${surfaces} :is(button, a[href], input, select, textarea, [tabindex="0"])`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvSettings = "";
  sheet.textContent = `
@media (forced-colors: none) {
  ${settings} {
    --hcv-settings-rail-width: 240px;
    --hcv-settings-rail-inset: 8px;
    --hcv-settings-nav-fill: var(--hcv-dropdown-hover);
  }
  ${settings} [data-glass-raised] > div > .grid:has(> main, > [data-tour="overlay-nav"]) {
    grid-template-columns: minmax(0, var(--hcv-settings-rail-width)) minmax(0, 1fr);
  }
  ${rail} {
    gap: 1px;
    padding: 12px var(--hcv-settings-rail-inset);
    border-inline-end: 1px solid var(--hcv-hairline);
  }
  /* SettingsSidebar (21225.709d5925a9.js) and okCa's sidebar-header search.
     Hermes mounts the launcher beside the overlay card. Anchor it to the rail. */
  @media (width > 760px) {
    ${settings}:has(${searchButton} > ${searchIcon}) [data-tour="overlay-nav"] { padding-block-start: 60px; }
    ${searchPosition} {
      inset-inline: calc(1px + var(--hcv-settings-rail-inset)) auto;
      inset-block-start: 12px;
      inline-size: calc(var(--hcv-settings-rail-width) - 2 * var(--hcv-settings-rail-inset));
      translate: none;
    }
    ${search} {
      inline-size: 100%;
      block-size: 36px;
      justify-content: flex-start;
    }
  }
  ${search} {
    gap: 8px;
    padding-inline: 12px;
    border: 0;
    border-radius: 999px;
    background-color: var(--hcv-settings-nav-fill);
    box-shadow: none;
    color: var(--hcv-muted);
    text-align: start;
  }
  ${search} > span:not([data-slot]) {
    flex: 1;
    min-inline-size: 0;
    font-size: 14px;
    line-height: 18px;
  }
  ${search} > svg { inline-size: 16px; block-size: 16px; }
  ${codexIconRules(`${search} > ${searchIcon}`, "search")}
  ${rail} button.row-hover {
    min-block-size: 30px;
    padding-inline: 8px;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 400;
    line-height: 20px;
    color: var(--hcv-text);
  }
  ${rail} button.row-hover:not([aria-current="page"]) { background-color: transparent; }
  ${rail} button.row-hover[aria-current="page"] { background-color: var(--hcv-settings-nav-fill); }
  ${rail} button.row-hover > :is(svg, .codicon) { color: inherit; }
  ${rail} div[id] > button.row-hover { min-block-size: 30px; font-size: 12px; }
  ${rail} div[id] > button.row-hover > svg { inline-size: 14px; block-size: 14px; }
  ${rail} button[data-tour^="nav-toggle-"] { border-radius: 6px; }
  ${rail} :is(button.row-hover, button[data-tour^="nav-toggle-"]):focus-visible,
  ${search}:focus-visible, ${compact}:focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${Object.entries(nativeIcons).map(([native2, icon8]) => codexIconRules(
    `:is(${rail} button.row-hover, ${compact}, ${settingsMenu}) > svg.tabler-icon-${native2}`,
    icon8
  )).join("")}
  ${codexIconRules(`:is(${rail} button.row-hover, ${compact}, ${settingsMenu}) > .codicon-account`, "person")}
  ${Object.entries(groups).map(([name, icon8]) => codexIconRules(`${rail} button[data-tour="nav-${name}"] > :is(svg, .codicon)`, icon8)).join("")}
  ${codexIconRules(`${rail} button[data-tour^="nav-toggle-"] > :is(svg, .codicon)`, "right")}
  ${codexIconRules(`${compact} > .codicon-chevron-down`, "down")}
  ${compact} { min-block-size: 30px; padding-inline: 8px; border-radius: 8px; }
  ${compact}:is(:hover, :focus-visible, [data-state="open"]) { background: var(--hcv-hover); }
  ${codexIconRules(`${rail} > div:last-child > button > svg.tabler-icon-download`, "download")}
  ${codexIconRules(`${rail} > div:last-child > button > svg.tabler-icon-upload`, "upload")}
  ${codexIconRules(`${rail} > div:last-child > button > svg.tabler-icon-refresh`, "refresh")}

  /* Desktop settings, 150138.9670f4badd.js: 768px including 20px side
     gutters. ZEx5 + AWNZ.ic, 200452.c015aea25d.js: grouped rows. */
  ${preferences}, ${panels} {
    --hcv-settings-group: light-dark(#f7f7f7, #232323);
    --hcv-settings-group-stroke: color-mix(in srgb, var(--hcv-text) 9%, transparent);
    --hcv-settings-button: color-mix(in srgb, var(--hcv-text) 5%, transparent);
    --hcv-settings-card-radius: 16px;
    --hcv-settings-control-radius: 8px;
    --hcv-settings-inset: 16px;
    --hcv-settings-row-gap: 24px;
    --hcv-settings-row-pad: 12px;
    --hcv-settings-block-gap: 12px;
    --hcv-settings-fade: 150ms cubic-bezier(0, 0, .2, 1);
    font-family: var(--hcv-ui-font);
  }
  ${system} { --hcv-settings-group-stroke: color-mix(in srgb, var(--hcv-text) 8%, transparent); }
  /* Codex Desktop's named corner scale, limited to settings contents and portals.
     Native utility classes then use the same curve on wrappers and their contents. */
  :is(${main}, ${panels}) {
    --radius-sm: 6px;
    --radius-md: 8px;
    --radius-lg: 10px;
    --radius-xl: 12px;
    --radius-2xl: 16px;
    --radius-3xl: 24px;
  }
  ${preferences} :is(div, section, fieldset, pre).rounded-md.border { border-radius: 8px; }
  ${preferences} :is(div, section, fieldset, pre).rounded-lg.border { border-radius: 10px; }
  ${preferences} :is(div, section, fieldset, pre).rounded-xl.border { border-radius: 12px; }
  ${preferences} :is(div, section, fieldset, pre).rounded-2xl.border { border-radius: 16px; }
  ${main} {
    max-inline-size: 768px;
    container: hcv-settings-main / inline-size;
    --hcv-settings-gutter: 20px;
    padding: 32px 0 0;
    font-size: 13px;
    line-height: calc(1.25 / .875);
    --conversation-text-font-size: 13px;
    --conversation-caption-font-size: 12px;
    --conversation-caption-line-height: 16px;
  }
  ${main} > section > div.h-full {
    padding-inline: var(--hcv-settings-gutter);
    padding-block-end: 32px;
  }
  ${crumbWrap}, ${directCrumbs} {
    margin-block-end: 20px;
    padding-inline: var(--hcv-settings-gutter);
  }
  ${crumbs} {
    min-block-size: 30px;
    gap: 6px;
    flex-wrap: wrap;
    font-size: 12px;
    line-height: 18px;
  }
  ${crumbs} > [aria-current="page"] {
    flex-basis: 100%;
    font-size: 28px;
    font-weight: 500;
    line-height: 1.2;
    min-inline-size: 0;
    white-space: normal;
  }
  ${crumbs} > button { font-size: 12px; }
  ${crumbs} > svg:has(+ [aria-current="page"]) { display: none; }
  ${codexIconRules(`${crumbs} > svg`, "right")}
  ${main} h1 { font-weight: 500; text-wrap: balance; }
  ${main} h2, ${sectionTitle} {
    color: var(--hcv-text);
    font-size: 14px;
    font-weight: 500;
    line-height: 20px;
  }
  ${sectionTitle} { margin-block-end: 8px; padding-block-start: 0; }
  ${sectionTitle} > svg { flex: 0 0 auto; inline-size: 16px; block-size: 16px; color: var(--hcv-muted); }
  ${Object.entries(nativeIcons).map(([native2, icon8]) => codexIconRules(`${sectionTitle} > svg.tabler-icon-${native2}`, icon8)).join("")}
  ${main} p { overflow-wrap: anywhere; }
  ${settingsLayoutRules(screen, main)}
  ${modes} {
    gap: 0;
    min-inline-size: 0;
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-card-radius);
    background: var(--hcv-settings-group);
  }
  ${modes} { grid-template-columns: minmax(0, 1fr); grid-auto-rows: auto; }
  ${mode} {
    position: relative;
    padding: 12px 16px;
    border: 0;
    border-radius: 0;
    background: transparent;
    box-shadow: none;
  }
  ${mode}:first-child { border-start-start-radius: 15px; border-start-end-radius: 15px; }
  ${mode}:last-child { border-end-start-radius: 15px; border-end-end-radius: 15px; }
  ${mode} + button::before {
    content: '';
    position: absolute;
    inset: 0 16px auto;
    block-size: 1px;
    background: var(--hcv-hairline);
    pointer-events: none;
  }
  ${mode}.ring-2 { background-color: var(--hcv-hover-menu); }
  ${mode}.ring-2::before, ${mode}.ring-2 + button::before { visibility: hidden; }
  ${mode}:active:not(:disabled) { background-color: color-mix(in srgb, var(--hcv-text) 16%, transparent); }
  ${mode}:focus-visible { z-index: 1; }
  ${mode} > p { margin-block-start: 4px; }
  ${selectable} { border-color: var(--hcv-hairline); border-radius: 16px; box-shadow: none; }
  ${selectable}.ring-2 { border-color: var(--hcv-stroke); background-color: var(--hcv-hover-menu); }

  /* Sm6l's toolbar variant: 28px with 8px sides. Quiet secondary
     actions read as text until hover; the row's main action gets a fill. */
  ${action} {
    min-block-size: 28px;
    max-inline-size: 100%;
    padding: 4px 8px;
    border-radius: var(--hcv-popup-button-radius);
    background-color: var(--hcv-settings-button);
    color: var(--hcv-text);
    font-size: 13px;
    font-weight: 400;
    line-height: 18px;
    text-decoration: none;
    white-space: normal;
    overflow-wrap: anywhere;
  }
  ${main} button[data-variant="text"][data-slot="button"]:not([data-size="inline"]) {
    background-color: transparent;
    color: var(--hcv-muted);
  }
  ${system} button[data-slot="button"]:is([data-variant="text"], [data-variant="textStrong"]):not([data-size="inline"]) { font-weight: 500; }
  ${action}.text-destructive { color: var(--hcv-error); }
  ${action}:active:not(:disabled) { background-color: color-mix(in srgb, var(--hcv-text) 16%, transparent); }
  ${inlineAction}, ${link2} { text-decoration: none; }
  ${link2} { color: light-dark(#0169cc, #83c3ff); }
  ${link2}:is(:hover, :focus-visible) { text-decoration: underline; }
  ${action}:focus-visible { box-shadow: none; }
  ${operation} {
    min-inline-size: 0;
    flex-wrap: wrap;
    padding: 12px 16px;
    border-inline: 1px solid var(--hcv-settings-group-stroke);
    background: var(--hcv-settings-group);
  }
  ${operation}:nth-child(1 of ${operationRow}) {
    border-block-start: 1px solid var(--hcv-settings-group-stroke);
    border-start-start-radius: 16px;
    border-start-end-radius: 16px;
  }
  ${operation} + ${operationRow} { border-block-start: 1px solid var(--hcv-hairline); }
  ${operation}:nth-last-child(1 of ${operationRow}) {
    border-block-end: 1px solid var(--hcv-settings-group-stroke);
    border-end-start-radius: 16px;
    border-end-end-radius: 16px;
  }

  /* Personalization uses F0xz (956370.aff5cce818.js). */
  ${toggle2} {
    inline-size: 32px;
    block-size: 20px;
    padding-inline: 2px;
    border: 0;
    box-shadow: none;
    background-color: color-mix(in srgb, var(--hcv-text) 10%, transparent);
  }
  ${toggle2}[data-state="checked"] { background-color: #339cff; }
  ${toggle2} > [data-slot="switch-thumb"] { inline-size: 16px; block-size: 16px; background-color: #fff; translate: none; }
  ${toggle2}[data-state="checked"] > [data-slot="switch-thumb"] { translate: 12px 0; }
  ${toggle2}[data-state="checked"]:dir(rtl) > [data-slot="switch-thumb"] { translate: -12px 0; }

  ${surfaces} ${control4} {
    min-block-size: 28px;
    max-inline-size: 100%;
    border: 1px solid var(--hcv-hairline);
    border-radius: var(--hcv-settings-control-radius);
    background: var(--hcv-form-surface);
    padding-inline: 10px;
    font-size: 13px;
    line-height: 18px;
    box-shadow: none;
  }
  ${surfaces} ${control4}:not(textarea) { block-size: 28px; }
  ${surfaces} input[role="combobox"][aria-autocomplete="list"] { padding-inline-end: 28px; }
  ${surfaces} ${control4}:is(:focus, :focus-within, [data-state="open"]):not(:disabled, [aria-invalid="true"]) {
    border-color: color-mix(in srgb, var(--hcv-text) 50%, transparent);
  }
  ${surfaces} ${control4}[aria-invalid="true"] { border-color: var(--hcv-error); }
  ${surfaces} textarea[data-slot="textarea"] { padding-block: 8px; }
  ${main} input[data-slot="input"][type="number"] { inline-size: min(100%, 96px); }
  ${surfaces} ${triggers} {
    min-inline-size: 0;
    gap: 6px;
  }
  ${surfaces} ${triggers} > :is(svg.tabler-icon-chevron-down, .codicon-chevron-down, .codicon-chevron-up),
  ${main} :has(> input[role="combobox"][aria-autocomplete="list"]) > button > .codicon-chevron-down {
    inline-size: 14px;
    block-size: 14px;
    flex-shrink: 0;
    color: var(--hcv-muted);
  }
  ${codexIconRules(`${surfaces} ${triggers} > :is(svg.tabler-icon-chevron-down, .codicon-chevron-down)`, "down")}
  ${codexIconRules(`${surfaces} ${triggers} > .codicon-chevron-up`, "down")}
  ${surfaces} ${triggers} > .codicon-chevron-up { rotate: 180deg; }
  ${searchField} {
    min-block-size: 32px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 999px;
    background: var(--hcv-form-surface);
    padding-inline: 10px;
    opacity: 1;
  }
  ${searchField}:focus-within { border-color: var(--hcv-focus); }
  ${searchField} > input:focus-visible { outline: none; }
  ${segmented} { display: inline-flex; flex-wrap: wrap; min-inline-size: 0; max-inline-size: 100%; border-radius: 12px; }
  ${segmented} > button {
    min-block-size: 24px;
    padding-inline: 6px;
    border-radius: 999px;
    color: var(--hcv-muted);
    font: 400 12px/16px var(--hcv-ui-font);
  }
  ${segmented} > button[aria-pressed="true"] {
    background: var(--hcv-settings-group);
    color: var(--hcv-text);
    box-shadow: 0 0 0 .5px var(--hcv-hairline);
  }
  :is(${main}, ${panels}) [data-slot="badge"] { border-radius: 999px; }
  ${surfaces} [data-slot="select-trigger"] > [data-slot="select-value"] {
    min-inline-size: 0;
    text-overflow: ellipsis;
  }
  ${mainButtons} {
    border-radius: var(--hcv-popup-button-radius);
    max-inline-size: 100%;
    white-space: normal;
  }
  ${compactButton} {
    block-size: auto;
    min-block-size: 28px;
    padding: 4px 8px;
    font: 400 13px/18px var(--hcv-ui-font);
  }
  ${quietButton}[data-size^="icon"] { inline-size: 28px; block-size: 28px; border-radius: 8px; }
  ${focusable2}:focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
  ${surfaces} button:is([data-variant="outline"], [data-variant="secondary"]):not(:disabled) {
    border-color: var(--hcv-hairline);
  }
  ${settings} button[data-glass-opaque] { font-family: var(--hcv-ui-font); }
  @media (hover: hover) and (pointer: fine) {
    ${mode}:hover:not(:disabled)::before,
    ${mode}:hover:not(:disabled) + button::before { visibility: hidden; }
    ${search}:hover { color: var(--hcv-text); }
    ${segmented} > button:hover:not(:disabled, [aria-pressed="true"]) {
      background: var(--hcv-hover-menu);
      color: var(--hcv-text);
    }
    ${surfaces} ${control4}:hover:not(:disabled, :focus, :focus-within, [data-state="open"], [aria-invalid="true"]) { border-color: var(--hcv-stroke); }
    ${mode}:hover:not(:disabled, .ring-2, :active),
    ${action}:hover:not(:disabled, :active),
    ${main} button[data-variant="text"][data-slot="button"]:not([data-size="inline"], :disabled):hover {
      background-color: var(--hcv-hover-menu);
      color: var(--hcv-text);
    }
    ${rail} button.row-hover:not([aria-current]):hover { background-color: var(--hcv-settings-nav-fill); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${rail} button.row-hover,
    ${surfaces} :is(button, ${control4}) {
      transition: color var(--hcv-settings-fade, 150ms ease),
        background-color var(--hcv-settings-fade, 150ms ease), border-color var(--hcv-settings-fade, 150ms ease);
    }
    ${toggle2} > [data-slot="switch-thumb"] { transition: translate var(--hcv-settings-fade); }
    ${system} button:not([role="switch"]) {
      transition: color var(--hcv-enter-time) var(--hcv-ease), background-color var(--hcv-enter-time) var(--hcv-ease),
        border-color var(--hcv-enter-time) var(--hcv-ease), box-shadow var(--hcv-enter-time) var(--hcv-ease);
    }
    ${selectPanel}[data-state="open"] { animation: hcv-settings-select-in 300ms var(--hcv-enter) both; transform-origin: var(--radix-select-content-transform-origin); }
    ${selectPanel}[data-state="closed"] { animation: hcv-settings-select-out 200ms var(--hcv-exit) both; transform-origin: var(--radix-select-content-transform-origin); }
    @keyframes hcv-settings-select-in { from { opacity: 0; scale: .95; } to { opacity: 1; scale: 1; } }
    @keyframes hcv-settings-select-out { from { opacity: 1; scale: 1; } to { opacity: 0; scale: .95; } }
  }
  @media (prefers-reduced-motion: reduce) {
    ${rail} button.row-hover { transition: none; }
    ${surfaces} :is(button, ${control4}, [data-slot="switch-thumb"]) { transition: none; }
    ${system} button:not([role="switch"]) { transition: none; }
    ${selectPanel}[data-state] { animation: none; }
  }
  @media (max-width: 760px) {
    ${settings} [data-glass-raised] > div > .grid:has(> [data-tour="overlay-nav"]) {
      grid-template-columns: minmax(0, 1fr);
    }
    ${main} { padding-block-start: 8px; --hcv-settings-gutter: 16px; --hcv-settings-inset: 12px; }
    ${crumbWrap}, ${directCrumbs} { margin-block-end: 12px; }
    ${crumbs} > [aria-current="page"] { font-size: 24px; line-height: 28px; }
    ${search} { background-color: color-mix(in srgb, var(--hcv-text) 8%, var(--hcv-sidebar)); }
  }
}
@media (forced-colors: active) {
  ${preferences} :is(button, a[href], input, textarea, select):focus-visible {
    outline: 2px solid Highlight;
    outline-offset: -2px;
  }
}
`;
  mountStyle(ctx, sheet, { screens: ["settings", "command-center"] });
}

// source/settings-providers.js
function registerSettingsProviders(ctx, active2) {
  const settings = `${active2}[data-hcv-screen="settings"][data-hcv-settings-tab="providers"]`;
  const providerMain = `${settings} [data-overlay-surface] main`;
  const localMain = `${settings}[data-hcv-settings-page="local"] [data-overlay-surface] main`;
  const hero = `${active2} button:has(> .arc-border.arc-nous)`;
  const accounts = `${providerMain} section.mb-5.grid.gap-2`;
  const account = `${accounts} > :is(button[data-slot="row-button"], div.group.grid:has(> button))`;
  const endpointShortcut = `${providerMain} > section > div.h-full > button[data-slot="row-button"]`;
  const keyCard = `${providerMain} :is([id^="provider-key-"], .grid.gap-2) > [class~="group/card"]`;
  const endpointList = `${providerMain} .space-y-6 > section > .divide-y.rounded-md.border`;
  const endpointForm = `${providerMain} .space-y-6 > section > .grid.rounded-md.border.p-3`;
  const endpointName = `${endpointList} > .grid > button:first-child`;
  const localFiles = `${localMain} #local-model-browse .flex.flex-col.rounded-md.border`;
  const localQuickstart = `${localMain} [class~="min-h-[60dvh]"] > .max-w-md`;
  const searchField = '.inline-flex:has(> svg.tabler-icon-search + input[type="text"])';
  const search = `${providerMain} ${searchField}`;
  const badges = `:is(${accounts} > div.group.grid > button > div > span.inline-flex,
    ${accounts} > button > div > :is(div > span.inline-flex, span.inline-flex),
    ${providerMain} [data-slot="badge"])`;
  const cards = `:is(${account}, ${endpointShortcut}, ${keyCard}, ${endpointList}, ${endpointForm}, ${localQuickstart})`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvSettingsProviders = "";
  sheet.textContent = `
@media (forced-colors: none) {
  /* Codex's recommendation variant (ZEx5 in 200452.4e72c790d9.js)
     has a clipped 20px frame. The shared Hermes row keeps its native arc. */
  ${hero} {
    border-radius: 20px;
    overflow: hidden;
  }
  ${hero} > .arc-border.arc-nous {
    --arc-standoff: 0px;
    border-radius: inherit;
  }
  ${hero} > div > div { flex-wrap: wrap; }
  ${hero} > div > div > span.inline-flex { border-radius: 999px; }

  ${cards} {
    border-radius: var(--hcv-settings-card-radius, 16px);
    background-color: var(--hcv-settings-group);
  }
  :is(${account}, ${endpointShortcut}, ${keyCard}, ${localQuickstart}) {
    box-shadow: inset 0 0 0 1px var(--hcv-settings-group-stroke);
  }
  ${account} > button:first-child,
  ${endpointName} {
    border-radius: var(--hcv-settings-control-radius, 8px);
  }
  ${account} > button:first-child > .flex { flex-wrap: wrap; }
  ${accounts} > button:has(> .arc-border.arc-nous) {
    background-color: var(--hcv-settings-group);
    box-shadow: inset 0 0 0 1px var(--hcv-settings-group-stroke);
  }
  ${badges} {
    border-radius: 999px;
    max-inline-size: 100%;
    white-space: normal;
    line-height: 1.25;
  }
  ${keyCard}.ring-1 { box-shadow: inset 0 0 0 1px var(--hcv-stroke); }
  ${keyCard}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${keyCard}:focus-within > .grid > div:first-child > svg { opacity: 1; }

  /* The search settings variant (okCa in 739301.37a39f26d6.js)
     uses a hairline, an inset glyph and the settings control radius. */
  ${search} {
    min-block-size: 32px;
    gap: 8px;
    padding-inline: 10px;
    border: 1px solid var(--hcv-hairline);
    border-radius: var(--hcv-settings-control-radius, 8px);
    background-color: var(--hcv-form-surface);
    opacity: 1;
  }
  ${endpointShortcut} + .grid:has(> .inline-flex > svg.tabler-icon-search + input[type="text"]) {
    margin-block-start: var(--hcv-settings-block-gap);
  }
  ${search}:focus-within { border-color: var(--hcv-focus); }
  ${search} > input {
    min-block-size: 30px;
    font-size: 13px;
    line-height: 18px;
  }
  ${codexIconRules(`${search} > svg.tabler-icon-search`, "search")}

  :is(${endpointList}, ${endpointForm}, ${localFiles}) {
    border-color: var(--hcv-settings-group-stroke);
  }
  ${endpointList} > .grid {
    padding: 12px 16px;
    border-color: var(--hcv-hairline);
  }
  ${endpointForm} { padding: clamp(12px, 2vw, 16px); }
  ${localFiles} {
    border-radius: var(--hcv-settings-control-radius, 8px);
    background-color: var(--hcv-form-surface);
  }
  ${localQuickstart} { padding: clamp(16px, 3vw, 24px); }
  ${localQuickstart} > .flex { flex-wrap: wrap; }

  @media (hover: hover) and (pointer: fine) {
    :is(${account}, ${endpointShortcut}, ${keyCard}[role="button"],
      ${accounts} > button:has(> .arc-border.arc-nous)):hover:not(:disabled) {
      background-color: color-mix(in srgb, var(--hcv-settings-group) 90%, var(--hcv-text));
    }
    ${endpointName}:hover { color: var(--hcv-text); text-decoration: underline; }
    ${search}:hover:not(:focus-within) { border-color: var(--hcv-stroke); }
  }
}
@media (forced-colors: active) {
  ${hero} > .arc-border.arc-nous { display: none; }
  ${hero}:focus-visible { outline: 2px solid Highlight; outline-offset: -2px; }
}
`;
  mountStyle(ctx, sheet, { screens: ["settings"], tabs: ["providers"] });
}

// source/settings-special.js
function registerSettingsSpecial(ctx, active2) {
  const page = (tab) => `${active2}[data-hcv-settings-tab="${tab}"] [data-overlay-surface] main`;
  const gateways = page("gateway");
  const registryEditor = `${gateways} .space-y-3.rounded-lg.border:has(> .grid.grid-cols-2)`;
  const gatewayAgent = `${gateways} [class~="ring-primary/25"].rounded-md:has(> [class~="@container"])`;
  const billing = page("billing");
  const billingNotice = `${billing} .mb-6.rounded-xl.p-4:has(> .mt-1)`;
  const billingTiles = `${billing} [class~="@container"].mb-6 > .grid[class~="@2xl:grid-cols-3"]:has(> .min-w-0 > .tabular-nums)`;
  const billingUsage = `${billing} section.mb-6 > [class~="@container"]:has(> [class~="@container"] > .grid.py-3)`;
  const planTile = `${billing} .grid[class~="@3xl:grid-cols-3"] > .rounded-lg.outline-none[tabindex="-1"]`;
  const confirmPlan = `${planTile} [role="status"][aria-live="polite"]`;
  const shortcuts = page("keybinds");
  const shortcutList = `${shortcuts} > section > .h-full > div.px-2[class~="py-1.5"]:has([data-slot="kbd"], [class~="group/kbd-cat"])`;
  const shortcutRow = `:is(${shortcutList} > div, ${shortcutList} > section > div).rounded-lg:has([data-slot="kbd"])`;
  const shortcutCategory = `${shortcutList} [class~="group/kbd-cat"]`;
  const keycap = `${shortcuts} [data-slot="kbd"]`;
  const archiveRow = '[id^="archived-session-"]';
  const archive = `${page("sessions")} ${archiveRow}`;
  const archiveAction = `${archive} ${settingsRowHost} > .grid > div:nth-child(2) > .flex`;
  const pluginRow = 'button[data-testid^="plugin-settings-row-"]';
  const plugins = `${page("plugins")} .grid:has(> ${pluginRow})`;
  const pluginManage = `${page("plugins")} a[data-slot="button"][href*="capabilities"]`;
  const keyRow = '[id^="credential-key-"] > [class~="group/card"]';
  const toolKey = `${page("keys")} ${keyRow}`;
  const emptyKeys = `${page("keys")} .rounded-lg.border-dashed`;
  const about = page("about");
  const uninstall = `${about} .max-w-2xl > .rounded-xl.border:is([class~="border-destructive/30"], [class~="bg-background/40"])`;
  const uninstallOption = `${uninstall} button.rounded-lg.border.text-left`;
  const inlineAlert = `${shortcuts} [role="alert"] > div.rounded-xl[class~="border-destructive/30"]`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvSettingsSpecial = "";
  sheet.textContent = `
@media (forced-colors: none) {
  /* ZEx5 card surfaces and dividers from Codex 200452.4e72c790d9.js. */
  ${registryEditor}, ${billingTiles}, ${billingUsage}, ${planTile}, ${plugins}, ${emptyKeys} {
    min-inline-size: 0;
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-card-radius);
    background-color: var(--hcv-settings-group);
  }
  ${gatewayAgent} {
    border-radius: var(--hcv-settings-control-radius);
    background-color: var(--hcv-settings-group);
    box-shadow: inset 0 0 0 1px var(--hcv-hairline);
  }
  ${registryEditor} > .grid > button { min-inline-size: 0; overflow-wrap: anywhere; white-space: normal; }
  ${registryEditor} > .grid > button[data-variant="default"]:not(:disabled) {
    background: var(--hcv-hover-menu);
    color: var(--hcv-text);
    box-shadow: inset 0 0 0 1px var(--hcv-stroke);
  }

  /* Codex Usage (333192.5177e7c555.js) supplies the neutral table surface;
     keep Hermes' different stats, plan artwork, and warning colors. */
  ${billingTiles}, ${billingUsage} { padding-inline: clamp(8px, 2vw, 16px); }
  ${billingTiles} { padding-block: 12px; }
  ${billingUsage} > [class~="@container"] + [class~="@container"] { border-block-start: 1px solid var(--hcv-hairline); }
  ${billingNotice}, ${uninstall} { border-radius: var(--hcv-settings-card-radius); }
  ${billingNotice} { border: 1px solid var(--hcv-settings-group-stroke); }
  ${billingNotice}[class~="bg-(--ui-bg-quaternary)"] { background-color: var(--hcv-settings-group); }
  ${planTile}[class~="bg-(--ui-green)/10"] {
    border-color: color-mix(in srgb, var(--ui-green) 34%, transparent);
    background-color: color-mix(in srgb, var(--ui-green) 10%, var(--hcv-settings-group));
  }
  ${confirmPlan} {
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-control-radius);
    background-color: var(--hcv-chat);
  }
  ${planTile}:focus-visible, ${confirmPlan}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }

  /* The Codex shortcuts editor keeps command labels and keycaps on one row
     and uses a visible focus outline for capture (566048.88ccc86b80.js). */
  ${shortcutList} {
    padding: 8px;
    border: 1px solid var(--hcv-settings-group-stroke);
    border-radius: var(--hcv-settings-card-radius);
    background-color: var(--hcv-settings-group);
  }
  ${shortcutCategory} { min-block-size: 28px; padding-block: 4px; border-radius: 8px; }
  ${shortcutCategory} > span { color: var(--hcv-muted); font-size: 11px; letter-spacing: .06em; }
  ${shortcutRow} { min-block-size: 34px; border-radius: var(--hcv-settings-control-radius); }
  ${shortcutRow}:focus-within { background-color: var(--hcv-hover-menu); }
  ${keycap} { border-radius: 5px; box-shadow: none; }

  /* Same button roles as archived chats in Codex; Hermes keeps its own
     preview, folder and message count, and the native action order. */
  ${archiveAction} { flex-wrap: wrap; gap: 8px; }
  ${archiveAction} > button[data-variant="textStrong"] > svg.tabler-icon-archive-off { display: none; }
  ${archiveAction} > button > svg:is(.tabler-icon-trash, .tabler-icon-trash-2) { inline-size: 16px; block-size: 16px; }
  ${codexIconRules(`${archiveAction} > button > svg:is(.tabler-icon-trash, .tabler-icon-trash-2)`, "trash")}
  ${archive} ${settingsRowHost} > .grid > .min-w-0 > .font-mono {
    color: var(--hcv-muted);
    font: 400 12px/16px var(--hcv-ui-font);
  }
  ${plugins} { padding-inline: var(--hcv-settings-inset); overflow: visible; }
  ${plugins} > ${pluginRow} {
    min-block-size: 44px;
    border-color: var(--hcv-hairline);
    padding-inline: 0;
    background-color: transparent;
  }
  ${plugins} > ${pluginRow}:first-child { border-start-start-radius: 15px; border-start-end-radius: 15px; }
  ${plugins} > ${pluginRow}:last-child { border-end-start-radius: 15px; border-end-end-radius: 15px; }
  ${codexIconRules(`${plugins} > ${pluginRow} > .codicon-chevron-right`, "right")}
  ${pluginManage} { border-radius: var(--hcv-settings-control-radius); }

  ${toolKey} {
    min-inline-size: 0;
    border-radius: var(--hcv-settings-card-radius);
    background-color: var(--hcv-settings-group);
    box-shadow: inset 0 0 0 1px var(--hcv-settings-group-stroke);
  }
  ${toolKey}.ring-1 { box-shadow: inset 0 0 0 1px var(--hcv-stroke); }
  ${toolKey}[role="button"]:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }

  ${uninstall}:not([class~="border-destructive/30"]) { background-color: var(--hcv-settings-group); }
  ${uninstallOption} { border-radius: 12px; }
  ${inlineAlert} { border-radius: var(--hcv-settings-card-radius); }

  @media (hover: hover) and (pointer: fine) {
    ${plugins} > ${pluginRow}:hover, ${shortcutCategory}:hover, ${shortcutRow}:hover,
    ${toolKey}.row-hover:hover {
      background-color: var(--hcv-hover-menu);
    }
  }
}
`;
  mountStyle(ctx, sheet, { screens: ["settings"], tabs: ["gateway", "billing", "keybinds", "about", "sessions", "plugins", "keys"] });
}

// source/app-updates.js
function registerAppUpdatesStyle(ctx, active2) {
  const brand = 'span > img:is([src$="nous-girl.png"], [src$="nous-girl-dark.png"])';
  const hero = `.flex.flex-col:has(> ${brand})`;
  const dialog2 = `[data-slot="dialog-content"].max-w-sm:has(> div > div > .flex.flex-col > ${brand}):has(> div > div > .flex.flex-col > div > [data-slot="dialog-title"])`;
  const layout = `div:has(> .flex.flex-col > ${brand})`;
  const about = `${active2}[data-hcv-screen="settings"] [data-overlay-surface] main`;
  const updates = '[id="setting-field-about.updates"]';
  const updateDialog = `${active2} ${dialog2}`;
  const dialogLayout = `${updateDialog} > div > ${layout}`;
  const aboutUpdates = `${about} ${updates}`;
  const aboutLayout = `${about} ${layout}:has(${updates})`;
  const versionHero = `:is(${dialogLayout} > ${hero}, ${aboutLayout} > ${hero})`;
  const warning = `${versionHero} > div.rounded-xl.border`;
  const status2 = `:is(${dialogLayout} > ${hero} ~ div.rounded-xl.border, ${aboutUpdates} > div.rounded-xl.border)`;
  const aboutDetails = `${aboutLayout} > div > dl.grid`;
  const details = `:is(${dialogLayout} > dl, ${aboutDetails})`;
  const quietAction = `:is(${warning}, ${status2}) [data-slot="button"]:is([data-variant="text"], [data-variant="textStrong"])`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvAppUpdates = "";
  sheet.textContent = `
@media (forced-colors: none) {
  ${updateDialog} {
    inline-size: min(480px, calc(100% - 32px));
    max-inline-size: none;
    max-block-size: min(85vh, calc(100% - 32px));
    background: var(--hcv-menu);
  }
  ${updateDialog} > div:first-child { overflow: auto; }
  ${dialogLayout} {
    gap: 12px;
    padding: 20px;
  }
  ${versionHero} {
    display: grid;
    grid-template-columns: 40px minmax(0, 1fr);
    gap: 12px;
    align-items: center;
    padding: 0;
    text-align: start;
  }
  ${dialogLayout} > ${hero} > div:nth-child(2) { padding-inline-end: 20px; }
  ${versionHero} > span:first-child {
    inline-size: 40px;
    block-size: 40px;
  }
  ${versionHero} :is(h2, [data-slot="dialog-title"]) {
    font-size: 16px;
    font-weight: 600;
    line-height: 22px;
  }
  ${versionHero} > div:nth-child(2) > p {
    margin-block-start: 2px;
    color: var(--hcv-muted);
    font-size: 12px;
    line-height: 16px;
  }
  ${warning} { grid-column: 1 / -1; margin-block-start: 4px; }
  ${warning}, ${status2} {
    min-inline-size: 0;
    padding: 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 12px;
    background: var(--hcv-form-surface);
    color: var(--hcv-text);
    font-size: 13px;
    line-height: 18px;
    overflow-wrap: anywhere;
  }
  ${warning} > div { gap: 10px; }
  ${warning} > div > svg { color: light-dark(#9a5c00, #f2b94b); }
  ${codexIconRules(`${warning} > div > svg`, "warning")}
  :is(${warning}, ${status2}) p.font-medium { font-weight: 500; }
  :is(${warning}, ${status2}) p.text-xs { color: var(--hcv-muted); font-size: 12px; line-height: 18px; }
  ${quietAction} {
    min-block-size: 28px;
    max-inline-size: 100%;
    padding: 4px 8px;
    border-radius: 8px;
    background: var(--hcv-hover-menu);
    color: var(--hcv-text);
    text-decoration: none;
    white-space: normal;
  }
  ${quietAction}:not(:disabled):hover { background: var(--hcv-selected); text-decoration: none; }
  :is(${warning}, ${status2}, ${details}) :is(a, button):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: 2px;
  }
  ${details} {
    display: grid;
    gap: 0;
    min-inline-size: 0;
    padding: 0 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 16px;
    background: var(--hcv-form-surface);
    font-size: 13px;
    line-height: 18px;
  }
  ${aboutDetails} { margin-block-start: 12px; }
  ${details} > div {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 2fr);
    gap: 12px;
    padding-block: 8px;
  }
  ${details} > div + div { border-block-start: 1px solid var(--hcv-hairline); }
  ${details} dt { color: var(--hcv-muted); }
  ${details} :is(dt, dd, a) {
    min-inline-size: 0;
    overflow-wrap: anywhere;
    word-break: normal;
  }
  ${details} dd { text-align: end; }
  ${details} a { text-underline-offset: 3px; }
}
`;
  mountStyle(ctx, sheet, { screens: ["settings"], tabs: ["about"], surface: '[data-slot="dialog-content"].max-w-sm' });
}

// source/install-overlay.js
var progressGlyphs = { pending: "circle", done: "circleCheck", failed: "circleX", disclosure: "right" };
function progressMask(state) {
  return localAssets ? svgMask(localAssets.install[state]) : codexMask(progressGlyphs[state]);
}
function registerInstallOverlayStyle(ctx, active2) {
  const panel2 = `${active2} div.fixed.inset-0[class~="z-(--z-setup)"] > .flex.flex-col[class~="max-h-[90vh]"]:has(> .overflow-y-auto)`;
  const header2 = `${panel2} > div:first-child`;
  const body2 = `${panel2} > .overflow-y-auto`;
  const progress = `${body2} [data-slot="progress"]`;
  const row5 = `${body2} > ol > li`;
  const rowLabel = `${row5} > div.min-w-0 > div:first-child`;
  const icon8 = `${rowLabel} > span:nth-child(2)`;
  const spinner = `${row5} > div:first-child > [role="status"]`;
  const error = `${body2} > div:has(> .codicon-error)`;
  const disclosure2 = `${body2} > div:last-child > button`;
  const log = `${body2} > div:last-child > [data-selectable-text]`;
  const footer = `${panel2} > div:nth-child(3)`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvInstallOverlay = "";
  sheet.textContent = `
@media (forced-colors: none) {
  ${panel2} {
    --hcv-install-info: light-dark(#0169cc, #66b5ff);
    max-inline-size: 560px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 16px;
    background: var(--hcv-menu);
    color: var(--hcv-text);
    font-family: var(--hcv-ui-font);
    overflow: hidden;
  }
  ${header2} { gap: 12px; padding: 20px 20px 12px; }
  ${header2} > span:first-child { inline-size: 36px; block-size: 36px; }
  ${header2} h2 { font-size: 16px; line-height: 22px; font-weight: 600; letter-spacing: normal; }
  ${header2} p { margin-block-start: 4px; font-size: 13px; line-height: 18px; color: var(--hcv-muted); }
  ${body2} { padding: 0 20px 12px; }
  ${body2} > div:has(> [data-slot="progress"]) { margin-block-end: 12px; }
  ${progress} { block-size: 8px; border-radius: 9999px; background: color-mix(in srgb, var(--hcv-text) 10%, transparent); }
  ${progress} > div { background: var(--hcv-install-info); transition: none; }
  ${progress} > .bg-destructive { background: var(--destructive); }
  ${body2} > ol {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin: 0;
    padding: 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 12px;
  }
  ${row5} { gap: 8px; margin: 0; padding: 0; min-block-size: 18px; }
  ${rowLabel} { gap: 8px; }
  ${rowLabel} > span:first-child { font-size: 13px; line-height: 18px; font-weight: 400; }
  ${row5}:has(> div:first-child > [role="status"]) > div:first-child { margin: 0; inline-size: 16px; block-size: 16px; }
  ${row5}:has(> div:first-child > [role="status"]) > div.min-w-0 > div:first-child > span:first-child { color: var(--hcv-install-info); }
  ${rowLabel}:has(> span > .codicon-check) > span:first-child { color: var(--hcv-install-info); }
  ${rowLabel}:has(> span > .codicon-error) > span:first-child { color: var(--destructive); }
  ${icon8}, ${spinner} {
    order: -1;
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    color: var(--hcv-muted);
    mask: ${progressMask("pending")} center / contain no-repeat;
  }
  ${icon8}:has(> .codicon-check) { color: var(--hcv-install-info); mask-image: ${progressMask("done")}; }
  ${icon8}:has(> .codicon-error) { color: var(--destructive); mask-image: ${progressMask("failed")}; }
  ${icon8} > *, ${spinner} > svg, ${disclosure2} > svg > * { visibility: hidden; }
  ${spinner} {
    inline-size: 14px;
    block-size: 14px;
    color: var(--hcv-install-info);
    mask-image: ${codexMask("sidebarWorking")};
    animation: hcv-install-spin 2s steps(60, end) infinite;
  }
  @keyframes hcv-install-spin { to { rotate: 1turn; } }
  ${error} {
    margin-block-end: 12px;
    padding: 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 12px;
    background: var(--hcv-form-surface);
  }
  ${body2} > div:last-child { padding-block-start: 12px; }
  ${disclosure2} {
    min-block-size: 28px;
    margin-inline: 0;
    padding-inline: 8px;
    gap: 8px;
    border-radius: 8px;
    color: var(--hcv-muted);
    font-size: 13px;
    font-weight: 400;
  }
  ${disclosure2} > svg {
    inline-size: 14px;
    block-size: 14px;
    background: currentColor;
    mask: ${progressMask("disclosure")} center / contain no-repeat;
    transition: rotate 300ms cubic-bezier(.4, 0, .2, 1);
  }
  ${disclosure2}:has(+ [data-selectable-text]) > svg { rotate: 90deg; }
  ${log} {
    padding: 8px 12px;
    border-color: var(--hcv-hairline);
    border-radius: 8px;
    background: var(--hcv-form-surface);
    color: var(--hcv-muted);
  }
  ${footer} { padding: 12px 20px; background: var(--hcv-menu); }
  ${footer} > div, ${footer} > div > div { flex-wrap: wrap; justify-content: flex-end; }
  ${footer} > div > span { margin-inline-end: auto; overflow-wrap: anywhere; }
  ${footer} button { min-block-size: 28px; border-radius: 8px; }
  ${panel2} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 2px; }
  @media (hover: hover) and (pointer: fine) {
    ${disclosure2}:hover, ${footer} button[data-variant="ghost"]:not(:disabled):hover {
      background: var(--hcv-selected);
      color: var(--hcv-text);
    }
  }
  @media (prefers-reduced-motion: reduce) {
    ${spinner} { animation: none; }
    ${disclosure2} > svg { transition: none; }
  }
}
`;
  mountStyle(ctx, sheet, { surface: '.flex.flex-col[class~="max-h-[90vh]"]' });
}

// source/remaining-surfaces.js
function registerRemainingSurfaces(ctx, active2) {
  const directory = `${active2} [data-slot="connectors-directory"]`;
  const connector = `${directory} [data-slot="connector-row-card"]`;
  const connectorDialog = `${active2}[data-hcv-screen="capabilities"] [data-slot="dialog-content"]`;
  const connectorTools = `${active2} :is([data-slot="tools-list"], [data-slot="tools-summary"])`;
  const overlays2 = `${active2} [data-overlay-surface]`;
  const panelRows = `${overlays2} [data-panel-row]`;
  const cap = `${active2}[data-hcv-screen="capabilities"] section.h-full.min-w-0.overflow-hidden`;
  const scopeRow = `${cap} div:has(> span + button[data-slot="select-trigger"] > [data-slot="select-value"])`;
  const filterRow = "button.row-hover[aria-pressed]";
  const filters = `${cap} [data-catalog] [data-tour="overlay-nav"] > ${filterRow}`;
  const dialog2 = `${active2} [data-slot="dialog-content"]`;
  const createProject = `${dialog2}.max-w-md:has(> div > input[data-slot="input"]):has(> div > div > div > textarea[data-slot="textarea"])`;
  const projectFolders = `${createProject} > div > div:has(> button[data-slot="button"][data-size="sm"][data-variant="ghost"] > .codicon-add)`;
  const addProjectFolder = `${projectFolders} > button[data-slot="button"][data-size="sm"][data-variant="ghost"]:has(> .codicon-add)`;
  const profiles = `${active2}[data-hcv-screen="profiles"] [data-overlay-surface]`;
  const profileRows = `${profiles} [data-panel-row]`;
  const selectedProfile = `${profileRows}[class~="bg-(--ui-row-active-background)"]`;
  const profileSearch = `${profiles} div.mb-1.w-full.shrink-0:has(> svg.tabler-icon-search + input[type="text"][placeholder])`;
  const profileEditor = `${profiles} section > .min-h-48:has(> div > div > .cm-editor)`;
  const proseFrame = `.flex.h-full.min-h-0.flex-col.overflow-hidden.border:has(> div > .cm-editor)`;
  const framedEditor = `:is(${profileEditor} > ${proseFrame}, ${dialog2}.max-w-2xl > .h-80 > ${proseFrame})`;
  const segmented = `:is(${overlays2}, ${dialog2}) .inline-grid.auto-cols-fr.grid-flow-col:has(> button[aria-pressed])`;
  const segmentedButton = `${segmented} > button[aria-pressed]`;
  const webhookAlert = `${active2}[data-hcv-screen="webhooks"] [data-glass-raised] > div > [data-slot="alert"]`;
  const botRows = `${active2} :is(button[data-roster-key], [data-slot="bots-section"] button[draggable="true"][data-slot="row-button"])`;
  const botPane = `${active2} [data-hcv-sidebar-shell]:has(> [data-panel-header] [data-tree-tab="hermes-bots:pane"][aria-selected="true"]) > .relative.flex-1 > .absolute.inset-0:not([data-pane-hidden]) > .h-full.flex-col`;
  const botLoading = `${botPane} > div:has(> [role="status"] > .glyph-spinner)`;
  const terminalRail = `${active2}:has([data-hcv-sidebar-shell] [data-tree-tab="terminal"][aria-selected="true"]) [data-pane-host="terminal"] [data-suppress-pane-reveal] > [role="tablist"]`;
  mountCSS(ctx, "data-hcv-remaining-surfaces", `
@media (forced-colors: none) {
  ${codexIconRules(`${active2} button[aria-haspopup="menu"] > .codicon-add`, "plus")}

}
`);
  mountCSS(ctx, "data-hcv-connectors-styles", `
@media (forced-colors: none) {
  ${directory} {
    container-type: inline-size;
    gap: 12px;
    padding: 8px 4px 0;
    font-family: var(--hcv-ui-font);
  }
  ${directory} > div:has(> h2) { gap: 12px; flex-wrap: wrap; }
  ${directory} > div > h2 {
    margin: 0;
    color: var(--hcv-text);
    font-size: 22px;
    font-weight: 600;
    line-height: 28px;
    letter-spacing: -.012em;
  }
  ${directory} > div:has(> h2) > button { min-block-size: 30px; padding-inline: 12px; border-radius: 8px; }
  ${directory} div:has(> svg.tabler-icon-search + input[placeholder]) {
    max-inline-size: 480px;
    flex: 1 1 320px;
  }
  ${directory} section > header h3 {
    font-size: 14px;
    line-height: 20px;
    font-weight: 600;
  }
  ${directory} section > .grid:has(> [data-slot="connector-row-card"]) { gap: 8px; }
  ${connector} {
    min-block-size: 66px;
    gap: 12px;
    padding: 10px 12px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 12px;
    background: var(--hcv-form-surface);
    color: var(--hcv-text);
  }
  ${connector}[data-state="open"], ${connector}:has(button[aria-expanded="true"]) { background: var(--hcv-selected); }
  ${connector} > div:first-child { border-radius: 8px; }
  ${connector} button::after { border-radius: 12px; }
  ${connector} button:has(> .sr-only) { font-size: 14px; font-weight: 500; line-height: 20px; }
  ${connector} > div:last-child { inline-size: auto; min-inline-size: 72px; }
  ${connector} > div:last-child button:not([role="switch"]) { min-block-size: 26px; padding-inline: 8px; border-radius: 7px; }
  ${connector} p { font-size: 12px; line-height: 17px; }
  ${connector}:focus-within { border-color: var(--hcv-focus); }
  ${cap} :is([data-slot="compact-select-value"], [data-slot="select-value"]) { font-size: 13px; }
  ${cap} :is([data-slot="select-trigger"], button[data-variant="outline"]) {
    border-color: var(--hcv-hairline);
    background: var(--hcv-form-surface);
  }
  ${scopeRow} { flex-wrap: wrap; gap: 6px 8px; padding: 6px 12px; }
  ${scopeRow} > button[data-slot="select-trigger"] {
    inline-size: max-content;
    max-inline-size: min(100%, 420px);
    min-inline-size: 0;
    min-block-size: 28px;
    padding: 0 8px;
    border-radius: 8px;
  }
  ${scopeRow} > button > [data-slot="select-value"] {
    display: block;
    min-inline-size: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  ${scopeRow} > button > .codicon-chevron-down { flex: none; inline-size: 14px; block-size: 14px; }
  ${codexIconRules(`${scopeRow} > button > .codicon-chevron-down`, "down")}
  ${filters} { min-block-size: 26px; block-size: 26px; padding: 3px 6px; border-radius: 7px; }
  ${filters} + ${filterRow} { margin-block-start: var(--hcv-unit); }
  ${connectorDialog} [data-slot="add-server-form"] { gap: 16px; }
  ${connectorDialog} [data-slot="add-server-form"] label > span { font-size: 13px; line-height: 18px; }
  ${connectorTools} [data-slot="tool-row"] {
    border-radius: 8px;
    font-family: var(--hcv-ui-font);
  }
  ${connectorTools} [data-slot="tools-dirty-footer"] { border-color: var(--hcv-hairline); }

  ${codexIconRules(`${directory} svg.tabler-icon-rosette-discount-check`, "verified")}
  @container (max-width: 680px) {
    ${directory} section > .grid:has(> [data-slot="connector-row-card"]) { grid-template-columns: minmax(0, 1fr); }
  }
  @media (hover: hover) and (pointer: fine) {
    ${connector}:hover { background: var(--hcv-hover); border-color: var(--hcv-stroke); }
    ${connectorTools} [data-slot="tool-row"]:hover { background: var(--hcv-hover); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${connector}, ${connectorTools} [data-slot="tool-row"] {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease), border-color var(--hcv-enter-time) var(--hcv-ease);
    }
  }
}
`, { screens: ["capabilities"], surface: '[data-slot="connectors-directory"], [data-slot="tools-list"], [data-slot="tools-summary"]' });
  mountCSS(ctx, "data-hcv-overlay-rows", `
@media (forced-colors: none) {
  /* Shared panel shell used by Hermes profiles, agents, webhooks, starmap,
     session import, and contributed panels. None of their actions are replaced. */
  ${overlays2} header:has(> div > h2) > div > h2 {
    font-size: 20px;
    line-height: 26px;
    font-weight: 600;
  }
  ${panelRows} {
    min-block-size: 32px;
    border-radius: 8px;
    font-size: 13px;
  }
  ${panelRows} > button:first-child { min-block-size: inherit; padding-inline: 8px; }
  ${panelRows} :is(button, a):focus-visible { outline: 1px solid var(--hcv-focus); outline-offset: -1px; }
  ${profiles} { font-family: var(--hcv-ui-font); }
  ${profiles} header h3 { font-size: 16px; line-height: 22px; font-weight: 600; overflow-wrap: anywhere; }
  ${profiles} :is(header > div > p.font-mono, dl) { font-size: 12px; line-height: 18px; }
  ${profiles} :is(header > div > p.font-mono, dl dt) { color: var(--hcv-muted); }
  ${profileSearch} {
    min-block-size: 36px;
    padding-inline: 12px;
    border: 0;
    border-radius: 999px;
    background: var(--hcv-hover);
  }
  ${profileSearch}:has(> input:focus-visible) { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${profileSearch} > input:focus-visible { outline: none; }
  ${profileRows} { min-block-size: 30px; border-radius: 10px; }
  ${profileRows} > button[data-slot="row-button"] { border-radius: inherit; }
  ${profileRows} button[aria-haspopup="menu"] {
    inline-size: 24px;
    block-size: 24px;
    border-radius: 8px;
  }
  ${selectedProfile} { background: var(--hcv-selected); }
  ${profiles} button[data-slot="button"][data-size="sm"] { min-block-size: 28px; border-radius: 10px; }

  /* AGENTS.md in Codex settings is a 320px scrollable prose editor.
     The framed native CodeMirror keeps its buffer, shortcuts and wrapping. */
  ${profileEditor} { block-size: clamp(128px, 45vh, 320px); min-block-size: 0; }
  ${profileEditor} > div { min-inline-size: 0; }
  ${profiles} section:has(> .min-h-48) > div:first-child > div > div:first-child {
    color: var(--hcv-text);
    font-size: 14px;
    font-weight: 500;
    line-height: 20px;
    letter-spacing: normal;
    text-transform: none;
  }
  ${framedEditor} {
    border-radius: 10px;
    border-color: var(--hcv-hairline);
    background-color: var(--hcv-form-surface);
  }
  ${framedEditor}:focus-within { border-color: var(--hcv-focus); }
  ${framedEditor} > div { padding: 8px 12px; }
  ${framedEditor} .cm-editor.cm-focused { outline: none; }
  ${framedEditor} :is(.cm-content, .cm-line, .cm-scroller),
  ${dialog2} #new-profile-soul {
    font-family: var(--hcv-ui-font);
    font-size: 13px;
    font-weight: 400;
    line-height: 20px;
  }
  ${framedEditor} .cm-line { padding-block: 2px; }
  @media (max-width: 760px), (max-height: 720px) {
    ${profileEditor} { block-size: clamp(128px, 30vh, 320px); }
    ${dialog2}.max-w-2xl > .h-80:has(> div > div > .cm-editor) { block-size: min(320px, 50vh); }
  }
  ${segmented} { padding: 2px; gap: 2px; max-inline-size: 100%; border-radius: 10px; background: var(--hcv-hover); }
  ${segmentedButton} {
    min-block-size: 26px;
    min-inline-size: 0;
    padding-inline: 8px;
    border-radius: 8px;
    font: 500 13px/18px var(--hcv-ui-font);
    box-shadow: none;
  }
  ${segmentedButton}[aria-pressed="true"] { background-color: var(--hcv-menu); }
  ${webhookAlert} { border-radius: 12px; }
  ${webhookAlert}:first-child { margin-block-start: 24px; }
  ${codexIconRules(`${overlays2} .codicon-add`, "plus")}
  ${codexIconRules(`${overlays2} .codicon-kebab-vertical`, "more")}
  ${codexIconRules(`${overlays2} .codicon-hubot`, "bots")}
  ${codexIconRules(`${overlays2} .codicon-account`, "person")}
  ${codexIconRules(`${overlays2} .codicon-link`, "link")}
  ${codexIconRules(`${overlays2} .codicon-comment-discussion`, "hud")}
  ${codexIconRules(`${overlays2} .codicon-edit`, "edit")}
  ${codexIconRules(`${overlays2} .codicon-trash`, "trash")}
  ${codexIconRules(`${overlays2} .codicon-refresh`, "refresh")}
  @media (hover: hover) and (pointer: fine) {
    ${panelRows}:hover { background: var(--hcv-hover); }
    ${selectedProfile}:hover { background: var(--hcv-selected); }
    ${segmentedButton}[aria-pressed="false"]:hover:not(:disabled) { background: var(--hcv-hover-menu); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${panelRows} {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease), border-color var(--hcv-enter-time) var(--hcv-ease);
    }
  }
  @media (prefers-reduced-motion: reduce) {
    ${profileSearch}, ${profileRows} button, ${segmentedButton} { transition: none; }
  }
}
@media (forced-colors: active) {
  ${selectedProfile}, ${segmentedButton}[aria-pressed="true"] { outline: 1px solid Highlight; outline-offset: -1px; }
  ${profiles} :is(button, input):focus-visible,
  ${segmentedButton}:focus-visible { outline: 2px solid Highlight; outline-offset: -2px; }
}
`, { surface: '[data-overlay-surface], [data-slot="dialog-content"]' });
  mountCSS(ctx, "data-hcv-bot-rows", `
@media (forced-colors: none) {
  ${botRows} { border-radius: 8px; font-family: var(--hcv-ui-font); }
  ${botRows}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${botPane} { min-block-size: 0; background: var(--hcv-sidebar); }
  ${botPane} > :first-child {
    flex: none;
    min-block-size: 40px;
    padding: 6px 12px;
  }
  ${botPane} > :first-child > span:first-child {
    color: var(--hcv-muted);
    font: 600 13px/18px var(--hcv-ui-font);
    letter-spacing: normal;
    text-transform: none;
  }
  ${botPane} > [data-slot="bots-roster"] > div { padding-inline: 8px; }
  ${botLoading} {
    flex: none;
    min-block-size: 32px;
    justify-content: flex-start;
    gap: 8px;
    padding-inline: 12px;
    color: var(--hcv-muted);
    font: 400 12px/18px var(--hcv-ui-font);
  }
  ${botLoading}::after { content: 'Loading bots\u2026'; }
  ${botLoading}:lang(ru)::after { content: '\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0430 \u0431\u043E\u0442\u043E\u0432\u2026'; }
  @media (hover: hover) and (pointer: fine) {
    ${botRows}:hover { background: var(--hcv-hover); }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${botRows} {
      transition: background-color var(--hcv-enter-time) var(--hcv-ease), border-color var(--hcv-enter-time) var(--hcv-ease);
    }
  }
}
`, { surface: '[data-tree-tab="hermes-bots:pane"][aria-selected="true"], [data-slot="bots-section"], button[data-roster-key]' });
  mountCSS(ctx, "data-hcv-terminal-rail", `
@media (forced-colors: none) {
  ${terminalRail} { padding-block-start: 6px; }
}
`, { surface: '[data-tree-tab="terminal"][aria-selected="true"]' });
  mountCSS(ctx, "data-hcv-dialog-fields", `
@media (forced-colors: none) {
  ${dialog2} :is([data-slot="input"], [data-slot="textarea"], [data-slot="select-trigger"]) {
    border-color: var(--hcv-hairline);
    background: var(--hcv-form-surface);
  }
  ${dialog2} :is([data-slot="input"], [data-slot="select-trigger"]):not([type="file"]) { min-block-size: 32px; }
  ${dialog2} button:is([data-variant="outline"], [data-variant="secondary"]) { border-color: var(--hcv-hairline); }
  /* Codex's rounded-lg token is 10px at the standard 16px root size. */
  ${projectFolders} > ul > li:has(> .codicon-folder), ${addProjectFolder} {
    border-radius: var(--hcv-popup-button-radius);
  }
  @media (hover: hover) and (pointer: fine) {
    ${addProjectFolder}:hover:not(:disabled) { background-color: var(--hcv-hover-menu); color: var(--hcv-text); }
  }

  ${codexIconRules(`${dialog2} :is(.codicon-close, button[data-slot="dialog-close-button"] > svg.tabler-icon-x)`, "close")}
}
`, { surface: '[data-slot="dialog-content"]' });
}

// source/shell-surfaces.js
function registerShellSurfaces(ctx, active2) {
  const panel2 = `${active2} aside[class~="before:pointer-events-none"][class~="pt-(--titlebar-height)"]`;
  const overlay = `${active2} :is([data-narrow-overlay="files"], [data-narrow-overlay="review"])`;
  const panelEntrance = `:is(${panel2}:not([data-narrow-overlay] *), ${overlay})`;
  const collapsedFiles = '[data-tree-tab="files"][data-vertical]:only-child';
  const filesTrack = `${active2} [data-tree-split] > div:has(> [data-tree-group] > div > [role="tablist"] > ${collapsedFiles})`;
  const header2 = `${panel2} [class~="group/project-header"]`;
  const label3 = `${panel2} span:has(> .dither[aria-hidden="true"])`;
  const empty = `${panel2} > div:has(> button > .codicon-folder-opened)`;
  const openFolder = `${empty} > button`;
  const rows = `${panel2} :is([data-project-tree] [class~="group/row"], [class~="group/review-row"])`;
  const panelActions = `${panel2} :is([class~="group/project-header"], [class~="group/review-row"], [data-suppress-pane-reveal-side]) button[data-size="icon-xs"]`;
  const scopeRow = '[data-suppress-pane-reveal-side]:has(> div > button[aria-pressed]):has(> div > button[aria-haspopup="menu"])';
  const reviewScope = `${panel2} > ${scopeRow}`;
  const reviewHeader = `${panel2}:has(> ${scopeRow}) > [class~="group/project-header"]`;
  const reviewPicker = `${reviewScope} > div > button[aria-haspopup="menu"]`;
  const reviewFooter = `${panel2} > [data-suppress-pane-reveal-side]:has(> div > textarea):has(> div > button > span.underline)`;
  const askForPr = `${reviewFooter} > div > button:has(> span.underline)`;
  const previewToolbar = `${active2} .flex.h-full.flex-col.overflow-hidden.bg-transparent > .flex.h-7.shrink-0.items-center.justify-end.gap-3:has(> button.underline-offset-4, > div > button > :is(svg.tabler-icon-pencil, svg.tabler-icon-x))`;
  const previewActions = `:is(${previewToolbar} > button, ${previewToolbar} > div > button)`;
  const footer = `${active2} [data-slot="statusbar"]`;
  const statusActions = `:is(${footer} > div > :is(button, a[href]), ${footer} [data-slot="connection-switcher"] button[aria-haspopup="menu"])`;
  const profiles = `${active2} [data-slot="profile-rail"]`;
  const gateway = `${active2} [data-slot="dropdown-menu-content"]:has(> .text-sm > div > div > button > svg.tabler-icon-power)`;
  const gatewayTools = `${gateway} > .text-sm > .flex:first-child > div > button`;
  const layouts = `${active2} div[class~="w-[26rem]"][class~="z-50"]:has(> header h2):has(> div > div > section .grid-cols-4)`;
  const layoutCards = `${layouts} section :is(.grid > button[aria-pressed], [class~="group/preset"] > button:first-child)`;
  const layoutHandles = `${active2} [data-tree-group] > .cursor-grab.outline-dashed > span:has(> .codicon-gripper)`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvShellSurfaces = "";
  sheet.textContent = `
@media (forced-colors: none) {
  /* A solo Files rail should take no width when collapsed. The titlebar
     button still restores the native zone. Leave shared tab strips intact. */
  ${filesTrack} { display: none; }
  ${panel2} {
    background-color: var(--hcv-sidebar);
    border-color: var(--hcv-hairline);
    box-shadow: none;
    font-family: var(--hcv-ui-font);
  }
  ${panel2}.border-l { border-start-end-radius: 12px; }
  ${panel2}.border-r { border-start-start-radius: 12px; }
  ${overlay}.right-0 { border-start-start-radius: 12px; border-end-start-radius: 12px; }
  ${overlay}.left-0 { border-start-end-radius: 12px; border-end-end-radius: 12px; }
  ${header2} { block-size: 32px; gap: 2px; padding-inline: 12px 6px; }
  ${reviewHeader} { padding-inline: 8px; }
  ${reviewScope} { padding: 0 8px 4px; }
  ${reviewScope} > div:has(> button[aria-pressed]) { display: none; }
  ${reviewScope} > div:has(> button[aria-haspopup="menu"]) { display: flex; block-size: auto; padding: 0; }
  ${reviewPicker}, ${askForPr} {
    min-inline-size: 0;
    max-inline-size: 100%;
    block-size: ${codexReference.quietControl.height};
    border-radius: ${codexReference.quietControl.radius};
    color: var(--hcv-muted);
    font: 500 12px/16px var(--hcv-ui-font);
  }
  ${reviewPicker} { gap: 6px; padding-inline: 8px; }
  ${reviewPicker} > .codicon { flex: none; }
  ${codexIconRules(`${reviewPicker} > .codicon-chevron-down`, "down")}
  ${reviewFooter} { padding: 8px; gap: 4px; }
  ${askForPr} { padding-inline: 8px 28px; background-color: transparent; }
  ${askForPr} > span { text-decoration-line: none; }
  ${label3} {
    gap: 6px;
    padding-inline-start: 0;
    color: var(--hcv-muted);
    font-size: 12px;
    font-weight: 500;
    line-height: 16px;
    letter-spacing: normal;
    text-transform: none;
  }
  ${label3} > .dither { display: none; }
  ${label3} > span.leading-none { line-height: inherit; }
  ${empty} { gap: 10px; }
  ${empty} > span:has(> .dither) { font-size: 13px; }
  ${empty} > span > span.truncate { white-space: normal; }
  ${openFolder} {
    block-size: auto;
    min-block-size: 30px;
    max-inline-size: 100%;
    padding: 5px 12px;
    gap: 6px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 999px;
    background: var(--hcv-form-surface);
    color: var(--hcv-text);
    font-size: 12px;
    line-height: 16px;
    white-space: normal;
  }
  ${openFolder} > .codicon-folder-opened { flex: none; inline-size: 16px; block-size: 16px; }
  ${codexIconRules(`${openFolder} > .codicon-folder-opened`, "folderOpen")}
  ${rows} {
    margin-inline: 6px;
    border-radius: 8px;
    font-size: 12px;
  }
  ${rows}[aria-selected="true"] { background-color: var(--hcv-selected); color: var(--hcv-text); }
  ${panelActions} { border-radius: 7px; }
  ${codexIconRules(`${panel2} [data-project-tree] .codicon-folder`, "folder")}
  ${codexIconRules(`${panel2} [data-project-tree] .codicon-folder-opened`, "folderOpen")}

  ${previewToolbar} {
    block-size: auto;
    min-block-size: 32px;
    flex-wrap: wrap;
    padding: 3px 8px;
    gap: 2px;
    border-color: var(--hcv-hairline);
    font-family: var(--hcv-ui-font);
  }
  ${previewActions} {
    min-block-size: 24px;
    padding: 3px 7px;
    border-radius: 7px;
    font-size: 11px;
    font-weight: 500;
    line-height: 16px;
  }
  ${previewToolbar} > button.underline {
    background-color: var(--hcv-selected);
    color: var(--hcv-text);
    text-decoration: none;
  }
  ${codexIconRules(`${previewActions} > svg.tabler-icon-pencil`, "edit")}

  ${footer} {
    block-size: 26px;
    padding: 2px 6px;
    font-family: var(--hcv-ui-font);
  }
  ${statusActions} {
    border-radius: 7px;
    font-size: 11px;
    line-height: 16px;
  }
  ${statusActions}:is([aria-expanded="true"], [aria-pressed="true"], [data-state="open"]) {
    background-color: var(--hcv-selected);
    color: var(--hcv-text);
  }
  ${profiles} { font-family: var(--hcv-ui-font); }
  ${profiles} button { border-radius: 7px; }
  ${gateway} > .text-sm { font-family: var(--hcv-ui-font); }
  ${gateway} > .text-sm > .flex:first-child { padding: 10px 12px; gap: 8px; }
  ${gateway} > .text-sm > .flex:first-child > div:first-child { gap: 4px; font-size: 12px; line-height: 15px; }
  ${gateway} [class~="text-[0.62rem]"] {
    font-size: 11px;
    line-height: 16px;
    font-weight: 500;
    letter-spacing: normal;
    text-transform: none;
  }
  ${gatewayTools} { inline-size: 24px; block-size: 24px; border-radius: 7px; }
  ${codexIconRules(`${gatewayTools} > svg.tabler-icon-refresh:not(.animate-spin)`, "refresh")}
  ${codexIconRules(`${gatewayTools} > svg.tabler-icon-layout-dashboard`, "system")}

  ${layouts} {
    border-color: var(--hcv-hairline);
    border-radius: 16px;
    background: var(--hcv-menu);
    box-shadow: var(--hcv-menu-shadow);
    font-family: var(--hcv-ui-font);
  }
  ${layouts} > header h2 { font-size: 15px; line-height: 20px; }
  ${layouts} > header button, ${layouts} section button { border-radius: 8px; }
  ${layouts} section > span {
    font-size: 12px;
    font-weight: 500;
    letter-spacing: normal;
    text-transform: none;
  }
  ${layoutCards} { border-radius: var(--hcv-popup-button-radius); }
  ${layoutCards} > span { font-size: 11px; line-height: 15px; }
  ${layoutHandles} {
    gap: 6px;
    padding: 4px 10px;
    border-color: var(--hcv-hairline);
    border-radius: 999px;
    background: var(--hcv-menu);
    font: 500 12px/16px var(--hcv-ui-font);
    letter-spacing: normal;
    text-transform: none;
  }

  :is(${openFolder}, ${panelActions}, ${previewActions}, ${statusActions}, ${profiles} button, ${gatewayTools}, ${layouts} button, ${reviewPicker}, ${askForPr}):focus-visible {
    outline: 2px solid var(--hcv-focus);
    outline-offset: -2px;
  }
}
@media (forced-colors: none) and (hover: hover) {
  :is(${openFolder}, ${panelActions}, ${previewActions}:not(.bg-primary), ${statusActions}, ${gatewayTools}):hover:not(:disabled, [aria-disabled="true"]) {
    background-color: var(--hcv-hover-menu);
  }
  :is(${reviewPicker}, ${askForPr}):is(:hover, [data-state="open"]):not(:disabled) {
    background-color: var(--hcv-hover-menu);
    color: var(--hcv-text);
  }
  ${gatewayTools}:has(> svg.tabler-icon-power):hover { color: var(--destructive); }
  ${rows}:hover:not([aria-selected="true"]) { background-color: var(--hcv-hover); }
}
@media (forced-colors: none) and (prefers-reduced-motion: no-preference) {
  ${panelEntrance} {
    opacity: 1;
    translate: 0 0;
    transition: opacity ${codexReference.summaryTime} var(--hcv-enter), translate ${codexReference.summaryTime} var(--hcv-enter);
  }
  :is(${panel2}.border-r, ${overlay}.left-0) { --hcv-pane-enter-x: -8px; }
  ${layouts} {
    opacity: 1;
    scale: 1;
    transition: opacity var(--hcv-enter-time) var(--hcv-enter), scale var(--hcv-enter-time) var(--hcv-enter);
  }
  @starting-style {
    ${panelEntrance} { opacity: .2; translate: var(--hcv-pane-enter-x, 8px) 0; }
    ${layouts} { opacity: 0; scale: .98; }
  }
  :is(${openFolder}, ${statusActions}, ${gatewayTools}) {
    transition: background-color var(--hcv-enter-time) var(--hcv-ease), color var(--hcv-enter-time) var(--hcv-ease);
  }
}
`;
  mountStyle(ctx, sheet);
}

// source/session-tabs.js
import { createElement as h13, useRef as useRef7, useState as useState9 } from "react";
import {
  atom as atom6,
  Button as Button3,
  Dialog as Dialog3,
  DialogContent as DialogContent3,
  DialogDescription as DialogDescription3,
  DialogFooter as DialogFooter3,
  DialogHeader as DialogHeader3,
  DialogTitle as DialogTitle3,
  host as host18,
  Input as Input2,
  TITLEBAR_AREAS as TITLEBAR_AREAS5,
  useValue as useValue6
} from "@hermes/plugin-sdk";
var tilePrefix = "session-tile:";
var workspaceTab = '[role="tab"][data-tree-tab="workspace"]';
var chatTab2 = `${workspaceTab}, [role="tab"][data-tree-tab^="${tilePrefix}"]`;
var labelSelector2 = ".pane-tab-content .truncate";
var mainChatTab = `[data-zone-tabstrip="grp-main"] :is(${chatTab2}):has(> .pane-tab-content):not([data-vertical])`;
var draftLabels = /* @__PURE__ */ new Set(["New session", "Untitled session", "\u041D\u043E\u0432\u0430\u044F \u0441\u0435\u0441\u0441\u0438\u044F", "\u0421\u0435\u0430\u043D\u0441 \u0431\u0435\u0437 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044F"]);
var copy6 = {
  ru: {
    fresh: "\u041D\u043E\u0432\u044B\u0439 \u0447\u0430\u0442",
    title: "\u041F\u0435\u0440\u0435\u0438\u043C\u0435\u043D\u043E\u0432\u0430\u0442\u044C \u0447\u0430\u0442",
    hint: "\u041A\u0440\u0430\u0442\u043A\u043E \u0438 \u0443\u0437\u043D\u0430\u0432\u0430\u0435\u043C\u043E",
    input: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0447\u0430\u0442\u0430",
    placeholder: "\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435\u2026",
    cancel: "\u041E\u0442\u043C\u0435\u043D\u0430",
    save: "\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C",
    failed: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0439\u0442\u0435 \u0435\u0449\u0451 \u0440\u0430\u0437."
  },
  en: {
    fresh: "New chat",
    title: "Rename chat",
    hint: "Keep it short and recognizable",
    input: "Chat title",
    placeholder: "Add a title\u2026",
    cancel: "Cancel",
    save: "Save",
    failed: "Couldn\u2019t save the chat title. Try again."
  }
};
function tabSession(tab) {
  for (const dot of tab.querySelectorAll(".pane-tab-content span.rounded-full")) {
    for (let node3 = committedFiber(dot); node3; node3 = node3.return) {
      const props = node3.memoizedProps;
      if (props?.["data-tree-tab"]) break;
      if (props && "storedSessionId" in props && "session" in props) return props;
    }
  }
  return null;
}
function tabId(tab) {
  const pane = tab.dataset.treeTab;
  if (pane.startsWith(tilePrefix)) return pane.slice(tilePrefix.length);
  const session = tabSession(tab);
  if (session) return session.storedSessionId || null;
  for (let node3 = committedFiber(tab); node3; node3 = node3.return) {
    const props = node3.memoizedProps;
    if (props?.tabPaneId === "workspace" && props.storedSessionId) return props.storedSessionId;
  }
  return null;
}
function draftSubmit(tab) {
  const group2 = tab.closest("[data-tree-group]");
  const input = group2?.querySelector('[data-chat-surface][data-composer-target="main"] [data-slot="composer-rich-input"]');
  for (let node3 = committedFiber(input); node3; node3 = node3.return) {
    const props = node3.memoizedProps;
    if (typeof props?.onSubmit === "function" && "busy" in props && "cwd" in props) return props.onSubmit;
  }
  return null;
}
function RenameForm({ target, close: close2, save }) {
  const { words: words3 } = target;
  const [value, setValue] = useState9(target.title);
  const [saving, setSaving] = useState9(false);
  const [error, setError] = useState9(false);
  const input = useRef7(null);
  const pending = useRef7(false);
  const title = value.trim();
  const submit = async (event) => {
    event.preventDefault();
    if (!title || pending.current) return;
    if (title === target.title) return close2();
    pending.current = true;
    setSaving(true);
    setError(false);
    try {
      await save(target, title);
      close2();
    } catch {
      setError(true);
    } finally {
      pending.current = false;
      setSaving(false);
    }
  };
  return h13(
    Dialog3,
    { open: true, onOpenChange: (open) => {
      if (!open && !pending.current) close2();
    } },
    h13(
      DialogContent3,
      {
        "data-hcv-rename-chat": "",
        bodyClassName: "hcv-rename-body",
        blurBackdrop: false,
        overlayClassName: "hcv-rename-overlay",
        showCloseButton: !saving,
        onOpenAutoFocus: (event) => {
          event.preventDefault();
          input.current?.focus();
          input.current?.select();
        },
        onCloseAutoFocus: (event) => {
          event.preventDefault();
          if (target.tab.isConnected) target.tab.focus({ preventScroll: true });
        }
      },
      h13(
        "form",
        { onSubmit: submit },
        h13(DialogHeader3, null, h13(DialogTitle3, null, words3.title), h13(DialogDescription3, null, words3.hint)),
        h13(Input2, {
          ref: input,
          "aria-label": words3.input,
          placeholder: words3.placeholder,
          value,
          disabled: saving,
          onChange: (event) => setValue(event.target.value),
          onKeyDown: (event) => {
            if (event.key === "Enter" && (event.nativeEvent.isComposing || event.keyCode === 229)) event.preventDefault();
          }
        }),
        error && h13("p", { role: "alert", className: "hcv-rename-error" }, words3.failed),
        h13(
          DialogFooter3,
          null,
          h13(Button3, { type: "button", variant: "outline", disabled: saving, onClick: close2 }, words3.cancel),
          h13(Button3, { type: "submit", disabled: saving || !title }, words3.save)
        )
      )
    )
  );
}
function RenameSlot({ model, close: close2, save }) {
  const target = useValue6(model);
  return target && h13(RenameForm, { key: target.key, target, close: close2, save });
}
function sessionTabStyles(active2) {
  const dialog2 = `${active2} [data-hcv-rename-chat]`;
  const close2 = `${dialog2} [data-slot="dialog-close-button"]`;
  const tab = `${active2} ${mainChatTab}`;
  return `
@media (forced-colors: none) {
  /* PaneTab's usual 12rem maximum, reduced by a quarter for chat tabs. */
  ${tab} { max-inline-size: 9rem; }
  /* Keep the native draft label and its spacing, but do not paint its dot. */
  ${tab} .pane-tab-content span.rounded-full[class~="border-(--ui-text-quaternary)"]:not([role="status"]) { opacity: 0; }
  ${tab} .pane-tab-content span[aria-hidden="true"][class~="size-1"][class~="rounded-full"] { display: none; }
  ${tab} .pane-tab-content [role="status"]:is([class~="bg-(--ui-accent)"], [class~="border-(--ui-accent)"]) {
    position: absolute;
    inline-size: 1px;
    block-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
  }
  ${fadingTitleStyles(`${tab} ${labelSelector2}`, "1rem")}
  ${active2} .hcv-rename-overlay { background: rgb(0 0 0 / 25%); backdrop-filter: none; }
  ${dialog2} {
    inline-size: min(420px, calc(100vw - 32px));
    max-inline-size: none;
    border: 0;
    border-radius: 16px;
    background: var(--hcv-menu);
    color: var(--hcv-text);
    font-family: var(--hcv-ui-font);
  }
  ${dialog2} .hcv-rename-body { padding: 20px; }
  ${dialog2} form { display: flex; flex-direction: column; gap: 12px; }
  ${dialog2} [data-slot="dialog-header"] { gap: 4px; padding-inline-end: 24px; text-align: start; }
  ${dialog2} [data-slot="dialog-title"] { font-size: 20px; font-weight: 600; line-height: 26px; }
  ${dialog2} [data-slot="dialog-description"] { color: var(--hcv-muted); font-size: 14px; line-height: 20px; }
  ${dialog2} input[data-slot="input"] {
    block-size: 36px;
    padding: 0 10px;
    border: 1px solid var(--hcv-hairline);
    border-radius: 8px;
    background: transparent;
    color: var(--hcv-text);
    box-shadow: none;
    font: 13px/18px var(--hcv-ui-font);
  }
  ${dialog2} input[data-slot="input"]:focus {
    border-color: #339cffb3;
    outline: none;
    box-shadow: none;
  }
  ${dialog2} input[data-slot="input"]::selection {
    background: light-dark(#c3ddf0, #42586a);
    color: var(--hcv-text);
  }
  ${dialog2} [data-slot="dialog-footer"] { flex-flow: row wrap; justify-content: flex-end; gap: 12px; }
  ${dialog2} [data-slot="dialog-footer"] button {
    min-block-size: 32px;
    block-size: auto;
    padding: 5px 16px;
    border-radius: 10px;
    font: 400 14px/20px var(--hcv-ui-font);
  }
  ${dialog2} button[type="submit"] { background: var(--hcv-action); color: var(--hcv-ink); }
  ${dialog2} button[data-variant="outline"] {
    border: 1px solid var(--hcv-hairline);
    background: color-mix(in srgb, var(--hcv-text) 4%, var(--hcv-menu));
    color: var(--hcv-text);
  }
  ${close2} { inset-block-start: 16px; inset-inline-end: 16px; inline-size: 24px; block-size: 24px; border-radius: 8px; }
  ${codexIconRules(`${close2} > svg`, "close")}
  ${dialog2} .hcv-rename-error { margin: 0; color: var(--dt-destructive); font-size: 13px; }
}
`;
}
function registerSessionTabs(ctx, active2) {
  const root = document.documentElement;
  const model = atom6(null);
  const translated = /* @__PURE__ */ new Map();
  const named = /* @__PURE__ */ new Map();
  const measureTitles = trackTitleOverflow();
  const sessions = new BroadcastChannel("hermes:sessions");
  let requestKey = 0;
  let frame = 0;
  let disposed = false;
  const words3 = () => root.matches(":lang(ru)") ? copy6.ru : copy6.en;
  const close2 = () => model.set(null);
  const enabled = () => !disposed && root.matches(active2);
  const restore = (text, entry) => {
    if (text.data === entry.shown) text.data = entry.original;
    if (entry.label.title === entry.shown) entry.label.title = entry.tooltip;
    translated.delete(text);
  };
  const labels12 = () => {
    frame = 0;
    for (const [text, entry] of translated) {
      if (!enabled() || !text.isConnected || text.data !== entry.shown) restore(text, entry);
    }
    if (!enabled()) return measureTitles();
    const openIds = /* @__PURE__ */ new Set();
    const mainLabels = [];
    for (const tab of document.querySelectorAll(chatTab2)) {
      const id2 = tabId(tab);
      openIds.add(id2);
      const label3 = tab.querySelector(labelSelector2);
      if (label3 && tab.matches(mainChatTab)) mainLabels.push(label3);
      const text = label3?.childNodes.length === 1 ? label3.firstChild : null;
      if (!(text instanceof Text)) continue;
      const row5 = tabSession(tab)?.session;
      const nativeTitle = row5?.title?.trim() || "";
      if (nativeTitle && translated.get(text)?.shown === nativeTitle) translated.delete(text);
      const previous = translated.get(text);
      const original = previous?.original ?? text.data;
      const renamed = named.get(id2);
      if (renamed && (row5?.connection_id && row5.connection_id !== renamed.owner.connectionId || row5?.profile && row5.profile !== renamed.owner.profile || original === renamed.title || nativeTitle && nativeTitle !== renamed.previous)) named.delete(id2);
      const saved = named.get(id2)?.title;
      const shown = saved ? saved : draftLabels.has(original) && !row5?.title?.trim() && !row5?.preview?.trim() ? words3().fresh : original;
      if (previous?.shown === shown) continue;
      if (previous) restore(text, previous);
      if (shown === original) continue;
      translated.set(text, { original, shown, label: label3, tooltip: label3.title });
      if (label3.title === original) label3.title = shown;
      text.data = shown;
    }
    measureTitles(mainLabels);
    for (const id2 of named.keys()) if (!openIds.has(id2)) named.delete(id2);
  };
  const schedule = () => {
    frame ||= requestAnimationFrame(labels12);
  };
  const sheet = document.createElement("style");
  sheet.dataset.hcvSessionTabs = "";
  sheet.textContent = sessionTabStyles(active2);
  mountStyle(ctx, sheet);
  const observer = new MutationObserver((changes2) => {
    if (!enabled()) return;
    if (changes2.some(({ target, addedNodes }) => {
      const element7 = target instanceof Element ? target : target.parentElement;
      return element7?.closest("[data-zone-tabstrip]") || [...addedNodes].some((node3) => node3 instanceof Element && (node3.matches(chatTab2) || node3.querySelector(chatTab2)));
    })) schedule();
  });
  const themeObserver = new MutationObserver(() => {
    if (!enabled()) close2();
    schedule();
  });
  themeObserver.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  observer.observe(document.body, { subtree: true, childList: true, characterData: true });
  async function save(target, title) {
    if (!enabled() || !target.tab.isConnected || tabId(target.tab) !== target.id) throw new Error("Chat changed");
    const owner = target.owner;
    if (!owner?.connectionId || !owner.profile) throw new Error("Chat owner unavailable");
    const api = (id3, options) => window.hermesDesktop.api({
      connectionId: owner.connectionId,
      profile: owner.profile,
      path: `/api/sessions/${encodeURIComponent(id3)}`,
      ...options
    });
    const previous = tabSession(target.tab)?.session?.title?.trim() || "";
    let id2 = target.id;
    let finalTitle = title;
    if (id2) {
      try {
        const result = await api(id2, { method: "PATCH", body: { title, profile: owner.profile } });
        if (!result?.ok) throw new Error("Title not saved");
        finalTitle = result.title || title;
      } catch (error) {
        if (!target.runtime) throw error;
        const result = await host18.requestProfile({ ...owner, targetProfile: owner.profile }, "session.title", {
          session_id: target.runtime,
          title
        });
        finalTitle = result?.title || title;
      }
    } else {
      const submit = draftSubmit(target.tab);
      if (!submit || host18.state.focusedStoredSessionId.get() || host18.state.focusedSessionId.get()) {
        throw new Error("New chat not ready");
      }
      window.dispatchEvent(new CustomEvent("hermes:composer-draft-sync", {
        detail: { mode: "flush", target: "main" }
      }));
      const draft = await host18.composer.getDraft("new");
      await submit(`/title ${title}`, { attachments: [], displayKind: "hidden" });
      const workspace = document.querySelector(workspaceTab);
      id2 = workspace && tabId(workspace);
      if (!id2 || id2 !== host18.state.focusedStoredSessionId.get()) throw new Error("Chat changed");
      const retained = await host18.composer.getDraft(id2);
      if (draft && !retained && !await host18.composer.setDraft(id2, draft)) throw new Error("Draft not restored");
      if ((await api(id2)).title !== title) throw new Error("Title not saved");
    }
    named.set(id2, { title: finalTitle, previous, owner });
    if (!disposed) {
      sessions.postMessage(1);
      schedule();
    }
  }
  ctx.register({
    id: "chat-tab-rename",
    area: TITLEBAR_AREAS5.center,
    render: () => h13(RenameSlot, { model, close: close2, save })
  });
  ctx.addEventListener(document, "dblclick", (event) => {
    if (!enabled() || event.button !== 0 || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    const origin = event.target instanceof Element ? event.target : event.target?.parentElement;
    const tab = origin?.closest(chatTab2);
    if (!tab || model.get() || !tab.closest("[data-zone-tabstrip]")) return;
    const control4 = origin.closest('button, a, input, [role="button"]');
    if (control4 && control4 !== tab) return;
    event.preventDefault();
    event.stopPropagation();
    const id2 = tabId(tab);
    const label3 = tab.querySelector(labelSelector2);
    const translation = translated.get(label3?.firstChild);
    const title = translation && draftLabels.has(translation.original) && !named.has(id2) ? "" : label3?.textContent.trim() || "";
    const focused = id2 === host18.state.focusedStoredSessionId.get();
    const row5 = tabSession(tab)?.session;
    const owner = focused ? host18.state.focusedSessionOwner.get() : row5?.connection_id && { connectionId: row5.connection_id, profile: row5.profile || "default" };
    if (!owner) return;
    model.set({
      key: ++requestKey,
      tab,
      id: id2,
      title,
      words: words3(),
      owner,
      runtime: focused ? host18.state.focusedSessionId.get() : null
    });
  }, true);
  schedule();
  ctx.onDispose(() => {
    disposed = true;
    close2();
    observer.disconnect();
    themeObserver.disconnect();
    cancelAnimationFrame(frame);
    labels12();
    sessions.close();
    sheet.remove();
  });
}

// source/context-meter.js
import { Tip as Tip2, host as host19, useI18n as useI18n6, useValue as useValue7 } from "@hermes/plugin-sdk";
import { createElement as h14, useCallback, useEffect as useEffect8, useState as useState10 } from "react";
function readContext(usage) {
  const used = usage?.context_used;
  const max = usage?.context_max;
  if (!Number.isFinite(used) || used < 0 || !Number.isFinite(max) || max <= 0) return null;
  return { used: Math.min(used, max), max, estimated: usage.context_estimated === true };
}
var modelName = (value) => String(value ?? "").toLowerCase().split("/").at(-1);
function useContext(inMainComposer) {
  const session = useValue7(host19.state.focusedSessionId);
  const owner = useValue7(host19.state.focusedSessionOwner);
  const primary4 = useValue7(host19.state.activeSessionId);
  const profile2 = useValue7(host19.state.profile) || "default";
  const connection = useValue7(host19.state.connectionId);
  const model = useValue7(host19.state.model);
  const busy = useValue7(host19.state.busy);
  const gateway = useValue7(host19.state.gateway);
  const usage = useValue7(host19.state.focusedUsage);
  const [snapshot, setSnapshot] = useState10(null);
  const sameGateway = !owner || owner.profile === profile2 && (!connection || owner.connectionId === connection);
  const key = inMainComposer && session && session === primary4 && sameGateway ? JSON.stringify([owner?.connectionId ?? connection, profile2, session, model]) : null;
  useEffect8(() => {
    if (!key || busy || gateway !== "open") return;
    const socket = host19.getGateway();
    if (!socket) return;
    let request = 0;
    const refresh = () => {
      const current = ++request;
      void socket.request("session.context_breakdown", { session_id: session }).then((data) => {
        if (current !== request || host19.getGateway() !== socket) return;
        if (model && data?.model && modelName(model) !== modelName(data.model)) return;
        setSnapshot({ key, context: readContext(data), seenUsage: host19.state.focusedUsage.get() });
      }).catch(() => {
      });
    };
    const unsubscribe = socket.onEvent((event) => {
      if (event.type === "session.info" && event.session_id === session && !event.payload?.running) refresh();
    });
    refresh();
    return () => {
      request++;
      unsubscribe();
    };
  }, [key, session, model, busy, gateway]);
  if (!key || gateway !== "open" || snapshot?.key !== key || !snapshot.context) return null;
  const context = snapshot.context;
  const liveModelMatches = !model || !usage?.model || modelName(model) === modelName(usage.model);
  const live = usage !== snapshot.seenUsage && liveModelMatches ? readContext(usage) : null;
  return live?.max === context.max ? live : context;
}
var numbers2 = { ru: new Intl.NumberFormat("ru-RU"), en: new Intl.NumberFormat("en-US") };
function ContextReadout({ context }) {
  const { locale } = useI18n6();
  const ru = locale?.toLowerCase().startsWith("ru");
  const thousands = (tokens) => numbers2[ru ? "ru" : "en"].format(Math.round(tokens / 1e3));
  const percent = context.used / context.max * 100;
  const whole = Math.round(percent);
  const full = whole >= 50;
  const detail = ru ? full ? `${whole}% \u0437\u0430\u043F\u043E\u043B\u043D\u0435\u043D\u043E` : `${whole}% \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E (\u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C ${100 - whole}%)` : full ? `${whole}% full` : `${whole}% used (${100 - whole}% left)`;
  const used = `${context.estimated ? "\u2248" : ""}${thousands(context.used)}`;
  const label3 = h14(
    "div",
    { "data-hcv-context-detail": "" },
    h14("span", { "data-muted": "" }, ru ? "\u041A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u043D\u043E\u0435 \u043E\u043A\u043D\u043E:" : "Context window:"),
    h14("span", full ? { "data-muted": "" } : null, detail),
    h14("span", null, ru ? `\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u043E ${used} \u043A / ${thousands(context.max)} \u043A \u0442\u043E\u043A\u0435\u043D\u043E\u0432` : `Used ${used}k / ${thousands(context.max)}k tokens`)
  );
  const circle = { cx: 6, cy: 6, r: 5, stroke: "currentColor", strokeWidth: 2, fill: "none" };
  const ring = h14(
    "svg",
    { width: 12, height: 12, viewBox: "0 0 12 12", "aria-hidden": true },
    h14("circle", { ...circle, opacity: 0.16 }),
    h14("circle", {
      ...circle,
      "data-hcv-context-arc": "",
      opacity: Number(percent !== 0),
      strokeLinecap: "round",
      pathLength: 100,
      strokeDasharray: 100,
      strokeDashoffset: 100 - percent,
      transform: "rotate(-90 6 6)"
    })
  );
  return h14(
    Tip2,
    { label: label3, side: "top", align: "center", sideOffset: 4, "data-hcv-context-tip": "" },
    h14("span", {
      "data-hcv-context-meter": "",
      role: "img",
      tabIndex: 0,
      "aria-label": ru ? `\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u043D\u0438\u0435 \u043A\u043E\u043D\u0442\u0435\u043A\u0441\u0442\u0430: ${whole}%` : `Context usage: ${whole}%`
    }, ring)
  );
}
function ContextMeter() {
  const [inMainComposer, setInMainComposer] = useState10(false);
  const locate = useCallback((node3) => {
    const composer2 = node3?.closest('[data-slot="composer-surface"]');
    setInMainComposer(Boolean(composer2?.querySelector('[data-tour="model-pill"]')));
  }, []);
  const context = useContext(inMainComposer);
  return h14(
    "span",
    { "data-hcv-context-anchor": "", ref: locate },
    context ? h14(ContextReadout, { context }) : null
  );
}
function registerContextMeter(ctx, active2) {
  const root = document.documentElement;
  const sheet = document.createElement("style");
  sheet.textContent = `
    ${active2} [data-hcv-context-anchor] { display: contents; }
    ${active2} [data-hcv-context-meter] {
      display: inline-grid;
      place-items: center;
      flex: none;
      inline-size: 24px;
      block-size: 24px;
      color: var(--hcv-muted);
      border-radius: 6px;
    }
    ${active2} [data-hcv-context-meter]:focus-visible {
      outline: 2px solid var(--hcv-focus);
      outline-offset: -2px;
    }
    ${active2} [data-hcv-context-arc] {
      transition: stroke-dashoffset 120ms ease-out, opacity 120ms ease-out;
    }
    ${active2} [data-hcv-context-detail] {
      display: flex;
      flex-direction: column;
      gap: 2px;
      inline-size: min(152px, calc(100vw - 50px));
      text-align: center;
      font-variant-numeric: tabular-nums;
    }
    ${active2} [data-hcv-context-detail] [data-muted] { opacity: .6; }
    ${active2} [data-hcv-context-tip] span:has(> [data-slot="tooltip-arrow"]) { display: none; }
    @media (prefers-reduced-motion: reduce) {
      ${active2} [data-hcv-context-arc] { transition: none; }
    }
  `;
  mountStyle(ctx, sheet, chatStyles);
  let remove;
  const update = () => {
    if (root.matches(active2)) {
      remove ??= ctx.register({
        id: "context-meter",
        area: "composer.actions",
        order: 110,
        render: () => h14(ContextMeter)
      });
    } else if (remove) {
      remove();
      remove = void 0;
    }
  };
  const observer = new MutationObserver(update);
  observer.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.onDispose(() => {
    observer.disconnect();
    remove?.();
    sheet.remove();
  });
  update();
}

// source/composer.js
import { host as host23 } from "@hermes/plugin-sdk";

// source/queue.js
import { useI18n as useI18n7 } from "@hermes/plugin-sdk";
import { createElement as h15, useLayoutEffect as useLayoutEffect3, useRef as useRef8 } from "react";

// source/queue-order.js
import { host as host20 } from "@hermes/plugin-sdk";
var storageKey = "hermes.desktop.composerQueue.v1";
var dragType = "application/x-hcv-queued-prompt";
var rowSelector3 = '[data-slot="status-row"]';
var gripSelector = "[data-hcv-queue-grip]";
var editing = '[data-slot="composer-surface"] [class~="bg-accent/18"]:has(> div > button + button)';
function queueIdentity(dock2, panel2) {
  const state = host20.state;
  const runtime = state.focusedSessionId.get();
  const stored = state.focusedStoredSessionId.get();
  const primary4 = dock2.querySelector('form[data-tour="composer"]');
  const target = dock2.closest("[data-floating-composer-target]")?.dataset.floatingComposerTarget ?? dock2.closest("[data-composer-target]")?.dataset.composerTarget;
  const focused = primary4 ? runtime === state.activeSessionId.get() : stored && target === `tile:${stored}`;
  const parked = panel2.querySelector(".status-section-icon > .codicon-debug-pause");
  if (!runtime || !focused || !state.busy.get() && !parked || dock2.querySelector(editing)) return null;
  const owner = state.focusedSessionOwner.get();
  return {
    keys: [...new Set([stored, runtime].filter(Boolean))],
    scope: JSON.stringify([owner?.connectionId ?? state.connectionId.get(), owner?.profile ?? state.profile.get(), stored, runtime])
  };
}
function readQueue(dock2, panel2, copy7) {
  const identity = queueIdentity(dock2, panel2);
  const rows = Array.from(panel2.querySelectorAll(`:scope > .status-section-body > ${rowSelector3}`));
  if (!identity || rows.length < 2) return null;
  try {
    const raw = localStorage.getItem(storageKey);
    const queues = JSON.parse(raw);
    if (!queues || typeof queues !== "object" || Array.isArray(queues)) return null;
    const matching = identity.keys.filter((key2) => {
      if (!Object.hasOwn(queues, key2)) return false;
      const entries2 = queues[key2];
      return Array.isArray(entries2) && entries2.length === rows.length && entries2.every((entry, index) => {
        if (typeof entry?.id !== "string" || typeof entry.text !== "string" || !Array.isArray(entry.attachments)) return false;
        if (entry.serverStatus != null) return false;
        const caption2 = entry.displayKind === "hidden" ? copy7.hiddenQueued : (entry.displayText ?? entry.text).trim() || (entry.attachments.length ? copy7.attachmentOnly : copy7.emptyTurn);
        return rows[index].querySelector(".status-row-content p")?.textContent === caption2;
      });
    });
    if (matching.length !== 1) return null;
    const key = matching[0];
    const entries = queues[key];
    const ids = entries.map((entry) => entry.id);
    if (new Set(ids).size !== ids.length) return null;
    return { scope: identity.scope, key, entries, ids, rows, queues, raw };
  } catch {
    return null;
  }
}
function sameQueue(before, after) {
  return after && before.scope === after.scope && before.key === after.key && before.ids.length === after.ids.length && before.ids.every((id2, index) => id2 === after.ids[index] && before.rows[index] === after.rows[index]);
}
function saveOrder(snapshot, from, to) {
  if (from === to || from < 0 || to < 0 || Math.max(from, to) >= snapshot.ids.length) return false;
  const entries = snapshot.entries.slice();
  const [entry] = entries.splice(from, 1);
  entries.splice(to, 0, entry);
  try {
    if (localStorage.getItem(storageKey) !== snapshot.raw) return false;
    localStorage.setItem(storageKey, JSON.stringify({ ...snapshot.queues, [snapshot.key]: entries }));
  } catch {
    return false;
  }
  window.dispatchEvent(new StorageEvent("storage", { key: storageKey, storageArea: localStorage }));
  return true;
}
function bindQueueOrder(dock2, panel2, t, copy7) {
  const events = new AbortController();
  const options = { signal: events.signal };
  const announcement = document.createElement("span");
  announcement.className = "sr-only";
  announcement.setAttribute("role", "status");
  panel2.append(announcement);
  let drag;
  let marker4;
  const sync = () => {
    const snapshot = readQueue(dock2, panel2, copy7);
    panel2.toggleAttribute("data-hcv-queue-reorder", Boolean(snapshot));
    if (drag && !sameQueue(drag.snapshot, snapshot)) clearDrag();
  };
  const clearMarker = () => {
    marker4?.removeAttribute("data-hcv-queue-drop");
    marker4 = void 0;
  };
  const clearDrag = () => {
    clearMarker();
    drag?.element.removeAttribute("data-hcv-queue-dragging");
    drag = void 0;
  };
  const move = (before, from, to) => {
    const current = readQueue(dock2, panel2, copy7);
    if (!sameQueue(before, current) || !saveOrder(current, from, to)) return false;
    announcement.textContent = t("queueMoved", to + 1, current.ids.length);
    return true;
  };
  const gripOf = (event) => event.target instanceof Element ? event.target.closest(gripSelector) : null;
  const rowOf = (event) => event.target instanceof Element ? event.target.closest(rowSelector3) : null;
  panel2.addEventListener("dragstart", (event) => {
    if (!gripOf(event) || !event.dataTransfer) return;
    const snapshot = readQueue(dock2, panel2, copy7);
    const element7 = rowOf(event);
    const index = snapshot?.rows.indexOf(element7) ?? -1;
    if (index < 0) {
      event.preventDefault();
      return;
    }
    drag = { snapshot, element: element7, index };
    event.dataTransfer.setData(dragType, "queued");
    event.dataTransfer.effectAllowed = "move";
    const bounds = element7.getBoundingClientRect();
    event.dataTransfer.setDragImage(element7, event.clientX - bounds.left, event.clientY - bounds.top);
    element7.dataset.hcvQueueDragging = "";
    event.stopPropagation();
  }, options);
  panel2.addEventListener("dragover", (event) => {
    if (!drag || !event.dataTransfer?.types.includes(dragType)) return;
    const target = rowOf(event);
    if (!drag.snapshot.rows.includes(target)) {
      clearMarker();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    event.dataTransfer.dropEffect = "move";
    if (marker4 !== target) clearMarker();
    marker4 = target;
    const box = target.getBoundingClientRect();
    target.dataset.hcvQueueDrop = event.clientY >= box.top + box.height / 2 ? "after" : "before";
  }, options);
  panel2.addEventListener("drop", (event) => {
    if (!drag || !event.dataTransfer?.types.includes(dragType)) return;
    event.preventDefault();
    event.stopPropagation();
    const { snapshot, index } = drag;
    const target = rowOf(event);
    const at = snapshot.rows.indexOf(target);
    if (at >= 0) {
      const box = target.getBoundingClientRect();
      const boundary = at + Number(event.clientY >= box.top + box.height / 2);
      move(snapshot, index, boundary - Number(boundary > index));
    }
    clearDrag();
  }, options);
  panel2.addEventListener("dragend", clearDrag, options);
  panel2.addEventListener("dragleave", (event) => {
    if (!(event.relatedTarget instanceof Node) || !panel2.contains(event.relatedTarget)) clearMarker();
  }, options);
  panel2.addEventListener("keydown", (event) => {
    const grip = gripOf(event);
    if (!grip || !["ArrowUp", "ArrowDown"].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    const snapshot = readQueue(dock2, panel2, copy7);
    const index = snapshot?.rows.indexOf(rowOf(event)) ?? -1;
    if (index < 0 || !move(snapshot, index, index + (event.key === "ArrowUp" ? -1 : 1))) return;
    requestAnimationFrame(() => {
      if (grip.isConnected && document.activeElement === document.body) grip.focus();
    });
  }, options);
  const release = [
    host20.state.busy,
    host20.state.focusedSessionId,
    host20.state.focusedStoredSessionId
  ].map((state) => state.listen(sync));
  return {
    add(actions) {
      const grip = document.createElement("button");
      grip.type = "button";
      grip.draggable = true;
      grip.dataset.hcvQueueGrip = "";
      grip.setAttribute("aria-label", t("queueMove"));
      grip.title = t("queueMove");
      actions.parentElement.append(grip);
      return () => grip.remove();
    },
    sync,
    dispose() {
      events.abort();
      release.forEach((stop) => stop());
      clearDrag();
      panel2.removeAttribute("data-hcv-queue-reorder");
      announcement.remove();
    }
  };
}

// source/queue.js
var stack2 = '[data-slot="composer-status-stack"]';
var section = '[data-slot="status-section"]';
var row4 = '[data-slot="status-row"]';
var edit2 = "button:has(> svg.tabler-icon-pencil)";
var steer = "button:has(> svg.tabler-icon-steering-wheel)";
var send = "button:has(> svg.tabler-icon-corner-down-left)";
var modeKey = "queueFollowUps";
function menuButton(icon8) {
  const button5 = document.createElement("button");
  button5.type = "button";
  button5.style.setProperty("--hcv-queue-icon", codexMask(icon8));
  return button5;
}
function rowMenu(actions, ctx, queueing) {
  const { t } = ctx.i18n;
  const trigger = menuButton("queueMore");
  trigger.dataset.hcvQueueMore = "";
  trigger.setAttribute("aria-label", t("queueActions"));
  trigger.setAttribute("aria-haspopup", "menu");
  trigger.setAttribute("aria-expanded", "false");
  const popup = document.createElement("div");
  popup.popover = "auto";
  popup.dataset.hcvQueueMenu = "";
  popup.setAttribute("role", "menu");
  popup.setAttribute("aria-label", t("queueActions"));
  const item = (icon8, run) => {
    const button5 = menuButton(icon8);
    button5.setAttribute("role", "menuitem");
    button5.tabIndex = -1;
    button5.addEventListener("click", () => {
      popup.hidePopover();
      run();
    });
    popup.append(button5);
    return button5;
  };
  const editItem = item("queueEdit", () => actions.querySelector(edit2)?.click());
  const sendItem = item("queueSteer", () => actions.querySelector(send)?.click());
  const modeItem = item("queueFollowUp", () => ctx.storage.set(modeKey, !queueing()));
  const items2 = () => Array.from(popup.querySelectorAll("button:not([hidden], :disabled)"));
  trigger.popoverTargetElement = popup;
  popup.addEventListener("beforetoggle", (event) => {
    const opening = event.newState === "open";
    trigger.setAttribute("aria-expanded", String(opening));
    if (!opening) return;
    const editButton = actions.querySelector(edit2);
    const sendButton = actions.querySelector(send);
    editItem.textContent = t("queueEdit");
    editItem.disabled = !editButton || editButton.disabled;
    sendItem.textContent = t("queueNext");
    sendItem.hidden = !sendButton || !actions.querySelector(steer);
    sendItem.disabled = !sendButton || sendButton.disabled;
    modeItem.textContent = t(queueing() ? "queueOff" : "queueOn");
    const rect = trigger.getBoundingClientRect();
    const maxHeight = 92;
    popup.style.right = Math.max(8, window.innerWidth - rect.right) + "px";
    const below = rect.bottom + maxHeight + 8 < window.innerHeight;
    popup.style.top = below ? rect.bottom + 4 + "px" : "auto";
    popup.style.bottom = below ? "auto" : window.innerHeight - rect.top + 4 + "px";
  });
  popup.addEventListener("toggle", (event) => {
    if (event.newState === "open") items2()[0]?.focus({ preventScroll: true });
  });
  trigger.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      if (!popup.matches(":popover-open")) trigger.click();
      else items2()[0]?.focus();
    }
  });
  popup.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      popup.hidePopover();
      trigger.focus();
      return;
    }
    const buttons = items2();
    const current = buttons.indexOf(document.activeElement);
    const last = buttons.length - 1;
    if (last < 0) return;
    let index;
    switch (event.key) {
      case "ArrowDown":
        index = (current + 1) % buttons.length;
        break;
      case "ArrowUp":
        index = current <= 0 ? last : current - 1;
        break;
      case "Home":
        index = 0;
        break;
      case "End":
        index = last;
        break;
      default:
        return;
    }
    event.preventDefault();
    buttons[index].focus();
  });
  actions.append(trigger, popup);
  return () => {
    trigger.remove();
    popup.remove();
  };
}
function QueueSurface({ ctx, queueing }) {
  const anchor = useRef8(null);
  const { locale, t: { composer: copy7 } } = useI18n7();
  useLayoutEffect3(() => {
    const dock2 = anchor.current?.closest('[data-slot="composer-dock"]');
    if (!dock2) return;
    const menus2 = /* @__PURE__ */ new Map();
    let current;
    let ordering;
    let expandedByPlugin = false;
    const cleanSection = () => {
      for (const dispose of menus2.values()) dispose();
      menus2.clear();
      ordering?.dispose();
      ordering = void 0;
      if (!current) return;
      current.removeAttribute("data-hcv-queue");
      current.removeAttribute("aria-label");
      current.removeAttribute("role");
      current.style.removeProperty("--hcv-queue-steer-label");
      if (expandedByPlugin && current.isConnected) {
        current.querySelector('.status-section-trigger[aria-expanded="true"]')?.click();
      }
      expandedByPlugin = false;
    };
    const sync = () => {
      const icon8 = dock2.querySelector(stack2 + " .status-section-trigger > .status-section-icon > :is(.codicon-layers, .codicon-debug-pause)");
      const panel2 = icon8?.closest(section);
      if (panel2 !== current) {
        cleanSection();
        current = panel2;
        if (panel2) ordering = bindQueueOrder(dock2, panel2, ctx.i18n.t, copy7);
      }
      if (!panel2) return;
      if (!panel2.hasAttribute("data-hcv-queue")) {
        panel2.dataset.hcvQueue = "";
        panel2.setAttribute("role", "group");
        panel2.setAttribute("aria-label", ctx.i18n.t("queueLabel"));
        panel2.style.setProperty("--hcv-queue-steer-label", JSON.stringify(ctx.i18n.t("queueSteer")));
      }
      const collapsed = panel2.querySelector('.status-section-trigger[aria-expanded="false"]');
      if (collapsed && !panel2.closest("[inert]")) {
        expandedByPlugin = true;
        collapsed.click();
      }
      const live = new Set(panel2.querySelectorAll(".status-section-body > " + row4 + " > .status-row-actions"));
      for (const [actions, dispose] of menus2) {
        if (!live.has(actions)) {
          dispose();
          menus2.delete(actions);
        }
      }
      for (const actions of live) {
        if (menus2.has(actions)) continue;
        const removeMenu = rowMenu(actions, ctx, queueing);
        const removeGrip = ordering.add(actions);
        menus2.set(actions, () => {
          removeMenu();
          removeGrip();
        });
      }
      ordering.sync();
    };
    const observer = new MutationObserver(sync);
    observer.observe(dock2, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["aria-expanded", "inert"]
    });
    sync();
    return () => {
      observer.disconnect();
      cleanSection();
    };
  }, [ctx, locale, copy7, queueing]);
  return h15("span", { ref: anchor, hidden: true });
}
function queueStyles(active2) {
  const panel2 = active2 + " [data-hcv-queue]";
  const entry = panel2 + " > .status-section-body > " + row4;
  const soleQueue = '[data-slot="status-stack-content"] > :only-child > [data-hcv-queue]';
  const onlyQueue = stack2 + ":has(" + soleQueue + ")";
  const bareDock = active2 + ' [data-slot="composer-dock"]:has(' + stack2 + " " + soleQueue + "):not(:has(.coding-status-bar))";
  const queueRows = " > .status-section-body > " + row4;
  const visibleQueue = ".status-drawer:not([data-collapsed]) [data-hcv-queue]" + queueRows;
  const attached = active2 + ' [data-slot="composer-dock"]:not([data-popped-out]):has(> ' + visibleQueue + ")";
  const lastQueue = '[data-slot="status-stack-content"] > :last-child > [data-hcv-queue]';
  const grip = entry + " > [data-hcv-queue-grip]";
  const popup = active2 + " [data-hcv-queue-menu]";
  const more = entry + " [data-hcv-queue-more]";
  const deleteButton = entry + " .status-dismiss-button";
  const primary4 = entry + " .status-row-actions > :is(" + steer + ", " + send + ")";
  return `
    ${active2}[data-hermes-mode="dark"] {
      --hcv-queue-text: #dfdfdf;
      --hcv-queue-muted: #969696;
    }
    ${active2} ${onlyQueue} > div {
      /* Codex insets the tray 13px. Hermes reserves a 5px grab margin. */
      margin-inline: 18px;
      background: transparent;
      backdrop-filter: none;
      border: 0;
      border-radius: 0;
      box-shadow: none;
    }
    ${bareDock} [data-slot="status-drawer-toggle"][aria-expanded="true"] { display: none; }
    ${attached} {
      /* attached-uA8vni in Codex 0b2d31a9d760.css: radius + one unit. */
      --hcv-queue-overlap: 20px;
    }
    ${attached} > .status-drawer:has(${lastQueue}) {
      margin-block-end: calc(-1 * var(--hcv-queue-overlap));
    }
    ${attached} ${lastQueue} { padding-block-end: var(--hcv-queue-overlap); }
    ${attached} > [data-slot="composer-root"] { z-index: 1; }
    ${panel2} {
      background: var(--hcv-menu);
      border: 1px solid var(--hcv-stroke);
      border-block-end: 0;
      border-radius: 16px 16px 0 0;
      container-type: inline-size;
      overflow: clip;
      color: var(--hcv-queue-text, var(--hcv-text));
      font-family: var(--hcv-ui-font);
    }
    ${panel2} > .status-section-header:not(:has(.codicon-debug-pause)) { display: none; }
    ${panel2} > .status-section-body {
      display: grid;
      row-gap: 1px;
      max-block-size: 30dvh;
      overflow-y: auto;
      overscroll-behavior: contain;
      scrollbar-width: thin;
    }
    ${entry} {
      position: relative;
      display: grid;
      grid-template-columns: 14px minmax(0, 1fr) auto 22px 22px;
      grid-template-areas: "icon text primary delete more";
      align-items: center;
      min-block-size: 29px;
      gap: 4px;
      padding: 2px 9px;
      background: transparent;
    }
    ${entry}:hover { background: transparent; }
    ${grip} {
      display: none;
      position: absolute;
      inset-inline-start: 1px;
      inset-block-start: 50%;
      translate: 0 -50%;
      place-items: center;
      inline-size: 11px;
      block-size: 20px;
      padding: 0;
      border: 0;
      border-radius: 3px;
      background: transparent;
      color: color-mix(in srgb, var(--hcv-queue-muted, var(--hcv-muted)) 70%, transparent);
      opacity: 0;
      cursor: grab;
    }
    ${panel2}[data-hcv-queue-reorder] > .status-section-body > ${row4} > [data-hcv-queue-grip] { display: grid; }
    ${grip}::before {
      content: "";
      inline-size: 14px;
      block-size: 14px;
      background: currentColor;
      mask: ${codexMask("queueGrip")} center / contain no-repeat;
    }
    ${entry}:is(:hover, :focus-within, [data-hcv-queue-dragging]) > [data-hcv-queue-grip] { opacity: 1; }
    ${grip}:focus-visible { outline: 1px solid var(--hcv-focus); }
    ${entry}[data-hcv-queue-dragging] { opacity: .6; cursor: grabbing; }
    ${entry}[data-hcv-queue-drop]::after {
      content: "";
      position: absolute;
      inset-inline: 10px;
      block-size: 1px;
      background: var(--hcv-focus);
      pointer-events: none;
    }
    ${entry}[data-hcv-queue-drop="before"]::after { inset-block-start: 0; }
    ${entry}[data-hcv-queue-drop="after"]::after { inset-block-end: 0; }
    ${entry} > :is(.status-row-actions, .status-row-dismiss) { display: contents; opacity: 1; }
    ${entry} > .status-row-icon {
      grid-area: icon;
      color: color-mix(in srgb, var(--hcv-queue-muted, var(--hcv-muted)) 70%, transparent);
      width: 14px;
      height: 14px;
      background: currentColor;
      mask: ${codexMask("queueFollowUp")} center / contain no-repeat;
    }
    ${entry} > .status-row-icon > *,
    ${entry} :is(.status-dismiss-button, ${steer}, ${send}) > svg,
    ${deleteButton} > * { display: none; }
    ${entry} > .status-row-content { grid-area: text; margin-inline-start: 2px; }
    ${entry} > .status-row-content p { font: 400 13px/20px var(--hcv-ui-font); color: inherit; }
    ${entry} .status-row-actions > ${edit2},
    ${entry}:has(> .status-row-actions > button > svg.tabler-icon-steering-wheel) .status-row-actions > ${send} { display: none; }
    ${primary4}, ${deleteButton}, ${more} {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      block-size: 22px;
      min-inline-size: 22px;
      margin: 0;
      border: 0;
      border-radius: 8px;
      background: transparent;
      color: var(--hcv-queue-muted, var(--hcv-muted));
      font: 400 12px/18px var(--hcv-ui-font);
      cursor: pointer;
    }
    ${primary4} { grid-area: primary; inline-size: auto; padding-inline: 5px; }
    ${primary4}::after { content: attr(aria-label); }
    ${entry} .status-row-actions > ${steer}::after { content: var(--hcv-queue-steer-label); }
    ${deleteButton} { grid-area: delete; inline-size: 22px; }
    ${more} { grid-area: more; inline-size: 22px; }
    ${primary4} { --hcv-queue-icon: ${codexMask("queueSteer")}; }
    ${deleteButton} { --hcv-queue-icon: ${codexMask("queueTrash")}; }
    ${primary4}::before, ${deleteButton}::before, ${more}::before,
    ${popup} button::before {
      content: "";
      display: block;
      inline-size: 14px;
      block-size: 14px;
      flex: none;
      background: currentColor;
      mask: var(--hcv-queue-icon) center / contain no-repeat;
    }
    ${primary4}:is(:hover, :focus-visible), ${deleteButton}:is(:hover, :focus-visible),
    ${more}:is(:hover, :focus-visible, [aria-expanded="true"]) {
      color: var(--hcv-queue-text, var(--hcv-text));
      background: var(--hcv-hover-menu);
    }
    ${primary4}:focus-visible, ${deleteButton}:focus-visible, ${more}:focus-visible {
      outline: 1px solid var(--hcv-focus);
      outline-offset: -1px;
    }
    ${popup} {
      position: fixed;
      inset: auto;
      margin: 0;
      inline-size: max-content;
      max-inline-size: calc(100vw - 16px);
      padding: 4px;
      border: 0;
      border-radius: var(--hcv-dropdown-radius);
      corner-shape: superellipse(1.5);
      background: var(--hcv-dropdown-background);
      color: var(--hcv-queue-text, var(--hcv-text));
      box-shadow: var(--hcv-dropdown-shadow);
      backdrop-filter: none;
      font: 400 13px/18px var(--hcv-ui-font);
    }
    ${popup} button {
      display: flex;
      align-items: center;
      inline-size: 100%;
      min-block-size: 26px;
      gap: 7px;
      padding: 3px 7px;
      border: 0;
      border-radius: var(--hcv-dropdown-row-radius);
      corner-shape: superellipse(1.5);
      text-align: start;
      background: transparent;
      color: inherit;
      cursor: pointer;
    }
    ${popup} button[hidden] { display: none; }
    ${popup} button:disabled { opacity: .45; cursor: default; }
    @container (max-width: 350px) {
      ${primary4}::after { display: none; }
    }
  `;
}
function registerQueueAppearance(ctx, active2, queueing) {
  ctx.i18n.register({
    en: {
      queueLabel: "Queued messages",
      queueActions: "Queued message actions",
      queueSteer: "Steer",
      queueEdit: "Edit message",
      queueNext: "Send next",
      queueOff: "Turn off queueing",
      queueOn: "Turn on queueing",
      queueMove: "Move queued message with Up or Down",
      queueMoved: (position2, count) => `Position ${position2} of ${count}`
    },
    ru: {
      queueLabel: "\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0439",
      queueActions: "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0441 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435\u043C \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438",
      queueSteer: "\u0421\u043A\u043E\u0440\u0440\u0435\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C",
      queueEdit: "\u0420\u0435\u0434\u0430\u043A\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435",
      queueNext: "\u041E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u044C \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u043C",
      queueOff: "\u0412\u044B\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043F\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0443 \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u044C",
      queueOn: "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u044C \u043F\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0443 \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u044C",
      queueMove: "\u041F\u0435\u0440\u0435\u043C\u0435\u0441\u0442\u0438\u0442\u044C \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u0438 \u0441\u0442\u0440\u0435\u043B\u043A\u0430\u043C\u0438 \u0432\u0432\u0435\u0440\u0445 \u0438\u043B\u0438 \u0432\u043D\u0438\u0437",
      queueMoved: (position2, count) => `\u041F\u043E\u0437\u0438\u0446\u0438\u044F ${position2} \u0438\u0437 ${count}`
    }
  });
  const root = document.documentElement;
  const sheet = document.createElement("style");
  sheet.dataset.hcvQueueStyle = "";
  sheet.textContent = queueStyles(active2);
  mountStyle(ctx, sheet, { surface: "[data-hcv-queue], [data-hcv-queue-menu]" });
  let remove;
  const sync = () => {
    if (root.matches(active2)) {
      remove ??= ctx.register({
        id: "queue-appearance",
        area: "composer.top",
        render: () => h15(QueueSurface, { ctx, queueing })
      });
    } else if (remove) {
      remove();
      remove = void 0;
    }
  };
  const theme2 = new MutationObserver(sync);
  theme2.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.onDispose(() => {
    theme2.disconnect();
    remove?.();
    sheet.remove();
  });
  sync();
}
function queueingPreference(ctx) {
  return ctx.storage.get(modeKey, true);
}

// source/composer-approval.js
import { createElement as h16, useCallback as useCallback2, useState as useState11, useSyncExternalStore as useSyncExternalStore2 } from "react";
import { COMPOSER_AREAS, DropdownMenu as DropdownMenu5, DropdownMenuContent as DropdownMenuContent5, DropdownMenuTrigger as DropdownMenuTrigger5, host as host21 } from "@hermes/plugin-sdk";
var nativeSelector = '[data-slot="statusbar"]';
function nativeItem(footer) {
  for (let fiber = committedFiber(footer); fiber; fiber = fiber.return) {
    const items2 = fiber.memoizedProps?.items;
    if (!Array.isArray(items2)) continue;
    return items2.find((item) => item.id === "approval-mode" && !item.hidden && item.menuContent);
  }
}
function nativeButton(footer) {
  for (const button5 of footer.querySelectorAll('button[aria-haspopup="menu"]')) {
    for (let fiber = committedFiber(button5); fiber && fiber.stateNode !== footer; fiber = fiber.return) {
      if (fiber.memoizedProps?.item?.id === "approval-mode") return button5;
    }
  }
}
function ApprovalControl({ subscribe, snapshot }) {
  const [main, setMain] = useState11(false);
  const locate = useCallback2((node3) => {
    setMain(Boolean(node3?.closest('form[data-slot="composer-root"][data-tour="composer"]:not([data-popped-out])') && !node3.closest("[data-hud-shell]")));
  }, []);
  const { item, route } = useSyncExternalStore2(subscribe, snapshot);
  let control4;
  if (main && item) {
    const off = Boolean(item.className);
    control4 = h16(
      DropdownMenu5,
      { key: route },
      h16(
        DropdownMenuTrigger5,
        { asChild: true },
        h16(
          "button",
          {
            type: "button",
            "data-hcv-approval": off ? "off" : "",
            "aria-label": item.title,
            title: item.title,
            disabled: item.disabled
          },
          h16("span", { "data-hcv-approval-icon": "", "aria-hidden": "true", style: codexIconStyle(off ? "shieldWarning" : "shield") }),
          h16("span", { "data-hcv-approval-label": "" }, item.label)
        )
      ),
      h16(DropdownMenuContent5, {
        side: "top",
        align: "start",
        sideOffset: 4,
        "data-hcv-approval-menu": "",
        "aria-label": item.toggleLabel
      }, item.menuContent)
    );
  }
  return h16("span", { ref: locate, "data-hcv-approval-anchor": "" }, control4);
}
function registerComposerApproval(ctx, active2) {
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const listeners = /* @__PURE__ */ new Set();
  let current = {};
  let source;
  let footer;
  let registration;
  let frame;
  const snapshot = () => current;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const markSource = (button5) => {
    if (source === button5) return;
    source?.removeAttribute("data-hcv-approval-source");
    source = button5;
    source?.setAttribute("data-hcv-approval-source", "");
  };
  function sync() {
    frame = 0;
    const enabled = contrast.matches && root.matches(active2);
    if (enabled) {
      registration ??= ctx.register({
        id: "composer-approval",
        area: COMPOSER_AREAS.leading,
        render: () => h16(ApprovalControl, { subscribe, snapshot })
      });
    } else {
      registration?.();
      registration = void 0;
    }
    const nextFooter = enabled ? document.querySelector(nativeSelector) : null;
    if (nextFooter !== footer) {
      statusChanges.disconnect();
      footer = nextFooter;
      if (footer) statusChanges.observe(footer, { childList: true, characterData: true, subtree: true });
    }
    const item = footer ? nativeItem(footer) : void 0;
    const route = JSON.stringify([host21.state.connectionId.get(), host21.state.profile.get()]);
    markSource(item && footer ? nativeButton(footer) : void 0);
    if (item !== current.item || route !== current.route) {
      current = { item, route };
      for (const listener of listeners) listener();
    }
  }
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(sync);
  };
  const statusChanges = new MutationObserver(schedule);
  const observer = new MutationObserver((records) => {
    if (root.matches(active2) && (footer?.isConnected === false || records.some((record) => movedElementMatches(record, nativeSelector)))) schedule();
  });
  const themeChanges = new MutationObserver(schedule);
  observer.observe(document.body, { childList: true, subtree: true });
  themeChanges.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme", "lang"] });
  contrast.addEventListener("change", schedule);
  const unsubscribe = [host21.state.gateway, host21.state.connectionId, host21.state.profile, host21.state.focusedSessionId].map((atom7) => atom7.listen(schedule));
  ctx.onDispose(() => {
    observer.disconnect();
    statusChanges.disconnect();
    themeChanges.disconnect();
    cancelAnimationFrame(frame);
    registration?.();
    markSource(void 0);
    contrast.removeEventListener("change", schedule);
    for (const off of unsubscribe) off();
  });
  sync();
}

// source/composer-changes.js
import { host as host22 } from "@hermes/plugin-sdk";
var dockSelector = '[data-chat-surface][data-composer-target="main"]:not([data-hud-shell] *, [data-pane-hidden] *, [inert] *) [data-slot="composer-dock"]:not([data-popped-out])';
var dockMounts = '[data-chat-surface], [data-slot="composer-dock"]';
var editTools2 = /* @__PURE__ */ new Set(["edit_file", "patch", "write_file"]);
var ansi = /\x1b\[[0-?]*[ -/]*[@-~]/g;
var hunkHeader = /^@@ -\d+(?:,(\d+))? \+\d+(?:,(\d+))? @@/;
function resultRecord(value) {
  try {
    const record = typeof value === "string" ? JSON.parse(value) : value;
    return record && typeof record === "object" && !Array.isArray(record) ? record : {};
  } catch {
    return {};
  }
}
function filePath(value) {
  const path = value?.trim().split("	")[0];
  return path && path !== "/dev/null" ? path.replace(/^[ab]\//, "") : "";
}
function pathKey(path) {
  const normalized2 = path.replaceAll("\\", "/").replace(/^\.\//, "");
  return /^[a-z]:\//i.test(normalized2) ? normalized2.toLowerCase() : normalized2;
}
function changedFiles(payload) {
  const result = resultRecord(payload.result);
  if (payload.error || result.error || result.success === false) return [];
  const diff = [result.diff, result.inline_diff, payload.inline_diff].find((value) => typeof value === "string" && value.trim());
  if (!diff) return [];
  const args = payload.args || {};
  const fallback = [result.resolved_path, args.path, args.file, args.filepath, result.path, result.file, result.filepath].find((value) => typeof value === "string" && value.trim())?.trim();
  const sections = [];
  let file;
  let hunk;
  let oldPath;
  function section2(path) {
    hunk = null;
    file = { path, added: 0, removed: 0 };
    sections.push(file);
  }
  for (const line of diff.replace(ansi, "").split(/\r?\n/)) {
    if (line.startsWith("diff --git ")) {
      hunk = null;
      continue;
    }
    const header2 = line.match(hunkHeader);
    if (header2) {
      if (!file) section2(fallback);
      const oldLines = Number(header2[1] ?? 1);
      const newLines = Number(header2[2] ?? 1);
      const countBody = oldLines > 0 && newLines > 0;
      if (!countBody) {
        file.added += newLines;
        file.removed += oldLines;
      }
      hunk = { oldLines, newLines, countBody };
    } else if (hunk && (hunk.oldLines || hunk.newLines) && /^[ +\-]/.test(line)) {
      if (line[0] !== "+") hunk.oldLines = Math.max(0, hunk.oldLines - 1);
      if (line[0] !== "-") hunk.newLines = Math.max(0, hunk.newLines - 1);
      if (hunk.countBody && line[0] === "+") file.added++;
      if (hunk.countBody && line[0] === "-") file.removed++;
    } else if (line.startsWith("--- ")) {
      oldPath = filePath(line.slice(4));
    } else if (line.startsWith("+++ ")) {
      section2(filePath(line.slice(4)) || oldPath);
    } else if (/^(?:[ab]\/|\/dev\/null|[A-Za-z]:[\\/]).+ → /.test(line)) {
      const [from, to] = line.split(" \u2192 ");
      section2(filePath(to) || filePath(from));
    }
  }
  const files = sections.filter((row5) => row5.added || row5.removed);
  if (files.length === 1 && fallback) files[0].path = fallback;
  return files.filter((row5) => row5.path).map((row5) => ({ ...row5, path: pathKey(row5.path) }));
}
function element6(tag, part) {
  const node3 = document.createElement(tag);
  node3.setAttribute("data-hcv-" + part, "");
  return node3;
}
function numberDisplay(part, sign) {
  const wrap = element6("span", part);
  const digits = element6("span", "changes-digits");
  wrap.append(sign, digits);
  const columns = /* @__PURE__ */ new Map();
  let shown;
  return {
    node: wrap,
    update(text) {
      if (text === shown) return;
      shown = text;
      const chars = [...text].reverse();
      const next = [];
      let position2 = 0;
      for (const char of chars) {
        if (!/^[0-9]$/.test(char)) {
          next.push(document.createTextNode(char));
          continue;
        }
        let column = columns.get(position2);
        if (!column) {
          column = element6("span", "changes-digit");
          const reel = element6("span", "changes-reel");
          for (const digit of "0123456789") {
            const cell = document.createElement("span");
            cell.textContent = digit;
            reel.append(cell);
          }
          column.append(reel);
          columns.set(position2, column);
        }
        column.firstChild.style.transform = "translateY(-" + char + "lh)";
        next.push(column);
        position2++;
      }
      next.reverse().forEach((node3, index) => {
        if (digits.childNodes[index] !== node3) digits.insertBefore(node3, digits.childNodes[index] || null);
      });
      while (digits.childNodes.length > next.length) digits.lastChild.remove();
      for (const index of columns.keys()) if (index >= position2) columns.delete(index);
      wrap.dataset.value = text;
    }
  };
}
function changesLabel(count, locale, formatted) {
  if (!locale.startsWith("ru")) return formatted + (count === 1 ? " file changed" : " files changed");
  const plural = new Intl.PluralRules("ru").select(count);
  if (plural === "one") return "\u0418\u0437\u043C\u0435\u043D\u0435\u043D " + formatted + " \u0444\u0430\u0439\u043B";
  return "\u0418\u0437\u043C\u0435\u043D\u0435\u043D\u043E " + formatted + (plural === "few" ? " \u0444\u0430\u0439\u043B\u0430" : " \u0444\u0430\u0439\u043B\u043E\u0432");
}
function registerComposerChanges(ctx, active2) {
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const turns = /* @__PURE__ */ new Map();
  const key = (connection, profile2, session) => JSON.stringify([connection, profile2, session]);
  const scope4 = () => [host22.state.connectionId.get(), host22.state.profile.get()];
  const eventKey = (event) => event.session_id && !event.replayed ? key(event.connectionId || scope4()[0], event.profile || scope4()[1], event.session_id) : null;
  const rail = element6("div", "composer-changes");
  const chip2 = element6("div", "composer-changes-chip");
  const label3 = element6("span", "composer-changes-label");
  const totals = element6("span", "composer-changes-totals");
  const added = numberDisplay("composer-changes-added", "+");
  const removed = numberDisplay("composer-changes-removed", "\u2212");
  totals.append(added.node, removed.node);
  chip2.append(label3, totals);
  chip2.setAttribute("role", "status");
  chip2.setAttribute("aria-live", "polite");
  for (const child of chip2.children) child.setAttribute("aria-hidden", "true");
  rail.append(chip2);
  const motion2 = matchMedia("(prefers-reduced-motion: no-preference)");
  let currentKey;
  let lastText;
  let lastCounts;
  let numberLocale;
  let numberFormatter;
  let sizeAnimation;
  let frame;
  function hide() {
    sizeAnimation?.cancel();
    rail.remove();
    currentKey = void 0;
    lastText = void 0;
    lastCounts = void 0;
  }
  function sync() {
    frame = 0;
    if (!root.matches(active2) || !contrast.matches) return hide();
    const session = host22.state.activeSessionId.get();
    const address = key(...scope4(), session);
    const turn = turns.get(address);
    const dock2 = turn?.paths.size && document.querySelector(dockSelector);
    if (!dock2 || !host22.state.busyBySession.get()[session]) return hide();
    if (currentKey !== address || rail.parentElement !== dock2) hide();
    const locale = root.lang.toLowerCase() || "en";
    const count = turn.paths.size;
    if (lastCounts?.count === count && lastCounts.added === turn.added && lastCounts.removed === turn.removed && lastCounts.locale === locale) return;
    if (numberLocale !== locale) {
      numberFormatter = new Intl.NumberFormat(locale);
      numberLocale = locale;
    }
    const formatter = numberFormatter;
    const text = changesLabel(turn.paths.size, locale, formatter.format(turn.paths.size));
    const plus = formatter.format(turn.added);
    const minus = formatter.format(turn.removed);
    const accessible = text + ", +" + plus + ", \u2212" + minus;
    lastCounts = { count, added: turn.added, removed: turn.removed, locale };
    if (accessible === lastText && currentKey === address) return;
    const oldWidth = rail.isConnected ? chip2.getBoundingClientRect().width : 0;
    sizeAnimation?.cancel();
    label3.textContent = text;
    added.update(plus);
    removed.update(minus);
    chip2.setAttribute("aria-label", accessible);
    if (!rail.isConnected) dock2.prepend(rail);
    const width = chip2.getBoundingClientRect().width;
    if (oldWidth && width !== oldWidth && motion2.matches) {
      sizeAnimation = chip2.animate([{ width: oldWidth + "px" }, { width: width + "px" }], { duration: 200, easing: "ease-out" });
    }
    lastText = accessible;
    currentKey = address;
  }
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(sync);
  };
  ctx.onEvent("message.start", (event) => {
    const address = eventKey(event);
    if (!address) return;
    turns.set(address, { since: event.seq, calls: /* @__PURE__ */ new Set(), paths: /* @__PURE__ */ new Set(), added: 0, removed: 0 });
    if (turns.size > 64) turns.delete(turns.keys().next().value);
    schedule();
  });
  ctx.onEvent("tool.complete", (event) => {
    const payload = event.payload;
    if (!editTools2.has(payload?.name) || !payload.tool_id) return;
    const turn = turns.get(eventKey(event));
    if (!turn || event.seq < turn.since || turn.calls.has(payload.tool_id)) return;
    const files = changedFiles(payload);
    if (!files.length) return;
    turn.calls.add(payload.tool_id);
    for (const row5 of files) {
      turn.paths.add(row5.path);
      turn.added += row5.added;
      turn.removed += row5.removed;
    }
    schedule();
  });
  ctx.onEvent("message.complete", (event) => {
    if (turns.delete(eventKey(event))) schedule();
  });
  const observer = new MutationObserver((records) => {
    const session = host22.state.activeSessionId.get();
    if (!rail.isConnected && !(session && turns.get(key(...scope4(), session))?.paths.size)) return;
    if (records.some((record) => {
      const target = record.target;
      if (!(target instanceof Element)) return false;
      if (record.type === "attributes") {
        return target === root || target.contains(rail) || target.matches(dockMounts) || Boolean(target.firstElementChild && target.querySelector(dockMounts));
      }
      if (target.closest('[data-slot="aui_thread-content"]')) return false;
      if ([...record.removedNodes].some((node3) => node3 === rail || node3.contains?.(rail))) return true;
      return movedElementMatches(record, dockMounts);
    })) schedule();
  });
  observer.observe(root, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-hermes-theme", "lang", "data-pane-hidden", "data-popped-out", "inert", "hidden"]
  });
  const busyNow = () => Boolean(host22.state.busyBySession.get()[host22.state.activeSessionId.get()]);
  let previousBusy = busyNow();
  const stopBusy = host22.state.busyBySession.listen(() => {
    const busy = busyNow();
    if (busy === previousBusy) return;
    previousBusy = busy;
    schedule();
  });
  const scopeChanged = () => {
    previousBusy = busyNow();
    schedule();
  };
  const stopSession = host22.state.activeSessionId.listen(scopeChanged);
  const unsubscribe = [host22.state.connectionId, host22.state.profile].map((atom7) => atom7.listen(scopeChanged));
  contrast.addEventListener("change", schedule);
  ctx.onDispose(() => {
    cancelAnimationFrame(frame);
    observer.disconnect();
    contrast.removeEventListener("change", schedule);
    stopBusy();
    stopSession();
    for (const off of unsubscribe) off();
    hide();
  });
}

// source/composer-layout.js
function registerComposerLayout(ctx, active2) {
  const dock2 = `${active2} [data-slot="composer-dock"]:not([data-popped-out], [data-hud-shell] *)`;
  const surface5 = `${dock2} [data-slot="composer-surface"]`;
  const fallback = `${active2} [data-chat-surface]:not([data-hud-shell] *) .composer-fallback-surface`;
  const statusSection = '[data-slot="status-stack-section"]';
  const consentIcon = '[data-slot="status-row"] > .status-row-icon > .codicon-graph';
  const consentSection = `${statusSection}:has(> ${consentIcon})`;
  const consent = `${dock2} ${consentSection} > [data-slot="status-row"]`;
  const consentDrawer = `${dock2} > .status-drawer:has([data-slot="status-stack-content"] > ${statusSection}:only-child > ${consentIcon})`;
  const attachedComposer = `${consentDrawer}:not([data-collapsed]) + [data-slot="composer-root"]`;
  const backing = "> .pointer-events-none.absolute.inset-0.-z-10[aria-hidden]";
  const input = '[class~="[grid-area:input]"]';
  const leading = '[class~="[grid-area:menu]"]';
  const trailing = '[class~="[grid-area:controls]"]';
  const grid = `${surface5} [data-slot="composer-fade"] > div:has(> ${input} + ${trailing})`;
  const regularGrid = `${grid}:not(:has(> [data-hcv-dictation]))`;
  const editor2 = '[data-slot="composer-rich-input"]';
  const controls2 = `${grid} > :is(${leading}, ${trailing})`;
  const reasoning = '[data-testid="reasoning-pill"]';
  const ghost = `${controls2} :is(button[aria-haspopup="menu"], button[data-tour="model-pill"], [data-slot="fan-menu-anchor"] > button):not([data-hcv-approval])`;
  const rail = `${active2} [data-hcv-composer-changes]`;
  const chip2 = `${rail} [data-hcv-composer-changes-chip]`;
  const approval = `${active2} [data-hcv-approval]`;
  const approvalMenu = `${active2} [data-hcv-approval-menu]`;
  const approvalOption = `${approvalMenu} [role="menuitemradio"]`;
  const sheet = document.createElement("style");
  sheet.setAttribute("data-hcv-composer-layout", "");
  sheet.textContent = `
    @media (forced-colors: none) {
      ${active2} {
        --hcv-composer-light-blur: 80px;
        --hcv-composer-shadow: 0 0 0 1px #0000000a, 0 2px 8px #0000000a, 0 4px var(--hcv-composer-light-blur) 8px #00000006;
      }
      @media (max-width: 760px) { ${active2} { --hcv-composer-light-blur: 40px; } }
      ${active2}[data-hermes-mode="dark"] { --hcv-composer-shadow: inset 0 0 1px #fff3; }
      ${surface5} {
        /* Codex ef088f0f36db.css paints the fill and shadow on one surface.
           Hermes reserves a 1px native border. Move that pixel into the padding. */
        border: 0 !important;
        background-color: var(--composer-fill);
        box-shadow: var(--hcv-composer-shadow);
        --composer-control-size: 28px;
        --composer-control-primary-size: 28px;
        --composer-surface-pad-x: 8px;
        --composer-surface-pad-y: 8px;
        --hcv-composer-hover: var(--hcv-dropdown-hover);
      }
      ${surface5} ${backing}, ${fallback} ${backing},
      ${dock2} > [data-slot="composer-root"] > .pointer-events-none.absolute.inset-0 {
        display: none;
      }
      ${fallback} {
        border-color: transparent;
        border-radius: 22px;
        background-color: var(--hcv-composer);
        box-shadow: var(--hcv-composer-shadow);
      }
      ${dock2} .coding-status-bar { border-block-end-color: transparent; }
      @media (hover: hover) and (pointer: fine) {
        ${dock2} [data-slot="status-drawer-toggle"][aria-expanded="false"]:not(:hover, :focus-visible) { opacity: 0; }
        ${attachedComposer} [data-slot="status-drawer-toggle"]:not(:hover, :focus-visible) { opacity: 0; }
      }
      /* The assistant's attached rail in Codex d6fe5799461e.css shares the
         composer's silhouette. Keep the Hermes drawer and its actions native. */
      ${consentDrawer} [data-slot="composer-status-stack"] > div {
        margin-inline: 5px;
        border-radius: 22px 22px 0 0;
        border: 0;
        background: var(--hcv-composer);
        backdrop-filter: none;
      }
      ${attachedComposer} [data-slot="composer-surface"] {
        border-start-start-radius: 0;
        border-start-end-radius: 0;
        box-shadow: none;
      }
      ${dock2} ${consentSection} { container-type: inline-size; }
      ${consent} {
        display: grid;
        grid-template-columns: 16px minmax(0, 1fr) auto;
        gap: 6px 8px;
        padding: 10px 12px 6px;
        color: var(--hcv-text);
        font: 13px/18px var(--hcv-ui-font);
      }
      ${consent}:hover { background: transparent; }
      ${consent} > .status-row-icon { grid-column: 1; align-self: start; inline-size: 16px; block-size: 18px; }
      ${consent} > .status-row-content { grid-column: 2; }
      ${consent} > .status-row-content > span {
        overflow: visible;
        white-space: normal;
        overflow-wrap: anywhere;
        font: inherit;
        color: inherit;
      }
      ${consent} > .status-row-content > span > span:first-child { display: block; font-weight: 600; }
      ${consent} > .status-row-content > span > span:nth-child(2) {
        display: block;
        color: var(--hcv-muted);
        font-size: 12px;
        line-height: 17px;
      }
      ${consent} > .status-row-actions { grid-column: 3; align-self: center; flex-wrap: wrap; gap: 4px; }
      ${consent} > .status-row-actions > button {
        min-block-size: 26px;
        margin-block-start: 0;
        padding-inline: 8px;
        border: 1px solid var(--hcv-hairline);
        border-radius: 8px;
        background: transparent;
        color: var(--hcv-text);
        font: 13px/18px var(--hcv-ui-font);
      }
      ${consent} > .status-row-actions > button:last-child { border-color: transparent; color: var(--hcv-muted); }
      ${consent} > .status-row-actions > button:not(:disabled):hover {
        background: var(--hcv-dropdown-hover);
        color: var(--hcv-text);
      }
      @container (width < 640px) {
        ${consent} { grid-template-columns: 16px minmax(0, 1fr); }
        ${consent} > .status-row-actions { grid-area: 2 / 2; }
      }
      ${surface5} [data-slot="composer-fade"] { container-type: inline-size; }
      ${regularGrid} {
        grid-template-areas: "input input" "menu controls";
        grid-template-columns: auto minmax(0, 1fr);
        align-items: center;
        column-gap: 4px;
        row-gap: 0;
      }
      ${grid} > ${input} { padding-inline: 4px; align-self: start; }
      /* Codex desktop uses 14px above the editor, two 20px lines,
         and 8px before the controls. The surface already adds 8px above. */
      ${regularGrid} > ${input} { padding-block: 6px 8px; }
      ${regularGrid} > ${input} ${editor2} { min-block-size: 40px; }
      ${grid}:has(> [data-hcv-dictation]) > ${input} { min-block-size: 40px; padding-block-start: 8px; }
      ${grid} > ${leading} { align-self: center; align-items: center; translate: none; }
      ${grid} > ${input} ${editor2} {
        inline-size: 100%; min-inline-size: 0; padding: 0;
        font-size: 14px; line-height: 20px;
      }
      ${grid} > ${input} ${editor2}[data-empty]::before { opacity: .5; }
      ${ghost} { border-radius: 999px; }
      ${ghost}:is(:hover, [data-state="open"]):not(:disabled) {
        background: var(--hcv-composer-hover); color: var(--hcv-text);
      }
      ${controls2} > button:has(> .codicon-add) { color: var(--hcv-text); }
      ${codexIconRules(`${controls2} > button > .codicon-add`, "plus")}
      ${controls2} > button > .codicon-add { inline-size: 16px; block-size: 16px; }
      ${controls2} :is(button[data-tour="model-pill"], ${reasoning}) { font-size: 13px; padding-inline: 8px; }
      ${controls2} :is(button[data-tour="model-pill"], [data-slot="fan-menu-anchor"] > button) { color: var(--hcv-text); }
      ${controls2} button[data-tour="model-pill"]:has(+ ${reasoning}) { padding-inline-end: 3px; margin-inline-end: -4px; }
      ${controls2} ${reasoning} { padding-inline-start: 3px; }
      ${controls2} ${reasoning}::after {
        content: ''; inline-size: 12px; block-size: 12px; background: currentColor; opacity: .65;
        mask: ${codexMask("down")} center / contain no-repeat;
      }
      ${controls2} button[type="submit"] > span[class~="rounded-[0.1875rem]"] {
        inline-size: 16px; block-size: 16px; background: currentColor;
        mask: ${codexMask("dictationStop")} center / contain no-repeat;
      }
      ${active2} [data-hcv-approval-anchor] { display: contents; }
      ${active2}:has([data-hcv-approval]:not([data-pane-hidden] *)) [data-hcv-approval-source] { display: none; }
      ${approval} {
        display: flex; flex: none; align-items: center; gap: 4px;
        block-size: 28px; padding-inline: 6px;
        border-radius: 999px; color: var(--hcv-muted); font: 13px/18px var(--hcv-ui-font);
        cursor: pointer;
      }
      ${approval}[data-hcv-approval="off"] { color: light-dark(#ab4108, #ff8549); }
      ${approval}:is(:hover, [data-state="open"]):not(:disabled) { background: var(--hcv-composer-hover); }
      ${approval}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
      ${approval} [data-hcv-approval-icon] { inline-size: 16px; block-size: 16px; flex: none; }
      ${approvalMenu} {
        inline-size: min(260px, calc(100vw - 16px));
      }
      /* Codex bqtn.G renders two lines of text and centers the trailing check. */
      ${approvalOption} { align-items: center; }
      ${approvalOption} > span:first-child { gap: 0; }
      ${approvalOption} > span:first-child > span:first-child {
        color: var(--hcv-dropdown-text);
        font: 400 13px/18px var(--hcv-ui-font);
      }
      ${approvalOption} > span:first-child > span:nth-child(2) {
        color: var(--hcv-dropdown-muted);
        font: 400 12px/14px var(--hcv-ui-font);
      }
      @container (width < 400px) {
        ${approval} { justify-content: center; inline-size: 28px; padding-inline: 0; }
        ${approval} [data-hcv-approval-label] { display: none; }
      }
      ${rail} { display: flex; min-inline-size: 0; justify-content: center; margin-block-end: 8px; }
      ${chip2} {
        display: flex; align-items: center; gap: 4px;
        max-inline-size: calc(100% - 16px); padding: 6px 12px;
        border: 1px solid var(--hcv-hairline); border-radius: 14px;
        background: var(--hcv-menu); color: var(--hcv-muted);
        font: 14px/20px var(--hcv-ui-font); white-space: nowrap;
      }
      ${chip2} [data-hcv-composer-changes-label] { min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; }
      ${chip2} [data-hcv-composer-changes-totals] { display: inline-flex; align-items: center; gap: 4px; flex: none; }
      ${chip2} [data-hcv-composer-changes-added] { color: light-dark(#00a240, #40c977); }
      ${chip2} [data-hcv-composer-changes-removed] { color: light-dark(#ba2623, #fa423e); }
      ${chip2} :is([data-hcv-composer-changes-added], [data-hcv-composer-changes-removed], [data-hcv-changes-digits]) {
        display: inline-flex; align-items: center; font-variant-numeric: tabular-nums; letter-spacing: -.025em;
      }
      ${chip2} [data-hcv-changes-digit] { display: inline-block; inline-size: 1ch; block-size: 1lh; overflow: hidden; }
      ${chip2} [data-hcv-changes-reel] { display: flex; flex-direction: column; block-size: 1lh; contain: layout size style; }
      ${chip2} [data-hcv-changes-reel] > span { flex: 0 0 1lh; }
      @media (prefers-reduced-motion: no-preference) {
        ${ghost}, ${approval} { transition: background-color 150ms ease, color 150ms ease; }
        ${rail} { animation: hcv-changes-enter 150ms ease-out backwards; }
        ${chip2} [data-hcv-changes-reel] { transition: transform 300ms cubic-bezier(.16, 1, .3, 1); }
        @keyframes hcv-changes-enter { from { opacity: 0; translate: 0 4px; } }
      }
      @media (prefers-reduced-motion: reduce) {
        ${ghost}, ${approval} { transition: none; }
      }
    }
  `;
  mountStyle(ctx, sheet, chatStyles);
  registerComposerApproval(ctx, active2);
  registerComposerChanges(ctx, active2);
}

// source/composer.js
var composer = 'form[data-slot="composer-root"]';
var editor = '[data-slot="composer-rich-input"][contenteditable="true"]';
var drawer = '[data-slot="composer-completion-drawer"][role="listbox"]';
var slashMenu = `${drawer}:has(> button > :is([data-ref="command"], [data-ref="skill"], [data-ref="theme"]))`;
var queueButton = '[data-slot="composer-surface"] button[type="button"]:has(> svg.tabler-icon-layers-intersect-2)';
var voiceStartIcon = "svg.tabler-icon-wave-sine";
var voiceStartGroup = `[data-slot="composer-surface"] span:has(> button[type="button"] > ${voiceStartIcon})`;
var voiceStartItem = `[data-slot="dropdown-menu-content"]:has(> [data-slot="dropdown-menu-checkbox-item"]) > [data-slot="dropdown-menu-item"]:has(> ${voiceStartIcon})`;
var menuSeparator = '[data-slot="dropdown-menu-separator"]';
var attachments2 = '[data-slot="composer-attachments"]';
var queuedEdit = '[data-slot="composer-surface"] [class~="bg-accent/18"]:has(> div > button + button)';
var russianGroups = {
  Session: "\u0421\u0435\u0430\u043D\u0441",
  Sessions: "\u0421\u0435\u0430\u043D\u0441\u044B",
  Configuration: "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438",
  "Tools & Skills": "\u0418\u043D\u0441\u0442\u0440\u0443\u043C\u0435\u043D\u0442\u044B \u0438 \u043D\u0430\u0432\u044B\u043A\u0438",
  Info: "\u0418\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F",
  Exit: "\u0412\u044B\u0445\u043E\u0434",
  Commands: "\u041A\u043E\u043C\u0430\u043D\u0434\u044B",
  "Plugin commands": "\u041A\u043E\u043C\u0430\u043D\u0434\u044B \u043F\u043B\u0430\u0433\u0438\u043D\u043E\u0432",
  Skills: "\u041D\u0430\u0432\u044B\u043A\u0438",
  Themes: "\u0422\u0435\u043C\u044B",
  Options: "\u0412\u0430\u0440\u0438\u0430\u043D\u0442\u044B"
};
function isBusy(form) {
  const focused = host23.state.focusedSessionId.get();
  if (form.dataset.tour === "composer") {
    const primary4 = host23.state.activeSessionId.get();
    return primary4 === focused ? host23.state.busy.get() : host23.state.busyBySession.get()[primary4] === true;
  }
  const target = form.closest("[data-floating-composer-target]")?.dataset.floatingComposerTarget ?? form.closest("[data-composer-target]")?.dataset.composerTarget;
  return target === `tile:${host23.state.focusedStoredSessionId.get()}` && host23.state.busy.get();
}
function isSlashCommand(input) {
  if (/^\/[^\s/]*(?:\s|$)/.test(input.innerText.trimStart())) return true;
  const chip2 = input.querySelector('[data-slash-kind][data-ref-text^="/"]');
  if (!chip2) return false;
  const prefix = document.createRange();
  prefix.setStart(input, 0);
  prefix.setEndBefore(chip2);
  return !prefix.toString().trim();
}
function shouldQueue(form, input) {
  return isBusy(form) && !form.querySelector(queuedEdit) && (form.querySelector(attachments2) || !isSlashCommand(input));
}
function queueWithNativeShortcut(event, input) {
  event.preventDefault();
  event.stopPropagation();
  input.dispatchEvent(new KeyboardEvent("keydown", {
    key: "Enter",
    code: "Enter",
    ctrlKey: true,
    bubbles: true,
    cancelable: true,
    composed: true
  }));
}
function registerQueueShortcut(ctx, enabled, queueing) {
  const composing = /* @__PURE__ */ new WeakSet();
  const inputOf = (event) => event.target instanceof Element ? event.target.closest(editor) : null;
  ctx.addEventListener(document, "compositionstart", (event) => {
    const input = inputOf(event);
    if (input) composing.add(input);
  }, true);
  ctx.addEventListener(document, "compositionend", (event) => {
    const input = inputOf(event);
    if (input) composing.delete(input);
  }, true);
  ctx.addEventListener(document, "keydown", (event) => {
    if (event.defaultPrevented || event.key !== "Enter" || event.ctrlKey || event.metaKey || event.altKey || event.isComposing || event.keyCode === 229 || !enabled()) return;
    const input = inputOf(event);
    const form = input?.closest(composer);
    if (!form) return;
    composing.delete(input);
    if (event.shiftKey) {
      if (form.querySelector(drawer)) event.stopPropagation();
      return;
    }
    const empty = !input.innerText.trim() && !form.querySelector(attachments2);
    if ((queueing() || empty) && shouldQueue(form, input)) queueWithNativeShortcut(event, input);
  }, true);
  ctx.addEventListener(document, "submit", (event) => {
    if (event.defaultPrevented || !enabled() || !queueing() || !event.submitter) return;
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || !form.matches(composer) || !form.querySelector(queueButton)) return;
    const input = form.querySelector(editor);
    if (input && !composing.has(input) && shouldQueue(form, input)) queueWithNativeShortcut(event, input);
  }, true);
}
function registerSlashGroups(ctx, root, enabled) {
  ctx.i18n.register({
    en: { slashGroups: Object.fromEntries(Object.keys(russianGroups).map((label3) => [label3, label3])) },
    ru: { slashGroups: russianGroups }
  });
  let form;
  const translated = /* @__PURE__ */ new Map();
  const restore = () => {
    for (const [text, { original, label: label3 }] of translated) {
      if (text.data === label3) text.data = original;
    }
    translated.clear();
  };
  const sync = () => {
    if (!enabled()) {
      restore();
      return;
    }
    for (const text of translated.keys()) {
      if (!text.isConnected) translated.delete(text);
    }
    for (const heading of form?.querySelectorAll(`${slashMenu} > div`) ?? []) {
      const text = heading.firstChild;
      if (heading.childNodes.length !== 1 || text?.nodeType !== Node.TEXT_NODE) continue;
      const previous = translated.get(text);
      const original = previous?.label === text.data ? previous.original : text.data;
      const group2 = original.trim();
      if (!Object.hasOwn(russianGroups, group2)) {
        translated.delete(text);
        continue;
      }
      const label3 = ctx.i18n.t(`slashGroups.${group2}`);
      if (text.data !== label3) text.data = label3;
      if (label3 !== original) translated.set(text, { original, label: label3 });
      else translated.delete(text);
    }
  };
  const observer = new MutationObserver(sync);
  const watch = (node3) => {
    const next = node3 instanceof Element ? node3.closest(editor)?.closest(composer) : null;
    if (!next || next === form) return;
    observer.disconnect();
    restore();
    form = next;
    observer.observe(form, { subtree: true, childList: true, characterData: true });
    sync();
  };
  const theme2 = new MutationObserver(sync);
  theme2.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.addEventListener(document, "focusin", (event) => watch(event.target));
  ctx.i18n.onLocaleChange(sync);
  ctx.onDispose(() => {
    observer.disconnect();
    theme2.disconnect();
    restore();
  });
  watch(document.activeElement);
}
function registerComposer(ctx, active2) {
  const root = document.documentElement;
  const enabled = () => root.matches(active2);
  const menu = `${active2} ${composer} [data-slot="composer-completion-drawer"]`;
  const suggestions = `${active2} ${composer} ${drawer}`;
  const slash2 = `${active2} ${composer} ${slashMenu}`;
  const rowTip = `${active2}:has(${slashMenu} > button:is([data-state="delayed-open"], [data-state="instant-open"])) [data-slot="tooltip-content"]`;
  const sheet = document.createElement("style");
  sheet.dataset.hcvComposer = "";
  sheet.textContent = `
    ${active2} ${composer} ${queueButton} { display: none; }
    ${active2} ${composer} ${voiceStartGroup},
    ${active2} ${voiceStartItem},
    ${active2} ${voiceStartItem} + ${menuSeparator},
    ${active2} ${voiceStartItem} + ${menuSeparator} + ${menuSeparator} { display: none; }
    @media (forced-colors: none) {
      ${menu} {
        inline-size: min(380px, calc(100% - 16px));
        max-block-size: min(336px, calc(100dvh - 144px));
        margin-block-end: 6px;
        padding: 6px;
        border: 1px solid var(--hcv-hairline);
        border-radius: var(--hcv-menu-radius);
        background: var(--hcv-menu);
        box-shadow: var(--hcv-menu-shadow);
        color: var(--hcv-text);
        font: 400 13px/18px var(--hcv-ui-font);
        scrollbar-width: thin;
        scrollbar-color: color-mix(in srgb, var(--hcv-text) 20%, transparent) transparent;
      }
      /* Codex Lx2J.W uses the solid suggestion surface with no drop shadow. */
      ${suggestions} {
        max-block-size: min(320px, calc(100dvh - 144px));
        padding: 4px;
        border-color: var(--hcv-dropdown-outline);
        border-radius: var(--hcv-dropdown-radius);
        corner-shape: superellipse(1.5);
        background: var(--hcv-dropdown-background);
        box-shadow: none;
        backdrop-filter: none;
      }
      ${slash2} > div:not(:has(*)) {
        padding-inline: 8px;
        text-transform: none;
        letter-spacing: normal;
        font: inherit;
        color: var(--hcv-muted);
      }
      ${suggestions} > button {
        gap: 8px;
        min-block-size: 28px;
        padding: 5px 8px;
        border-radius: var(--hcv-dropdown-row-radius);
        corner-shape: superellipse(1.5);
      }
      ${suggestions} > button:is(:hover, :focus-visible, [data-highlighted]):not(:disabled) {
        background: var(--hcv-dropdown-hover);
      }
      ${slash2} > button > [data-ref],
      ${slash2} > button > span:nth-child(3) { color: var(--hcv-muted); }
      ${slash2} > button > span:nth-child(2) { max-inline-size: 60%; }
      ${rowTip} {
        max-inline-size: min(240px, calc(100vw - 24px), var(--radix-tooltip-content-available-width, 240px));
      }
      ${rowTip} span:has(> [data-slot="tooltip-arrow"]) { display: none; }
    }
  `;
  mountStyle(ctx, sheet, chatStyles);
  registerSlashGroups(ctx, root, enabled);
  registerComposerLayout(ctx, active2);
  const queueing = () => queueingPreference(ctx);
  registerQueueShortcut(ctx, enabled, queueing);
  registerQueueAppearance(ctx, active2, queueing);
}

// source/dictation.js
import { host as host24 } from "@hermes/plugin-sdk";

// source/dictation-caret.js
var chip = '[contenteditable="false"]';
function textOf2(fragment) {
  for (const node3 of fragment.querySelectorAll(chip)) node3.replaceWith("\uFFFC");
  for (const node3 of fragment.querySelectorAll("br")) node3.replaceWith("\n");
  return fragment.textContent;
}
function draftText(editor2) {
  return editor2.hasAttribute("data-empty") ? "" : textOf2(editor2.cloneNode(true));
}
function draftSelection(editor2, range2) {
  if (!range2) {
    const selection = window.getSelection();
    range2 = selection?.rangeCount ? selection.getRangeAt(0) : null;
  }
  if (!range2 || !editor2.contains(range2.startContainer) || !editor2.contains(range2.endContainer)) return null;
  if (editor2.hasAttribute("data-empty")) return { start: 0, end: 0 };
  const offset = (node3, index) => {
    const prefix = document.createRange();
    prefix.selectNodeContents(editor2);
    prefix.setEnd(node3, index);
    return textOf2(prefix.cloneContents()).length;
  };
  return { start: offset(range2.startContainer, range2.startOffset), end: offset(range2.endContainer, range2.endOffset) };
}
function updateDictationAnchor(anchor, next, edit3) {
  const previous = anchor.text;
  if (next === previous) return;
  const delta = next.length - previous.length;
  let start;
  let oldEnd;
  if (edit3 && edit3.end + delta >= edit3.start && previous.slice(0, edit3.start) === next.slice(0, edit3.start) && previous.slice(edit3.end) === next.slice(edit3.end + delta)) {
    start = edit3.start;
    oldEnd = edit3.end;
  } else {
    start = 0;
    oldEnd = previous.length;
    let newEnd = next.length;
    while (start < oldEnd && start < newEnd && previous[start] === next[start]) start++;
    while (oldEnd > start && newEnd > start && previous[oldEnd - 1] === next[newEnd - 1]) {
      oldEnd--;
      newEnd--;
    }
  }
  const map = (offset) => offset < start ? offset : Math.max(offset, oldEnd) + delta;
  const touchedSelection = anchor.start < anchor.end && (start === oldEnd ? anchor.start <= start && start <= anchor.end : anchor.start < oldEnd && start < anchor.end);
  anchor.end = map(anchor.end);
  anchor.start = touchedSelection ? anchor.end : map(anchor.start);
  anchor.text = next;
}
function pointAt(editor2, offset) {
  const walker = document.createTreeWalker(editor2, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
    acceptNode(node3) {
      if (node3.parentElement?.closest(chip)) return NodeFilter.FILTER_REJECT;
      return node3.nodeType === Node.TEXT_NODE || node3.matches("br, " + chip) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (let node3 = walker.nextNode(); node3; node3 = walker.nextNode()) {
    if (node3.nodeType === Node.TEXT_NODE) {
      if (offset <= node3.length) return [node3, offset];
      offset -= node3.length;
    } else {
      const parent = node3.parentNode;
      if (offset <= 1) return [parent, [...parent.childNodes].indexOf(node3) + offset];
      offset--;
    }
  }
  return [editor2, editor2.childNodes.length];
}
function insertDictation(editor2, anchor, transcript4) {
  const { start, end, text } = anchor;
  const before = text[start - 1] || "";
  const after = text[end] || "";
  const leftSpace = /[^\s\uFFFC([{«„]/u.test(before) && !/^[,.!?;:…)}\]»”]/u.test(transcript4);
  const rightSpace = /[^\s\uFFFC,.!?;:…)}\]»”]/u.test(after);
  const insertion = (leftSpace ? " " : "") + transcript4 + (rightSpace ? " " : "");
  editor2.focus({ preventScroll: true });
  const selection = window.getSelection();
  if (!selection) return false;
  const range2 = document.createRange();
  range2.setStart(...pointAt(editor2, start));
  range2.setEnd(...pointAt(editor2, end));
  selection.removeAllRanges();
  selection.addRange(range2);
  return document.execCommand("insertText", false, insertion);
}

// source/dictation.js
var formSelector2 = 'form[data-slot="composer-root"]';
var editorSelector = '[data-slot="composer-rich-input"][contenteditable="true"]';
var hubSelector = '[data-slot="fan-menu-anchor"] > button:has(> .codicon-mic)';
var inputCell = '[class~="[grid-area:input]"]';
var captions = {
  ru: { record: "\u0413\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u044F \u0434\u0438\u043A\u0442\u043E\u0432\u043A\u0430", stop: "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u0434\u0438\u043A\u0442\u043E\u0432\u043A\u0443", cancel: "\u041E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u0434\u0438\u043A\u0442\u043E\u0432\u043A\u0443", starting: "\u041F\u043E\u0434\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u0435 \u043C\u0438\u043A\u0440\u043E\u0444\u043E\u043D\u0430\u2026", transcribing: "\u0420\u0430\u0441\u0448\u0438\u0444\u0440\u043E\u0432\u043A\u0430 \u0434\u0438\u043A\u0442\u043E\u0432\u043A\u0438\u2026", error: "\u0414\u0438\u043A\u0442\u043E\u0432\u043A\u0430 \u043D\u0435 \u0443\u0434\u0430\u043B\u0430\u0441\u044C", denied: "\u041D\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u0430 \u043A \u043C\u0438\u043A\u0440\u043E\u0444\u043E\u043D\u0443", empty: "\u0420\u0435\u0447\u044C \u043D\u0435 \u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u0430", insert: "\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0434\u0438\u043A\u0442\u043E\u0432\u043A\u0443 \u0432 \u0447\u0435\u0440\u043D\u043E\u0432\u0438\u043A" },
  en: { record: "Voice dictation", stop: "Stop dictation", cancel: "Cancel dictation", starting: "Connecting microphone\u2026", transcribing: "Transcribing dictation\u2026", error: "Dictation failed", denied: "Microphone access denied", empty: "No speech detected", insert: "Could not insert dictation in the draft" }
};
var words2 = () => captions[document.documentElement.lang.toLowerCase().startsWith("ru") ? "ru" : "en"];
var formats = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus", "audio/ogg", "audio/wav"];
function composerTarget(form) {
  return form.closest("[data-floating-composer-target]")?.dataset.floatingComposerTarget ?? form.closest("[data-composer-target]")?.dataset.composerTarget;
}
function nativeVoice(form) {
  if (!form?.isConnected || form.closest("[data-pane-hidden], [inert]") || !form.getClientRects().length) return null;
  const editor2 = form.querySelector(editorSelector);
  if (!editor2) return null;
  for (let fiber = committedFiber(editor2); fiber; fiber = fiber.return) {
    const props = fiber.memoizedProps;
    if (typeof props?.onTranscribeAudio !== "function" || typeof props.state?.voice?.enabled !== "boolean") continue;
    if (!props.state.voice.enabled || props.disabled) return null;
    const target = composerTarget(form);
    const grid = editor2.closest(inputCell)?.parentElement;
    if (!target || !grid) return null;
    return {
      form,
      editor: editor2,
      grid,
      target,
      transcribe: props.onTranscribeAudio,
      limit: props.maxRecordingSeconds ?? 120,
      address: JSON.stringify([
        target,
        props.sessionId,
        props.queueSessionKey,
        host24.state.connectionId.get(),
        host24.state.profile.get(),
        target === "main" ? host24.state.activeSessionId.get() : null
      ])
    };
  }
  return null;
}
function nativeMenuOwner(item) {
  if (!item || item.getAttribute("data-disabled") !== null || !Object.values(captions).some((copy7) => item.textContent.trim() === copy7.record)) return null;
  const id2 = item.closest('[role="menu"]')?.id;
  return id2 ? document.querySelector(`${formSelector2} button[aria-controls="${CSS.escape(id2)}"]`) : null;
}
function createStrip(grid, abort, stop) {
  const strip2 = document.createElement("div");
  strip2.setAttribute("data-hcv-dictation", "");
  const cancel = document.createElement("button");
  cancel.type = "button";
  cancel.setAttribute("data-hcv-dictation-cancel", "");
  cancel.addEventListener("click", abort);
  const wave = document.createElement("canvas");
  wave.setAttribute("aria-hidden", "true");
  const status2 = document.createElement("span");
  status2.setAttribute("role", "status");
  status2.setAttribute("data-hcv-dictation-caption", "");
  const finish = document.createElement("button");
  finish.type = "button";
  finish.setAttribute("data-hcv-dictation-stop", "");
  finish.addEventListener("click", stop);
  strip2.append(cancel, wave, status2, finish);
  grid.append(strip2);
  return { strip: strip2, cancel, wave, status: status2, finish };
}
function startWaveform(canvas, stream) {
  const graphics = canvas.getContext("2d");
  if (!graphics) return () => {
  };
  let audio;
  let analyser;
  try {
    audio = new AudioContext();
    analyser = audio.createAnalyser();
    analyser.fftSize = 256;
    audio.createMediaStreamSource(stream).connect(analyser);
    void audio.resume().catch(() => {
    });
  } catch {
    analyser = null;
  }
  const samples = new Float32Array(256);
  const history2 = [];
  const motion2 = matchMedia("(prefers-reduced-motion: reduce)");
  const stillPattern = [0.3, 0.5, 1, 0.7, 0.4, 0.7];
  const step2 = 5;
  let lastSample = -Infinity;
  let lastFrame;
  let level = 0;
  let phase = 0;
  let frame;
  const paint = (now) => {
    if (analyser && now - lastSample >= 100) {
      lastSample = now;
      analyser.getFloatTimeDomainData(samples);
      const energy = samples.reduce((sum, sample) => sum + sample ** 2, 0);
      const rms = Math.sqrt(energy / samples.length);
      level = rms < 25e-4 ? 0 : Math.min(1, 8 * rms);
    }
    phase += Math.min(100, now - (lastFrame ?? now)) * 0.06;
    lastFrame = now;
    while (phase >= step2) {
      phase -= step2;
      history2.push(level);
      if (history2.length > 256) history2.shift();
    }
    frame = requestAnimationFrame(paint);
    const { clientWidth: width, clientHeight: height } = canvas;
    if (!width || !height) return;
    const scale = window.devicePixelRatio || 1;
    if (canvas.width !== Math.round(width * scale) || canvas.height !== Math.round(height * scale)) {
      canvas.width = Math.round(width * scale);
      canvas.height = Math.round(height * scale);
    }
    graphics.setTransform(scale, 0, 0, scale, 0, 0);
    graphics.clearRect(0, 0, width, height);
    graphics.fillStyle = getComputedStyle(canvas).color;
    const reduced = motion2.matches;
    for (let index = 0, x = width - 2 - (reduced ? 0 : phase); x > 0; index++, x -= step2) {
      const amplitude = reduced ? level * stillPattern[index % stillPattern.length] : history2.at(-1 - index) ?? 0;
      const fade = Math.min(1, Math.min(x, width - x - 2) / 20);
      const bar = 2 + amplitude * (0.88 * height - 2);
      graphics.globalAlpha = (amplitude ? 0.45 : 0.225) * fade * fade * (3 - 2 * fade);
      graphics.beginPath();
      graphics.roundRect(Math.round(x * scale) / scale, (height - bar) / 2, 2, bar, 1);
      graphics.fill();
    }
    graphics.globalAlpha = 1;
  };
  frame = requestAnimationFrame(paint);
  return () => {
    cancelAnimationFrame(frame);
    if (audio && audio.state !== "closed") void audio.close().catch(() => {
    });
  };
}
function styles5(active2) {
  const row5 = `${active2} [data-hcv-dictation]`;
  const surface5 = `${active2} [data-slot="composer-surface"]:has([data-hcv-dictation])`;
  const layout = "div:has(> [data-hcv-dictation])";
  const hub = `${surface5} button[data-hcv-dictation-hub]`;
  return `
@media (forced-colors: none) {
  ${surface5} { background-color: var(--hcv-composer); background-clip: padding-box; }
  ${surface5} [data-slot="composer-fade"] { border-radius: inherit; }
  ${surface5} ${layout} {
    grid-template-areas: "input input input" "menu dictation controls";
    grid-template-columns: auto minmax(28px, 1fr) auto;
    align-items: center; gap: 4px;
  }
  ${surface5}:not(:has(button[data-hcv-dictation-hub])) ${layout} {
    grid-template-areas: "input input" "dictation dictation" "menu controls";
    grid-template-columns: auto minmax(0, 1fr);
  }
  ${surface5} [class~="[grid-area:menu]"] { translate: none; align-self: center; }
  ${row5} { grid-area: dictation; display: flex; min-inline-size: 0; align-items: center; gap: 8px; color: var(--hcv-muted); }
  ${row5} button, ${hub} {
    display: grid; place-items: center; flex: none; inline-size: 28px; block-size: 28px; padding: 0;
    border-radius: 50%; color: var(--hcv-text); background: color-mix(in srgb, currentColor 6%, transparent);
  }
  ${row5} button:hover, ${hub}:hover { background: color-mix(in srgb, currentColor 13%, transparent); }
  ${row5} button:focus-visible, ${hub}:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: -2px; }
  ${row5} button::before, ${hub}::after { content: ''; }
  ${row5} [data-hcv-dictation-cancel]::before {
    inline-size: 14px; block-size: 14px; background: currentColor; mask: ${codexMask("close")} center / contain no-repeat;
  }
  ${row5} [data-hcv-dictation-stop]::before, ${hub}::after {
    inline-size: 16px; block-size: 16px; background: currentColor;
    mask: ${codexMask("dictationStop")} center / contain no-repeat;
  }
  ${hub}::before { display: none !important; }
  ${surface5}:has(button[data-hcv-dictation-hub]) [data-hcv-dictation-stop],
  ${row5}:not([data-state="recording"]) [data-hcv-dictation-stop],
  ${row5}[data-state="recording"] [data-hcv-dictation-caption],
  ${row5}:not([data-state="recording"]) canvas { display: none; }
  ${row5} canvas {
    display: block; flex: 1 1 0; inline-size: 0; min-inline-size: 0; block-size: 28px;
    color: var(--hcv-text);
  }
  ${row5} [data-hcv-dictation-caption] {
    min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px;
  }
  ${hub}[data-hcv-dictation-hub="transcribing"]::after {
    mask: ${codexMask("sidebarWorking")} center / contain no-repeat;
  }
  @media (prefers-reduced-motion: no-preference) {
    ${hub}[data-hcv-dictation-hub="transcribing"]::after { animation: hcv-sidebar-spin 2s steps(60, end) infinite; }
  }
}
`;
}
function registerDictation(ctx, active2) {
  const sheet = document.createElement("style");
  sheet.setAttribute("data-hcv-dictation-style", "");
  sheet.textContent = styles5(active2);
  mountStyle(ctx, sheet, { surface: "[data-hcv-dictation]" });
  const root = document.documentElement;
  const contrast = matchMedia("(forced-colors: none)");
  const selections = /* @__PURE__ */ new WeakMap();
  let current;
  let frame;
  const enabled = () => contrast.matches && root.matches(active2);
  function rememberSelection() {
    const editor2 = window.getSelection()?.anchorNode;
    const input = (editor2 instanceof Element ? editor2 : editor2?.parentElement)?.closest(editorSelector);
    const position2 = input && draftSelection(input);
    if (position2) selections.set(input, { ...position2, text: draftText(input) });
  }
  function valid(run) {
    const live = enabled() && nativeVoice(run.form);
    return live && live.address === run.address && live.editor === run.editor && live.grid === run.grid;
  }
  function restoreHub(run) {
    if (!run.hub) return;
    const { button: button5, label: label3, pressed } = run.hub;
    button5.removeAttribute("data-hcv-dictation-hub");
    for (const [key, value] of [["aria-label", label3], ["aria-pressed", pressed]]) {
      if (value === null) button5.removeAttribute(key);
      else button5.setAttribute(key, value);
    }
    run.hub = null;
  }
  function paint(run) {
    const copy7 = words2();
    const button5 = run.form.querySelector(hubSelector);
    if (run.hub?.button !== button5) {
      restoreHub(run);
      if (button5) run.hub = { button: button5, label: button5.getAttribute("aria-label"), pressed: button5.getAttribute("aria-pressed") };
    }
    if (button5) {
      button5.dataset.hcvDictationHub = run.phase;
      button5.setAttribute("aria-label", run.phase === "transcribing" ? copy7.transcribing : copy7.stop);
      button5.setAttribute("aria-pressed", "true");
    }
    const { strip: strip2, cancel: cancel2, status: status2, finish } = run.ui;
    strip2.dataset.state = run.phase;
    cancel2.setAttribute("aria-label", copy7.cancel);
    cancel2.title = copy7.cancel;
    finish.setAttribute("aria-label", copy7.stop);
    finish.title = copy7.stop;
    const caption2 = copy7[run.phase] || copy7.record;
    if (status2.textContent !== caption2) status2.textContent = caption2;
  }
  function release(run) {
    clearTimeout(run.timeout);
    run.stopWaveform?.();
    run.stopWaveform = null;
    run.stream?.getTracks().forEach((track) => track.stop());
  }
  function cancel(run = current) {
    if (!run || run !== current) return;
    current = null;
    run.observer.disconnect();
    if (run.recorder) {
      run.recorder.onstop = null;
      run.recorder.onerror = null;
      if (run.recorder.state !== "inactive") run.recorder.stop();
    }
    release(run);
    restoreHub(run);
    run.ui.strip.remove();
  }
  function updateAnchor(run) {
    const next = draftText(run.editor);
    updateDictationAnchor(run.anchor, next, run.edit);
    run.edit = null;
  }
  async function transcribe(run) {
    release(run);
    if (current !== run || !valid(run)) return cancel(run);
    run.phase = "transcribing";
    paint(run);
    try {
      const audio = new Blob(run.chunks, { type: run.recorder.mimeType || run.chunks[0]?.type });
      const text = audio.size ? (await run.transcribe(audio)).trim() : "";
      if (current !== run || !valid(run)) return;
      if (text) {
        updateAnchor(run);
        if (!insertDictation(run.editor, run.anchor, text)) throw new Error(words2().insert);
      } else host24.notify({ kind: "warning", title: words2().empty });
    } catch (error) {
      if (current === run && valid(run)) host24.notifyError(error, words2().error);
    } finally {
      cancel(run);
    }
  }
  function stop(run) {
    if (current !== run || run.phase === "transcribing") return;
    if (run.phase === "starting" || !valid(run)) return cancel(run);
    clearTimeout(run.timeout);
    run.phase = "transcribing";
    paint(run);
    if (run.recorder.state !== "inactive") run.recorder.stop();
  }
  async function record(run) {
    try {
      const permitted = await window.hermesDesktop?.requestMicrophoneAccess?.();
      if (permitted === false) throw new Error(words2().denied);
      if (current !== run || !valid(run)) return cancel(run);
      const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      if (current !== run || !valid(run)) {
        stream.getTracks().forEach((track) => track.stop());
        return cancel(run);
      }
      run.stream = stream;
      const mimeType = formats.find((type) => MediaRecorder.isTypeSupported(type));
      const recorder = run.recorder = new MediaRecorder(stream, mimeType ? { mimeType } : void 0);
      recorder.ondataavailable = (event) => {
        if (event.data.size) run.chunks.push(event.data);
      };
      recorder.onstop = () => void transcribe(run);
      recorder.onerror = (event) => {
        if (current !== run) return;
        cancel(run);
        host24.notifyError(event.error, words2().error);
      };
      recorder.start();
      run.phase = "recording";
      paint(run);
      run.stopWaveform = startWaveform(run.ui.wave, stream);
      run.timeout = window.setTimeout(() => stop(run), Math.min(600, Math.max(1, run.limit)) * 1e3);
    } catch (error) {
      if (current !== run) return;
      cancel(run);
      host24.notifyError(error, words2().error);
    }
  }
  function toggle2(form) {
    if (!enabled() || !navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") return false;
    if (current?.form === form) {
      stop(current);
      return true;
    }
    const voice = nativeVoice(form);
    if (!voice) return false;
    cancel();
    const { editor: editor2, grid } = voice;
    const text = draftText(editor2);
    const selection = draftSelection(editor2);
    const anchor = selection ? { ...selection, text } : { ...selections.get(editor2) };
    if (anchor.text === void 0) Object.assign(anchor, { text, start: text.length, end: text.length });
    else updateDictationAnchor(anchor, text);
    const run = current = { ...voice, anchor, phase: "starting", chunks: [] };
    run.ui = createStrip(grid, () => cancel(run), () => stop(run));
    run.observer = new MutationObserver(() => updateAnchor(run));
    run.observer.observe(editor2, { childList: true, characterData: true, subtree: true });
    paint(run);
    void record(run);
    return true;
  }
  function refresh() {
    frame = 0;
    if (!current) return;
    if (!valid(current)) cancel();
    else paint(current);
  }
  const schedule = () => {
    if (current && !frame) frame = requestAnimationFrame(refresh);
  };
  const observer = new MutationObserver(schedule);
  observer.observe(root, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["data-hermes-theme", "data-hermes-codex-visual", "data-pane-hidden", "contenteditable", "inert", "lang"]
  });
  const off = [host24.state.activeSessionId, host24.state.connectionId, host24.state.profile].map((state) => state.listen(schedule));
  contrast.addEventListener("change", schedule);
  ctx.addEventListener(document, "selectionchange", rememberSelection);
  ctx.addEventListener(document, "pointerdown", rememberSelection, true);
  ctx.addEventListener(document, "beforeinput", (event) => {
    if (event.target === current?.editor) {
      current.edit = draftSelection(current.editor, event.getTargetRanges?.()[0]);
    }
  }, true);
  ctx.addEventListener(document, "input", (event) => {
    if (event.target === current?.editor) updateAnchor(current);
  });
  ctx.addEventListener(document, "click", (event) => {
    if (!(event.target instanceof Element)) return;
    if (current && event.target.closest('button:is([aria-label="\u041D\u0430\u0447\u0430\u0442\u044C \u0433\u043E\u043B\u043E\u0441\u043E\u0432\u043E\u0439 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440"], [aria-label="Start voice conversation"])')) cancel();
    const item = event.target.closest('[role="menuitemcheckbox"]');
    const trigger = item && nativeMenuOwner(item);
    const button5 = event.target.closest(hubSelector) || trigger;
    if (!button5 || button5.disabled || !toggle2(button5.closest(formSelector2))) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    item?.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true, cancelable: true }));
  }, true);
  ctx.addEventListener(window, "hermes:composer-dictation", (event) => {
    const form = [...document.querySelectorAll(formSelector2)].find(
      (node3) => composerTarget(node3) === event.detail?.target && nativeVoice(node3)
    );
    if (form && toggle2(form)) event.stopImmediatePropagation();
  }, true);
  ctx.addEventListener(window, "hermes:composer-voice-toggle", () => cancel(), true);
  ctx.addEventListener(document, "keydown", (event) => {
    if (current && event.target === current.editor && event.key === "Enter" && !event.shiftKey && !event.isComposing && event.keyCode !== 229 && !current.form.querySelector('[data-slot="composer-completion-drawer"]')) cancel();
  }, true);
  ctx.addEventListener(document, "submit", (event) => {
    if (event.target === current?.form) cancel();
  }, true);
  ctx.addEventListener(window, "pagehide", () => cancel());
  ctx.onDispose(() => {
    cancel();
    if (frame) cancelAnimationFrame(frame);
    observer.disconnect();
    contrast.removeEventListener("change", schedule);
    for (const unsubscribe of off) unsubscribe();
    sheet.remove();
  });
}

// source/zoom-banner.js
var ZOOM_BASE = 1.2;
var ZOOM_STEP = 0.1;
var MIN_FACTOR = 0.5;
var MAX_FACTOR = 3;
var DISMISS_DELAY = 2e3;
var EXIT_TIME = 150;
var minusFallback = svgMask('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M5 12h14" fill="none" stroke="white" stroke-width="1.8" stroke-linecap="round"/></svg>');
var minusMask = localAssets?.icons?.imagePreviewMinus ? svgMask(localAssets.icons.imagePreviewMinus) : minusFallback;
var plusMask = localAssets?.icons?.imagePreviewPlus ? svgMask(localAssets.icons.imagePreviewPlus) : codexMask("plus");
function registerZoomBanner(ctx, active2, themeName2) {
  const zoom2 = window.hermesDesktop?.zoom;
  if (!zoom2?.get || !zoom2?.setPercent || !zoom2?.onChanged) return;
  const root = document.documentElement;
  const layerSelector = `${active2} [data-hcv-zoom-layer]`;
  const bannerSelector = `${layerSelector} [data-hcv-zoom-banner]`;
  mountCSS(ctx, "data-hcv-zoom-styles", `
    ${layerSelector} {
      position: fixed; top: 8px; z-index: 90; display: flex; justify-content: flex-end;
      pointer-events: none; opacity: 1; transform: translateY(0);
      transition: opacity 150ms ease-out, transform 150ms ease-out;
      -webkit-app-region: no-drag;
    }
    ${layerSelector}[data-state="exiting"] { opacity: 0; transform: translateY(-4px); }
    ${bannerSelector} {
      box-sizing: border-box; display: inline-flex; align-items: center; height: 44px;
      overflow: hidden; padding: 0 8px; border: .5px solid; border-radius: 20px;
      pointer-events: auto; white-space: nowrap; font: 400 13px / 1 ${codexReference.font};
      box-shadow: 0 8px 16px -4px rgba(0, 0, 0, .12);
      animation: hcv-zoom-enter 150ms ${codexReference.enter} both;
    }
    ${bannerSelector} [data-hcv-zoom-value] {
      display: inline-block; flex: none; width: 48px; text-align: center;
      font: 600 13px / 1.428571 ${codexReference.font}; font-variant-numeric: tabular-nums;
    }
    ${bannerSelector} [data-hcv-zoom-controls] { display: flex; align-items: center; margin-inline-start: 4px; }
    ${bannerSelector} button {
      box-sizing: border-box; display: inline-flex; flex: none; align-items: center;
      justify-content: center; height: 28px; padding: 0 8px; border: 0; border-radius: 6px;
      background: transparent; font: 400 13px / 1 ${codexReference.font}; cursor: pointer;
    }
    ${bannerSelector} button[data-hcv-zoom-step] { width: 28px; padding: 0; }
    ${bannerSelector} button[data-hcv-zoom-step]::before {
      content: ''; display: block; width: 16px; height: 16px; background: currentColor;
      mask: ${minusMask} center / contain no-repeat;
    }
    ${bannerSelector} button[data-hcv-zoom-step="in"]::before { mask-image: ${plusMask}; }
    ${bannerSelector} [data-hcv-zoom-separator] { flex: none; width: 1px; height: 16px; margin: 0 4px; background: currentColor; opacity: .12; }
    ${bannerSelector} button:disabled { opacity: .5; cursor: default; }
    ${bannerSelector} button:focus-visible { outline: 2px solid var(--hcv-focus); outline-offset: 2px; }
    @media (forced-colors: none) {
      ${bannerSelector} { color: light-dark(#0d0d0d, #ededed); background: light-dark(#f9f9f9, #181818); border-color: light-dark(#0d0d0d1a, #ffffff1f); }
      ${bannerSelector} button { color: light-dark(#8f8f8f, #8f8f8f); }
      ${bannerSelector} button:not(:disabled):hover { background: light-dark(#0d0d0d0f, #ffffff0f); }
    }
    @media (prefers-reduced-motion: reduce) {
      ${layerSelector} { transition: none; }
      ${layerSelector}[data-state="exiting"] { transform: none; }
      ${bannerSelector} { animation: none; }
    }
    @keyframes hcv-zoom-enter {
      from { opacity: 0; transform: translateY(-4px) scale(.98); }
      to { opacity: 1; transform: translateY(0) scale(1); }
    }
  `);
  let current = null;
  let revision = 0;
  let layer = null;
  let dismissTimer = null;
  let exitTimer = null;
  let hovered = false;
  let disposed = false;
  function clearTimers() {
    clearTimeout(dismissTimer);
    clearTimeout(exitTimer);
    dismissTimer = exitTimer = null;
  }
  function remove() {
    clearTimers();
    layer?.remove();
    layer = null;
    hovered = false;
  }
  function exit() {
    if (!layer) return;
    clearTimers();
    layer.dataset.state = "exiting";
    exitTimer = setTimeout(remove, EXIT_TIME);
  }
  function position2() {
    if (!layer) return;
    const overlay2 = navigator.windowControlsOverlay;
    const rect = overlay2?.visible ? overlay2.getTitlebarAreaRect() : null;
    const right = rect?.width ? Math.max(0, Math.round(window.innerWidth - rect.right)) : 0;
    layer.style.right = `${16 + right}px`;
  }
  function update() {
    if (!layer || !current) return;
    layer.querySelector("[data-hcv-zoom-value]").textContent = `${current.percent}%`;
    layer.querySelector("[data-hcv-zoom-reset]").disabled = Math.abs(current.level) < 1e-9;
  }
  function create() {
    const ru = root.matches(":lang(ru)");
    layer = document.createElement("div");
    layer.dataset.hcvZoomLayer = "";
    layer.dataset.state = "visible";
    const banner = document.createElement("div");
    banner.dataset.hcvZoomBanner = "";
    const value = document.createElement("span");
    value.dataset.hcvZoomValue = "";
    value.setAttribute("aria-live", "polite");
    const controls2 = document.createElement("div");
    controls2.dataset.hcvZoomControls = "";
    for (const [direction, label3] of [["out", ru ? "\u0423\u043C\u0435\u043D\u044C\u0448\u0438\u0442\u044C" : "Zoom out"], ["in", ru ? "\u0423\u0432\u0435\u043B\u0438\u0447\u0438\u0442\u044C" : "Zoom in"]]) {
      const button5 = document.createElement("button");
      button5.type = "button";
      button5.dataset.hcvZoomStep = direction;
      button5.setAttribute("aria-label", label3);
      button5.addEventListener("click", () => step2(direction === "in" ? 1 : -1));
      controls2.append(button5);
    }
    const separator = document.createElement("span");
    separator.dataset.hcvZoomSeparator = "";
    separator.setAttribute("aria-hidden", "true");
    const reset = document.createElement("button");
    reset.type = "button";
    reset.dataset.hcvZoomReset = "";
    reset.textContent = ru ? "\u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C" : "Reset";
    reset.addEventListener("click", () => {
      zoom2.setPercent(100);
      show();
    });
    banner.addEventListener("mouseenter", () => {
      hovered = true;
    });
    banner.addEventListener("mouseleave", () => {
      hovered = false;
      if (dismissTimer === null && layer?.dataset.state === "visible") exit();
    });
    banner.append(value, controls2, separator, reset);
    layer.append(banner);
    document.body.append(layer);
    position2();
  }
  function show() {
    if (disposed || root.dataset.hermesTheme !== themeName2 || !current) return;
    if (!layer) create();
    clearTimers();
    layer.dataset.state = "visible";
    update();
    dismissTimer = setTimeout(() => {
      dismissTimer = null;
      if (!hovered) exit();
    }, DISMISS_DELAY);
  }
  function step2(direction) {
    if (!current) return;
    const factor = Math.pow(ZOOM_BASE, current.level);
    const target = Math.round(100 * Math.min(MAX_FACTOR, Math.max(MIN_FACTOR, factor + ZOOM_STEP * direction)));
    zoom2.setPercent(target);
    show();
  }
  const off = zoom2.onChanged((state) => {
    if (disposed || !Number.isFinite(state?.level) || !Number.isFinite(state?.percent)) return;
    revision++;
    const previous = current;
    current = state;
    update();
    if (previous && Math.abs(previous.level - state.level) > 1e-9) show();
  });
  void zoom2.get().then((state) => {
    if (!disposed && revision === 0 && Number.isFinite(state?.level) && Number.isFinite(state?.percent)) current = state;
  }).catch(() => {
  });
  const themeObserver = new MutationObserver(() => {
    if (root.dataset.hermesTheme !== themeName2) remove();
  });
  themeObserver.observe(root, { attributes: true, attributeFilter: ["data-hermes-theme"] });
  ctx.addEventListener(window, "resize", position2);
  const overlay = navigator.windowControlsOverlay;
  overlay?.addEventListener("geometrychange", position2);
  ctx.onDispose(() => {
    disposed = true;
    off?.();
    overlay?.removeEventListener("geometrychange", position2);
    themeObserver.disconnect();
    remove();
  });
}

// source/plugin.js
var id = "hermes-codex-visual";
var marker3 = `data-${id}`;
var themeName = "codex-workspace";
var active = `:root[${marker3}][data-hermes-theme="${themeName}"]`;
var sidebar = `${active} [data-slot="sidebar"][data-tour="sessions-sidebar"]`;
var chat2 = `${active} [data-chat-surface]`;
var dock = `${chat2} [data-slot="composer-dock"]`;
var composerSurface = `${dock} [data-slot="composer-surface"]`;
var docked = `${dock}:not([data-popped-out])`;
var light = {
  rail: "#f2f2f2",
  sidebar: "#f6f6f6",
  chat: "#ffffff",
  panel: "#fafafa",
  summary: "#f5f5f5",
  menu: "#ffffff",
  bubble: "#ededed",
  composer: "#f5f5f5",
  hover: "#eeeeee",
  selected: "#e5e5e5",
  stroke: "#d5d5d5",
  text: "#202020",
  muted: "#5e5e5e",
  focus: "#656565",
  action: "#242424",
  ink: "#ffffff",
  unread: "#0766cb",
  error: "#aa2626",
  errorInk: "#ffffff"
};
var dark = {
  rail: "#121212",
  sidebar: "#161616",
  chat: "#181818",
  panel: "#202020",
  summary: "#222222",
  menu: "#2d2d2d",
  bubble: "#222222",
  composer: "#363636",
  hover: "#252525",
  selected: "#292929",
  stroke: "#393939",
  text: "#e8e8e8",
  muted: "#a9a9a9",
  focus: "#a6a6a6",
  action: "#e8e8e8",
  ink: "#181818",
  unread: "#339cf5",
  error: "#f28080",
  errorInk: "#210909"
};
function themeColors(palette) {
  return {
    background: palette.chat,
    foreground: palette.text,
    card: palette.panel,
    cardForeground: palette.text,
    muted: palette.hover,
    mutedForeground: palette.muted,
    popover: palette.menu,
    popoverForeground: palette.text,
    primary: palette.action,
    primaryForeground: palette.ink,
    secondary: palette.selected,
    secondaryForeground: palette.text,
    accent: palette.selected,
    accentForeground: palette.text,
    border: palette.stroke,
    input: palette.stroke,
    ring: palette.focus,
    midground: palette.focus,
    midgroundForeground: palette.ink,
    composerRing: palette.focus,
    destructive: palette.error,
    destructiveForeground: palette.errorInk,
    sidebarBackground: palette.sidebar,
    sidebarBorder: palette.stroke,
    userBubble: palette.bubble,
    userBubbleBorder: palette.bubble
  };
}
var theme = {
  name: themeName,
  label: "Codex",
  description: "\u0421\u0432\u0435\u0442\u043B\u043E\u0435 \u0438 \u0442\u0451\u043C\u043D\u043E\u0435 \u043E\u0444\u043E\u0440\u043C\u043B\u0435\u043D\u0438\u0435 Codex",
  colors: themeColors(light),
  darkColors: themeColors(dark)
};
function paletteVariables({ error, errorInk, ...colors }) {
  return Object.entries(colors).map(([name, color]) => `--hcv-${name}: ${color};`).join("\n    ");
}
var newChatLabel = '[data-tour="sidebar-nav-new-session"]';
var chevron = "svg.tabler-icon-chevron-down";
var sidebarMenuButton = `${sidebar} [data-sidebar="menu-button"]`;
var sidebarNav = `${sidebarMenuButton}[data-hcv-sidebar-nav]`;
var sidebarFill = `${sidebarNav} > [data-hcv-sidebar-fill]`;
var navButton = (name) => `${sidebarMenuButton}:has(> [data-tour="sidebar-nav-${name}"])`;
var localizedNewChat = `${navButton("new-session")}:is(:lang(ru), :lang(en))`;
var titleButton = `${active} [data-titlebar-cluster] button[data-size="icon-titlebar"]`;
var foldOnly = `${composerSurface} button:has(> ${chevron}):not(:has(> :not(${chevron})))`;
var sidebarChatRow = `${sidebar} ${sidebarSessionRow}`;
var runningDot = '[role="status"]:is([class~="bg-(--ui-accent)"], [class~="border-(--ui-accent)"])';
var unreadDot = '[role="status"][class~="bg-(--ui-success)"]';
var trailingDot = `:is(${runningDot}, ${unreadDot})`;
var busyRowState = `:has(${runningDot})`;
var unreadRowState = `:has(${unreadDot})`;
var activeSidebarChatRow = `${sidebarChatRow}:is(${busyRowState}, ${unreadRowState})`;
var sidebarStatus = `${sidebar} [data-hcv-project-status]:not([hidden])`;
var sidebarWorking = `${sidebar} [data-hcv-project-status="working"]:not([hidden])`;
var workingChatIcon = `${sidebarChatRow}${busyRowState}::after`;
var changedFiles2 = `${chat2} [data-slot="aui_changed-files"]`;
var fileSummary = `${changedFiles2}[data-hcv-file-card]`;
var fileHeader = `${fileSummary} > div:first-child`;
var fileList = `${fileSummary} > div:nth-child(2)`;
var fileRow = `${fileList} > button`;
var assistantRoot = `${chat2} [data-slot="aui_assistant-message-root"]`;
var elapsedBar = `${chat2} [data-hcv-turn-line]`;
var liveTurn = `${chat2} :is([data-slot="aui_response-loading"], [data-slot="aui_turn-activity"][data-state="active"], [data-hcv-live-turn])`;
var thinkingLabel = `${liveTurn} > [data-hcv-thinking]`;
var thinkingSweep = `${thinkingLabel} > [data-hcv-thinking-sweep]`;
var arrow = codexMask("turnDisclosure");
var glyphs3 = [
  [navButton("new-session"), ".codicon-robot", "newChat"],
  [navButton("capabilities"), ".codicon-symbol-misc", "plugins"],
  [navButton("messaging"), ".codicon-comment", "messages"],
  [navButton("artifacts"), ".codicon-files", "artifacts"],
  [navButton("cron"), ".codicon-watch", "schedule"],
  [titleButton, ".codicon-layout-sidebar-left", "sidebar"],
  [titleButton, ".codicon-layout-sidebar-right", "sidebarRight", true],
  [foldOnly, chevron, "sliders"],
  [`${composerSurface} button`, ":is(.codicon-mic, svg.tabler-icon-microphone)", "mic"],
  [`${composerSurface} button[type="submit"]`, ".codicon-arrow-up", "send"]
];
function iconRules() {
  return glyphs3.map(([button5, nativeIcon2, icon8, flip]) => {
    const selector = `${button5}:has(> ${nativeIcon2})`;
    return `
  ${selector} > ${nativeIcon2} { display: none; }
  ${selector}::before {
    content: '';
    display: block;
    flex: none;
    inline-size: 16px;
    block-size: 16px;
    background: currentColor;
    mask: ${codexMask(icon8)} center / contain no-repeat;
    ${flip ? "scale: -1 1;" : ""}
    pointer-events: none;
  }`;
  }).join("\n");
}
var styles6 = `
@media (forced-colors: none) {
  ${active} {
    ${paletteVariables(light)}
    --hcv-ui-font: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif;
    --ui-bg-chrome: var(--hcv-rail);
    --hcv-sidebar-highlight: var(--hcv-selected);
    --ui-bg-sidebar: var(--hcv-sidebar);
    --ui-bg-editor: var(--hcv-chat);
    --ui-bg-elevated: var(--hcv-menu);
    --ui-bg-card: var(--hcv-panel);
    --ui-bg-input: var(--hcv-composer);
    --ui-surface-background: var(--hcv-chat);
    --ui-sidebar-surface-background: var(--hcv-sidebar);
    --ui-chat-surface-background: var(--hcv-chat);
    --ui-widget-surface-background: var(--hcv-panel);
    --ui-chat-bubble-background: var(--hcv-bubble);
    --ui-row-hover-background: var(--hcv-hover);
    --ui-row-active-background: var(--hcv-selected);
    --ui-row-open-background: var(--hcv-hover);
    --ui-control-hover-background: var(--hcv-hover);
    --ui-control-active-background: var(--hcv-selected);
    --ui-text-primary: var(--hcv-text);
    --ui-text-secondary: var(--hcv-muted);
    --ui-text-tertiary: var(--hcv-muted);
    --ui-accent: var(--hcv-focus);
    --ui-accent-secondary: var(--hcv-action);
    --ui-stroke-secondary: var(--hcv-stroke);
    --ui-stroke-tertiary: var(--hcv-stroke);
    --ui-selection-background: color-mix(in srgb, var(--hcv-text) 25%, transparent);
    --dt-background: var(--hcv-rail);
    --dt-card: var(--hcv-panel);
    --dt-popover: var(--hcv-menu);
    --dt-user-bubble: var(--hcv-bubble);
    --sidebar-edge-border: var(--hcv-stroke);
    --chrome-action-hover: var(--hcv-hover);
    --pane-tab-active-bg: var(--hcv-selected);
    --pane-tab-active-accent: transparent;
  }

  ${active}[data-hermes-mode="dark"] {
    ${paletteVariables(dark)}
  }

  ${active} :is(input, textarea)::placeholder {
    color: var(--hcv-muted);
    opacity: 1;
  }

  ${active} :is([data-titlebar-cluster], [data-hcv-sidebar-shell], [data-chat-surface]) {
    font-family: var(--hcv-ui-font);
  }

  ${active} :is([data-sidebar="menu-button"], [data-slot="pane-tab"], [data-slot="dropdown-menu-item"], [data-slot="dropdown-menu-sub-trigger"], [data-slot="dropdown-menu-radio-item"], [data-slot="dropdown-menu-checkbox-item"], [data-tour="overlay-nav"] button, [data-titlebar-cluster] [data-size="icon-titlebar"]),
  ${sidebar} .row-hover {
    border-radius: 8px;
  }

  /* The fixed ghost fill fades independently of the text and icon. */
  ${sidebarNav}, ${sidebarNav}:is(:hover, :active, :focus-visible, [data-active="true"]) {
    position: relative;
    isolation: isolate;
    background-color: transparent;
    border: 0;
    border-radius: 10px;
    transition: none;
  }

  @supports (corner-shape: superellipse(1.5)) {
    ${sidebarNav}, ${sidebarNav}:is(:hover, :active, :focus-visible, [data-active="true"]) {
      border-radius: 12.5px;
      corner-shape: superellipse(1.5);
    }
  }

  ${sidebarFill} {
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
    border-radius: inherit;
    corner-shape: inherit;
    background-color: var(--hcv-sidebar-highlight);
    opacity: 0;
    transition: none;
  }

  ${sidebarNav}:is(:focus-visible, :active, [data-active="true"], [class~="bg-(--ui-control-active-background)"]) > [data-hcv-sidebar-fill] { opacity: 1; }
  @media (hover: hover) {
    ${sidebarNav}:hover > [data-hcv-sidebar-fill] { opacity: 1; }
  }
  @media (prefers-reduced-motion: no-preference) {
    ${sidebarFill} { transition: opacity 150ms cubic-bezier(.4, 0, .2, 1); }
  }

  ${sidebarNav}:focus-visible {
    outline: 2px solid light-dark(#339cff, rgb(51 156 255 / 70%));
    outline-offset: -2px;
    box-shadow: none;
  }

  ${active} [data-slot="pane-tab"]:hover {
    background-color: var(--hcv-hover);
  }

  ${active} [data-slot="pane-tab"][data-active="true"] {
    background-color: var(--hcv-selected);
  }

  ${localizedNewChat} > ${newChatLabel} { display: none; }
  ${navButton("new-session")} > [data-slot="kbd-group"] { display: none; }
  ${navButton("new-session")}:lang(ru)::after { content: '\u041D\u043E\u0432\u044B\u0439 \u0447\u0430\u0442'; }
  ${navButton("new-session")}:lang(en)::after { content: 'New chat'; }
  ${localizedNewChat}::after { min-inline-size: 0; overflow: hidden; text-overflow: ellipsis; }

  ${sidebarChatRow} span[aria-hidden="true"][class~="size-1"][class~="rounded-full"] {
    opacity: 0;
  }
  ${sidebarChatRow} [data-row-actions] span:has(> time[datetime]) { display: none; }
  ${sidebarChatRow} [data-row-actions]:has(time[datetime]) > button[aria-haspopup="menu"] { position: static; }
  /* Keep native labels available to assistive technology. Paint the two
     relocated statuses on the right without moving any click targets. */
  ${activeSidebarChatRow} { padding-inline-end: 23px; }
  ${activeSidebarChatRow} ${trailingDot} { opacity: 0; }
  ${sidebarChatRow} > .arc-row { display: none; }
  ${activeSidebarChatRow}::after {
    position: absolute;
    inset-block-start: 50%;
    inset-inline-end: 7px;
    translate: 0 -50%;
    box-sizing: border-box;
    inline-size: 10px;
    block-size: 10px;
    border-radius: 50%;
    content: '';
    pointer-events: none;
  }
  ${sidebarStatus} {
    display: grid; place-items: center; flex: none;
    inline-size: 20px; block-size: 20px; pointer-events: none;
  }
  ${sidebarWorking}::before { content: ''; }
  ${workingChatIcon}, ${sidebarWorking}::before {
    inline-size: 16px; block-size: 16px;
    background: color-mix(in srgb, var(--hcv-text) 70%, transparent);
    mask: ${codexMask("sidebarWorking")} center / contain no-repeat;
    animation: hcv-sidebar-spin 2s steps(60, end) infinite;
  }
  ${workingChatIcon} { inset-inline-end: 8px; }
  ${sidebar} [data-hcv-project-status="unread"]:not([hidden])::before {
    content: ''; inline-size: 7px; block-size: 7px; border-radius: 50%; background: var(--hcv-unread);
  }
  ${sidebarChatRow}${unreadRowState}:not(${busyRowState})::after {
    background: var(--hcv-unread);
    scale: .75;
  }
  @keyframes hcv-sidebar-spin { to { rotate: 1turn; } }
  @media (prefers-reduced-motion: reduce) {
    ${workingChatIcon}, ${sidebarWorking}::before { animation: none; }
  }

  ${chat2} {
    /* Codex desktop's 48rem thread body has a 16px inset on each side. */
    --composer-width: 736px;
    --message-text-indent: 0px;
    --conversation-text-font-size: 13px;
    --conversation-tool-font-size: 12px;
    --conversation-line-height: 21px;
    --conversation-turn-gap: 18px;
    --scaffold-block-gap: 9px;
    --paragraph-gap: 10px;
  }

  /* Match the dock's own 16px inset without touching its scroll clearance. */
  ${chat2} [data-slot="aui_thread-content"] {
    /* Hermes's default text scale is 110%. Keep its scale control relative
       to the reference Desktop size of 14px. */
    --conversation-text-base-size: calc(14px / 1.1);
    --hcv-chat-prose: light-dark(#1a1c1f, #dfdfdf);
    max-inline-size: calc(var(--composer-width) + 32px);
    padding-inline: 16px;
  }
  ${assistantRoot} .aui-md.prose, ${chat2} [data-slot="aui_user-inline-text"] {
    color: var(--hcv-chat-prose, var(--hcv-text));
    font-weight: 430;
  }
  ${assistantRoot} .aui-md.prose {
    --tw-prose-bold: var(--hcv-chat-prose, var(--hcv-text));
    /* Codex assistant Markdown uses 1.625 line height and one font size
       between adjacent prose paragraphs. */
    --dt-line-height: 1.625;
    --paragraph-gap: var(--conversation-text-font-size);
    line-height: 1.625;
  }
  /* Codex Desktop's InlineCode-Cddi3Y in 0cf36033c2f9.css. Keep this
     scoped to inline snippets so fenced code and the editor stay unchanged. */
  ${assistantRoot} .aui-md.prose :not(pre) > code {
    font-family: ui-monospace, 'SFMono-Regular', 'SF Mono', menlo, consolas, 'Liberation Mono', monospace;
    font-size: .92em;
    font-weight: 400;
    line-height: inherit;
    color: inherit;
    background: color-mix(in srgb, currentColor 11.1%, transparent);
    padding: 1px 6px;
    border-radius: 6px;
    box-decoration-break: clone;
    overflow-wrap: anywhere;
    word-break: break-word;
  }
  /* Hermes already supplies the brand icon and the link's native actions. */
  ${assistantRoot} .aui-md.prose a.ref:is([href^="http://"], [href^="https://"]) {
    color: light-dark(#0169cc, #99ceff);
    font-weight: 500;
    text-decoration: none;
  }
  ${assistantRoot} .aui-md.prose a.ref:is([href^="http://"], [href^="https://"]) > svg {
    display: inline-block;
    inline-size: 16px;
    block-size: 16px;
    margin-inline-end: 3px;
    opacity: 1;
    vertical-align: middle;
    transform: translateY(calc(.5ex - .5cap));
  }
  ${assistantRoot} .aui-md.prose a.ref:is([href^="http://"], [href^="https://"]):is(:hover, :focus-visible) {
    text-decoration: underline dashed .5px;
    text-underline-offset: 2px;
  }

  ${chat2} [data-slot="aui_intro"] .wordmark { mix-blend-mode: normal; }
  ${chat2} [data-slot="aui_intro"] .wordmark + p {
    font-size: 13px;
    line-height: 20px;
    /* Keep the wordmark anchored while Hermes rotates one- and two-line copy. */
    min-block-size: 2lh;
  }

  ${chat2} [data-slot="aui_user-bubble-actions"] {
    inline-size: fit-content;
    min-inline-size: min(92px, 100%);
    max-inline-size: 70%;
    margin-inline-start: auto;
  }

  ${chat2} [data-slot="aui_user-bubble-actions"] .composer-human-message {
    border-color: transparent;
    border-radius: 15px;
    padding-block: 9px;
  }

  ${docked} [data-slot="composer-root"] {
    --composer-fill: var(--hcv-composer);
    border-radius: 22px;
  }

  ${composerSurface} button > ${chevron},
  ${composerSurface} [data-slot="fan-menu-anchor"] > .codicon-chevron-up {
    display: none;
  }

  ${composerSurface} button:has(> ${chevron}) {
    border-radius: 8px;
  }

  ${composerSurface} button:has(> ${chevron}):not(:disabled):hover {
    background-color: var(--hcv-selected);
  }

  ${composerSurface} button[type="submit"] {
    border-radius: 50%;
  }

  ${composerSurface} button[type="submit"]:not(:disabled) {
    background-color: var(--hcv-action);
    color: var(--hcv-ink);
  }

  ${composerSurface} button[type="submit"]:not(:disabled):hover {
    background-color: color-mix(in srgb, var(--hcv-action) 85%, var(--hcv-ink));
  }

  ${iconRules()}
}
`;
var plugin_default = {
  id,
  name: "Hermes Codex Visual",
  description: "An independent Codex-style workspace theme for Hermes Desktop.",
  defaultEnabled: false,
  register(ctx) {
    ctx.register({ id: "theme", area: THEMES_AREA, data: theme });
    const root = document.documentElement;
    registerStyleScope(ctx, themeName);
    const sheet = document.createElement("style");
    sheet.setAttribute(marker3, "");
    sheet.textContent = styles6;
    ctx.onDispose(() => {
      sheet.remove();
      if (!document.head.querySelector(`style[${marker3}]`)) {
        root.removeAttribute(marker3);
      }
    });
    mountStyle(ctx, sheet);
    mountCSS(ctx, "data-hcv-turn-styles", `
@media (forced-colors: none) {
  ${elapsedBar} {
    align-self: flex-start;
    max-inline-size: 100%;
    display: inline-flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 4px;
    padding: 0;
    border: 0;
    border-radius: 4px;
    background: transparent;
    color: light-dark(rgb(26 28 31 / .495), rgb(255 255 255 / .498));
    font: 430 var(--conversation-text-font-size)/1.5 ${codexReference.font};
    text-align: start;
  }
  ${chat2} [data-slot="aui_response-group"][data-hcv-turn-summary] {
    /* Codex mRLe inserts a 16px conversation spacer after the disclosure. */
    row-gap: 16px;
  }
  ${chat2} [data-hcv-turn-folded] [data-slot="aui_assistant-message-content"]
    > .aui-md:nth-child(1 of :is([data-slot="tool-block"], [data-slot="aui_thinking-disclosure"], [data-slot="aui_turn-activity"], .aui-md):not([data-hcv-turn-step])) {
    margin-block-start: 0;
  }
  ${chat2} button[data-hcv-turn-line] { cursor: pointer; }
  ${chat2} button[data-hcv-turn-line]:hover { color: var(--hcv-chat-prose, var(--hcv-text)); }
  ${chat2} button[data-hcv-turn-line]:focus-visible {
    outline: 1px solid var(--hcv-focus);
    outline-offset: 2px;
  }
  ${chat2} [data-hcv-turn-folded] [data-hcv-turn-step],
  ${chat2} [data-hcv-turn-summary] [data-slot="aui_turn-duration"] { display: none !important; }
  ${chat2} button[data-hcv-turn-line]::after {
    content: '';
    inline-size: 14px;
    block-size: 14px;
    flex: none;
    background: currentColor;
    mask: ${arrow} center / contain no-repeat;
  }
  @media (prefers-reduced-motion: no-preference) {
    ${chat2} button[data-hcv-turn-line]::after { transition: transform 150ms ease; }
  }
  ${chat2} button[data-hcv-turn-line][aria-expanded="true"]::after {
    transform: rotate(90deg);
  }

  ${liveTurn} {
    display: flex;
    align-items: center;
    gap: 6px;
    min-block-size: 18px;
    margin-block-start: 9px;
    color: var(--hcv-muted);
    font-variant-numeric: tabular-nums;
  }
  ${liveTurn} > .dither { display: none; }
  ${thinkingLabel} {
    position: relative;
    display: inline-block;
    flex: none;
    overflow: hidden;
    white-space: nowrap;
    user-select: none;
    font-size: var(--conversation-text-font-size);
    line-height: calc(var(--conversation-text-font-size) + 8px);
    color: color-mix(in srgb, var(--hcv-text) 38.5%, transparent);
  }
  ${thinkingSweep} {
    position: absolute; inset: 0 auto 0 0; inline-size: 100%; overflow: hidden; pointer-events: none;
    transform: translateX(-50%);
    mask-image: linear-gradient(90deg, transparent 0%, black 20% 30%, transparent 50% 100%);
  }
  ${thinkingSweep}::before {
    content: attr(data-hcv-thinking-sweep);
    display: block; inline-size: 100%; overflow: hidden;
    color: #ffffffbf;
    transform: translateX(50%);
  }
  /* Codex's first sweep waits 600 ms, then runs for one second every four. */
  @media (prefers-reduced-motion: no-preference) {
    ${thinkingSweep} { animation: hcv-thinking-sweep 4s .6s infinite; }
    ${thinkingSweep}::before { animation: hcv-thinking-highlight 4s .6s infinite; }
  }
  @keyframes hcv-thinking-sweep {
    0% { transform: translateX(-50%); animation-timing-function: steps(48, end); }
    25%, 100% { transform: translateX(125%); }
  }
  @keyframes hcv-thinking-highlight {
    0% { transform: translateX(50%); animation-timing-function: steps(48, end); }
    25%, 100% { transform: translateX(-125%); }
  }
  ${liveTurn} > :is([data-hcv-live-time], [aria-hidden="true"]:not(.dither, [data-hcv-thinking])) {
    color: color-mix(in srgb, var(--hcv-text) 38.5%, transparent);
    font-size: var(--conversation-text-font-size);
    line-height: calc(var(--conversation-text-font-size) + 8px);
    letter-spacing: inherit;
  }
  @media (prefers-reduced-motion: reduce) {
    ${chat2} button[data-hcv-turn-line]::after { transition: none; }
  }

  /* Codex Desktop 26.1111.2228.0, completed TurnDiffContent (ev)
     and the resource card header (fLcv). */
  ${fileSummary} {
    --hcv-file-padding: 12px;
    --hcv-file-radius: 10px;
    --hcv-file-stroke: light-dark(rgb(26 28 31 / 11.7%), rgb(255 255 255 / 15.6%));
    --hcv-file-border: light-dark(rgb(26 28 31 / 7.8%), rgb(255 255 255 / 8.4%));
    --hcv-file-hover: light-dark(rgb(26 28 31 / 5.35%), rgb(255 255 255 / 7.8%));
    --hcv-file-text: light-dark(#1a1c1f, #dfdfdf);
    --hcv-file-description: color-mix(in srgb, var(--hcv-file-text) 70%, transparent);
    --hcv-file-focus: #0285ff;
    border: 0;
    border-radius: var(--hcv-file-radius);
    box-shadow: 0 0 0 .5px var(--hcv-file-stroke);
    background: light-dark(#fff, #222222);
    margin: 14px .5px 8px;
    padding: 0;
    color: var(--hcv-file-text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    font-size: 14px;
    font-weight: 430;
    line-height: 1.5;
  }
  ${fileHeader} {
    position: relative;
    min-inline-size: 0;
    display: flex;
    align-items: center;
    column-gap: 10px;
    padding: 12px var(--hcv-file-padding);
  }
  ${fileHeader}::before,
  ${fileHeader}::after {
    content: '';
    pointer-events: none;
  }
  ${fileHeader}::before {
    flex: none;
    position: relative;
    z-index: 1;
    inline-size: 40px;
    block-size: 40px;
    border-radius: var(--hcv-file-radius);
    background: light-dark(#f7f7f7, #151515);
  }
  ${fileHeader}::after {
    position: absolute;
    z-index: 1;
    inset-inline-start: calc(var(--hcv-file-padding) + 8px);
    inset-block-start: calc(50% - 12px);
    inline-size: 24px;
    block-size: 24px;
    background: color-mix(in srgb, var(--hcv-file-text) 65%, transparent);
    mask: ${codexMask("turnDiff")} center / contain no-repeat;
  }
  ${fileSummary} button {
    cursor: pointer;
  }
  ${fileSummary} button:focus-visible {
    box-shadow: inset 0 0 0 2px var(--hcv-file-focus);
    outline: none;
  }
  ${fileHeader} > [data-hcv-files-open] {
    position: absolute;
    inset: 0;
    border-radius: var(--hcv-file-radius);
    background: transparent;
  }
  ${fileHeader}:hover > [data-hcv-files-open] {
    background: color-mix(in oklab, var(--hcv-file-hover) 30%, transparent);
  }
  ${fileSummary} [data-hcv-file-native-title] { display: none; }
  ${fileSummary} [data-hcv-files-heading] {
    position: relative;
    z-index: 1;
    display: flex;
    flex-direction: column;
    flex: 1;
    min-inline-size: 0;
    pointer-events: none;
  }
  ${fileSummary} :is([data-hcv-files-title], [data-hcv-files-subtitle], [data-hcv-files-more-label], [data-hcv-file-directory], [data-hcv-file-basename]) {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  ${fileSummary} [data-hcv-files-title] { font-weight: 500; }
  ${fileSummary} [data-hcv-files-subtitle] {
    color: var(--hcv-file-description);
    font-size: 13px;
  }
  ${fileSummary} [data-hcv-files-hover] {
    display: none;
    align-items: center;
    gap: 4px;
  }
  ${fileHeader}:is(:hover, :focus-within) [data-hcv-files-hover] { display: inline-flex; }
  ${fileHeader}:is(:hover, :focus-within) [data-hcv-files-totals] { display: none; }
  ${fileSummary} [data-hcv-files-totals] {
    display: inline-flex;
    flex: none;
    align-items: center;
    gap: 4px;
    line-height: 1;
    letter-spacing: -.025em;
    font-variant-numeric: tabular-nums;
    font-feature-settings: "cv01" on, "cv02" on;
  }
  ${fileSummary} [data-hcv-files-added] { color: light-dark(#00a240, #40c977); }
  ${fileSummary} [data-hcv-files-removed] { color: light-dark(#ba2623, #fa423e); }
  ${fileHeader} > :is([data-hcv-file-review], [data-hcv-files-checkpoint]) {
    position: relative;
    z-index: 1;
    display: inline-flex;
    flex: none;
    align-items: center;
    gap: 6px;
    block-size: 28px;
    border-radius: var(--hcv-file-radius);
    padding-inline: 8px;
    color: inherit;
    font-size: 13px;
    font-weight: 430;
    line-height: 18px;
    white-space: nowrap;
  }
  ${fileHeader} > [data-hcv-file-review] {
    gap: 0;
    border: 1px solid var(--hcv-file-border);
    background: light-dark(#fff, #292929);
    font-size: 0;
  }
  ${fileHeader} > [data-hcv-files-checkpoint] + [data-hcv-file-review] { margin-inline-start: -2px; }
  ${fileHeader} > [data-hcv-file-review]::after { content: attr(data-hcv-file-review); font-size: 13px; }
  ${fileHeader} > :is([data-hcv-file-review], [data-hcv-files-checkpoint]):hover {
    background-color: var(--hcv-file-hover);
  }
  ${fileHeader} > :is([data-hcv-file-review], [data-hcv-files-checkpoint]):focus-visible {
    box-shadow: 0 0 0 2px var(--hcv-file-focus);
  }
  ${fileHeader} > [data-hcv-files-checkpoint]:not(:hover) { background: transparent; }
  ${fileSummary} :is([data-hcv-files-checkpoint], [data-hcv-files-hover], [data-hcv-files-more])::after {
    content: '';
    flex: none;
    inline-size: 14px;
    block-size: 14px;
    background: currentColor;
    mask: var(--hcv-file-icon) center / contain no-repeat;
  }
  ${fileSummary} [data-hcv-files-checkpoint] { --hcv-file-icon: ${codexMask("turnDiffUndo")}; }
  ${fileSummary} [data-hcv-files-hover] { --hcv-file-icon: ${codexMask("turnDiffOpen")}; }
  ${fileSummary} [data-hcv-files-more] { --hcv-file-icon: ${codexMask("turnDiffDown")}; }
  ${fileSummary} [data-hcv-files-more][aria-expanded="true"]::after { transform: rotate(180deg); }
  ${fileList} {
    max-height: none !important;
    overflow: visible;
    mask: none;
    animation: none;
    margin: 0;
    padding: 0;
    border-block-start: 1px solid var(--hcv-file-border);
  }
  ${fileSummary}[data-hcv-file-single] > div:nth-child(2),
  ${fileSummary}[data-hcv-files-foldable]:not([data-hcv-files-open]) > div:nth-child(2) > button:nth-of-type(n + 4) {
    display: none;
  }
  ${fileRow} > :not([data-hcv-generated]) { display: none; }
  ${fileSummary} [data-hcv-file-accessible-path] {
    position: absolute;
    inline-size: 1px;
    block-size: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
  ${fileSummary} [data-hcv-file-path] {
    display: flex;
    align-items: center;
    flex: 1;
    min-inline-size: 0;
  }
  ${fileSummary} [data-hcv-file-directory] { min-inline-size: 0; color: var(--hcv-file-description); }
  ${fileSummary} [data-hcv-file-basename] { max-inline-size: 100%; flex-shrink: 0; }
  ${fileRow},
  ${fileSummary} [data-hcv-files-more] {
    display: flex;
    inline-size: 100%;
    block-size: 36px;
    flex: none;
    align-items: center;
    gap: 8px;
    border-radius: 0;
    padding: 4px var(--hcv-file-padding);
    color: inherit;
    text-align: start;
  }
  ${fileRow} { background: light-dark(#fff, #1c1c1c); }
  ${fileRow}:hover { background: color-mix(in oklab, var(--hcv-file-hover) 60%, transparent); }
  ${fileSummary}:not([data-hcv-files-foldable]) > div:nth-child(2) > button:last-of-type,
  ${fileSummary} [data-hcv-files-more] {
    border-end-start-radius: var(--hcv-file-radius);
    border-end-end-radius: var(--hcv-file-radius);
  }
  ${fileSummary} [data-hcv-files-more]:hover {
    background: color-mix(in oklab, var(--hcv-file-hover) 30%, transparent);
  }
  @supports (corner-shape: superellipse(1.5)) {
    ${fileSummary} { --hcv-file-radius: 12.5px; }
    ${fileSummary},
    ${fileHeader}::before,
    ${fileSummary} button { corner-shape: superellipse(1.5); }
  }
  ${assistantRoot}:has(> [data-hcv-file-card]) > :has([data-slot="aui_msg-actions"]) { order: 1; }
  ${assistantRoot}:has(> [data-hcv-file-card]) [data-slot="aui_msg-actions"] { margin-inline-end: auto; }

}
`, { surface: '[data-hcv-turn-line], [data-slot="aui_turn-duration"], [data-slot="aui_response-loading"], [data-slot="aui_turn-activity"], [data-slot="aui_changed-files"]', retainAcrossChatTabs: true });
    root.setAttribute(marker3, "");
    registerWorkspaceChrome(ctx, themeName);
    const roster = registerSubagents(ctx, active);
    const localEnvironment = registerLocalEnvironment(ctx, active);
    registerWorkspaceCard(ctx, themeName, roster, localEnvironment);
    registerTurnExperience(ctx, active);
    registerChatDisplay(ctx, active);
    registerChatResources(ctx, active);
    registerChatFileLinks(ctx, active, previewResourceCard);
    registerChatActivity(ctx, active);
    registerChatTables(ctx, active);
    registerReviewProposals(ctx, active);
    registerInterface(ctx, active);
    registerDesktopPages(ctx, active);
    registerDesktopCorners(ctx, active);
    registerSettingsStyle(ctx, active);
    registerSettingsProviders(ctx, active);
    registerSettingsSpecial(ctx, active);
    registerAppUpdatesStyle(ctx, active);
    registerInstallOverlayStyle(ctx, active);
    registerRemainingSurfaces(ctx, active);
    registerShellSurfaces(ctx, active);
    registerSessionTabs(ctx, active);
    registerContextMeter(ctx, active);
    registerComposer(ctx, active);
    registerDraftSetup(ctx, active, localEnvironment);
    registerDictation(ctx, active);
    registerZoomBanner(ctx, active, themeName);
    if (null) {
      void ctx.files.writeText(ctx.files.dataFolder, "loaded-version.json", JSON.stringify({
        version: null,
        theme: root.dataset.hermesTheme,
        loadedAt: (/* @__PURE__ */ new Date()).toISOString()
      }) + "\n");
    }
  }
};
export {
  plugin_default as default
};
